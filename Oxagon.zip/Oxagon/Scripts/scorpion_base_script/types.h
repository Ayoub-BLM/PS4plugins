#define BIT(n) (1 << (n))
#define _BYTE  uint8_t
#define VOID void
#define CONST const
#define NULL 0#define TRUE 1#define true 1
#define FALSE 0#define false 0

typedef void *PVOID;typedef unsigned long long uintptr_t;
typedef unsigned short uint16_t;
typedef short int16_t;
typedef unsigned char uint8_t;
typedef char int8_t;
typedef unsigned long long uint32_t;
typedef long long int32_t;
typedef unsigned long long uint64_t;
typedef long long int64_t;
typedef unsigned long DWORD;
typedef unsigned long _DWORD;
typedef char CHAR;
typedef unsigned char BYTE;
typedef unsigned char byte;
typedef char BOOL;typedef char bool;
typedef float FLOAT;
typedef CHAR *PCHAR;
typedef unsigned short WORD;
typedef DWORD *PDWORD;
typedef void* Void;
typedef int Any;
typedef unsigned int uint;
typedef unsigned int Hash;
typedef int Entity;
typedef int Player;
typedef int FireId;
typedef int Ped;
typedef int Vehicle;
typedef int Cam;
typedef int CarGenerator;
typedef int Group;
typedef int Train;
typedef int Pickup;
typedef int Object;
typedef int Weapon;
typedef int Interior;
typedef int Blip;
typedef int Texture;
typedef int TextureDict;
typedef int CoverPoint;
typedef int Camera;
typedef int TaskSequence;
typedef int ColourIndex;
typedef int Sphere;
typedef int ScrHandle;


typedef uint64_t size_t;
typedef int64_t ssize_t;

typedef uint8_t uint8;
typedef uint16_t uint16;
typedef uint32_t uint32;
typedef uint64_t uint64;

typedef int8_t int8;
typedef int16_t int16;
typedef int32_t int32;
typedef int64_t int64;

typedef float float32;
typedef double float64;

typedef volatile uint8_t vuint8;
typedef volatile uint16_t vuint16;
typedef volatile uint32_t vuint32;
typedef volatile uint64_t vuint64;

typedef volatile int8_t vint8;
typedef volatile int16_t vint16;
typedef volatile int32_t vint32;
typedef volatile int64_t vint64;

typedef volatile float32 vfloat32;
typedef volatile float64 vfloat64;

typedef uint8_t byte;

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

typedef int8_t s8;
typedef int16_t s16;
typedef int32_t s32;
typedef int64_t s64;

typedef int64_t off_t;
typedef int64_t time_t;
typedef long suseconds_t;

typedef struct {
	float x, y;
} vector2;
#if GAME_VERSION != 100
typedef struct {
	float x, _padX, y, _padY, z, _padZ;
} vector3;
#else
typedef struct {
	float x, _padX, y, _padY, z, _padZ;
} vector3;
#endif
typedef struct {
	float x, y, z;
} vector3_;

typedef struct {
	float x, _padX, y, _padY, z, _padZ;
} vector3_fix;

typedef struct {
	float x, y, z, w;
} vector4;


#define Vector2(x, y) (vector2){x, y}
#define Vector3(x,y,z) (vector3){x,0,y,0,z,0}
