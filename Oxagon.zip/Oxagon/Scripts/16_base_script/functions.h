void SPRITE(char* TextOne, char* TextTwo, float X, float Y, float Width, float Height, float Rotation, int R, int G, int B, int A)
{
	if (!HAS_STREAMED_TEXTURE_DICT_LOADED(TextOne))
	REQUEST_STREAMED_TEXTURE_DICT(TextOne, false);
    else{
		DRAW_SPRITE(TextOne, TextTwo, X, Y, Width, Height, Rotation, R, G, B, A, 0, 0);
	}
}
void playSound(char* sound)
{
	if (EnableSounds)
		PLAY_SOUND_FRONTEND(-1, sound, "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
}
void TeleportToPlayer(int ped)
{
	if(IS_PED_IN_ANY_VEHICLE(ped, 0))
			{
				if(IS_PED_IN_ANY_VEHICLE(PLAYER_PED_ID(), 0))
				{
					vector3 coord = GET_ENTITY_COORDS(ped, false);
					SET_ENTITY_COORDS(GET_VEHICLE_PED_IS_USING(PLAYER_PED_ID()), coord.x, coord.y, coord.z, 1, 0, 0, 1);
				}
				else
				{
					SET_PED_INTO_VEHICLE(PLAYER_PED_ID(), GET_VEHICLE_PED_IS_USING(ped), -2);
				}
			}
			else
			{
				if(IS_PED_IN_ANY_VEHICLE(PLAYER_PED_ID(), 0))
				{
					vector3 coord = GET_ENTITY_COORDS(ped, false);
					SET_ENTITY_COORDS(GET_VEHICLE_PED_IS_USING(PLAYER_PED_ID()), coord.x, coord.y, coord.z, 1, 0, 0, 1);
				}
				else
				{
					vector3 coord = GET_ENTITY_COORDS(ped, false);
					SET_ENTITY_COORDS(PLAYER_PED_ID(), coord.x, coord.y, coord.z, 1, 0, 0, 1);
				}
			}
}

void RemoveMyCar(int car) {
	for (int i = 0; i < 50; i++) {
		NETWORK_REQUEST_CONTROL_OF_ENTITY(car);
		SET_ENTITY_AS_MISSION_ENTITY(car, 0, 1);
		DELETE_ENTITY(&car);
	}
}