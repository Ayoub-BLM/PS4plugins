import re

crossmap_file = "crossmap.txt"
header_file = "natives.h"
output_file = "natives_new.h"

# -------------------------
# ????? crossmap
# -------------------------
crossmap = {}

with open(crossmap_file, "r", encoding="utf-8") as f:
    for line in f:
        m = re.search(r'(0x[0-9A-Fa-f]+)\s*,\s*(0x[0-9A-Fa-f]+)', line)
        if m:
            native_hash = m.group(1).upper()
            cross_hash = m.group(2).upper()
            crossmap[native_hash] = cross_hash

print(f"Loaded {len(crossmap)} entries.")

# -------------------------
# ????? header
# -------------------------
with open(header_file, "r", encoding="utf-8") as f:
    text = f.read()

# ?????? invoke(...) ???? Native Hash ??????? ??? //
pattern = re.compile(
    r'invoke\s*\(\s*(0x[0-9A-Fa-f]+)(.*?)\)\s*;\s*}\s*//\s*(0x[0-9A-Fa-f]+)',
    re.MULTILINE
)

count = 0

def replace(match):
    global count

    old_address = match.group(1)
    rest = match.group(2)
    native_hash = match.group(3).upper()

    if native_hash in crossmap:
        count += 1
        return f'invoke({crossmap[native_hash]}{rest}); }} // {native_hash}'

    return match.group(0)

text = pattern.sub(replace, text)

with open(output_file, "w", encoding="utf-8") as f:
    f.write(text)

print(f"Replaced {count} natives.")