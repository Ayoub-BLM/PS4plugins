-- compat_ENTITY.lua — AUTO GENERATO


-- ENTITY


ENTITY=ENTITY or {}


-- PC:0x7239B21A38F536BA Old:0x3AC90869


function ENTITY.DOES_ENTITY_EXIST(entity)


  return Velora.invoke(0x9B2A20,"bool", entity)


end


-- PC:0xDDE6DF5AE89981D2 Old:0xACFEB3F9


function ENTITY.DOES_ENTITY_BELONG_TO_THIS_SCRIPT(entity, p1)


  return Velora.invoke(0x9B22F0,"bool", entity, p1)


end


-- PC:0x060D6E96F8B8E48D Old:0xA5B33300


function ENTITY.DOES_ENTITY_HAVE_DRAWABLE(entity)


  return Velora.invoke(0x9B2370,"bool", entity)


end


-- PC:0xDA95EA3317CC5064 Old:0x9BCD2979


function ENTITY.DOES_ENTITY_HAVE_PHYSICS(entity)


  return Velora.invoke(0x9B23D0,"bool", entity)


end


function ENTITY.DOES_ENTITY_HAVE_SKELETON(entity)


  return Velora.invoke(0x9B2430,"bool", entity)


end


function ENTITY.DOES_ENTITY_HAVE_ANIM_DIRECTOR(entity)


  return Velora.invoke(0x9B24C0,"bool", entity)


end


-- PC:0x20B711662962B472 Old:0x1D9CAB92


function ENTITY.HAS_ENTITY_ANIM_FINISHED(entity, animDict, animName, p3)


  return Velora.invoke(0x9B2520,"bool", entity, animDict, animName, p3)


end


-- PC:0x95EB9964FF5C5C65 Old:0x6B74582E


function ENTITY.HAS_ENTITY_BEEN_DAMAGED_BY_ANY_OBJECT(entity)


  return Velora.invoke(0x9B2550,"bool", entity)


end


-- PC:0x605F5A140F202491 Old:0x53FD4A25


function ENTITY.HAS_ENTITY_BEEN_DAMAGED_BY_ANY_PED(entity)


  return Velora.invoke(0x9B25B0,"bool", entity)


end


-- PC:0xDFD5033FDBA0A9C8 Old:0x878C2CE0


function ENTITY.HAS_ENTITY_BEEN_DAMAGED_BY_ANY_VEHICLE(entity)


  return Velora.invoke(0x9B2610,"bool", entity)


end


-- PC:0xC86D67D52A707CF8 Old:0x07FC77E0


function ENTITY.HAS_ENTITY_BEEN_DAMAGED_BY_ENTITY(entity1, entity2, p2)


  return Velora.invoke(0x9B2670,"bool", entity1, entity2, p2)


end


-- PC:0xFCDFF7B72D23A1AC Old:0x53576FA7


function ENTITY.HAS_ENTITY_CLEAR_LOS_TO_ENTITY(entity1, entity2, traceType)


  return Velora.invoke(0x9B26A0,"bool", entity1, entity2, traceType)


end


function ENTITY.HAS_ENTITY_CLEAR_LOS_TO_ENTITY_ADJUST_FOR_COVER(entity1, entity2, traceType)


  return Velora.invoke(0x9B26D0,"bool", entity1, entity2, traceType)


end


-- PC:0x0267D00AF114F17A Old:0x210D87C8


function ENTITY.HAS_ENTITY_CLEAR_LOS_TO_ENTITY_IN_FRONT(entity1, entity2)


  return Velora.invoke(0x9B2700,"bool", entity1, entity2)


end


-- PC:0x8BAD02F0368D9E14 Old:0x662A2F41


function ENTITY.HAS_ENTITY_COLLIDED_WITH_ANYTHING(entity)


  return Velora.invoke(0x9B2730,"bool", entity)


end


-- PC:0x5C3D0A935F535C4C Old:0xC0E3AA47


function ENTITY.GET_LAST_MATERIAL_HIT_BY_ENTITY(entity)


  return Velora.invoke(0x9B2840,"int", entity)


end


-- PC:0xE465D4AB7CA6AE72 Old:0xAB415C07


function ENTITY.GET_COLLISION_NORMAL_OF_LAST_HIT_FOR_ENTITY(entity)


  local x,y,z=Velora.invoke(0x9B2920,"vector3", entity)


  return {x=x,y=y,z=z}


end


-- PC:0x40FDEDB72F8293B2 Old:0x58D9775F


function ENTITY.FORCE_ENTITY_AI_AND_ANIMATION_UPDATE(entity)


  Velora.invoke(0x9B2A20,"void", entity)


end


-- PC:0x346D81500D088F42 Old:0x83943F41


function ENTITY.GET_ENTITY_ANIM_CURRENT_TIME(entity, animDict, animName)


  return Velora.invoke(0x9B30B0,"float", entity, animDict, animName)


end


-- PC:0x50BD2730B191E360 Old:0x433A9D18


function ENTITY.GET_ENTITY_ANIM_TOTAL_TIME(entity, animDict, animName)


  return Velora.invoke(0x9B2AC0,"float", entity, animDict, animName)


end


-- PC:0xFEDDF04D62B8D790 Old:0x8B5E3E3D


function ENTITY.GET_ANIM_DURATION(animDict, animName)


  return Velora.invoke(0x9B2AF0,"float", animDict, animName)


end


-- PC:0x48C2BED9180FE123 Old:0xFE1589F9


function ENTITY.GET_ENTITY_ATTACHED_TO(entity)


  return Velora.invoke(0x9B2B30,"int", entity)


end


-- PC:0x3FEF770D40960D5A Old:0x1647F1CB


function ENTITY.GET_ENTITY_COORDS(entity, alive)


  local x,y,z=Velora.invoke(0x9B2BC0,"vector3", entity, alive)


  return {x=x,y=y,z=z}


end


-- PC:0x0A794A5A57F8DF91 Old:0x84DCECBF


function ENTITY.GET_ENTITY_FORWARD_VECTOR(entity)


  local x,y,z=Velora.invoke(0x9B2C70,"vector3", entity)


  return {x=x,y=y,z=z}


end


-- PC:0x8BB4EF4214E0E6D5 Old:0x49FAE914


function ENTITY.GET_ENTITY_FORWARD_X(entity)


  return Velora.invoke(0x9B2D10,"float", entity)


end


-- PC:0x866A4A5FAE349510 Old:0x9E2F917C


function ENTITY.GET_ENTITY_FORWARD_Y(entity)


  return Velora.invoke(0x9B2D80,"float", entity)


end


-- PC:0xE83D4F9BA2A38914 Old:0x972CC383


function ENTITY.GET_ENTITY_HEADING(entity)


  return Velora.invoke(0x9B2DF0,"float", entity)


end


-- PC:0x846BF6291198A71E Old:0x9320E642


function ENTITY.GET_ENTITY_HEADING_FROM_EULERS(entity)


  return Velora.invoke(0x9B2EA0,"float", entity)


end


-- PC:0xEEF059FAD016D209 Old:0x8E3222B7


function ENTITY.GET_ENTITY_HEALTH(entity)


  return Velora.invoke(0x9B3010,"int", entity)


end


-- PC:0x15D757606D170C3C Old:0xC7AE6AA1


function ENTITY.GET_ENTITY_MAX_HEALTH(entity)


  return Velora.invoke(0x9B3060,"int", entity)


end


-- PC:0x166E7CF68597D8B5 Old:0x96F84DF8


function ENTITY.SET_ENTITY_MAX_HEALTH(entity, value)


  Velora.invoke(0x9B30B0,"void", entity, value)


end


-- PC:0x5A504562485944DD Old:0xEE443481


function ENTITY.GET_ENTITY_HEIGHT(entity, X, Y, Z, atTop, inWorldCoords)


  return Velora.invoke(0x9B31E0,"float", entity, X, Y, Z, atTop, inWorldCoords)


end


-- PC:0x1DD55701034110E5 Old:0x57F56A4D


function ENTITY.GET_ENTITY_HEIGHT_ABOVE_GROUND(entity)


  return Velora.invoke(0x9B3160,"float", entity)


end


-- PC:0xECB2FC7235A7D137 Old:0xEB9EB001


function ENTITY.GET_ENTITY_MATRIX(entity)


  Velora.invoke(0x9B31E0,"void", entity)


end


-- PC:0x9F47B058362C84B5 Old:0xDAFCB3EC


function ENTITY.GET_ENTITY_MODEL(entity)


  return Velora.invoke(0x9B3560,"int", entity)


end


-- PC:0x2274BC1C4885E333 Old:0x6477EC9E


function ENTITY.GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS(entity, posX, posY, posZ)


  local x,y,z=Velora.invoke(0x9B3350,"vector3", entity, posX, posY, posZ)


  return {x=x,y=y,z=z}


end


-- PC:0x1899F328B0E12848 Old:0xABCF043A


function ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(entity, offsetX, offsetY, offsetZ)


  local x,y,z=Velora.invoke(0x9B3470,"vector3", entity, offsetX, offsetY, offsetZ)


  return {x=x,y=y,z=z}


end


-- PC:0xD45DC2893621E1FE Old:0xFCE6ECE5


function ENTITY.GET_ENTITY_PITCH(entity)


  return Velora.invoke(0x9B3530,"float", entity)


end


-- PC:0x7B3703D2D32DFA18 Old:0x5154EC90


function ENTITY.GET_ENTITY_QUATERNION(entity)


  Velora.invoke(0x9B3560,"void", entity)


end


-- PC:0x831E0242595560DF Old:0x36610842


function ENTITY.GET_ENTITY_ROLL(entity)


  return Velora.invoke(0x9B46A0,"float", entity)


end


-- PC:0xAFBD61CC738D9EB9 Old:0x8FF45B04


function ENTITY.GET_ENTITY_ROTATION(entity, rotationOrder)


  local x,y,z=Velora.invoke(0x9B36D0,"vector3", entity, rotationOrder)


  return {x=x,y=y,z=z}


end


-- PC:0x213B91045D09B983 Old:0x9BF8A73F


function ENTITY.GET_ENTITY_ROTATION_VELOCITY(entity)


  local x,y,z=Velora.invoke(0x9B3840,"vector3", entity)


  return {x=x,y=y,z=z}


end


-- PC:0xD5037BA82E12416F Old:0x9E1E4798


function ENTITY.GET_ENTITY_SPEED(entity)


  return Velora.invoke(0x9B3980,"float", entity)


end


-- PC:0x9A8D700A51CB7B0D Old:0x3ED2B997


function ENTITY.GET_ENTITY_SPEED_VECTOR(entity, relative)


  local x,y,z=Velora.invoke(0x9B3A30,"vector3", entity, relative)


  return {x=x,y=y,z=z}


end


-- PC:0x95EED5A694951F9F Old:0xF4268190


function ENTITY.GET_ENTITY_UPRIGHT_VALUE(entity)


  return Velora.invoke(0x9B3B70,"float", entity)


end


-- PC:0x4805D2B1D8CF94A9 Old:0xC14C9B6B


function ENTITY.GET_ENTITY_VELOCITY(entity)


  local x,y,z=Velora.invoke(0x9B3BC0,"vector3", entity)


  return {x=x,y=y,z=z}


end


-- PC:0xD7E3B9735C0F89D6 Old:0xBC5A9C58


function ENTITY.GET_OBJECT_INDEX_FROM_ENTITY_INDEX(entity)


  return Velora.invoke(0x9B3C90,"int", entity)


end


-- PC:0x04A2A40C73395041 Old:0xC46F74AC


function ENTITY.GET_PED_INDEX_FROM_ENTITY_INDEX(entity)


  return Velora.invoke(0x9B3CA0,"int", entity)


end


-- PC:0x4B53F92932ADFAC0 Old:0xC69CF43D


function ENTITY.GET_VEHICLE_INDEX_FROM_ENTITY_INDEX(entity)


  return Velora.invoke(0x9B3CB0,"int", entity)


end


-- PC:0x44A8FCB8ED227738 Old:0x7C6339DF


function ENTITY.GET_WORLD_POSITION_OF_ENTITY_BONE(entity, boneIndex)


  local x,y,z=Velora.invoke(0x9B3CC0,"vector3", entity, boneIndex)


  return {x=x,y=y,z=z}


end


-- PC:0x7196842CB375CDB3 Old:0xCE17FDEC


function ENTITY.GET_NEAREST_PLAYER_TO_ENTITY(entity)


  return Velora.invoke(0x9B3D30,"int", entity)


end


-- PC:0x4DC9A62F844D9337 Old:0xB1808F56


function ENTITY.GET_NEAREST_PLAYER_TO_ENTITY_ON_TEAM(entity, team)


  return Velora.invoke(0x9B3D70,"int", entity, team)


end


-- PC:0x8ACD366038D14505 Old:0x0B1BD08D


function ENTITY.GET_ENTITY_TYPE(entity)


  return Velora.invoke(0x9B3DD0,"int", entity)


end


-- PC:0xF6F5161F4534EDFF Old:0xFC30DDFF


function ENTITY.GET_ENTITY_POPULATION_TYPE(entity)


  return Velora.invoke(0x9B3E40,"int", entity)


end


-- PC:0x731EC8A916BD11A1 Old:0xD4B9715A


function ENTITY.IS_AN_ENTITY(handle)


  return Velora.invoke(0x9B3EB0,"bool", handle)


end


-- PC:0x524AC5ECEA15343E Old:0x55D33EAB


function ENTITY.IS_ENTITY_A_PED(entity)


  return Velora.invoke(0x9B3EF0,"bool", entity)


end


-- PC:0x0A7B270912999B3C Old:0x2632E124


function ENTITY.IS_ENTITY_A_MISSION_ENTITY(entity)


  return Velora.invoke(0x9B3F50,"bool", entity)


end


-- PC:0x6AC7003FA6E5575E Old:0xBE800B01


function ENTITY.IS_ENTITY_A_VEHICLE(entity)


  return Velora.invoke(0x9B3FB0,"bool", entity)


end


-- PC:0x8D68C8FD0FACA94E Old:0x3F52E561


function ENTITY.IS_ENTITY_AN_OBJECT(entity)


  return Velora.invoke(0x9B4010,"bool", entity)


end


-- PC:0x20B60995556D004F Old:0xD749B606


function ENTITY.IS_ENTITY_AT_COORD(entity, xPos, yPos, zPos, xSize, ySize, zSize, p7, p8, p9)


  return Velora.invoke(0x9B4070,"bool", entity, xPos, yPos, zPos, xSize, ySize, zSize, p7, p8, p9)


end


-- PC:0x751B70C3D034E187 Old:0xDABDCB52


function ENTITY.IS_ENTITY_AT_ENTITY(entity1, entity2, xSize, ySize, zSize, p5, p6, p7)


  return Velora.invoke(0x9B40C0,"bool", entity1, entity2, xSize, ySize, zSize, p5, p6, p7)


end


-- PC:0xB346476EF1A64897 Old:0xEC1479D5


function ENTITY.IS_ENTITY_ATTACHED(entity)


  return Velora.invoke(0x9B4110,"bool", entity)


end


-- PC:0xCF511840CEEDE0CC Old:0x0B5DE340


function ENTITY.IS_ENTITY_ATTACHED_TO_ANY_OBJECT(entity)


  return Velora.invoke(0x9B41A0,"bool", entity)


end


-- PC:0xB1632E9A5F988D11 Old:0x9D7A609C


function ENTITY.IS_ENTITY_ATTACHED_TO_ANY_PED(entity)


  return Velora.invoke(0x9B4230,"bool", entity)


end


-- PC:0x26AA915AD89BFB4B Old:0xDE5C995E


function ENTITY.IS_ENTITY_ATTACHED_TO_ANY_VEHICLE(entity)


  return Velora.invoke(0x9B42C0,"bool", entity)


end


-- PC:0xEFBE71898A993728 Old:0xB0ABFEA8


function ENTITY.IS_ENTITY_ATTACHED_TO_ENTITY(from, to)


  return Velora.invoke(0x9B4350,"bool", from, to)


end


-- PC:0x5F9532F3B5CC2551 Old:0xB6F7CBAC


function ENTITY.IS_ENTITY_DEAD(entity, p1)


  return Velora.invoke(0x9B4380,"bool", entity, p1)


end


-- PC:0x886E37EC497200B6 Old:0xA4157987


function ENTITY.IS_ENTITY_IN_AIR(entity)


  return Velora.invoke(0x9B4440,"bool", entity)


end


-- PC:0x51210CED3DA1C78A Old:0x883622FA


function ENTITY.IS_ENTITY_IN_ANGLED_AREA(entity, x1, y1, z1, x2, y2, z2, width, debug, includeZ, p10)


  return Velora.invoke(0x9B4470,"bool", entity, x1, y1, z1, x2, y2, z2, width, debug, includeZ, p10)


end


-- PC:0x54736AA40E271165 Old:0x8C2DFA9D


function ENTITY.IS_ENTITY_IN_AREA(entity, x1, y1, z1, x2, y2, z2, p7, p8, p9)


  return Velora.invoke(0x9B44C0,"bool", entity, x1, y1, z1, x2, y2, z2, p7, p8, p9)


end


-- PC:0xB6463CF6AF527071 Old:0x45C82B21


function ENTITY.IS_ENTITY_IN_ZONE(entity, zone)


  return Velora.invoke(0x9B4510,"bool", entity, zone)


end


-- PC:0xCFB0A0D8EDD145A3 Old:0x4C3C2508


function ENTITY.IS_ENTITY_IN_WATER(entity)


  return Velora.invoke(0x9B4600,"bool", entity)


end


-- PC:0xE81AFC1BC4CC41CE Old:0x0170F68C


function ENTITY.GET_ENTITY_SUBMERGED_LEVEL(entity)


  return Velora.invoke(0x9B4630,"float", entity)


end


-- PC:0x694E00132F2823ED Old:0x40C84A74


function ENTITY.SET_ENTITY_REQUIRES_MORE_EXPENSIVE_RIVER_CHECK(entity, toggle)


  Velora.invoke(0x9B46A0,"void", entity, toggle)


end


-- PC:0xE659E47AF827484B Old:0xC1FEC5ED


function ENTITY.IS_ENTITY_ON_SCREEN(entity)


  return Velora.invoke(0x9B4BA0,"bool", entity)


end


-- PC:0x1F0B79228E461EC9 Old:0x0D130D34


function ENTITY.IS_ENTITY_PLAYING_ANIM(entity, animDict, animName, taskFlag)


  return Velora.invoke(0x9B47A0,"bool", entity, animDict, animName, taskFlag)


end


-- PC:0x1218E6886D3D8327 Old:0x928E12E9


function ENTITY.IS_ENTITY_STATIC(entity)


  return Velora.invoke(0x9B47D0,"bool", entity)


end


-- PC:0x17FFC1B2BA35A494 Old:0x6B931477


function ENTITY.IS_ENTITY_TOUCHING_ENTITY(entity, targetEntity)


  return Velora.invoke(0x9B4830,"bool", entity, targetEntity)


end


-- PC:0x0F42323798A58C8C Old:0x307E7611


function ENTITY.IS_ENTITY_TOUCHING_MODEL(entity, modelHash)


  return Velora.invoke(0x9B4860,"bool", entity, modelHash)


end


-- PC:0x5333F526F6AB19AA Old:0x3BCDF4E1


function ENTITY.IS_ENTITY_UPRIGHT(entity, angle)


  return Velora.invoke(0x9B4890,"bool", entity, angle)


end


-- PC:0x1DBD58820FA61D71 Old:0x5ACAA48F


function ENTITY.IS_ENTITY_UPSIDEDOWN(entity)


  return Velora.invoke(0x9B4920,"bool", entity)


end


-- PC:0x47D6F43D77935C75 Old:0x120B4ED5


function ENTITY.IS_ENTITY_VISIBLE(entity)


  return Velora.invoke(0x9B4980,"bool", entity)


end


-- PC:0xD796CB5BA8F20E32 Old:0x5D240E9D


function ENTITY.IS_ENTITY_VISIBLE_TO_SCRIPT(entity)


  return Velora.invoke(0x9B49E0,"bool", entity)


end


-- PC:0xE31C2C72B8692B64 Old:0x46BC5B40


function ENTITY.IS_ENTITY_OCCLUDED(entity)


  return Velora.invoke(0x9B4A60,"bool", entity)


end


-- PC:0xEE5D2A122E09EC42 Old:0xEA127CBC


function ENTITY.WOULD_ENTITY_BE_OCCLUDED(entityModelHash, x, y, z, p4)


  return Velora.invoke(0x9B4A90,"bool", entityModelHash, x, y, z, p4)


end


-- PC:0xD05BFF0C0A12C68F Old:0x00AB7A4A


function ENTITY.IS_ENTITY_WAITING_FOR_WORLD_COLLISION(entity)


  return Velora.invoke(0x9B4AD0,"bool", entity)


end


-- PC:0x18FF00FC7EFF559E Old:0x28924E98


function ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(entity, forceType, x, y, z, p5, isDirectionRel, isForceRel, p8)


  Velora.invoke(0x9B4BA0,"void", entity, forceType, x, y, z, p5, isDirectionRel, isForceRel, p8)


end


-- PC:0xC5F68BE9613E2D18 Old:0xC1C0855A


function ENTITY.APPLY_FORCE_TO_ENTITY(entity, forceFlags, x, y, z, offX, offY, offZ, boneIndex, isDirectionRel, ignoreUpVec, isForceRel, p12, p13)


  Velora.invoke(0x9B4C40,"void", entity, forceFlags, x, y, z, offX, offY, offZ, boneIndex, isDirectionRel, ignoreUpVec, isForceRel, p12, p13)


end


-- PC:0x6B9BBD38AB0796DF Old:0xEC024237


function ENTITY.ATTACH_ENTITY_TO_ENTITY(entity1, entity2, boneIndex, xPos, yPos, zPos, xRot, yRot, zRot, p9, useSoftPinning, collision, isPed, vertexIndex, fixedRot)


  Velora.invoke(0x9B4CC0,"void", entity1, entity2, boneIndex, xPos, yPos, zPos, xRot, yRot, zRot, p9, useSoftPinning, collision, isPed, vertexIndex, fixedRot)


end


function ENTITY.ATTACH_ENTITY_BONE_TO_ENTITY_BONE(entity1, entity2, boneIndex1, boneIndex2, p4, p5)


  Velora.invoke(0x9B4E60,"void", entity1, entity2, boneIndex1, boneIndex2, p4, p5)


end


function ENTITY.ATTACH_ENTITY_BONE_TO_ENTITY_BONE_Y_FORWARD(entity1, entity2, boneIndex1, boneIndex2, p4, p5)


  Velora.invoke(0x9B4E90,"void", entity1, entity2, boneIndex1, boneIndex2, p4, p5)


end


-- PC:0xC3675780C92F90F9 Old:0x0547417F


function ENTITY.ATTACH_ENTITY_TO_ENTITY_PHYSICALLY(entity1, entity2, boneIndex1, boneIndex2, xPos1, yPos1, zPos1, xPos2, yPos2, zPos2, xRot, yRot, zRot, breakForce, fixedRot, p15, collision, p17, p18)


  Velora.invoke(0x9B4EC0,"void", entity1, entity2, boneIndex1, boneIndex2, xPos1, yPos1, zPos1, xPos2, yPos2, zPos2, xRot, yRot, zRot, breakForce, fixedRot, p15, collision, p17, p18)


end


-- PC:0xF4080490ADC51C6F Old:0x6909BA59


function ENTITY.PROCESS_ENTITY_ATTACHMENTS(entity)


  Velora.invoke(0x9B5020,"void", entity)


end


-- PC:0xFB71170B7E76ACBA Old:0xE4ECAC22


function ENTITY.GET_ENTITY_BONE_INDEX_BY_NAME(entity, boneName)


  return Velora.invoke(0x9B5100,"int", entity, boneName)


end


-- PC:0xA72CD9CA74A5ECBA Old:0x2B83F43B


function ENTITY.CLEAR_ENTITY_LAST_DAMAGE_ENTITY(entity)


  Velora.invoke(0x9B5100,"void", entity)


end


-- PC:0xAE3CBE5BF394C9C9 Old:0xFAA3D236


function ENTITY.DELETE_ENTITY()


  Velora.invoke(0x9B5160,"void")


end


-- PC:0x961AC54BF0613F5D Old:0xC8EFCB41


function ENTITY.DETACH_ENTITY(entity, dynamic, collision)


  Velora.invoke(0x9B5170,"void", entity, dynamic, collision)


end


-- PC:0x428CA6DBD1094446 Old:0x65C16D57


function ENTITY.FREEZE_ENTITY_POSITION(entity, toggle)


  Velora.invoke(0x9B5190,"void", entity, toggle)


end


-- PC:0x3910051CCECDB00C Old:0xD3850671


function ENTITY.SET_ENTITY_SHOULD_FREEZE_WAITING_ON_COLLISION(entity, toggle)


  Velora.invoke(0x9B51B0,"void", entity, toggle)


end


-- PC:0x7FB218262B810701 Old:0x878753D5


function ENTITY.PLAY_ENTITY_ANIM(entity, animName, animDict, p3, loop, stayInAnim, p6, delta, bitset)


  return Velora.invoke(0x9B55C0,"bool", entity, animName, animDict, p3, loop, stayInAnim, p6, delta, bitset)


end


-- PC:0xC77720A12FE14A86 Old:0x012760AA


function ENTITY.PLAY_SYNCHRONIZED_ENTITY_ANIM(entity, syncedScene, animation, propName, p4, p5, p6, p7)


  return Velora.invoke(0x9B5310,"bool", entity, syncedScene, animation, propName, p4, p5, p6, p7)


end


-- PC:0xB9C54555ED30FBC4 Old:0xEB4CBA74


function ENTITY.PLAY_SYNCHRONIZED_MAP_ENTITY_ANIM(x1, y1, z1, x2, y2, z2, p6, p7, p8, p9, p10, p11)


  return Velora.invoke(0x9B5360,"bool", x1, y1, z1, x2, y2, z2, p6, p7, p8, p9, p10, p11)


end


-- PC:0x11E79CAB7183B6F5 Old:0x7253D5B2


function ENTITY.STOP_SYNCHRONIZED_MAP_ENTITY_ANIM(x1, y1, z1, x2, y2, z2)


  return Velora.invoke(0x9B5450,"bool", x1, y1, z1, x2, y2, z2)


end


-- PC:0x28004F88151E03E0 Old:0xC4769830


function ENTITY.STOP_ENTITY_ANIM(entity, animation, animGroup, p3)


  return Velora.invoke(0x9B54F0,"bool", entity, animation, animGroup, p3)


end


-- PC:0x43D3807C077261E3 Old:0xE27D2FC1


function ENTITY.STOP_SYNCHRONIZED_ENTITY_ANIM(entity, p1, p2)


  return Velora.invoke(0x9B5510,"bool", entity, p1, p2)


end


-- PC:0xEAF4CD9EA3E7E922 Old:0x66571CA0


function ENTITY.HAS_ANIM_EVENT_FIRED(entity, actionHash)


  return Velora.invoke(0x9B5550,"bool", entity, actionHash)


end


-- PC:0x07F1BE2BCCAA27A7 Old:0xC41DDA62


function ENTITY.FIND_ANIM_EVENT_PHASE(animDictionary, animName, p2, p3, p4)


  return Velora.invoke(0x9B5580,"bool", animDictionary, animName, p2, p3, p4)


end


-- PC:0x4487C259F0F70977 Old:0x99D90735


function ENTITY.SET_ENTITY_ANIM_CURRENT_TIME(entity, animDictionary, animName, time)


  Velora.invoke(0x9B55C0,"void", entity, animDictionary, animName, time)


end


-- PC:0x28D1A16553C51776 Old:0x3990C90A


function ENTITY.SET_ENTITY_ANIM_SPEED(entity, animDictionary, animName, speedMultiplier)


  Velora.invoke(0x9B55E0,"void", entity, animDictionary, animName, speedMultiplier)


end


-- PC:0xAD738C3085FE7E11 Old:0x5D1F9E0F


function ENTITY.SET_ENTITY_AS_MISSION_ENTITY(entity, p1, p2)


  Velora.invoke(0x9B5600,"void", entity, p1, p2)


end


-- PC:0xB736A491E64A32CF Old:0xADF2267C


function ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED()


  Velora.invoke(0x9B5620,"void")


end


-- PC:0x2595DD4236549CE3 Old:0x9A388380


function ENTITY.SET_PED_AS_NO_LONGER_NEEDED()


  Velora.invoke(0x9B5680,"void")


end


-- PC:0x629BFA74418D6239 Old:0x9B0E10BE


function ENTITY.SET_VEHICLE_AS_NO_LONGER_NEEDED()


  Velora.invoke(0x9B56E0,"void")


end


-- PC:0x3AE22DEB5BA5A3E6 Old:0x3F6B949F


function ENTITY.SET_OBJECT_AS_NO_LONGER_NEEDED()


  Velora.invoke(0x9B5740,"void")


end


-- PC:0x1760FFA8AB074D66 Old:0x60B6E744


function ENTITY.SET_ENTITY_CAN_BE_DAMAGED(entity, toggle)


  Velora.invoke(0x9B57A0,"void", entity, toggle)


end


-- PC:0xD95CC5D2AB15A09F Old:0xE4938B5D


function ENTITY.GET_ENTITY_CAN_BE_DAMAGED(entity)


  return Velora.invoke(0x9B5890,"bool", entity)


end


-- PC:0xE22D8FDE858B8119 Old:0x34165B5D


function ENTITY.SET_ENTITY_CAN_BE_DAMAGED_BY_RELATIONSHIP_GROUP(entity, bCanBeDamaged, relGroup)


  Velora.invoke(0x9B5890,"void", entity, bCanBeDamaged, relGroup)


end


function ENTITY.SET_ENTITY_CAN_ONLY_BE_DAMAGED_BY_SCRIPT_PARTICIPANTS(entity, toggle)


  Velora.invoke(0x9B5960,"void", entity, toggle)


end


-- PC:0xD3997889736FD899 Old:0x3B13797C


function ENTITY.SET_ENTITY_CAN_BE_TARGETED_WITHOUT_LOS(entity, toggle)


  Velora.invoke(0x9B59E0,"void", entity, toggle)


end


-- PC:0x1A9205C1B9EE827F Old:0x139FD37D


function ENTITY.SET_ENTITY_COLLISION(entity, toggle, keepPhysics)


  Velora.invoke(0x9B5AE0,"void", entity, toggle, keepPhysics)


end


-- PC:0xCCF1E97BEFDAE480 Old:0xE8C0C629


function ENTITY.GET_ENTITY_COLLISION_DISABLED(entity)


  return Velora.invoke(0x9B5B70,"bool", entity)


end


-- PC:0x9EBC85ED0FFFE51C Old:0xBD0D4831


function ENTITY.SET_ENTITY_COMPLETELY_DISABLE_COLLISION(entity, toggle, keepPhysics)


  Velora.invoke(0x9B5B70,"void", entity, toggle, keepPhysics)


end


-- PC:0x06843DA7060A026B Old:0xDF70B41B


function ENTITY.SET_ENTITY_COORDS(entity, xPos, yPos, zPos, xAxis, yAxis, zAxis, clearArea)


  Velora.invoke(0x9B5BA0,"void", entity, xPos, yPos, zPos, xAxis, yAxis, zAxis, clearArea)


end


-- PC:0x621873ECE1178967 Old:0x749B282E


function ENTITY.SET_ENTITY_COORDS_WITHOUT_PLANTS_RESET(entity, xPos, yPos, zPos, alive, deadFlag, ragdollFlag, clearArea)


  Velora.invoke(0x9B5BF0,"void", entity, xPos, yPos, zPos, alive, deadFlag, ragdollFlag, clearArea)


end


-- PC:0x239A3351AC1DA385 Old:0x4C83DE8D


function ENTITY.SET_ENTITY_COORDS_NO_OFFSET(entity, xPos, yPos, zPos, xAxis, yAxis, zAxis)


  Velora.invoke(0x9B5C40,"void", entity, xPos, yPos, zPos, xAxis, yAxis, zAxis)


end


-- PC:0x1718DE8E3F2823CA Old:0x236F525B


function ENTITY.SET_ENTITY_DYNAMIC(entity, toggle)


  Velora.invoke(0x9B5C70,"void", entity, toggle)


end


-- PC:0x8E2530AA8ADA980E Old:0xE0FF064D


function ENTITY.SET_ENTITY_HEADING(entity, heading)


  Velora.invoke(0x9B5CF0,"void", entity, heading)


end


-- PC:0x6B76DC1F3AE6E6A3 Old:0xFBCD1831


function ENTITY.SET_ENTITY_HEALTH(entity, health, p2)


  Velora.invoke(0x9B5D00,"void", entity, health, p2)


end


-- PC:0x3882114BDE571AD4 Old:0xC1213A21


function ENTITY.SET_ENTITY_INVINCIBLE(entity, toggle)


  Velora.invoke(0x9B5D20,"void", entity, toggle)


end


-- PC:0xEA02E132F5C68722 Old:0x9729EE32


function ENTITY.SET_ENTITY_IS_TARGET_PRIORITY(entity, p1, p2)


  Velora.invoke(0x9B5E00,"void", entity, p1, p2)


end


-- PC:0x7CFBA6A80BDF3874 Old:0xE8FC85AF


function ENTITY.SET_ENTITY_LIGHTS(entity, toggle)


  Velora.invoke(0x9B5F20,"void", entity, toggle)


end


-- PC:0x0DC7CABAB1E9B67E Old:0xC52F295B


function ENTITY.SET_ENTITY_LOAD_COLLISION_FLAG(entity, toggle, p2)


  Velora.invoke(0x9B5F90,"void", entity, toggle, p2)


end


-- PC:0xE9676F61BC0B3321 Old:0x851687F9


function ENTITY.HAS_COLLISION_LOADED_AROUND_ENTITY(entity)


  return Velora.invoke(0x9B6050,"bool", entity)


end


-- PC:0x0E46A3FCBDE2A1B1 Old:0x46AFFED3


function ENTITY.SET_ENTITY_MAX_SPEED(entity, speed)


  Velora.invoke(0x9B6050,"void", entity, speed)


end


-- PC:0x79F020FF9EDC0748 Old:0x4B707F50


function ENTITY.SET_ENTITY_ONLY_DAMAGED_BY_PLAYER(entity, toggle)


  Velora.invoke(0x9B60C0,"void", entity, toggle)


end


-- PC:0x7022BD828FA0B082 Old:0x202237E2


function ENTITY.SET_ENTITY_ONLY_DAMAGED_BY_RELATIONSHIP_GROUP(entity, p1, p2)


  Velora.invoke(0x9B6140,"void", entity, p1, p2)


end


-- PC:0xFAEE099C6F890BB8 Old:0x7E9EAB66


function ENTITY.SET_ENTITY_PROOFS(entity, bulletProof, fireProof, explosionProof, collisionProof, meleeProof, steamProof, p7, waterProof)


  Velora.invoke(0x9B6210,"void", entity, bulletProof, fireProof, explosionProof, collisionProof, meleeProof, steamProof, p7, waterProof)


end


function ENTITY.GET_ENTITY_PROOFS(entity)


  return Velora.invoke(0x9B6480,"bool", entity)


end


-- PC:0x77B21BE7AC540F07 Old:0x83B6046F


function ENTITY.SET_ENTITY_QUATERNION(entity, x, y, z, w)


  Velora.invoke(0x9B6480,"void", entity, x, y, z, w)


end


-- PC:0x0A50A1EEDAD01E65 Old:0x6B189A1A


function ENTITY.SET_ENTITY_RECORDS_COLLISIONS(entity, toggle)


  Velora.invoke(0x9B6650,"void", entity, toggle)


end


-- PC:0x8524A8B0171D5E07 Old:0x0A345EFE


function ENTITY.SET_ENTITY_ROTATION(entity, pitch, roll, yaw, rotationOrder, p5)


  Velora.invoke(0x9B66A0,"void", entity, pitch, roll, yaw, rotationOrder, p5)


end


-- PC:0xEA1C610A04DB6BBB Old:0xD043E8E1


function ENTITY.SET_ENTITY_VISIBLE(entity, toggle, p2)


  Velora.invoke(0x9B66C0,"void", entity, toggle, p2)


end


function ENTITY.SET_ENTITY_WATER_REFLECTION_FLAG(entity, toggle)


  Velora.invoke(0x9B66E0,"void", entity, toggle)


end


function ENTITY.SET_ENTITY_MIRROR_REFLECTION_FLAG(entity, p1)


  Velora.invoke(0x9B6750,"void", entity, p1)


end


-- PC:0x1C99BB7B6E96D16F Old:0xFF5A1988


function ENTITY.SET_ENTITY_VELOCITY(entity, x, y, z)


  Velora.invoke(0x9B67C0,"void", entity, x, y, z)


end


function ENTITY.SET_ENTITY_ANGULAR_VELOCITY(entity, x, y, z)


  Velora.invoke(0x9B6850,"void", entity, x, y, z)


end


-- PC:0x4A4722448F18EEF5 Old:0xE2F262BF


function ENTITY.SET_ENTITY_HAS_GRAVITY(entity, toggle)


  Velora.invoke(0x9B68E0,"void", entity, toggle)


end


-- PC:0x5927F96A78577363 Old:0xD7ACC7AD


function ENTITY.SET_ENTITY_LOD_DIST(entity, value)


  Velora.invoke(0x9B6A00,"void", entity, value)


end


-- PC:0x4159C2762B5791D6 Old:0x4DA3D51F


function ENTITY.GET_ENTITY_LOD_DIST(entity)


  return Velora.invoke(0x9B6AB0,"int", entity)


end


-- PC:0x44A0870B7E92D7C0 Old:0xAE667CB0


function ENTITY.SET_ENTITY_ALPHA(entity, alphaLevel, skin)


  Velora.invoke(0x9B6AB0,"void", entity, alphaLevel, skin)


end


-- PC:0x5A47B3B5E63E94C6 Old:0x1560B017


function ENTITY.GET_ENTITY_ALPHA(entity)


  return Velora.invoke(0x9B6B70,"int", entity)


end


-- PC:0x9B1E824FFBB7027A Old:0x8A30761C


function ENTITY.RESET_ENTITY_ALPHA(entity)


  Velora.invoke(0x9B6B70,"void", entity)


end


function ENTITY.RESET_PICKUP_ENTITY_GLOW(entity)


  Velora.invoke(0x9B6B80,"void", entity)


end


function ENTITY.SET_PICKUP_COLLIDES_WITH_PROJECTILES(p0, p1)


  Velora.invoke(0x9B6BC0,"void", p0, p1)


end


function ENTITY.SET_ENTITY_SORT_BIAS(entity, p1)


  Velora.invoke(0x9B6C20,"void", entity, p1)


end


-- PC:0xACAD101E1FB66689 Old:0xD8FF798A


function ENTITY.SET_ENTITY_ALWAYS_PRERENDER(entity, toggle)


  Velora.invoke(0x9B6C80,"void", entity, toggle)


end


-- PC:0x730F5F8D3F0F2050 Old:0xAAC9317B


function ENTITY.SET_ENTITY_RENDER_SCORCHED(entity, toggle)


  Velora.invoke(0x9B6CE0,"void", entity, toggle)


end


-- PC:0x57C5DB656185EAC4 Old:0xC47F5B91


function ENTITY.SET_ENTITY_TRAFFICLIGHT_OVERRIDE(entity, state)


  Velora.invoke(0x9B6D60,"void", entity, state)


end


function ENTITY.SET_ENTITY_IS_IN_VEHICLE(entity)


  Velora.invoke(0x9B6DC0,"void", entity)


end


-- PC:0x92C47782FDA8B2A3 Old:0x0BC12F9E


function ENTITY.CREATE_MODEL_SWAP(x, y, z, radius, originalModel, newModel, p6)


  Velora.invoke(0x9B6E20,"void", x, y, z, radius, originalModel, newModel, p6)


end


-- PC:0x033C0F9A64E229AE Old:0xCE0AA8BC


function ENTITY.REMOVE_MODEL_SWAP(x, y, z, radius, originalModel, newModel, p6)


  Velora.invoke(0x9B6F00,"void", x, y, z, radius, originalModel, newModel, p6)


end


-- PC:0x8A97BCA30A0CE478 Old:0x7BD5CF2F


function ENTITY.CREATE_MODEL_HIDE(x, y, z, radius, modelHash, p5)


  Velora.invoke(0x9B6F90,"void", x, y, z, radius, modelHash, p5)


end


-- PC:0x3A52AE588830BF7F Old:0x07AAF22C


function ENTITY.CREATE_MODEL_HIDE_EXCLUDING_SCRIPT_OBJECTS(x, y, z, radius, modelHash, p5)


  Velora.invoke(0x9B7060,"void", x, y, z, radius, modelHash, p5)


end


-- PC:0xD9E3006FB3CBD765 Old:0x993DBC10


function ENTITY.REMOVE_MODEL_HIDE(x, y, z, radius, modelHash, p5)


  Velora.invoke(0x9B7130,"void", x, y, z, radius, modelHash, p5)


end


-- PC:0x150E808B375A385A Old:0x335190A2


function ENTITY.CREATE_FORCED_OBJECT(x, y, z, p3, modelHash, p5)


  Velora.invoke(0x9B71C0,"void", x, y, z, p3, modelHash, p5)


end


-- PC:0x61B6775E83C0DB6F Old:0xAED73ADD


function ENTITY.REMOVE_FORCED_OBJECT(x, y, z, p3, modelHash)


  Velora.invoke(0x9B7290,"void", x, y, z, p3, modelHash)


end


-- PC:0xA53ED5520C07654A Old:0x1E11BFE9


function ENTITY.SET_ENTITY_NO_COLLISION_ENTITY(entity1, entity2, thisFrameOnly)


  Velora.invoke(0x9B7310,"void", entity1, entity2, thisFrameOnly)


end


-- PC:0x295D82A8559F9150 Old:0xE90005B8


function ENTITY.SET_ENTITY_MOTION_BLUR(entity, toggle)


  Velora.invoke(0x9B7340,"void", entity, toggle)


end


-- PC:0xE12ABE5E3A389A6C Old:0x44767B31


function ENTITY.SET_CAN_AUTO_VAULT_ON_ENTITY(entity, toggle)


  Velora.invoke(0x9B73A0,"void", entity, toggle)


end


-- PC:0xA80AE305E0A3044F Old:0xE224A6A5


function ENTITY.SET_CAN_CLIMB_ON_ENTITY(entity, toggle)


  Velora.invoke(0x9B7420,"void", entity, toggle)


end


-- PC:0xDC6F8601FAF2E893 Old:0xA0466A69


function ENTITY.SET_WAIT_FOR_COLLISIONS_BEFORE_PROBE(entity, toggle)


  Velora.invoke(0x9B74A0,"void", entity, toggle)


end


function ENTITY.SET_ENTITY_NOWEAPONDECALS(entity, p1)


  Velora.invoke(0x9B7500,"void", entity, p1)


end


function ENTITY.SET_ENTITY_USE_MAX_DISTANCE_FOR_WATER_REFLECTION(entity, p1)


  Velora.invoke(0x9B7570,"void", entity, p1)


end


function ENTITY.GET_ENTITY_BONE_ROTATION(entity, boneIndex)


  local x,y,z=Velora.invoke(0x9B78C0,"vector3", entity, boneIndex)


  return {x=x,y=y,z=z}


end


function ENTITY.GET_ENTITY_BONE_POSTION(entity, boneIndex)


  local x,y,z=Velora.invoke(0x9B7640,"vector3", entity, boneIndex)


  return {x=x,y=y,z=z}


end


function ENTITY.GET_ENTITY_BONE_OBJECT_ROTATION(entity, boneIndex)


  local x,y,z=Velora.invoke(0x9B76B0,"vector3", entity, boneIndex)


  return {x=x,y=y,z=z}


end


function ENTITY.GET_ENTITY_BONE_OBJECT_POSTION(entity, boneIndex)


  local x,y,z=Velora.invoke(0x9B7720,"vector3", entity, boneIndex)


  return {x=x,y=y,z=z}


end


function ENTITY.GET_ENTITY_BONE_COUNT(entity)


  return Velora.invoke(0x9B7810,"int", entity)


end


function ENTITY.ENABLE_ENTITY_BULLET_COLLISION(entity)


  Velora.invoke(0x9B78C0,"void", entity)


end


function ENTITY.SET_ENTITY_CAN_ONLY_BE_DAMAGED_BY_ENTITY(entity1, entity2)


  Velora.invoke(0x9B7920,"void", entity1, entity2)


end


function ENTITY.SET_ENTITY_CANT_CAUSE_COLLISION_DAMAGED_ENTITY(entity1, entity2)


  Velora.invoke(0x9B79A0,"void", entity1, entity2)


end


function ENTITY.SET_ALLOW_MIGRATE_TO_SPECTATOR(entity, p1)


  Velora.invoke(0x9B7A20,"void", entity, p1)


end


function ENTITY.GET_ENTITY_OF_TYPE_ATTACHED_TO_ENTITY(entity, modelHash)


  return Velora.invoke(0x9B7B30,"int", entity, modelHash)


end


function ENTITY.SET_PICK_UP_BY_CARGOBOB_DISABLED(entity, toggle)


  Velora.invoke(0x9B7B30,"void", entity, toggle)


end


