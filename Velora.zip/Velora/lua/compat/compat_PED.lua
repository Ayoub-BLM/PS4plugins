-- compat_PED.lua — AUTO GENERATO


-- PED


PED=PED or {}


-- PC:0xD49F9B0955C367DE Old:0x0389EF71


function PED.CREATE_PED(pedType, modelHash, x, y, z, heading, isNetwork, bScriptHostPed)


  return Velora.invoke(0xA8FBF0,"int", pedType, modelHash, x, y, z, heading, isNetwork, bScriptHostPed)


end


-- PC:0x9614299DCB53E54B Old:0x13EFB9A0


function PED.DELETE_PED()


  Velora.invoke(0xA8FC40,"void")


end


-- PC:0xEF29A16337FACADB Old:0x8C8A8D6E


function PED.CLONE_PED(ped, isNetwork, bScriptHostPed, copyHeadBlendFlag)


  return Velora.invoke(0xA8FCF0,"int", ped, isNetwork, bScriptHostPed, copyHeadBlendFlag)


end


function PED.CLONE_PED_ALT(ped, isNetwork, bScriptHostPed, copyHeadBlendFlag, p4)


  return Velora.invoke(0xA8FCA0,"int", ped, isNetwork, bScriptHostPed, copyHeadBlendFlag, p4)


end


-- PC:0xE952D6431689AD9A Old:0xFC70EEC7


function PED.CLONE_PED_TO_TARGET(ped, targetPed)


  Velora.invoke(0xA8FCF0,"void", ped, targetPed)


end


function PED.CLONE_PED_TO_TARGET_ALT(ped, targetPed, p2)


  Velora.invoke(0xA8FD90,"void", ped, targetPed, p2)


end


-- PC:0xA3EE4A07279BB9DB Old:0x7DA6BC83


function PED.IS_PED_IN_VEHICLE(ped, vehicle, atGetIn)


  return Velora.invoke(0xA90360,"bool", ped, vehicle, atGetIn)


end


-- PC:0x796D90EFB19AA332 Old:0xA6438D4B


function PED.IS_PED_IN_MODEL(ped, modelHash)


  return Velora.invoke(0xA8FE60,"bool", ped, modelHash)


end


-- PC:0x997ABD671D25CA0B Old:0x3B0171EE


function PED.IS_PED_IN_ANY_VEHICLE(ped, atGetIn)


  return Velora.invoke(0xA8FF40,"bool", ped, atGetIn)


end


-- PC:0x16EC4839969F9F5E Old:0xB98DB96B


function PED.IS_COP_PED_IN_AREA_3D(x1, y1, z1, x2, y2, z2)


  return Velora.invoke(0xA8FF70,"bool", x1, y1, z1, x2, y2, z2)


end


-- PC:0x84A2DD9AC37C35C1 Old:0x2530A087


function PED.IS_PED_INJURED(ped)


  return Velora.invoke(0xA90020,"bool", ped)


end


-- PC:0x5983BB449D7FDB12 Old:0x69DFA0AF


function PED.IS_PED_HURT(ped)


  return Velora.invoke(0xA90080,"bool", ped)


end


-- PC:0xD839450756ED5A80 Old:0xBADA0093


function PED.IS_PED_FATALLY_INJURED(ped)


  return Velora.invoke(0xA900E0,"bool", ped)


end


-- PC:0x3317DEDB88C95038 Old:0xCBDB7739


function PED.IS_PED_DEAD_OR_DYING(ped, p1)


  return Velora.invoke(0xA90140,"bool", ped, p1)


end


-- PC:0xE0A0AEC214B1FABA Old:0x1FA39EFE


function PED.IS_CONVERSATION_PED_DEAD(ped)


  return Velora.invoke(0xA901C0,"bool", ped)


end


-- PC:0x3998B1276A3300E5 Old:0xDEBAB2AF


function PED.IS_PED_AIMING_FROM_COVER(ped)


  return Velora.invoke(0xA90230,"bool", ped)


end


-- PC:0x24B100C68C645951 Old:0x961E1745


function PED.IS_PED_RELOADING(ped)


  return Velora.invoke(0xA90260,"bool", ped)


end


-- PC:0x12534C348C6CB68B Old:0x404794CA


function PED.IS_PED_A_PLAYER(ped)


  return Velora.invoke(0xA902C0,"bool", ped)


end


-- PC:0x7DD959874C1FD534 Old:0x3000F092


function PED.CREATE_PED_INSIDE_VEHICLE(vehicle, pedType, modelHash, seat, isNetwork, bScriptHostPed)


  return Velora.invoke(0xA90320,"int", vehicle, pedType, modelHash, seat, isNetwork, bScriptHostPed)


end


-- PC:0xAA5A7ECE2AA8FE70 Old:0x961458F9


function PED.SET_PED_DESIRED_HEADING(ped, heading)


  Velora.invoke(0xA90360,"void", ped, heading)


end


-- PC:0xFF287323B0E2C69A Old:0x290421BE


function PED.FORCE_ALL_HEADING_VALUES_TO_ALIGN(ped)


  Velora.invoke(0xA90450,"void", ped)


end


-- PC:0xD71649DB0A545AA3 Old:0x0B775838


function PED.IS_PED_FACING_PED(ped, otherPed, angle)


  return Velora.invoke(0xA90640,"bool", ped, otherPed, angle)


end


-- PC:0x4E209B2C1EAD5159 Old:0xFD7814A5


function PED.IS_PED_IN_MELEE_COMBAT(ped)


  return Velora.invoke(0xA90490,"bool", ped)


end


-- PC:0x530944F6F4B8A214 Old:0xA0DC0B87


function PED.IS_PED_STOPPED(ped)


  return Velora.invoke(0xA90500,"bool", ped)


end


-- PC:0x7E9DFE24AC1E58EF Old:0x741BF04F


function PED.IS_PED_SHOOTING_IN_AREA(ped, x1, y1, z1, x2, y2, z2, p7, p8)


  return Velora.invoke(0xA90560,"bool", ped, x1, y1, z1, x2, y2, z2, p7, p8)


end


-- PC:0xA0D3D71EA1086C55 Old:0x91833867


function PED.IS_ANY_PED_SHOOTING_IN_AREA(x1, y1, z1, x2, y2, z2, p6, p7)


  return Velora.invoke(0xA905A0,"bool", x1, y1, z1, x2, y2, z2, p6, p7)


end


-- PC:0x34616828CD07F1A1 Old:0xE7C3405E


function PED.IS_PED_SHOOTING(ped)


  return Velora.invoke(0xA905E0,"bool", ped)


end


-- PC:0x7AEFB85C1D49DEB6 Old:0x6C17122E


function PED.SET_PED_ACCURACY(ped, accuracy)


  Velora.invoke(0xA90640,"void", ped, accuracy)


end


-- PC:0x37F4AD56ECBC0CD6 Old:0x0A2A0AA0


function PED.GET_PED_ACCURACY(ped)


  return Velora.invoke(0xA90740,"int", ped)


end


function PED.SET_AMBIENT_LAW_PED_ACCURACY_MODIFIER(multiplier)


  Velora.invoke(0xA90740,"void", multiplier)


end


-- PC:0xC9D55B1A358A5BF7 Old:0x5F1DDFCB


function PED.IS_PED_MODEL(ped, modelHash)


  return Velora.invoke(0xA90830,"bool", ped, modelHash)


end


-- PC:0x2D05CED3A38D0F3A Old:0x05CC1380


function PED.EXPLODE_PED_HEAD(ped, weaponHash)


  Velora.invoke(0xA90830,"void", ped, weaponHash)


end


-- PC:0xAC6D445B994DF95E Old:0x4FFB8C6C


function PED.REMOVE_PED_ELEGANTLY()


  Velora.invoke(0xA90840,"void")


end


-- PC:0x5BA652A0CD14DF2F Old:0xF686B26E


function PED.ADD_ARMOUR_TO_PED(ped, amount)


  Velora.invoke(0xA90850,"void", ped, amount)


end


-- PC:0xCEA04D83135264CC Old:0x4E3A0CC4


function PED.SET_PED_ARMOUR(ped, amount)


  Velora.invoke(0xA90930,"void", ped, amount)


end


-- PC:0xF75B0D629E1C063D Old:0x07500C79


function PED.SET_PED_INTO_VEHICLE(ped, vehicle, seatIndex)


  Velora.invoke(0xA90A10,"void", ped, vehicle, seatIndex)


end


-- PC:0x3C028C636A414ED9 Old:0x58A80BD5


function PED.SET_PED_ALLOW_VEHICLES_OVERRIDE(ped, toggle)


  Velora.invoke(0xA90A30,"void", ped, toggle)


end


-- PC:0x3E8349C08E4B82E4 Old:0xF9ABE88F


function PED.CAN_CREATE_RANDOM_PED(p0)


  return Velora.invoke(0xA90CB0,"bool", p0)


end


-- PC:0xB4AC7D0CF06BFE8F Old:0x5A949543


function PED.CREATE_RANDOM_PED(posX, posY, posZ)


  return Velora.invoke(0xA90B50,"int", posX, posY, posZ)


end


-- PC:0x9B62392B474F44A0 Old:0xB927CE9A


function PED.CREATE_RANDOM_PED_AS_DRIVER(vehicle, returnHandle)


  return Velora.invoke(0xA90BD0,"int", vehicle, returnHandle)


end


-- PC:0xB8EB95E5B4E56978 Old:0x99861609


function PED.CAN_CREATE_RANDOM_DRIVER()


  return Velora.invoke(0xA90C00,"bool")


end


-- PC:0xEACEEDA81751915C Old:0x7018BE31


function PED.CAN_CREATE_RANDOM_BIKE_RIDER()


  return Velora.invoke(0xA90C50,"bool")


end


-- PC:0x9E8C908F41584ECD Old:0x20E01957


function PED.SET_PED_MOVE_ANIMS_BLEND_OUT(ped)


  Velora.invoke(0xA90CB0,"void", ped)


end


-- PC:0xC1670E958EEE24E5 Old:0xAA7F1131


function PED.SET_PED_CAN_BE_DRAGGED_OUT(ped, toggle)


  Velora.invoke(0xA90D10,"void", ped, toggle)


end


-- PC:0xF2BEBCDFAFDAA19E Old:0x6CD58238


function PED.SET_PED_ALLOW_HURT_COMBAT_FOR_ALL_MISSION_PEDS(toggle)


  Velora.invoke(0xA90D70,"void", toggle)


end


-- PC:0x6D9F5FAA7488BA46 Old:0x90950455


function PED.IS_PED_MALE(ped)


  return Velora.invoke(0xA90EB0,"bool", ped)


end


-- PC:0xB980061DA992779D Old:0x194BB7B0


function PED.IS_PED_HUMAN(ped)


  return Velora.invoke(0xA90E00,"bool", ped)


end


-- PC:0x9A9112A0FE9A4713 Old:0xAFE92319


function PED.GET_VEHICLE_PED_IS_IN(ped, includeEntering)


  return Velora.invoke(0xA90E80,"int", ped, includeEntering)


end


-- PC:0xBB8DE8CF6A8DD8BB Old:0x5E3B5942


function PED.RESET_PED_LAST_VEHICLE(ped)


  Velora.invoke(0xA90EB0,"void", ped)


end


-- PC:0x95E3D6257B166CF2 Old:0x039C82BB


function PED.SET_PED_DENSITY_MULTIPLIER_THIS_FRAME(multiplier)


  Velora.invoke(0xA90F10,"void", multiplier)


end


-- PC:0x7A556143A1C03898 Old:0x2909ABF0


function PED.SET_SCENARIO_PED_DENSITY_MULTIPLIER_THIS_FRAME(p0, p1)


  Velora.invoke(0xA90F20,"void", p0, p1)


end


-- PC:0x5A7F62FDA59759BD Old:0xB48C0C04


function PED.SUPPRESS_AMBIENT_PED_AGGRESSIVE_CLEANUP_THIS_FRAME()


  Velora.invoke(0xA90F40,"void")


end


-- PC:0x5086C7843552CF85 Old:0x25EA2AA5


function PED.SET_SCRIPTED_CONVERSION_COORD_THIS_FRAME(x, y, z)


  Velora.invoke(0xA90F50,"void", x, y, z)


end


-- PC:0xEE01041D559983EA Old:0x7A97283F


function PED.SET_PED_NON_CREATION_AREA(x1, y1, z1, x2, y2, z2)


  Velora.invoke(0xA90FB0,"void", x1, y1, z1, x2, y2, z2)


end


-- PC:0x2E05208086BA0651 Old:0x6F7043A3


function PED.CLEAR_PED_NON_CREATION_AREA()


  Velora.invoke(0xA91030,"void")


end


-- PC:0x4759CC730F947C81 Old:0x8C555ADD


function PED.INSTANTLY_FILL_PED_POPULATION()


  Velora.invoke(0xA91040,"void")


end


-- PC:0x460BC76A0E10655E Old:0x43103006


function PED.IS_PED_ON_MOUNT(ped)


  return Velora.invoke(0xA911D0,"bool", ped)


end


-- PC:0xE7E11B8DCBED1058 Old:0xDD31EC4E


function PED.GET_MOUNT(ped)


  return Velora.invoke(0xA91090,"int", ped)


end


-- PC:0x67722AEB798E5FAB Old:0xA1AE7CC7


function PED.IS_PED_ON_VEHICLE(ped)


  return Velora.invoke(0xA910D0,"bool", ped)


end


-- PC:0xEC5F66E459AF3BB2 Old:0x63CB4603


function PED.IS_PED_ON_SPECIFIC_VEHICLE(ped, vehicle)


  return Velora.invoke(0xA91130,"bool", ped, vehicle)


end


-- PC:0xA9C8960E8684C1B5 Old:0x40D90BF2


function PED.SET_PED_MONEY(ped, amount)


  Velora.invoke(0xA911D0,"void", ped, amount)


end


-- PC:0x3F69145BBA87BAE7 Old:0xEB3C4C7E


function PED.GET_PED_MONEY(ped)


  return Velora.invoke(0xA91280,"int", ped)


end


-- PC:0xFF4803BC019852D9 Old:0xD41C9AED


function PED.SET_HEALTH_SNACKS_CARRIED_BY_ALL_NEW_PEDS(p0, p1)


  Velora.invoke(0xA91280,"void", p0, p1)


end


-- PC:0x6B0E6172C9A4D902 Old:0x30B98369


function PED.SET_AMBIENT_PEDS_DROP_MONEY(p0)


  Velora.invoke(0xA912C0,"void", p0)


end


-- PC:0x9911F4A24485F653 Old:0x02A080C8


function PED.SET_BLOCKING_OF_NON_TEMPORARY_EVENTS_FOR_AMBIENT_PEDS_THIS_FRAME(p0)


  Velora.invoke(0xA912F0,"void", p0)


end


-- PC:0xEBD76F2359F190AC Old:0x6F6FC7E6


function PED.SET_PED_SUFFERS_CRITICAL_HITS(ped, toggle)


  Velora.invoke(0xA91310,"void", ped, toggle)


end


-- PC:0xAFC976FD0580C7B3 Old:0x1572022A


function PED.SET_PED_UPPER_BODY_DAMAGE_ONLY(ped, toggle)


  Velora.invoke(0xA91360,"void", ped, toggle)


end


-- PC:0xA808AA1D79230FC2 Old:0xDDDE26FA


function PED.IS_PED_SITTING_IN_VEHICLE(ped, vehicle)


  return Velora.invoke(0xA91840,"bool", ped, vehicle)


end


-- PC:0x826AA586EDB9FEF8 Old:0x0EA9CA03


function PED.IS_PED_SITTING_IN_ANY_VEHICLE(ped)


  return Velora.invoke(0xA913F0,"bool", ped)


end


-- PC:0x01FEE67DB37F59B2 Old:0xC60D0785


function PED.IS_PED_ON_FOOT(ped)


  return Velora.invoke(0xA91480,"bool", ped)


end


-- PC:0x94495889E22C6479 Old:0x4D885B2E


function PED.IS_PED_ON_ANY_BIKE(ped)


  return Velora.invoke(0xA914B0,"bool", ped)


end


-- PC:0xC70B5FAE151982D8 Old:0x0EDAC574


function PED.IS_PED_PLANTING_BOMB(ped)


  return Velora.invoke(0xA91520,"bool", ped)


end


-- PC:0xCD5003B097200F36 Old:0x129F9DC1


function PED.GET_DEAD_PED_PICKUP_COORDS(ped, p1, p2)


  local x,y,z=Velora.invoke(0xA91590,"vector3", ped, p1, p2)


  return {x=x,y=y,z=z}


end


-- PC:0x2E0E1C2B4F6CB339 Old:0x1118A947


function PED.IS_PED_IN_ANY_BOAT(ped)


  return Velora.invoke(0xA91600,"bool", ped)


end


-- PC:0xFBFC01CCFB35D99E Old:0xE65F8059


function PED.IS_PED_IN_ANY_SUB(ped)


  return Velora.invoke(0xA91670,"bool", ped)


end


-- PC:0x298B91AE825E5705 Old:0x7AB5523B


function PED.IS_PED_IN_ANY_HELI(ped)


  return Velora.invoke(0xA916E0,"bool", ped)


end


-- PC:0x5FFF4CFC74D8FB80 Old:0x51BBCE7E


function PED.IS_PED_IN_ANY_PLANE(ped)


  return Velora.invoke(0xA91750,"bool", ped)


end


-- PC:0x9134873537FA419C Old:0xCA072485


function PED.IS_PED_IN_FLYING_VEHICLE(ped)


  return Velora.invoke(0xA917C0,"bool", ped)


end


-- PC:0x56CEF0AC79073BDE Old:0x604C872B


function PED.SET_PED_DIES_IN_WATER(ped, toggle)


  Velora.invoke(0xA91840,"void", ped, toggle)


end


function PED.GET_PED_DIES_IN_WATER(ped)


  return Velora.invoke(0xA918F0,"bool", ped)


end


-- PC:0xD718A22995E2B4BC Old:0x8D4D9ABB


function PED.SET_PED_DIES_IN_SINKING_VEHICLE(ped, toggle)


  Velora.invoke(0xA918F0,"void", ped, toggle)


end


-- PC:0x9483AF821605B1D8 Old:0x2CE311A7


function PED.GET_PED_ARMOUR(ped)


  return Velora.invoke(0xA91990,"int", ped)


end


-- PC:0xEDF4079F9D54C9A1 Old:0xB014A09C


function PED.SET_PED_STAY_IN_VEHICLE_WHEN_JACKED(ped, toggle)


  Velora.invoke(0xA91990,"void", ped, toggle)


end


-- PC:0xC7EF1BA83230BA07 Old:0x5DB7B3A9


function PED.SET_PED_CAN_BE_SHOT_IN_VEHICLE(ped, toggle)


  Velora.invoke(0xA919F0,"void", ped, toggle)


end


-- PC:0xD75960F6BD9EA49C Old:0xAB933841


function PED.GET_PED_LAST_DAMAGE_BONE(ped)


  return Velora.invoke(0xA91AC0,"bool", ped)


end


-- PC:0x8EF6B7AC68E2F01B Old:0x56CB715E


function PED.CLEAR_PED_LAST_DAMAGE_BONE(ped)


  Velora.invoke(0xA91AC0,"void", ped)


end


-- PC:0x1B1E2A40A65B8521 Old:0x516E30EE


function PED.SET_AI_WEAPON_DAMAGE_MODIFIER(value)


  Velora.invoke(0xA91B10,"void", value)


end


-- PC:0xEA16670E7BA4743C Old:0x6E965420


function PED.RESET_AI_WEAPON_DAMAGE_MODIFIER()


  Velora.invoke(0xA91B30,"void")


end


-- PC:0x66460DEDDD417254 Old:0x0F9A401F


function PED.SET_AI_MELEE_WEAPON_DAMAGE_MODIFIER(modifier)


  Velora.invoke(0xA91B50,"void", modifier)


end


-- PC:0x46E56A7CD1D63C3F Old:0x97886238


function PED.RESET_AI_MELEE_WEAPON_DAMAGE_MODIFIER()


  Velora.invoke(0xA91B70,"void")


end


-- PC:0x2F3C3D9F50681DE4 Old:0xCC9D7F1A


function PED.SET_TREAT_AS_AMBIENT_PED_FOR_DRIVER_LOCKON(ped, p1)


  Velora.invoke(0xA91B90,"void", ped, p1)


end


-- PC:0x63F58F7C80513AAD Old:0x75C49F74


function PED.SET_PED_CAN_BE_TARGETTED(ped, toggle)


  Velora.invoke(0xA91BE0,"void", ped, toggle)


end


-- PC:0xBF1CA77833E58F2C Old:0xB103A8E1


function PED.SET_PED_CAN_BE_TARGETTED_BY_TEAM(ped, team, toggle)


  Velora.invoke(0xA91C40,"void", ped, team, toggle)


end


-- PC:0x66B57B72E0836A76 Old:0xD050F490


function PED.SET_PED_CAN_BE_TARGETTED_BY_PLAYER(ped, player, toggle)


  Velora.invoke(0xA91CC0,"void", ped, player, toggle)


end


-- PC:0x061CB768363D6424 Old:0x7DA12905


function PED.SET_ALLOW_LOCKON_TO_PED_IF_FRIENDLY(ped, toggle)


  Velora.invoke(0xA91D40,"void", ped, toggle)


end


-- PC:0xFD325494792302D7 Old:0x7F67671D


function PED.SET_USE_CAMERA_HEADING_FOR_DESIRED_DIRECTION_LOCK_ON_TEST(ped, toggle)


  Velora.invoke(0xA91DA0,"void", ped, toggle)


end


-- PC:0x0BD04E29640C9C12 Old:0x84FA790D


function PED.IS_PED_IN_ANY_POLICE_VEHICLE(ped)


  return Velora.invoke(0xA91E70,"bool", ped)


end


-- PC:0x16E42E800B472221 Old:0xA819680B


function PED.FORCE_PED_TO_OPEN_PARACHUTE(ped)


  Velora.invoke(0xA91E70,"void", ped)


end


-- PC:0x7DCE8BDA0F1C1200 Old:0xCD71F11B


function PED.IS_PED_IN_PARACHUTE_FREE_FALL(ped)


  return Velora.invoke(0xA92450,"bool", ped)


end


-- PC:0xFB92A102F1C4DFA3 Old:0xABF77334


function PED.IS_PED_FALLING(ped)


  return Velora.invoke(0xA91F90,"bool", ped)


end


-- PC:0xCEDABC5900A0BF97 Old:0x07E5BC0E


function PED.IS_PED_JUMPING(ped)


  return Velora.invoke(0xA91FF0,"bool", ped)


end


function PED.IS_PED_LANDING(p0)


  return Velora.invoke(0xA92050,"bool", p0)


end


function PED.IS_PED_DOING_A_BEAST_JUMP(p0)


  return Velora.invoke(0xA920B0,"bool", p0)


end


-- PC:0x53E8CB4F48BFE623 Old:0xBCE03D35


function PED.IS_PED_CLIMBING(ped)


  return Velora.invoke(0xA92130,"bool", ped)


end


-- PC:0x117C70D1F5730B5E Old:0xC3169BDA


function PED.IS_PED_VAULTING(ped)


  return Velora.invoke(0xA92190,"bool", ped)


end


-- PC:0x5527B8246FEF9B11 Old:0x7BC5BF3C


function PED.IS_PED_DIVING(ped)


  return Velora.invoke(0xA921F0,"bool", ped)


end


-- PC:0x433DDFFE2044B636 Old:0xB19215F6


function PED.IS_PED_JUMPING_OUT_OF_VEHICLE(ped)


  return Velora.invoke(0xA92250,"bool", ped)


end


function PED.IS_PED_OPENING_DOOR(ped)


  return Velora.invoke(0xA92280,"bool", ped)


end


-- PC:0x79CFD9827CC979B6 Old:0x7D4BC475


function PED.GET_PED_PARACHUTE_STATE(ped)


  return Velora.invoke(0xA92310,"int", ped)


end


-- PC:0x8B9F1FC6AE8166C0 Old:0x01F3B035


function PED.GET_PED_PARACHUTE_LANDING_TYPE(ped)


  return Velora.invoke(0xA923E0,"int", ped)


end


-- PC:0x333FC8DB079B7186 Old:0x5AEFEC3A


function PED.SET_PED_PARACHUTE_TINT_INDEX(ped, tintIndex)


  Velora.invoke(0xA92450,"void", ped, tintIndex)


end


-- PC:0xEAF5F7E5AE7C6C9D Old:0xE9E7FAC5


function PED.GET_PED_PARACHUTE_TINT_INDEX(ped)


  Velora.invoke(0xA924A0,"void", ped)


end


-- PC:0xE88DA0751C22A2AD Old:0x177EFC79


function PED.SET_PED_RESERVE_PARACHUTE_TINT_INDEX(ped, p1)


  Velora.invoke(0xA924F0,"void", ped, p1)


end


-- PC:0x8C4F3BF23B6237DB Old:0x19198A16


function PED.CREATE_PARACHUTE_BAG_OBJECT(ped, p1, p2)


  return Velora.invoke(0xA925D0,"int", ped, p1, p2)


end


-- PC:0x030983CA930B692D Old:0xB90353D7


function PED.SET_PED_DUCKING(ped, toggle)


  Velora.invoke(0xA925D0,"void", ped, toggle)


end


-- PC:0xD125AE748725C6BC Old:0x9199C77D


function PED.IS_PED_DUCKING(ped)


  return Velora.invoke(0xA92750,"bool", ped)


end


-- PC:0x6E575D6A898AB852 Old:0x16FD386C


function PED.IS_PED_IN_ANY_TAXI(ped)


  return Velora.invoke(0xA92690,"bool", ped)


end


-- PC:0xF107E836A70DCE05 Old:0xEF3B4ED9


function PED.SET_PED_ID_RANGE(ped, value)


  Velora.invoke(0xA92750,"void", ped, value)


end


-- PC:0x52D59AB61DDC05DD Old:0x9A2180FF


function PED.SET_PED_HIGHLY_PERCEPTIVE(ped, toggle)


  Velora.invoke(0xA927B0,"void", ped, toggle)


end


function PED.SET_COP_PERCEPTION_OVERRIDES(seeingRange, seeingRangePeripheral, hearingRange, visualFieldMinAzimuthAngle, visualFieldMaxAzimuthAngle, fieldOfGazeMaxAngle, p6)


  Velora.invoke(0xA92800,"void", seeingRange, seeingRangePeripheral, hearingRange, visualFieldMinAzimuthAngle, visualFieldMaxAzimuthAngle, fieldOfGazeMaxAngle, p6)


end


-- PC:0xEC4B4B3B9908052A Old:0xF30658D2


function PED.SET_PED_INJURED_ON_GROUND_BEHAVIOUR(ped, p1)


  Velora.invoke(0xA92880,"void", ped, p1)


end


-- PC:0x733C87D4CE22BEA2 Old:0x43709044


function PED.DISABLE_PED_INJURED_ON_GROUND_BEHAVIOUR(ped)


  Velora.invoke(0xA928F0,"void", ped)


end


-- PC:0xF29CF591C4BF6CEE Old:0x4BD72FE8


function PED.SET_PED_SEEING_RANGE(ped, value)


  Velora.invoke(0xA92940,"void", ped, value)


end


-- PC:0x33A8F7F7D5F7F33C Old:0xB32087E0


function PED.SET_PED_HEARING_RANGE(ped, value)


  Velora.invoke(0xA929A0,"void", ped, value)


end


-- PC:0x2DB492222FB21E26 Old:0x72E2E18B


function PED.SET_PED_VISUAL_FIELD_MIN_ANGLE(ped, value)


  Velora.invoke(0xA92A00,"void", ped, value)


end


-- PC:0x70793BDCA1E854D4 Old:0x0CEA0F9A


function PED.SET_PED_VISUAL_FIELD_MAX_ANGLE(ped, value)


  Velora.invoke(0xA92A60,"void", ped, value)


end


-- PC:0x7A276EB2C224D70F Old:0x5CC2F1B8


function PED.SET_PED_VISUAL_FIELD_MIN_ELEVATION_ANGLE(ped, angle)


  Velora.invoke(0xA92AC0,"void", ped, angle)


end


-- PC:0x78D0B67629D75856 Old:0x39D9102F


function PED.SET_PED_VISUAL_FIELD_MAX_ELEVATION_ANGLE(ped, angle)


  Velora.invoke(0xA92B20,"void", ped, angle)


end


-- PC:0x9C74B0BC831B753A Old:0xFDF2F7C2


function PED.SET_PED_VISUAL_FIELD_PERIPHERAL_RANGE(ped, range)


  Velora.invoke(0xA92B80,"void", ped, range)


end


-- PC:0x3B6405E8AB34A907 Old:0xE57202A1


function PED.SET_PED_VISUAL_FIELD_CENTER_ANGLE(ped, angle)


  Velora.invoke(0xA92BE0,"void", ped, angle)


end


function PED.GET_PED_VISUAL_FIELD_CENTER_ANGLE(ped)


  return Velora.invoke(0xA92CA0,"float", ped)


end


-- PC:0x88CBB5CEB96B7BD2 Old:0x67E28E1D


function PED.SET_PED_STEALTH_MOVEMENT(ped, p1, action)


  Velora.invoke(0xA92CA0,"void", ped, p1, action)


end


-- PC:0x7C2AC9CA66575FBF Old:0x40321B83


function PED.GET_PED_STEALTH_MOVEMENT(ped)


  return Velora.invoke(0xA92E40,"bool", ped)


end


-- PC:0x90370EBE0FEE1A3D Old:0x8DC0368D


function PED.CREATE_GROUP(unused)


  return Velora.invoke(0xA92DC0,"int", unused)


end


-- PC:0x2A7819605465FBCE Old:0x7265BEA2


function PED.SET_PED_AS_GROUP_LEADER(ped, groupId)


  Velora.invoke(0xA92E40,"void", ped, groupId)


end


-- PC:0x9F3480FE65DB31B5 Old:0x0EE13F92


function PED.SET_PED_AS_GROUP_MEMBER(ped, groupId)


  Velora.invoke(0xA92E50,"void", ped, groupId)


end


-- PC:0x2E2F4240B3F24647 Old:0xD0D8BDBC


function PED.SET_PED_CAN_TELEPORT_TO_GROUP_LEADER(pedHandle, groupHandle, toggle)


  Velora.invoke(0xA92E60,"void", pedHandle, groupHandle, toggle)


end


-- PC:0x8EB2F69076AF7053 Old:0x48D72B88


function PED.REMOVE_GROUP(groupId)


  Velora.invoke(0xA92E80,"void", groupId)


end


-- PC:0xED74007FFB146BC2 Old:0x82697713


function PED.REMOVE_PED_FROM_GROUP(ped)


  Velora.invoke(0xA92E90,"void", ped)


end


-- PC:0x9BB01E3834671191 Old:0x876D5363


function PED.IS_PED_GROUP_MEMBER(ped, groupId)


  return Velora.invoke(0xA92F70,"bool", ped, groupId)


end


-- PC:0x1C86D8AEF8254B78 Old:0x9678D4FF


function PED.IS_PED_HANGING_ON_TO_VEHICLE(ped)


  return Velora.invoke(0xA92ED0,"bool", ped)


end


-- PC:0x4102C7858CFEE4E4 Old:0x7B820CD5


function PED.SET_GROUP_SEPARATION_RANGE(groupHandle, separationRange)


  Velora.invoke(0xA92F70,"void", groupHandle, separationRange)


end


-- PC:0xFA0675AB151073FA Old:0x2F0D0973


function PED.SET_PED_MIN_GROUND_TIME_FOR_STUNGUN(ped, ms)


  Velora.invoke(0xA92F80,"void", ped, ms)


end


-- PC:0xD6A86331A537A7B9 Old:0x02C2A6C3


function PED.IS_PED_PRONE(ped)


  return Velora.invoke(0xA93820,"bool", ped)


end


-- PC:0x4859F1FC66A6278E Old:0xFE027CB5


function PED.IS_PED_IN_COMBAT(ped, target)


  return Velora.invoke(0xA93020,"bool", ped, target)


end


function PED.GET_PED_TARGET_FROM_COMBAT_PED(ped, p1)


  return Velora.invoke(0xA93050,"int", ped, p1)


end


-- PC:0xEAD42DE3610D0721 Old:0xCCD525E1


function PED.CAN_PED_IN_COMBAT_SEE_TARGET(ped, target)


  return Velora.invoke(0xA93080,"bool", ped, target)


end


-- PC:0xB2C086CC1BF8F2BF Old:0xAC3CEB9C


function PED.IS_PED_DOING_DRIVEBY(ped)


  return Velora.invoke(0xA93130,"bool", ped)


end


-- PC:0x4AE4FF911DFB61DA Old:0x3B321816


function PED.IS_PED_JACKING(ped)


  return Velora.invoke(0xA931C0,"bool", ped)


end


-- PC:0x9A497FE2DF198913 Old:0xD45D605C


function PED.IS_PED_BEING_JACKED(ped)


  return Velora.invoke(0xA931F0,"bool", ped)


end


-- PC:0x4FBACCE3B4138EE8 Old:0x0A66CE30


function PED.IS_PED_BEING_STUNNED(ped, p1)


  return Velora.invoke(0xA93220,"bool", ped, p1)


end


-- PC:0x9B128DC36C1E04CF Old:0xDE1DBB59


function PED.GET_PEDS_JACKER(ped)


  return Velora.invoke(0xA93250,"int", ped)


end


-- PC:0x5486A79D9FBD342D Old:0x1D196361


function PED.GET_JACK_TARGET(ped)


  return Velora.invoke(0xA93270,"int", ped)


end


-- PC:0xBBCCE00B381F8482 Old:0x85D813C6


function PED.IS_PED_FLEEING(ped)


  return Velora.invoke(0xA93290,"bool", ped)


end


-- PC:0x60DFD0691A170B88 Old:0x972C5A8B


function PED.IS_PED_IN_COVER(ped, exceptUseWeapon)


  return Velora.invoke(0xA932C0,"bool", ped, exceptUseWeapon)


end


-- PC:0x845333B3150583AB Old:0xB89DBB80


function PED.IS_PED_IN_COVER_FACING_LEFT(ped)


  return Velora.invoke(0xA932F0,"bool", ped)


end


-- PC:0x6A03BF943D767C93 Old:0xDD5D08A7


function PED.IS_PED_IN_HIGH_COVER(ped)


  return Velora.invoke(0xA93320,"bool", ped)


end


-- PC:0x9F65DBC537E59AD5 Old:0xA3589628


function PED.IS_PED_GOING_INTO_COVER(ped)


  return Velora.invoke(0xA93350,"bool", ped)


end


-- PC:0xAAD6D1ACF08F4612 Old:0xCC78999D


function PED.SET_PED_PINNED_DOWN(ped, pinned, i)


  return Velora.invoke(0xA93410,"bool", ped, pinned, i)


end


-- PC:0x6F4C85ACD641BCD2 Old:0xACF162E0


function PED.GET_SEAT_PED_IS_TRYING_TO_ENTER(ped)


  return Velora.invoke(0xA935A0,"int", ped)


end


-- PC:0x814FA8BE5449445D Old:0x99968B37


function PED.GET_VEHICLE_PED_IS_TRYING_TO_ENTER(ped)


  return Velora.invoke(0xA935C0,"int", ped)


end


-- PC:0x93C8B64DEB84728C Old:0x84ADF9EB


function PED.GET_PED_SOURCE_OF_DEATH(ped)


  return Velora.invoke(0xA935E0,"int", ped)


end


-- PC:0x16FFE42AB2D2DC59 Old:0x63458C27


function PED.GET_PED_CAUSE_OF_DEATH(ped)


  return Velora.invoke(0xA93640,"int", ped)


end


-- PC:0x1E98817B311AE98A Old:0xDF6D5D54


function PED.GET_PED_TIME_OF_DEATH(ped)


  return Velora.invoke(0xA93690,"int", ped)


end


-- PC:0x5407B7288D0478B7 Old:0xEF0B78E6


function PED.COUNT_PEDS_IN_COMBAT_WITH_TARGET(ped)


  return Velora.invoke(0xA936E0,"int", ped)


end


-- PC:0x336B3D200AB007CB Old:0xFB18CB19


function PED.COUNT_PEDS_IN_COMBAT_WITH_TARGET_WITHIN_RADIUS(ped, x, y, z, radius)


  return Velora.invoke(0xA93750,"int", ped, x, y, z, radius)


end


-- PC:0xADB3F206518799E8 Old:0x423B7BA2


function PED.SET_PED_RELATIONSHIP_GROUP_DEFAULT_HASH(ped, hash)


  Velora.invoke(0xA93820,"void", ped, hash)


end


-- PC:0xC80A74AC829DDD92 Old:0x79F8C18C


function PED.SET_PED_RELATIONSHIP_GROUP_HASH(ped, hash)


  Velora.invoke(0xA93880,"void", ped, hash)


end


-- PC:0xBF25EB89375A37AD Old:0xD4A215BA


function PED.SET_RELATIONSHIP_BETWEEN_GROUPS(relationship, group1, group2)


  Velora.invoke(0xA93890,"void", relationship, group1, group2)


end


-- PC:0x5E29243FB56FC6D4 Old:0x994B8C2D


function PED.CLEAR_RELATIONSHIP_BETWEEN_GROUPS(relationship, group1, group2)


  Velora.invoke(0xA93910,"void", relationship, group1, group2)


end


-- PC:0xF372BC22FCB88606 Old:0x8B635546


function PED.ADD_RELATIONSHIP_GROUP(name)


  return Velora.invoke(0xA939C0,"bool", name)


end


-- PC:0xB6BA2444AB393DA2 Old:0x4A1DC59A


function PED.REMOVE_RELATIONSHIP_GROUP(groupHash)


  Velora.invoke(0xA939C0,"void", groupHash)


end


function PED.DOES_RELATIONSHIP_GROUP_EXIST(groupHash)


  return Velora.invoke(0xA93BD0,"bool", groupHash)


end


-- PC:0xEBA5AD3A0EAF7121 Old:0xE254C39C


function PED.GET_RELATIONSHIP_BETWEEN_PEDS(ped1, ped2)


  return Velora.invoke(0xA93A00,"int", ped1, ped2)


end


-- PC:0x42FDD0F017B1E38E Old:0x714BD6E4


function PED.GET_PED_RELATIONSHIP_GROUP_DEFAULT_HASH(ped)


  return Velora.invoke(0xA93AB0,"int", ped)


end


-- PC:0x7DBDD04862D95F04 Old:0x354F283C


function PED.GET_PED_RELATIONSHIP_GROUP_HASH(ped)


  return Velora.invoke(0xA93B10,"int", ped)


end


-- PC:0x9E6B70061662AE5C Old:0x4E372FE2


function PED.GET_RELATIONSHIP_BETWEEN_GROUPS(group1, group2)


  return Velora.invoke(0xA93B70,"int", group1, group2)


end


function PED.SET_RELATIONSHIP_GROUP_AFFECTS_WANTED_LEVEL(group, p1)


  Velora.invoke(0xA93BD0,"void", group, p1)


end


function PED.TELL_GROUP_PEDS_IN_AREA_TO_ATTACK(ped, p1, p2, hash, p4, p5)


  Velora.invoke(0xA93C60,"void", ped, p1, p2, hash, p4, p5)


end


-- PC:0x4328652AE5769C71 Old:0x7FDDC0A6


function PED.SET_PED_CAN_BE_TARGETED_WITHOUT_LOS(ped, toggle)


  Velora.invoke(0xA93C80,"void", ped, toggle)


end


-- PC:0x112942C6E708F70B Old:0xD78AC46C


function PED.SET_PED_TO_INFORM_RESPECTED_FRIENDS(ped, radius, maxFriends)


  Velora.invoke(0xA93CE0,"void", ped, radius, maxFriends)


end


-- PC:0x625B774D75C87068 Old:0x7A877554


function PED.IS_PED_RESPONDING_TO_EVENT(ped, event)


  return Velora.invoke(0xA93E40,"bool", ped, event)


end


function PED.GET_POS_FROM_FIRED_EVENT(ped, eventType, outData)


  return Velora.invoke(0xA93DC0,"bool", ped, eventType, outData)


end


-- PC:0x9AC577F5A12AD8A9 Old:0xB4629D66


function PED.SET_PED_FIRING_PATTERN(ped, patternHash)


  Velora.invoke(0xA93E40,"void", ped, patternHash)


end


-- PC:0x614DA022990752DC Old:0xFB301746


function PED.SET_PED_SHOOT_RATE(ped, shootRate)


  Velora.invoke(0xA93E50,"void", ped, shootRate)


end


-- PC:0xFF41B4B141ED981C Old:0xD8B7637C


function PED.SET_COMBAT_FLOAT(ped, combatType, p2)


  Velora.invoke(0xA93F00,"void", ped, combatType, p2)


end


-- PC:0x52DFF8A10508090A Old:0x511D7EF8


function PED.GET_COMBAT_FLOAT(ped, p1)


  return Velora.invoke(0xA93FF0,"float", ped, p1)


end


-- PC:0x8DE69FE35CA09A45 Old:0xF7E1A691


function PED.GET_GROUP_SIZE(groupID, p1)


  Velora.invoke(0xA93FF0,"void", groupID, p1)


end


-- PC:0x7C6B0C22F9F40BBE Old:0x935C978D


function PED.DOES_GROUP_EXIST(groupId)


  return Velora.invoke(0xA94160,"bool", groupId)


end


-- PC:0xF162E133B4E7A675 Old:0x134E0785


function PED.GET_PED_GROUP_INDEX(ped)


  return Velora.invoke(0xA940C0,"int", ped)


end


-- PC:0x5891CAC5D4ACFF74 Old:0x836D9795


function PED.IS_PED_IN_GROUP(ped)


  return Velora.invoke(0xA940E0,"bool", ped)


end


-- PC:0x6A3975DEA89F9A17 Old:0xDE7442EE


function PED.GET_PLAYER_PED_IS_FOLLOWING(ped)


  return Velora.invoke(0xA94140,"int", ped)


end


-- PC:0xCE2F5FC3AF7E8C1E Old:0x08FAC739


function PED.SET_GROUP_FORMATION(groupId, formationType)


  Velora.invoke(0xA94160,"void", groupId, formationType)


end


-- PC:0x1D9D45004C28C916 Old:0xB1E086FF


function PED.SET_GROUP_FORMATION_SPACING(groupId, x, y, z)


  Velora.invoke(0xA941D0,"void", groupId, x, y, z)


end


-- PC:0x63DAB4CCB3273205 Old:0x267FCEAD


function PED.RESET_GROUP_FORMATION_DEFAULT_SPACING(groupHandle)


  Velora.invoke(0xA94280,"void", groupHandle)


end


-- PC:0x6094AD011A2EA87D Old:0x6DE3AADA


function PED.GET_VEHICLE_PED_IS_USING(ped)


  return Velora.invoke(0xA943A0,"int", ped)


end


-- PC:0xF92691AED837A5FC Old:0x56E0C163


function PED.GET_VEHICLE_PED_IS_ENTERING(ped)


  return Velora.invoke(0xA94380,"int", ped)


end


-- PC:0x9FF447B6B6AD960A Old:0x3CA16652


function PED.SET_PED_GRAVITY(ped, toggle)


  Velora.invoke(0xA943A0,"void", ped, toggle)


end


-- PC:0x697157CED63F18D4 Old:0x4DC27FCF


function PED.APPLY_DAMAGE_TO_PED(ped, damageAmount, p2, p3)


  Velora.invoke(0xA94490,"void", ped, damageAmount, p2, p3)


end


-- PC:0x36B77BB84687C318 Old:0x0170C6E1


function PED.GET_TIME_PED_DAMAGED_BY_WEAPON(ped, weaponHash)


  return Velora.invoke(0xA946B0,"int", ped, weaponHash)


end


-- PC:0xDA1F1B7BE1A8766F Old:0xC4D122F8


function PED.SET_PED_ALLOWED_TO_DUCK(ped, toggle)


  Velora.invoke(0xA946B0,"void", ped, toggle)


end


-- PC:0x3DBFC55D5C9BB447 Old:0x0E038813


function PED.SET_PED_NEVER_LEAVES_GROUP(ped, toggle)


  Velora.invoke(0xA94710,"void", ped, toggle)


end


-- PC:0xFF059E1E4C01E63C Old:0xB1460D43


function PED.GET_PED_TYPE(ped)


  return Velora.invoke(0xA947D0,"int", ped)


end


-- PC:0xBB03C38DD3FB7FFD Old:0x84E7DE9F


function PED.SET_PED_AS_COP(ped, toggle)


  Velora.invoke(0xA947D0,"void", ped, toggle)


end


function PED.SET_PED_HEALTH_PENDING_LAST_DAMAGE_EVENT_OVERRIDE_FLAG(toggle)


  Velora.invoke(0xA94860,"void", toggle)


end


-- PC:0xF5F6378C4F3419D3 Old:0x5533F60B


function PED.SET_PED_MAX_HEALTH(ped, value)


  Velora.invoke(0xA94890,"void", ped, value)


end


-- PC:0x4700A416E8324EF3 Old:0xA45B6C8D


function PED.GET_PED_MAX_HEALTH(ped)


  return Velora.invoke(0xA94950,"int", ped)


end


-- PC:0x43C851690662113D Old:0xFE0A106B


function PED.SET_PED_MAX_TIME_IN_WATER(ped, value)


  Velora.invoke(0xA94950,"void", ped, value)


end


-- PC:0x6BA428C528D9E522 Old:0x082EF240


function PED.SET_PED_MAX_TIME_UNDERWATER(ped, value)


  Velora.invoke(0xA949D0,"void", ped, value)


end


-- PC:0x2735233A786B1BEF Old:0x373CC405


function PED.SET_CORPSE_RAGDOLL_FRICTION(ped, p1)


  Velora.invoke(0xA94A30,"void", ped, p1)


end


-- PC:0x952F06BEECD775CC Old:0x79CA237B


function PED.SET_PED_VEHICLE_FORCED_SEAT_USAGE(ped, vehicle, seatIndex, flags, p4)


  Velora.invoke(0xA94A80,"void", ped, vehicle, seatIndex, flags, p4)


end


-- PC:0xE6CA85E7259CE16B Old:0xCC1D8F66


function PED.CLEAR_ALL_PED_VEHICLE_FORCED_SEAT_USAGE(ped)


  Velora.invoke(0xA94AA0,"void", ped)


end


function PED.SET_PED_CAN_BE_KNOCKED_OFF_BIKE(p0, p1)


  Velora.invoke(0xA94AF0,"void", p0, p1)


end


-- PC:0x7A6535691B477C48 Old:0x8A251612


function PED.SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(ped, state)


  Velora.invoke(0xA94B00,"void", ped, state)


end


-- PC:0x51AC07A44D4F5B8A Old:0xC9D098B3


function PED.CAN_KNOCK_PED_OFF_VEHICLE(ped)


  return Velora.invoke(0xA94C40,"bool", ped)


end


-- PC:0x45BBCBA77C29A841 Old:0xACDD0674


function PED.KNOCK_PED_OFF_VEHICLE(ped)


  Velora.invoke(0xA94C40,"void", ped)


end


-- PC:0x87052FE446E07247 Old:0x9561AD98


function PED.SET_PED_COORDS_NO_GANG(ped, posX, posY, posZ)


  Velora.invoke(0xA94C50,"void", ped, posX, posY, posZ)


end


-- PC:0x51455483CF23ED97 Old:0x9AA3CC8C


function PED.GET_PED_AS_GROUP_MEMBER(groupID, memberNumber)


  return Velora.invoke(0xA94DB0,"int", groupID, memberNumber)


end


-- PC:0x5CCE68DBD5FE93EC Old:0x52873C6A


function PED.GET_PED_AS_GROUP_LEADER(groupID)


  return Velora.invoke(0xA94D40,"int", groupID)


end


-- PC:0x971D38760FBC02EF Old:0xA7EC79CE


function PED.SET_PED_KEEP_TASK(ped, toggle)


  Velora.invoke(0xA94DB0,"void", ped, toggle)


end


-- PC:0x49E50BDB8BA4DAB2 Old:0x397F06E3


function PED.SET_PED_ALLOW_MINOR_REACTIONS_AS_MISSION_PED(ped, toggle)


  Velora.invoke(0xA94E10,"void", ped, toggle)


end


-- PC:0x9DE327631295B4C2 Old:0x7AB43DB8


function PED.IS_PED_SWIMMING(ped)


  return Velora.invoke(0xA94F30,"bool", ped)


end


-- PC:0xC024869A53992F34 Old:0x0E8D524F


function PED.IS_PED_SWIMMING_UNDER_WATER(ped)


  return Velora.invoke(0xA94EC0,"bool", ped)


end


-- PC:0x9AFEFF481A85AB2E Old:0xD66AE1D3


function PED.SET_PED_COORDS_KEEP_VEHICLE(ped, posX, posY, posZ)


  Velora.invoke(0xA94F30,"void", ped, posX, posY, posZ)


end


-- PC:0x2A30922C90C9B42C Old:0x6FE1E440


function PED.SET_PED_DIES_IN_VEHICLE(ped, toggle)


  Velora.invoke(0xA94FC0,"void", ped, toggle)


end


-- PC:0x102E68B2024D536D Old:0x23441648


function PED.SET_CREATE_RANDOM_COPS(toggle)


  Velora.invoke(0xA95020,"void", toggle)


end


-- PC:0x8A4986851C4EF6E7 Old:0x82E548CC


function PED.SET_CREATE_RANDOM_COPS_NOT_ON_SCENARIOS(toggle)


  Velora.invoke(0xA95050,"void", toggle)


end


-- PC:0x444CB7D7DBE6973D Old:0xEDC31475


function PED.SET_CREATE_RANDOM_COPS_ON_SCENARIOS(toggle)


  Velora.invoke(0xA95070,"void", toggle)


end


-- PC:0x5EE2CAFF7F17770D Old:0xAA73DAD9


function PED.CAN_CREATE_RANDOM_COPS()


  return Velora.invoke(0xA950B0,"bool")


end


-- PC:0x02A0C9720B854BFA Old:0xAE620A1B


function PED.SET_PED_AS_ENEMY(ped, toggle)


  Velora.invoke(0xA950B0,"void", ped, toggle)


end


-- PC:0x1CCE141467FF42A2 Old:0x149C60A8


function PED.SET_PED_CAN_SMASH_GLASS(ped, p1, p2)


  Velora.invoke(0xA95100,"void", ped, p1, p2)


end


-- PC:0x6F972C1AB75A1ED0 Old:0x759EF63A


function PED.IS_PED_IN_ANY_TRAIN(ped)


  return Velora.invoke(0xA952E0,"bool", ped)


end


-- PC:0xBB062B2B5722478E Old:0x90E805AC


function PED.IS_PED_GETTING_INTO_A_VEHICLE(ped)


  return Velora.invoke(0xA951F0,"bool", ped)


end


-- PC:0x44D28D5DDFE5F68C Old:0x46828B4E


function PED.IS_PED_TRYING_TO_ENTER_A_LOCKED_VEHICLE(ped)


  return Velora.invoke(0xA95220,"bool", ped)


end


-- PC:0xDF1AF8B5D56542FA Old:0xAC9BBA23


function PED.SET_ENABLE_HANDCUFFS(ped, toggle)


  Velora.invoke(0xA952E0,"void", ped, toggle)


end


-- PC:0xC52E0F855C58FC2E Old:0x9208D689


function PED.SET_ENABLE_BOUND_ANKLES(ped, toggle)


  Velora.invoke(0xA95360,"void", ped, toggle)


end


-- PC:0xF99F62004024D506 Old:0x7BF61471


function PED.SET_ENABLE_SCUBA(ped, toggle)


  Velora.invoke(0xA953E0,"void", ped, toggle)


end


-- PC:0xB3B1CB349FF9C75D Old:0x47C60963


function PED.SET_CAN_ATTACK_FRIENDLY(ped, toggle, p2)


  Velora.invoke(0xA95440,"void", ped, toggle, p2)


end


-- PC:0xF6AA118530443FD2 Old:0xF83E4DAF


function PED.GET_PED_ALERTNESS(ped)


  return Velora.invoke(0xA95520,"int", ped)


end


-- PC:0xDBA71115ED9941A6 Old:0x2C32D9AE


function PED.SET_PED_ALERTNESS(ped, value)


  Velora.invoke(0xA95520,"void", ped, value)


end


-- PC:0xBC0ED94165A48BC2 Old:0x89AD49FF


function PED.SET_PED_GET_OUT_UPSIDE_DOWN_VEHICLE(ped, toggle)


  Velora.invoke(0xA95570,"void", ped, toggle)


end


-- PC:0xAF8A94EDE7712BEF Old:0xA817CDEB


function PED.SET_PED_MOVEMENT_CLIPSET(ped, clipSet, transitionSpeed)


  Velora.invoke(0xA955D0,"void", ped, clipSet, transitionSpeed)


end


-- PC:0xAA74EC0CB0AAEA2C Old:0xB83CEE93


function PED.RESET_PED_MOVEMENT_CLIPSET(ped, p1)


  Velora.invoke(0xA955F0,"void", ped, p1)


end


-- PC:0x29A28F3F8CF6D854 Old:0x0BACF010


function PED.SET_PED_STRAFE_CLIPSET(ped, clipSet)


  Velora.invoke(0xA95660,"void", ped, clipSet)


end


-- PC:0x20510814175EA477 Old:0xF1967A12


function PED.RESET_PED_STRAFE_CLIPSET(ped)


  Velora.invoke(0xA95670,"void", ped)


end


-- PC:0x2622E35B77D3ACA2 Old:0xF8BE54DC


function PED.SET_PED_WEAPON_MOVEMENT_CLIPSET(ped, clipSet)


  Velora.invoke(0xA956D0,"void", ped, clipSet)


end


-- PC:0x97B0DB5B4AA74E77 Old:0xC60C9ACD


function PED.RESET_PED_WEAPON_MOVEMENT_CLIPSET(ped)


  Velora.invoke(0xA956E0,"void", ped)


end


-- PC:0xED34AB6C5CB36520 Old:0xD4C73595


function PED.SET_PED_DRIVE_BY_CLIPSET_OVERRIDE(ped, clipset)


  Velora.invoke(0xA95740,"void", ped, clipset)


end


-- PC:0x4AFE3690D7E0B5AC Old:0xAEC9163B


function PED.CLEAR_PED_DRIVE_BY_CLIPSET_OVERRIDE(ped)


  Velora.invoke(0xA95750,"void", ped)


end


function PED.SET_PED_MOTION_IN_COVER_CLIPSET_OVERRIDE(ped, p1)


  Velora.invoke(0xA957A0,"void", ped, p1)


end


function PED.CLEAR_PED_MOTION_IN_COVER_CLIPSET_OVERRIDE(ped)


  Velora.invoke(0xA957B0,"void", ped)


end


function PED.CLEAR_PED_FALL_UPPER_BODY_CLIPSET_OVERRIDE(ped)


  Velora.invoke(0xA95800,"void", ped)


end


-- PC:0x530071295899A8C6 Old:0x27F25C0E


function PED.SET_PED_IN_VEHICLE_CONTEXT(ped, context)


  Velora.invoke(0xA95850,"void", ped, context)


end


-- PC:0x22EF8FF8778030EB Old:0x3C94D88A


function PED.RESET_PED_IN_VEHICLE_CONTEXT(ped)


  Velora.invoke(0xA958C0,"void", ped)


end


-- PC:0x6EC47A344923E1ED Old:0x3C30B447


function PED.IS_SCRIPTED_SCENARIO_PED_USING_CONDITIONAL_ANIM(ped, animDict, anim)


  return Velora.invoke(0xA95950,"bool", ped, animDict, anim)


end


-- PC:0x6C60394CB4F75E9A Old:0x895E1D67


function PED.SET_PED_ALTERNATE_WALK_ANIM(ped, animDict, animName, p3, p4)


  Velora.invoke(0xA95950,"void", ped, animDict, animName, p3, p4)


end


-- PC:0x8844BBFCE30AA9E9 Old:0x5736FB23


function PED.CLEAR_PED_ALTERNATE_WALK_ANIM(ped, p1)


  Velora.invoke(0xA95980,"void", ped, p1)


end


-- PC:0x90A43CC281FFAB46 Old:0xBA84FD8C


function PED.SET_PED_ALTERNATE_MOVEMENT_ANIM(ped, stance, animDictionary, animationName, p4, p5)


  Velora.invoke(0xA95A20,"void", ped, stance, animDictionary, animationName, p4, p5)


end


-- PC:0xD8D19675ED5FBDCE Old:0x7A7F5BC3


function PED.CLEAR_PED_ALTERNATE_MOVEMENT_ANIM(ped, stance, p2)


  Velora.invoke(0xA95A50,"void", ped, stance, p2)


end


-- PC:0xDDF803377F94AAA8 Old:0x170DA109


function PED.SET_PED_GESTURE_GROUP(ped, animGroupGesture)


  Velora.invoke(0xA95B00,"void", ped, animGroupGesture)


end


-- PC:0xBE22B26DD764C040 Old:0xC59D4268


function PED.GET_ANIM_INITIAL_OFFSET_POSITION(animDict, animName, x, y, z, xRot, yRot, zRot, p8, p9)


  local x,y,z=Velora.invoke(0xA960A0,"vector3", animDict, animName, x, y, z, xRot, yRot, zRot, p8, p9)


  return {x=x,y=y,z=z}


end


-- PC:0x4B805E6046EE9E47 Old:0x5F7789E6


function PED.GET_ANIM_INITIAL_OFFSET_ROTATION(animDict, animName, x, y, z, xRot, yRot, zRot, p8, p9)


  local x,y,z=Velora.invoke(0xA95CA0,"vector3", animDict, animName, x, y, z, xRot, yRot, zRot, p8, p9)


  return {x=x,y=y,z=z}


end


-- PC:0x67F3780DD425D4FC Old:0x29850FE2


function PED.GET_PED_DRAWABLE_VARIATION(ped, componentId)


  return Velora.invoke(0xA95DB0,"int", ped, componentId)


end


-- PC:0x27561561732A7842 Old:0x9754C27D


function PED.GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(ped, componentId)


  return Velora.invoke(0xA95E20,"int", ped, componentId)


end


-- PC:0x04A355E041E004E6 Old:0xC0A8590A


function PED.GET_PED_TEXTURE_VARIATION(ped, componentId)


  return Velora.invoke(0xA95E50,"int", ped, componentId)


end


-- PC:0x8F7156A3142A6BAD Old:0x83D9FBE7


function PED.GET_NUMBER_OF_PED_TEXTURE_VARIATIONS(ped, componentId, drawableId)


  return Velora.invoke(0xA95EC0,"int", ped, componentId, drawableId)


end


-- PC:0x5FAF9754E789FB47 Old:0xC9780B95


function PED.GET_NUMBER_OF_PED_PROP_DRAWABLE_VARIATIONS(ped, propId)


  return Velora.invoke(0xA95EF0,"int", ped, propId)


end


-- PC:0xA6E7F1CEB523E171 Old:0x4892B882


function PED.GET_NUMBER_OF_PED_PROP_TEXTURE_VARIATIONS(ped, propId, drawableId)


  return Velora.invoke(0xA95F20,"int", ped, propId, drawableId)


end


-- PC:0xE3DD5F2A84B42281 Old:0xEF1BC082


function PED.GET_PED_PALETTE_VARIATION(ped, componentId)


  return Velora.invoke(0xA95F50,"int", ped, componentId)


end


-- PC:0x9E30E91FB03A2CAF Old:0x52559BB6


function PED.GET_MP_OUTFIT_DATA_FROM_METADATA(p0, p1)


  return Velora.invoke(0xA95FB0,"bool", p0, p1)


end


-- PC:0x1E77FA7A62EE6C4C Old:0x021F5B36


function PED.GET_FM_MALE_SHOP_PED_APPAREL_ITEM_INDEX(p0)


  return Velora.invoke(0xA95FE0,"int", p0)


end


-- PC:0xF033419D1B81FAE8 Old:0x8FDDB5DB


function PED.GET_FM_FEMALE_SHOP_PED_APPAREL_ITEM_INDEX(p0)


  return Velora.invoke(0xA96000,"int", p0)


end


-- PC:0xE825F6B6CEA7671D Old:0x952ABD9A


function PED.IS_PED_COMPONENT_VARIATION_VALID(ped, componentId, drawableId, textureId)


  return Velora.invoke(0xA96020,"bool", ped, componentId, drawableId, textureId)


end


-- PC:0x262B14F48D29DE80 Old:0xD4F7B05C


function PED.SET_PED_COMPONENT_VARIATION(ped, componentId, drawableId, textureId, paletteId)


  Velora.invoke(0xA960A0,"void", ped, componentId, drawableId, textureId, paletteId)


end


-- PC:0xC8A9481A01E63C28 Old:0x4111BA46


function PED.SET_PED_RANDOM_COMPONENT_VARIATION(ped, p1)


  Velora.invoke(0xA96160,"void", ped, p1)


end


-- PC:0xC44AA05345C992C6 Old:0xE3318E0E


function PED.SET_PED_RANDOM_PROPS(ped)


  Velora.invoke(0xA96200,"void", ped)


end


-- PC:0x45EEE61580806D63 Old:0xC866A984


function PED.SET_PED_DEFAULT_COMPONENT_VARIATION(ped)


  Velora.invoke(0xA962B0,"void", ped)


end


-- PC:0x137BBD05230DB22D Old:0x837BD370


function PED.SET_PED_BLEND_FROM_PARENTS(ped, p1, p2, p3, p4)


  Velora.invoke(0xA96330,"void", ped, p1, p2, p3, p4)


end


-- PC:0x9414E18B9434C2FE Old:0x60746B88


function PED.SET_PED_HEAD_BLEND_DATA(ped, shapeFirstID, shapeSecondID, shapeThirdID, skinFirstID, skinSecondID, skinThirdID, shapeMix, skinMix, thirdMix, isParent)


  Velora.invoke(0xA96350,"void", ped, shapeFirstID, shapeSecondID, shapeThirdID, skinFirstID, skinSecondID, skinThirdID, shapeMix, skinMix, thirdMix, isParent)


end


-- PC:0x2746BD9D88C5C5D0 Old:0x44E1680C


function PED.GET_PED_HEAD_BLEND_DATA(ped, headBlendData)


  return Velora.invoke(0xA965A0,"bool", ped, headBlendData)


end


-- PC:0x723538F61C647C5A Old:0x5CB76219


function PED.UPDATE_PED_HEAD_BLEND_DATA(ped, shapeMix, skinMix, thirdMix)


  Velora.invoke(0xA965A0,"void", ped, shapeMix, skinMix, thirdMix)


end


function PED.SET_HEAD_BLEND_EYE_COLOR(ped, index)


  Velora.invoke(0xA96620,"void", ped, index)


end


function PED.GET_HEAD_BLEND_EYE_COLOR(ped)


  return Velora.invoke(0xA966D0,"int", ped)


end


-- PC:0x48F44967FA05CC1E Old:0xD28DBA90


function PED.SET_PED_HEAD_OVERLAY(ped, overlayID, index, opacity)


  Velora.invoke(0xA966D0,"void", ped, overlayID, index, opacity)


end


function PED.GET_PED_HEAD_OVERLAY(ped, overlayID)


  return Velora.invoke(0xA968E0,"int", ped, overlayID)


end


-- PC:0xCF1CE768BB43480E Old:0xFF43C18D


function PED.GET_PED_HEAD_OVERLAY_NUM(overlayID)


  return Velora.invoke(0xA967C0,"int", overlayID)


end


function PED.SET_PED_HEAD_OVERLAY_TINT(ped, overlayID, colorType, colorID, secondColorID)


  Velora.invoke(0xA968E0,"void", ped, overlayID, colorType, colorID, secondColorID)


end


function PED.SET_PED_HAIR_TINT(ped, colorID, highlightColorID)


  Velora.invoke(0xA96960,"void", ped, colorID, highlightColorID)


end


function PED.GET_NUM_PED_HAIR_TINTS()


  return Velora.invoke(0xA969E0,"int")


end


function PED.GET_NUM_PED_MAKEUP_TINTS()


  return Velora.invoke(0xA969D0,"int")


end


function PED.GET_PED_HAIR_TINT_COLOR(hairColorIndex)


  Velora.invoke(0xA969E0,"void", hairColorIndex)


end


function PED.GET_PED_MAKEUP_TINT_COLOR(makeupColorIndex)


  Velora.invoke(0xA96A30,"void", makeupColorIndex)


end


function PED.IS_PED_HAIR_TINT_FOR_CREATOR(colorId)


  return Velora.invoke(0xA96E10,"bool", colorId)


end


function PED.GET_DEFAULT_SECONDARY_TINT_FOR_CREATOR(colorId)


  return Velora.invoke(0xA96AD0,"int", colorId)


end


function PED.IS_PED_LIPSTICK_TINT_FOR_CREATOR(colorId)


  return Velora.invoke(0xA96B10,"bool", colorId)


end


function PED.IS_PED_BLUSH_TINT_FOR_CREATOR(colorId)


  return Velora.invoke(0xA96B60,"bool", colorId)


end


function PED.IS_PED_HAIR_TINT_FOR_BARBER(colorID)


  return Velora.invoke(0xA96BB0,"bool", colorID)


end


function PED.GET_DEFAULT_SECONDARY_TINT_FOR_BARBER(colorID)


  return Velora.invoke(0xA96C00,"int", colorID)


end


function PED.IS_PED_LIPSTICK_TINT_FOR_BARBER(colorID)


  return Velora.invoke(0xA96C40,"bool", colorID)


end


function PED.IS_PED_BLUSH_TINT_FOR_BARBER(colorID)


  return Velora.invoke(0xA96C90,"bool", colorID)


end


function PED.IS_PED_BLUSH_FACEPAINT_TINT_FOR_BARBER(colorId)


  return Velora.invoke(0xA96CE0,"bool", colorId)


end


function PED.GET_TINT_INDEX_FOR_LAST_GEN_HAIR_TEXTURE(modelHash, drawableId, textureId)


  return Velora.invoke(0xA96D30,"int", modelHash, drawableId, textureId)


end


function PED.SET_PED_MICRO_MORPH(ped, index, scale)


  Velora.invoke(0xA96E10,"void", ped, index, scale)


end


-- PC:0x654CD0A825161131 Old:0x2B1BD9C5


function PED.HAS_PED_HEAD_BLEND_FINISHED(ped)


  return Velora.invoke(0xA96EE0,"bool", ped)


end


-- PC:0x4668D80430D6C299 Old:0x894314A4


function PED.FINALIZE_HEAD_BLEND(ped)


  Velora.invoke(0xA96EE0,"void", ped)


end


-- PC:0xCC9682B8951C5229 Old:0x57E5B3F9


function PED.SET_HEAD_BLEND_PALETTE_COLOR(ped, r, g, b, id)


  Velora.invoke(0xA96F30,"void", ped, r, g, b, id)


end


-- PC:0xA21C118553BBDF02 Old:0xC6F36292


function PED.DISABLE_HEAD_BLEND_PALETTE_COLOR(ped)


  Velora.invoke(0xA96FF0,"void", ped)


end


-- PC:0x68D353AB88B97E0C Old:0x211DEFEC


function PED.GET_PED_HEAD_BLEND_FIRST_INDEX(type)


  return Velora.invoke(0xA97230,"int", type)


end


-- PC:0x5EF37013A6539C9D Old:0x095D3BD8


function PED.GET_PED_HEAD_BLEND_NUM_HEADS(type)


  return Velora.invoke(0xA970A0,"int", type)


end


-- PC:0x39D55A620FCB6A3A Old:0x45F3BDFB


function PED.SET_PED_PRELOAD_VARIATION_DATA(ped, slot, drawableId, textureId)


  return Velora.invoke(0xA97110,"int", ped, slot, drawableId, textureId)


end


-- PC:0x66680A92700F43DF Old:0xC6517D52


function PED.HAS_PED_PRELOAD_VARIATION_DATA_FINISHED(ped)


  return Velora.invoke(0xA971D0,"bool", ped)


end


-- PC:0x5AAB586FFEC0FD96 Old:0x6435F67F


function PED.RELEASE_PED_PRELOAD_VARIATION_DATA(ped)


  Velora.invoke(0xA97230,"void", ped)


end


-- PC:0x2B16A3BFF1FBCE49 Old:0xC0E23671


function PED.SET_PED_PRELOAD_PROP_DATA(ped, componentId, drawableId, TextureId)


  return Velora.invoke(0xA973A0,"int", ped, componentId, drawableId, TextureId)


end


-- PC:0x784002A632822099 Old:0x3B0CA391


function PED.HAS_PED_PRELOAD_PROP_DATA_FINISHED(ped)


  return Velora.invoke(0xA97340,"bool", ped)


end


-- PC:0xF79F9DEF0AADE61A Old:0xFD103BA7


function PED.RELEASE_PED_PRELOAD_PROP_DATA(ped)


  Velora.invoke(0xA973A0,"void", ped)


end


-- PC:0x898CC20EA75BACD8 Old:0x746DDAC0


function PED.GET_PED_PROP_INDEX(ped, componentId, p2)


  return Velora.invoke(0xA97450,"int", ped, componentId, p2)


end


-- PC:0x93376B65A266EB5F Old:0x0829F2E2


function PED.SET_PED_PROP_INDEX(ped, componentId, drawableId, TextureId, attach)


  Velora.invoke(0xA97450,"void", ped, componentId, drawableId, TextureId, attach)


end


-- PC:0x6FD7816A36615F48 Old:0x08D8B180


function PED.KNOCK_OFF_PED_PROP(ped, p1, p2, p3, p4)


  Velora.invoke(0xA97480,"void", ped, p1, p2, p3, p4)


end


-- PC:0x0943E5B8E078E76E Old:0x2D23D743


function PED.CLEAR_PED_PROP(ped, propId, p2)


  Velora.invoke(0xA97520,"void", ped, propId, p2)


end


-- PC:0xCD8A7537A9B52F06 Old:0x81DF8B43


function PED.CLEAR_ALL_PED_PROPS(ped, p1)


  Velora.invoke(0xA97580,"void", ped, p1)


end


-- PC:0xAFF4710E2A0A6C12 Old:0x728D3D53


function PED.DROP_AMBIENT_PROP(ped)


  Velora.invoke(0xA975D0,"void", ped)


end


-- PC:0xE131A28626F81AB2 Old:0x922A6653


function PED.GET_PED_PROP_TEXTURE_INDEX(ped, componentId)


  return Velora.invoke(0xA976C0,"int", ped, componentId)


end


-- PC:0x1280804F7CFD2D6C Old:0x7BCD8991


function PED.CLEAR_PED_PARACHUTE_PACK_VARIATION(ped)


  Velora.invoke(0xA976C0,"void", ped)


end


function PED.SET_PED_SCUBA_GEAR_VARIATION(ped)


  Velora.invoke(0xA97710,"void", ped)


end


-- PC:0xB50EB4CCB29704AC Old:0x080275EE


function PED.CLEAR_PED_SCUBA_GEAR_VARIATION(ped)


  Velora.invoke(0xA97760,"void", ped)


end


function PED.IS_USING_PED_SCUBA_GEAR_VARIATION(p0)


  return Velora.invoke(0xA97810,"bool", p0)


end


-- PC:0x9F8AA94D6D97DBF4 Old:0xDFE34E4A


function PED.SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(ped, toggle)


  Velora.invoke(0xA97810,"void", ped, toggle)


end


-- PC:0x4F5F651ACCC9C4CF Old:0xCFA20D68


function PED.SET_PED_BOUNDS_ORIENTATION(ped, p1, p2, x, y, z)


  Velora.invoke(0xA97830,"void", ped, p1, p2, x, y, z)


end


-- PC:0x2F25D9AEFA34FBA2 Old:0x50A95442


function PED.REGISTER_TARGET(ped, target)


  Velora.invoke(0xA978D0,"void", ped, target)


end


-- PC:0x9222F300BF8354FE Old:0x7F87559E


function PED.REGISTER_HATED_TARGETS_AROUND_PED(ped, radius)


  Velora.invoke(0xA97980,"void", ped, radius)


end


-- PC:0x876046A8E3A4B71C Old:0xDC8239EB


function PED.GET_RANDOM_PED_AT_COORD(x, y, z, xRadius, yRadius, zRadius, pedType)


  return Velora.invoke(0xA97B50,"int", x, y, z, xRadius, yRadius, zRadius, pedType)


end


-- PC:0xC33AB876A77F8164 Old:0x8F6C1F55


function PED.GET_CLOSEST_PED(x, y, z, radius, p4, p5, p7, p8, pedType)


  return Velora.invoke(0xA97A50,"bool", x, y, z, radius, p4, p5, p7, p8, pedType)


end


-- PC:0x14F19A8782C8071E Old:0x85615FD0


function PED.SET_SCENARIO_PEDS_TO_BE_RETURNED_BY_NEXT_COMMAND(value)


  Velora.invoke(0xA97B50,"void", value)


end


-- PC:0x03EA03AF85A85CB7 Old:0x18DD76A1


function PED.GET_CAN_PED_BE_GRABBED_BY_SCRIPT(ped, p1, p2, p3, p4, p5, p6, p7, p8)


  return Velora.invoke(0xA97C60,"bool", ped, p1, p2, p3, p4, p5, p6, p7, p8)


end


-- PC:0xDED5AF5A0EA4B297 Old:0x6D55B3B3


function PED.SET_DRIVER_RACING_MODIFIER(driver, modifier)


  Velora.invoke(0xA97C60,"void", driver, modifier)


end


-- PC:0xB195FFA8042FC5C3 Old:0xAAD4012C


function PED.SET_DRIVER_ABILITY(driver, ability)


  Velora.invoke(0xA97CD0,"void", driver, ability)


end


-- PC:0xA731F608CA104E3C Old:0x8B02A8FB


function PED.SET_DRIVER_AGGRESSIVENESS(driver, aggressiveness)


  Velora.invoke(0xA97D40,"void", driver, aggressiveness)


end


-- PC:0x128F79EDCECE4FD5 Old:0xC0EFB7A3


function PED.CAN_PED_RAGDOLL(ped)


  return Velora.invoke(0xA97EE0,"bool", ped)


end


-- PC:0xAE99FB955581844A Old:0x83CB5052


function PED.SET_PED_TO_RAGDOLL(ped, time1, time2, ragdollType, p4, p5, p6)


  return Velora.invoke(0xA97E30,"bool", ped, time1, time2, ragdollType, p4, p5, p6)


end


-- PC:0xD76632D99E4966C8 Old:0xFA12E286


function PED.SET_PED_TO_RAGDOLL_WITH_FALL(ped, time, p2, ragdollType, x, y, z, velocity, p8, p9, p10, p11, p12, p13)


  return Velora.invoke(0xA97E90,"bool", ped, time, p2, ragdollType, x, y, z, velocity, p8, p9, p10, p11, p12, p13)


end


-- PC:0xF0A4F1BBF4FA7497 Old:0x2654A0F4


function PED.SET_PED_RAGDOLL_ON_COLLISION(ped, toggle)


  Velora.invoke(0xA97EE0,"void", ped, toggle)


end


-- PC:0x47E4E977581C5B55 Old:0xC833BBE1


function PED.IS_PED_RAGDOLL(ped)


  return Velora.invoke(0xA98000,"bool", ped)


end


-- PC:0xE3B6097CC25AA69E Old:0x44A153F2


function PED.IS_PED_RUNNING_RAGDOLL_TASK(ped)


  return Velora.invoke(0xA97F70,"bool", ped)


end


-- PC:0x01F6594B923B9251 Old:0x20A5BDE0


function PED.SET_PED_RAGDOLL_FORCE_FALL(ped)


  Velora.invoke(0xA98000,"void", ped)


end


-- PC:0x9FA4664CF62E47E8 Old:0xF2865370


function PED.RESET_PED_RAGDOLL_TIMER(ped)


  Velora.invoke(0xA98080,"void", ped)


end


-- PC:0xB128377056A54E2A Old:0xCF1384C4


function PED.SET_PED_CAN_RAGDOLL(ped, toggle)


  Velora.invoke(0xA980F0,"void", ped, toggle)


end


-- PC:0xD1871251F3B5ACD7 Old:0xBD4236F6


function PED.IS_PED_RUNNING_MELEE_TASK(ped)


  return Velora.invoke(0xA98250,"bool", ped)


end


-- PC:0x2AFE52F782F25775 Old:0xFB2AFED1


function PED.IS_PED_RUNNING_MOBILE_PHONE_TASK(ped)


  return Velora.invoke(0xA98170,"bool", ped)


end


-- PC:0xA3F3564A5B3646C0 Old:0x97353375


function PED.IS_MOBILE_PHONE_TO_PED_EAR(ped)


  return Velora.invoke(0xA981C0,"bool", ped)


end


-- PC:0x26695EC767728D84 Old:0x9C8F830D


function PED.SET_RAGDOLL_BLOCKING_FLAGS(ped, blockingFlag)


  Velora.invoke(0xA98250,"void", ped, blockingFlag)


end


-- PC:0xD86D101FCFD00A4B Old:0x77CBA290


function PED.CLEAR_RAGDOLL_BLOCKING_FLAGS(ped, blockingFlag)


  Velora.invoke(0xA98260,"void", ped, blockingFlag)


end


-- PC:0xC7F76DF27A5045A1 Old:0x3EFBDD9B


function PED.SET_PED_ANGLED_DEFENSIVE_AREA(ped, p1, p2, p3, p4, p5, p6, p7, p8, p9)


  Velora.invoke(0xA982D0,"void", ped, p1, p2, p3, p4, p5, p6, p7, p8, p9)


end


-- PC:0x9D3151A373974804 Old:0xBD96D8E8


function PED.SET_PED_SPHERE_DEFENSIVE_AREA(ped, x, y, z, radius, p5, p6)


  Velora.invoke(0xA98300,"void", ped, x, y, z, radius, p5, p6)


end


-- PC:0xF9B8F91AAD3B953E Old:0x40638BDC


function PED.SET_PED_DEFENSIVE_SPHERE_ATTACHED_TO_PED(ped, target, xOffset, yOffset, zOffset, radius, p6)


  Velora.invoke(0xA983F0,"void", ped, target, xOffset, yOffset, zOffset, radius, p6)


end


-- PC:0xE4723DB6E736CCFF Old:0x4763B2C6


function PED.SET_PED_DEFENSIVE_SPHERE_ATTACHED_TO_VEHICLE(ped, target, xOffset, yOffset, zOffset, radius, p6)


  Velora.invoke(0xA98420,"void", ped, target, xOffset, yOffset, zOffset, radius, p6)


end


-- PC:0x4EF47FE21698A8B6 Old:0x74BDA7CE


function PED.SET_PED_DEFENSIVE_AREA_ATTACHED_TO_PED(ped, attachPed, p2, p3, p4, p5, p6, p7, p8, p9, p10)


  Velora.invoke(0xA98450,"void", ped, attachPed, p2, p3, p4, p5, p6, p7, p8, p9, p10)


end


-- PC:0x413C6C763A4AFFAD Old:0xB66B0C9A


function PED.SET_PED_DEFENSIVE_AREA_DIRECTION(ped, p1, p2, p3, p4)


  Velora.invoke(0xA98490,"void", ped, p1, p2, p3, p4)


end


-- PC:0x74D4E028107450A9 Old:0x34AAAFA5


function PED.REMOVE_PED_DEFENSIVE_AREA(ped, toggle)


  Velora.invoke(0xA98550,"void", ped, toggle)


end


-- PC:0x3C06B8786DD94CD1 Old:0xCB65198D


function PED.GET_PED_DEFENSIVE_AREA_POSITION(ped, p1)


  local x,y,z=Velora.invoke(0xA986A0,"vector3", ped, p1)


  return {x=x,y=y,z=z}


end


-- PC:0xBA63D9FE45412247 Old:0x6D88BCD3


function PED.IS_PED_DEFENSIVE_AREA_ACTIVE(ped, p1)


  return Velora.invoke(0xA98620,"bool", ped, p1)


end


-- PC:0x8421EB4DA7E391B9 Old:0xF3B7EFBF


function PED.SET_PED_PREFERRED_COVER_SET(ped, itemSet)


  Velora.invoke(0xA986A0,"void", ped, itemSet)


end


-- PC:0xFDDB234CF74073D9 Old:0xA0134498


function PED.REMOVE_PED_PREFERRED_COVER_SET(ped)


  Velora.invoke(0xA986F0,"void", ped)


end


-- PC:0x8D8ACD8388CD99CE Old:0x14D3E6E3


function PED.REVIVE_INJURED_PED(ped)


  Velora.invoke(0xA98740,"void", ped)


end


-- PC:0x71BC8E838B9C6035 Old:0xA4B82097


function PED.RESURRECT_PED(ped)


  Velora.invoke(0xA987D0,"void", ped)


end


-- PC:0x98EFA132A4117BE1 Old:0x20D6273E


function PED.SET_PED_NAME_DEBUG(ped, name)


  Velora.invoke(0xA98870,"void", ped, name)


end


-- PC:0xE0AF41401ADF87E3 Old:0x5231F901


function PED.GET_PED_EXTRACTED_DISPLACEMENT(ped, worldSpace)


  local x,y,z=Velora.invoke(0xA98960,"vector3", ped, worldSpace)


  return {x=x,y=y,z=z}


end


-- PC:0x5BA7919BED300023 Old:0xE94E24D4


function PED.SET_PED_DIES_WHEN_INJURED(ped, toggle)


  Velora.invoke(0xA98960,"void", ped, toggle)


end


-- PC:0x97A790315D3831FD Old:0x4CAD1A4A


function PED.SET_PED_ENABLE_WEAPON_BLOCKING(ped, toggle)


  Velora.invoke(0xA989D0,"void", ped, toggle)


end


-- PC:0xF9ACF4A08098EA25 Old:0x141CC936


function PED.SPECIAL_FUNCTION_DO_NOT_USE(ped, p1)


  Velora.invoke(0xA98A30,"void", ped, p1)


end


-- PC:0x3AC1F7B898F30C05 Old:0xC4BC4841


function PED.RESET_PED_VISIBLE_DAMAGE(ped)


  Velora.invoke(0xA98AB0,"void", ped)


end


-- PC:0x816F6981C60BF53B Old:0x1E54DB12


function PED.APPLY_PED_BLOOD_DAMAGE_BY_ZONE(ped, p1, p2, p3, p4)


  Velora.invoke(0xA98B00,"void", ped, p1, p2, p3, p4)


end


-- PC:0x83F7E01C7B769A26 Old:0x376CE3C0


function PED.APPLY_PED_BLOOD(ped, boneIndex, xRot, yRot, zRot, woundType)


  Velora.invoke(0xA98C50,"void", ped, boneIndex, xRot, yRot, zRot, woundType)


end


-- PC:0x3311E47B91EDCBBC Old:0x8F3F3A9C


function PED.APPLY_PED_BLOOD_BY_ZONE(ped, p1, p2, p3, p4)


  Velora.invoke(0xA98D20,"void", ped, p1, p2, p3, p4)


end


-- PC:0xEF0D582CBF2D9B0F Old:0xFC13CE80


function PED.APPLY_PED_BLOOD_SPECIFIC(ped, p1, p2, p3, p4, p5, p6, p7, p8)


  Velora.invoke(0xA98E00,"void", ped, p1, p2, p3, p4, p5, p6, p7, p8)


end


-- PC:0x397C38AA7B4A5F83 Old:0x8A13A41F


function PED.APPLY_PED_DAMAGE_DECAL(ped, damageZone, xOffset, yOffset, heading, scale, alpha, variation, fadeIn, decalName)


  Velora.invoke(0xA98F10,"void", ped, damageZone, xOffset, yOffset, heading, scale, alpha, variation, fadeIn, decalName)


end


-- PC:0x46DF918788CB093F Old:0x208D0CB8


function PED.APPLY_PED_DAMAGE_PACK(ped, damagePack, damage, mult)


  Velora.invoke(0xA99030,"void", ped, damagePack, damage, mult)


end


-- PC:0x8FE22675A5A45817 Old:0xF7ADC960


function PED.CLEAR_PED_BLOOD_DAMAGE(ped)


  Velora.invoke(0xA990E0,"void", ped)


end


-- PC:0x56E3B78C5408D9F4 Old:0xF210BE69


function PED.CLEAR_PED_BLOOD_DAMAGE_BY_ZONE(ped, p1)


  Velora.invoke(0xA99130,"void", ped, p1)


end


-- PC:0x62AB793144DE75DC Old:0x0CB6C4ED


function PED.HIDE_PED_BLOOD_DAMAGE_BY_ZONE(ped, p1, p2)


  Velora.invoke(0xA99180,"void", ped, p1, p2)


end


-- PC:0x523C79AEEFCC4A2A Old:0x70AA5B7D


function PED.CLEAR_PED_DAMAGE_DECAL_BY_ZONE(ped, p1, p2)


  Velora.invoke(0xA991F0,"void", ped, p1, p2)


end


-- PC:0x71EAB450D86954A1 Old:0x47187F7F


function PED.GET_PED_DECORATIONS_STATE(ped)


  return Velora.invoke(0xA99350,"int", ped)


end


function PED.MARK_PED_DECORATIONS_AS_CLONED_FROM_LOCAL_PLAYER(ped, p1)


  Velora.invoke(0xA99350,"void", ped, p1)


end


-- PC:0x9C720776DAA43E7E Old:0x629F15BD


function PED.CLEAR_PED_WETNESS(ped)


  Velora.invoke(0xA993C0,"void", ped)


end


-- PC:0x44CB6447D2571AA0 Old:0x7B33289A


function PED.SET_PED_WETNESS_HEIGHT(ped, height)


  Velora.invoke(0xA99420,"void", ped, height)


end


-- PC:0xB5485E4907B53019 Old:0xBDE749F7


function PED.SET_PED_WETNESS_ENABLED_THIS_FRAME(ped)


  Velora.invoke(0xA99490,"void", ped)


end


function PED.SET_PED_WETNESS(ped, wetLevel)


  Velora.invoke(0xA994E0,"void", ped, wetLevel)


end


-- PC:0x6585D955A68452A5 Old:0xA993915F


function PED.CLEAR_PED_ENV_DIRT(ped)


  Velora.invoke(0xA99540,"void", ped)


end


-- PC:0x27B0405F59637D1F Old:0x76A1DB9F


function PED.SET_PED_SWEAT(ped, sweat)


  Velora.invoke(0xA99580,"void", ped, sweat)


end


-- PC:0x5F5D1665E352A839 Old:0x70559AC7


function PED.ADD_PED_DECORATION_FROM_HASHES(ped, collection, overlay)


  Velora.invoke(0xA995D0,"void", ped, collection, overlay)


end


-- PC:0x5619BFA07CFD7833 Old:0x8CD3E487


function PED.ADD_PED_DECORATION_FROM_HASHES_IN_CORONA(ped, collection, overlay)


  Velora.invoke(0xA99670,"void", ped, collection, overlay)


end


-- PC:0x9FD452BFBE7A7A8B Old:0x3543019E


function PED.GET_PED_DECORATION_ZONE_FROM_HASHES(collection, overlay)


  return Velora.invoke(0xA99790,"int", collection, overlay)


end


-- PC:0x0E5173C163976E38 Old:0xD4496BF3


function PED.CLEAR_PED_DECORATIONS(ped)


  Velora.invoke(0xA99790,"void", ped)


end


-- PC:0xE3B27E70CEAB9F0C Old:0xEFD58EB9


function PED.CLEAR_PED_DECORATIONS_LEAVE_SCARS(ped)


  Velora.invoke(0xA997E0,"void", ped)


end


-- PC:0x11B499C1E0FF8559 Old:0xF7E2FBAD


function PED.WAS_PED_SKELETON_UPDATED(ped)


  return Velora.invoke(0xA99910,"bool", ped)


end


-- PC:0x17C07FC640E86B4E Old:0x4579CAB1


function PED.GET_PED_BONE_COORDS(ped, boneId, offsetX, offsetY, offsetZ)


  local x,y,z=Velora.invoke(0xA998A0,"vector3", ped, boneId, offsetX, offsetY, offsetZ)


  return {x=x,y=y,z=z}


end


-- PC:0x418EF2A1BCE56685 Old:0x1CFBFD4B


function PED.CREATE_NM_MESSAGE(startImmediately, messageId)


  Velora.invoke(0xA99910,"void", startImmediately, messageId)


end


-- PC:0xB158DFCCC56E5C5B Old:0x737C3689


function PED.GIVE_PED_NM_MESSAGE(ped)


  Velora.invoke(0xA99980,"void", ped)


end


-- PC:0x1B5C85C612E5256E Old:0xA38C0234


function PED.ADD_SCENARIO_BLOCKING_AREA(x1, y1, z1, x2, y2, z2, p6, p7, p8, p9)


  return Velora.invoke(0xA999F0,"int", x1, y1, z1, x2, y2, z2, p6, p7, p8, p9)


end


-- PC:0xD37401D78A929A49 Old:0x4DDF845F


function PED.REMOVE_SCENARIO_BLOCKING_AREAS()


  Velora.invoke(0xA999F0,"void")


end


-- PC:0x31D16B74C6E29D66 Old:0x4483EF06


function PED.REMOVE_SCENARIO_BLOCKING_AREA(p0, p1)


  Velora.invoke(0xA99A10,"void", p0, p1)


end


-- PC:0x28157D43CF600981 Old:0x80EAD297


function PED.SET_SCENARIO_PEDS_SPAWN_IN_SPHERE_AREA(x, y, z, range, p4)


  Velora.invoke(0xA99A30,"void", x, y, z, range, p4)


end


function PED.DOES_SCENARIO_BLOCKING_AREA_EXISTS(x1, y1, z1, x2, y2, z2)


  return Velora.invoke(0xA99C00,"bool", x1, y1, z1, x2, y2, z2)


end


-- PC:0x1BF094736DD62C2E Old:0x0F65B0D4


function PED.IS_PED_USING_SCENARIO(ped, scenario)


  return Velora.invoke(0xA99B40,"bool", ped, scenario)


end


-- PC:0x57AB4A3080F85143 Old:0x195EF5B7


function PED.IS_PED_USING_ANY_SCENARIO(ped)


  return Velora.invoke(0xA99B70,"bool", ped)


end


-- PC:0xFE07FF6495D52E2A Old:0x59DE73AC


function PED.SET_PED_PANIC_EXIT_SCENARIO(p0, p1, p2, p3)


  return Velora.invoke(0xA99BD0,"bool", p0, p1, p2, p3)


end


-- PC:0x9A77DFD295E29B09 Old:0xC08FE5F6


function PED.TOGGLE_SCENARIO_PED_COWER_IN_PLACE(ped, toggle)


  Velora.invoke(0xA99C00,"void", ped, toggle)


end


-- PC:0x25361A96E0F7E419 Old:0x58C0F6CF


function PED.TRIGGER_PED_SCENARIO_PANICEXITTOFLEE(p0, p1, p2, p3)


  return Velora.invoke(0xA99D50,"bool", p0, p1, p2, p3)


end


function PED.SET_PED_SHOULD_PLAY_DIRECTED_NORMAL_SCENARIO_EXIT(p0, p1, p2, p3)


  return Velora.invoke(0xA99CA0,"bool", p0, p1, p2, p3)


end


-- PC:0xA3A9299C4F2ADB98 Old:0x033F43FA


function PED.SET_PED_SHOULD_PLAY_NORMAL_SCENARIO_EXIT(ped)


  Velora.invoke(0xA99D50,"void", ped)


end


-- PC:0xF1C03A5352243A30 Old:0x4C684C81


function PED.SET_PED_SHOULD_PLAY_IMMEDIATE_SCENARIO_EXIT(ped)


  Velora.invoke(0xA99DA0,"void", ped)


end


-- PC:0xEEED8FAFEC331A70 Old:0x7B4C3E6F


function PED.SET_PED_SHOULD_PLAY_FLEE_SCENARIO_EXIT(ped, p1, p2, p3)


  return Velora.invoke(0xA99EB0,"bool", ped, p1, p2, p3)


end


-- PC:0x425AECF167663F48 Old:0x5BC276AE


function PED.SET_PED_SHOULD_IGNORE_SCENARIO_EXIT_COLLISION_CHECKS(ped, p1)


  Velora.invoke(0xA99EB0,"void", ped, p1)


end


function PED.SET_PED_SHOULD_IGNORE_SCENARIO_NAV_CHECKS(p0, p1)


  Velora.invoke(0xA99F00,"void", p0, p1)


end


function PED.SET_PED_SHOULD_PROBE_FOR_SCENARIO_EXITS_IN_ONE_FRAME(p0, p1)


  Velora.invoke(0xA99F60,"void", p0, p1)


end


function PED.IS_PED_GESTURING(p0)


  return Velora.invoke(0xA9A000,"bool", p0)


end


function PED.RESET_FACIAL_IDLE_ANIM(ped)


  Velora.invoke(0xA9A000,"void", ped)


end


-- PC:0xE1E65CA8AC9C00ED Old:0x1F6CCDDE


function PED.PLAY_FACIAL_ANIM(ped, animName, animDict)


  Velora.invoke(0xA9A050,"void", ped, animName, animDict)


end


function PED.SET_FACIAL_CLIPSET(ped, animDict)


  Velora.invoke(0xA9A070,"void", ped, animDict)


end


-- PC:0xFFC24B988B938B38 Old:0x9BA19C13


function PED.SET_FACIAL_IDLE_ANIM_OVERRIDE(ped, animName, animDict)


  Velora.invoke(0xA9A120,"void", ped, animName, animDict)


end


-- PC:0x726256CC1EEB182F Old:0x5244F4E2


function PED.CLEAR_FACIAL_IDLE_ANIM_OVERRIDE(ped)


  Velora.invoke(0xA9A140,"void", ped)


end


-- PC:0xBAF20C5432058024 Old:0xE131E3B3


function PED.SET_PED_CAN_PLAY_GESTURE_ANIMS(ped, toggle)


  Velora.invoke(0xA9A150,"void", ped, toggle)


end


-- PC:0xF833DDBA3B104D43 Old:0xA2FDAF27


function PED.SET_PED_CAN_PLAY_VISEME_ANIMS(ped, toggle, p2)


  Velora.invoke(0xA9A1C0,"void", ped, toggle, p2)


end


-- PC:0x33A60D8BDD6E508C Old:0xADB2511A


function PED.SET_PED_IS_IGNORED_BY_AUTO_OPEN_DOORS(ped, p1)


  Velora.invoke(0xA9A250,"void", ped, p1)


end


-- PC:0x6373D1349925A70E Old:0xF8053081


function PED.SET_PED_CAN_PLAY_AMBIENT_ANIMS(ped, toggle)


  Velora.invoke(0xA9A2B0,"void", ped, toggle)


end


-- PC:0x0EB0585D15254740 Old:0x5720A5DD


function PED.SET_PED_CAN_PLAY_AMBIENT_BASE_ANIMS(ped, toggle)


  Velora.invoke(0xA9A300,"void", ped, toggle)


end


-- PC:0xC2EE020F5FB4DB53 Old:0xB7CD0A49


function PED.TRIGGER_IDLE_ANIMATION_ON_PED(ped)


  Velora.invoke(0xA9A350,"void", ped)


end


-- PC:0x6C3B4D6D13B4C841 Old:0x343B4DE0


function PED.SET_PED_CAN_ARM_IK(ped, toggle)


  Velora.invoke(0xA9A3B0,"void", ped, toggle)


end


-- PC:0xC11C18092C5530DC Old:0xD3B04476


function PED.SET_PED_CAN_HEAD_IK(ped, toggle)


  Velora.invoke(0xA9A460,"void", ped, toggle)


end


-- PC:0x73518ECE2485412B Old:0x9955BC6F


function PED.SET_PED_CAN_LEG_IK(ped, toggle)


  Velora.invoke(0xA9A4C0,"void", ped, toggle)


end


-- PC:0xF2B7106D37947CE0 Old:0x8E5D4EAB


function PED.SET_PED_CAN_TORSO_IK(ped, toggle)


  Velora.invoke(0xA9A520,"void", ped, toggle)


end


-- PC:0xF5846EDB26A98A24 Old:0x7B0040A8


function PED.SET_PED_CAN_TORSO_REACT_IK(ped, p1)


  Velora.invoke(0xA9A580,"void", ped, p1)


end


-- PC:0x6647C5F6F5792496 Old:0x0FDA62DE


function PED.SET_PED_CAN_TORSO_VEHICLE_IK(ped, p1)


  Velora.invoke(0xA9A5E0,"void", ped, p1)


end


-- PC:0xEC4686EC06434678 Old:0x584C5178


function PED.SET_PED_CAN_USE_AUTO_CONVERSATION_LOOKAT(ped, toggle)


  Velora.invoke(0xA9A640,"void", ped, toggle)


end


-- PC:0x5CD3CB88A7F8850D Old:0x2A5DF721


function PED.IS_PED_HEADTRACKING_PED(ped1, ped2)


  return Velora.invoke(0xA9A6F0,"bool", ped1, ped2)


end


-- PC:0x813A0A7C9D2E831F Old:0x233C9ACF


function PED.IS_PED_HEADTRACKING_ENTITY(ped, entity)


  return Velora.invoke(0xA9A6C0,"bool", ped, entity)


end


-- PC:0xCD17B554996A8D9E Old:0x6DEF6F1C


function PED.SET_PED_PRIMARY_LOOKAT(ped, lookAt)


  Velora.invoke(0xA9A6F0,"void", ped, lookAt)


end


function PED.SET_PED_CLOTH_PIN_FRAMES(p0, p1)


  Velora.invoke(0xA9A700,"void", p0, p1)


end


function PED.SET_PED_CLOTH_PACKAGE_INDEX(p0, p1)


  Velora.invoke(0xA9A750,"void", p0, p1)


end


function PED.SET_PED_CLOTH_PRONE(p0, p1)


  Velora.invoke(0xA9A7A0,"void", p0, p1)


end


-- PC:0x1913FE4CBF41C463 Old:0x9CFBE10D


function PED.SET_PED_CONFIG_FLAG(ped, flagId, value)


  Velora.invoke(0xA9A7F0,"void", ped, flagId, value)


end


-- PC:0xC1E8A365BF3B29F2 Old:0xCFF6FF66


function PED.SET_PED_RESET_FLAG(ped, flagId, doReset)


  Velora.invoke(0xA9A8A0,"void", ped, flagId, doReset)


end


-- PC:0x7EE53118C892B513 Old:0xABE98267


function PED.GET_PED_CONFIG_FLAG(ped, flagId, p2)


  return Velora.invoke(0xA9A9C0,"bool", ped, flagId, p2)


end


-- PC:0xAF9E59B1B1FBF2A0 Old:0x2FC10D11


function PED.GET_PED_RESET_FLAG(ped, flagId)


  return Velora.invoke(0xA9A950,"bool", ped, flagId)


end


-- PC:0x0BDDB8D9EC6BCF3C Old:0x2AB3670B


function PED.SET_PED_GROUP_MEMBER_PASSENGER_INDEX(ped, index)


  Velora.invoke(0xA9A9C0,"void", ped, index)


end


-- PC:0x6B7A646C242A7059 Old:0x542FEB4D


function PED.SET_PED_CAN_EVASIVE_DIVE(ped, toggle)


  Velora.invoke(0xA9AA20,"void", ped, toggle)


end


-- PC:0x414641C26E105898 Old:0xD82829DC


function PED.IS_PED_EVASIVE_DIVING(ped)


  return Velora.invoke(0xA9AB10,"bool", ped)


end


-- PC:0x96A05E4FB321B1BA Old:0xFD64EAE5


function PED.SET_PED_SHOOTS_AT_COORD(ped, x, y, z, toggle)


  Velora.invoke(0xA9AB10,"void", ped, x, y, z, toggle)


end


-- PC:0xE163A4BCE4DE6F11 Old:0x7820CA43


function PED.SET_PED_MODEL_IS_SUPPRESSED(modelHash, toggle)


  Velora.invoke(0xA9AB30,"void", modelHash, toggle)


end


-- PC:0xB47BD05FA66B40CF Old:0x5AD7DC55


function PED.STOP_ANY_PED_MODEL_BEING_SUPPRESSED()


  Velora.invoke(0xA9AB50,"void")


end


-- PC:0x638C03B0F9878F57 Old:0x6FD9A7CD


function PED.SET_PED_CAN_BE_TARGETED_WHEN_INJURED(ped, toggle)


  Velora.invoke(0xA9AB60,"void", ped, toggle)


end


-- PC:0x7FB17BA2E7DECA5B Old:0xE9B97A2B


function PED.SET_PED_GENERATES_DEAD_BODY_EVENTS(ped, toggle)


  Velora.invoke(0xA9AC20,"void", ped, toggle)


end


-- PC:0xE43A13C9E4CCCBCF Old:0xFF1F6AEB


function PED.BLOCK_PED_FROM_GENERATING_DEAD_BODY_EVENTS_WHEN_DEAD(ped, toggle)


  Velora.invoke(0xA9AC40,"void", ped, toggle)


end


function PED.SET_PED_WILL_ONLY_ATTACK_WANTED_PLAYER(p0, p1)


  Velora.invoke(0xA9AC90,"void", p0, p1)


end


-- PC:0xDF993EE5E90ABA25 Old:0xE9BD733A


function PED.SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(ped, toggle)


  Velora.invoke(0xA9ACF0,"void", ped, toggle)


end


-- PC:0x54C7C4A94367717E Old:0x1862A461


function PED.GIVE_PED_HELMET(ped, cannotRemove, helmetFlag, textureIndex)


  Velora.invoke(0xA9AD50,"void", ped, cannotRemove, helmetFlag, textureIndex)


end


-- PC:0xA7B2458D0AD6DED8 Old:0x2086B1F0


function PED.REMOVE_PED_HELMET(ped, instantly)


  Velora.invoke(0xA9AD70,"void", ped, instantly)


end


-- PC:0x14590DDBEDB1EC85 Old:0xA1008E0E


function PED.IS_PED_TAKING_OFF_HELMET(ped)


  return Velora.invoke(0xA9ADF0,"bool", ped)


end


-- PC:0x560A43136EB58105 Old:0xED366E53


function PED.SET_PED_HELMET(ped, canWearHelmet)


  Velora.invoke(0xA9ADF0,"void", ped, canWearHelmet)


end


-- PC:0xC0E78D5C2CE3EB25 Old:0x12677780


function PED.SET_PED_HELMET_FLAG(ped, helmetFlag)


  Velora.invoke(0xA9AE40,"void", ped, helmetFlag)


end


-- PC:0x26D83693ED99291C Old:0xA316D13F


function PED.SET_PED_HELMET_PROP_INDEX(ped, propIndex, p2)


  Velora.invoke(0xA9AE90,"void", ped, propIndex, p2)


end


function PED.SET_PED_HELMET_VISOR_PROP_INDICES(ped, p1, p2, p3)


  Velora.invoke(0xA9AF30,"void", ped, p1, p2, p3)


end


function PED.IS_PED_HELMET_VISOR_UP(ped)


  return Velora.invoke(0xA9B030,"bool", ped)


end


-- PC:0xF1550C4BD22582E2 Old:0x5F6C3328


function PED.SET_PED_HELMET_TEXTURE_INDEX(ped, textureIndex)


  Velora.invoke(0xA9B030,"void", ped, textureIndex)


end


-- PC:0xF33BDFE19B309B19 Old:0x0D680D49


function PED.IS_PED_WEARING_HELMET(ped)


  return Velora.invoke(0xA9B0F0,"bool", ped)


end


-- PC:0x687C0B594907D2E8 Old:0x24A1284E


function PED.CLEAR_PED_STORED_HAT_PROP(ped)


  Velora.invoke(0xA9B0F0,"void", ped)


end


-- PC:0x451294E859ECC018 Old:0x8A3A3116


function PED.GET_PED_HELMET_STORED_HAT_PROP_INDEX(ped)


  return Velora.invoke(0xA9B240,"int", ped)


end


-- PC:0x9D728C1E12BF5518 Old:0x74EB662D


function PED.GET_PED_HELMET_STORED_HAT_TEX_INDEX(ped)


  return Velora.invoke(0xA9B1B0,"int", ped)


end


-- PC:0xF2385935BFFD4D92 Old:0xFFF149FE


function PED.IS_CURRENT_HEAD_PROP_A_HELMET(p0)


  return Velora.invoke(0xA9B210,"bool", p0)


end


-- PC:0x332B562EEDA62399 Old:0xCF94BA97


function PED.SET_PED_TO_LOAD_COVER(ped, toggle)


  Velora.invoke(0xA9B240,"void", ped, toggle)


end


-- PC:0xCB7553CDCEF4A735 Old:0x5194658B


function PED.SET_PED_CAN_COWER_IN_COVER(ped, toggle)


  Velora.invoke(0xA9B2A0,"void", ped, toggle)


end


-- PC:0xC514825C507E3736 Old:0xC1DAE216


function PED.SET_PED_CAN_PEEK_IN_COVER(ped, toggle)


  Velora.invoke(0xA9B300,"void", ped, toggle)


end


-- PC:0x94D94BF1A75AED3D Old:0x7C563CD2


function PED.SET_PED_PLAYS_HEAD_ON_HORN_ANIM_WHEN_DIES_IN_VEHICLE(ped, toggle)


  Velora.invoke(0xA9B360,"void", ped, toggle)


end


-- PC:0xC396F5B86FF9FEBD Old:0xFDDB042E


function PED.SET_PED_LEG_IK_MODE(ped, mode)


  Velora.invoke(0xA9B370,"void", ped, mode)


end


-- PC:0x0A986918B102B448 Old:0xA211A128


function PED.SET_PED_MOTION_BLUR(ped, toggle)


  Velora.invoke(0xA9B3D0,"void", ped, toggle)


end


-- PC:0xED7F7EFE9FABF340 Old:0xB5F8BA28


function PED.SET_PED_CAN_SWITCH_WEAPON(ped, toggle)


  Velora.invoke(0xA9B430,"void", ped, toggle)


end


-- PC:0xEEB64139BA29A7CF Old:0xFE2554FC


function PED.SET_PED_DIES_INSTANTLY_IN_WATER(ped, toggle)


  Velora.invoke(0xA9B490,"void", ped, toggle)


end


-- PC:0x1A330D297AAC6BC1 Old:0x77BB7CB8


function PED.SET_LADDER_CLIMB_INPUT_STATE(ped, p1)


  Velora.invoke(0xA9B4E0,"void", ped, p1)


end


-- PC:0xC158D28142A34608 Old:0x4AC3421E


function PED.STOP_PED_WEAPON_FIRING_WHEN_DROPPED(ped)


  Velora.invoke(0xA9B540,"void", ped)


end


-- PC:0x5917BBA32D06C230 Old:0x7CEFFA45


function PED.SET_SCRIPTED_ANIM_SEAT_OFFSET(ped, p1)


  Velora.invoke(0xA9B580,"void", ped, p1)


end


-- PC:0x4D9CA1009AFBD057 Old:0x12E62F9E


function PED.SET_PED_COMBAT_MOVEMENT(ped, combatMovement)


  Velora.invoke(0xA9B5D0,"void", ped, combatMovement)


end


-- PC:0xDEA92412FCAEB3F5 Old:0xF3E7730E


function PED.GET_PED_COMBAT_MOVEMENT(ped)


  return Velora.invoke(0xA9B680,"int", ped)


end


-- PC:0xC7622C0D36B2FDA8 Old:0x6C23D329


function PED.SET_PED_COMBAT_ABILITY(ped, abilityLevel)


  Velora.invoke(0xA9B680,"void", ped, abilityLevel)


end


-- PC:0x3C606747B23E497B Old:0x8818A959


function PED.SET_PED_COMBAT_RANGE(ped, combatRange)


  Velora.invoke(0xA9B6D0,"void", ped, combatRange)


end


-- PC:0xF9D9F7F2DB8E2FA0 Old:0x9B9B7163


function PED.GET_PED_COMBAT_RANGE(ped)


  return Velora.invoke(0xA9B780,"int", ped)


end


-- PC:0x9F7794730795E019 Old:0x81D64248


function PED.SET_PED_COMBAT_ATTRIBUTES(ped, attributeId, enabled)


  Velora.invoke(0xA9B780,"void", ped, attributeId, enabled)


end


-- PC:0x0703B9079823DA4A Old:0xCFA613FF


function PED.SET_PED_TARGET_LOSS_RESPONSE(ped, responseType)


  Velora.invoke(0xA9B7F0,"void", ped, responseType)


end


-- PC:0xDCCA191DF9980FD7 Old:0x139C0875


function PED.IS_PED_PERFORMING_MELEE_ACTION(ped)


  return Velora.invoke(0xA9BBD0,"bool", ped)


end


-- PC:0xFD4CCDBCC59941B7 Old:0x9ADD7B21


function PED.IS_PED_PERFORMING_STEALTH_KILL(ped)


  return Velora.invoke(0xA9B8B0,"bool", ped)


end


-- PC:0xEBD0EDBA5BE957CF Old:0x9BE7C860


function PED.IS_PED_PERFORMING_A_COUNTER_ATTACK(ped)


  return Velora.invoke(0xA9B950,"bool", ped)


end


-- PC:0x863B23EFDE9C5DF2 Old:0xD044C8AF


function PED.IS_PED_BEING_STEALTH_KILLED(ped)


  return Velora.invoke(0xA9B9E0,"bool", ped)


end


-- PC:0x18A3E9EE1297FD39 Old:0xAFEC26A4


function PED.GET_MELEE_TARGET_FOR_PED(ped)


  return Velora.invoke(0xA9BA50,"int", ped)


end


-- PC:0xF9800AA1A771B000 Old:0x2EA4B54E


function PED.WAS_PED_KILLED_BY_STEALTH(ped)


  return Velora.invoke(0xA9BAE0,"bool", ped)


end


-- PC:0x7F08E26039C7347C Old:0xBDD3CE69


function PED.WAS_PED_KILLED_BY_TAKEDOWN(ped)


  return Velora.invoke(0xA9BB30,"bool", ped)


end


-- PC:0x61767F73EACEED21 Old:0x3993092B


function PED.WAS_PED_KNOCKED_OUT(ped)


  return Velora.invoke(0xA9BB80,"bool", ped)


end


-- PC:0x70A2D1137C8ED7C9 Old:0xA717A875


function PED.SET_PED_FLEE_ATTRIBUTES(ped, attributeFlags, enable)


  Velora.invoke(0xA9BBD0,"void", ped, attributeFlags, enable)


end


-- PC:0xA549131166868ED3 Old:0x16F30DF4


function PED.SET_PED_COWER_HASH(ped, p1)


  Velora.invoke(0xA9BC40,"void", ped, p1)


end


-- PC:0x2016C603D6B8987C Old:0xA6F2C057


function PED.SET_PED_STEERS_AROUND_DEAD_BODIES(ped, toggle)


  Velora.invoke(0xA9BCA0,"void", ped, toggle)


end


-- PC:0x46F2193B3AD1D891 Old:0x797CAE4F


function PED.SET_PED_STEERS_AROUND_PEDS(ped, toggle)


  Velora.invoke(0xA9BD00,"void", ped, toggle)


end


-- PC:0x1509C089ADC208BF Old:0x3BD9B0A6


function PED.SET_PED_STEERS_AROUND_OBJECTS(ped, toggle)


  Velora.invoke(0xA9BD50,"void", ped, toggle)


end


-- PC:0xEB6FB9D48DDE23EC Old:0x533C0651


function PED.SET_PED_STEERS_AROUND_VEHICLES(ped, toggle)


  Velora.invoke(0xA9BDB0,"void", ped, toggle)


end


-- PC:0xA9B61A329BFDCBEA Old:0x2276DE0D


function PED.SET_PED_IS_AVOIDED_BY_OTHERS(p0, p1)


  Velora.invoke(0xA9BE10,"void", p0, p1)


end


-- PC:0x570389D1C3DE3C6B Old:0x59C52BE6


function PED.SET_PED_INCREASED_AVOIDANCE_RADIUS(ped)


  Velora.invoke(0xA9BE70,"void", ped)


end


-- PC:0x576594E8D64375E2 Old:0x1D87DDC1


function PED.SET_PED_BLOCKS_PATHING_WHEN_DEAD(ped, toggle)


  Velora.invoke(0xA9BEB0,"void", ped, toggle)


end


-- PC:0xA52D5247A4227E14 Old:0xB52BA5F5


function PED.SET_PED_NO_TIME_DELAY_BEFORE_SHOT(p0)


  Velora.invoke(0xA9BF10,"void", p0)


end


-- PC:0x083961498679DC9F Old:0xFBD9B050


function PED.IS_ANY_PED_NEAR_POINT(x, y, z, radius)


  return Velora.invoke(0xA9C030,"bool", x, y, z, radius)


end


-- PC:0x2208438012482A1A Old:0x187B9070


function PED.FORCE_PED_AI_AND_ANIMATION_UPDATE(ped, p1, p2)


  Velora.invoke(0xA9C030,"void", ped, p1, p2)


end


-- PC:0xFCF37A457CB96DC0 Old:0x45037B9B


function PED.IS_PED_HEADING_TOWARDS_POSITION(ped, x, y, z, p4)


  return Velora.invoke(0xA9C0F0,"bool", ped, x, y, z, p4)


end


-- PC:0x7D7A2E43E74E2EB8 Old:0x840D24D3


function PED.REQUEST_PED_VISIBILITY_TRACKING(ped)


  Velora.invoke(0xA9C0F0,"void", ped)


end


-- PC:0x2BC338A7B21F4608 Old:0x31C31DAA


function PED.REQUEST_PED_VEHICLE_VISIBILITY_TRACKING(ped, p1)


  Velora.invoke(0xA9C130,"void", ped, p1)


end


function PED.REQUEST_PED_RESTRICTED_VEHICLE_VISIBILITY_TRACKING(ped, p1)


  Velora.invoke(0xA9C190,"void", ped, p1)


end


-- PC:0x75BA1CB3B7D40CAF Old:0x9194DB71


function PED.REQUEST_PED_USE_SMALL_BBOX_VISIBILITY_TRACKING(ped, p1)


  Velora.invoke(0xA9C1E0,"void", ped, p1)


end


-- PC:0x91C8E617F64188AC Old:0x33248CC1


function PED.IS_TRACKED_PED_VISIBLE(ped)


  return Velora.invoke(0xA9C500,"bool", ped)


end


-- PC:0x511F1A683387C7E2 Old:0x5B1B70AA


function PED.GET_TRACKED_PED_PIXELCOUNT(ped)


  return Velora.invoke(0xA9C2A0,"int", ped)


end


-- PC:0x4C5E1F087CD10BB7 Old:0x7EB613D9


function PED.IS_PED_TRACKED(ped)


  return Velora.invoke(0xA9C300,"bool", ped)


end


-- PC:0x8507BCB710FA6DC0 Old:0xECD73DB0


function PED.HAS_PED_RECEIVED_EVENT(ped, eventId)


  return Velora.invoke(0xA9C360,"bool", ped, eventId)


end


-- PC:0x6CD5A433374D4CFB Old:0x74A0F291


function PED.CAN_PED_SEE_HATED_PED(ped1, ped2)


  return Velora.invoke(0xA9C390,"bool", ped1, ped2)


end


function PED.CAN_PED_SHUFFLE_TO_OR_FROM_TURRET_SEAT(ped)


  return Velora.invoke(0xA9C3C0,"bool", ped)


end


function PED.CAN_PED_SHUFFLE_TO_OR_FROM_EXTRA_SEAT(ped)


  return Velora.invoke(0xA9C440,"bool", ped)


end


-- PC:0x3F428D08BE5AAE31 Old:0x259C6BA2


function PED.GET_PED_BONE_INDEX(ped, boneId)


  return Velora.invoke(0xA9C4C0,"int", ped, boneId)


end


-- PC:0x2057EF813397A772 Old:0x849F0716


function PED.GET_PED_RAGDOLL_BONE_INDEX(ped, bone)


  return Velora.invoke(0xA9C4F0,"int", ped, bone)


end


-- PC:0xBF29516833893561 Old:0xFC1CFC27


function PED.SET_PED_ENVEFF_SCALE(ped, value)


  Velora.invoke(0xA9C500,"void", ped, value)


end


-- PC:0x9C14D30395A51A3C Old:0xA3421E39


function PED.GET_PED_ENVEFF_SCALE(ped)


  return Velora.invoke(0xA9C630,"float", ped)


end


-- PC:0xD2C5AA0C0E8D0F1E Old:0xC70F4A84


function PED.SET_ENABLE_PED_ENVEFF_SCALE(ped, toggle)


  Velora.invoke(0xA9C630,"void", ped, toggle)


end


-- PC:0x110F526AB784111F Old:0x3B882533


function PED.SET_PED_ENVEFF_CPV_ADD(ped, p1)


  Velora.invoke(0xA9C6B0,"void", ped, p1)


end


-- PC:0xD69411AA0CEBF9E9 Old:0x87A0C174


function PED.SET_PED_ENVEFF_COLOR_MODULATOR(ped, p1, p2, p3)


  Velora.invoke(0xA9C750,"void", ped, p1, p2, p3)


end


function PED.SET_PED_EMISSIVE_SCALE(ped, intensity)


  Velora.invoke(0xA9C820,"void", ped, intensity)


end


function PED.GET_PED_EMISSIVE_SCALE(ped)


  return Velora.invoke(0xA9C9C0,"float", ped)


end


function PED.IS_PED_SHADER_READY(ped)


  return Velora.invoke(0xA9C950,"bool", ped)


end


function PED.SET_PED_ENABLE_CREW_EMBLEM(ped, toggle)


  Velora.invoke(0xA9C9C0,"void", ped, toggle)


end


-- PC:0x1216E0BFA72CC703 Old:0x7BD26837


function PED.REQUEST_RAGDOLL_BOUNDS_UPDATE(p0, p1)


  Velora.invoke(0xA9CA10,"void", p0, p1)


end


-- PC:0x2B5AA717A181FB4C Old:0x98E29ED0


function PED.SET_PED_AO_BLOB_RENDERING(ped, toggle)


  Velora.invoke(0xA9CA20,"void", ped, toggle)


end


function PED.IS_PED_SHELTERED(ped)


  return Velora.invoke(0xA9CB70,"bool", ped)


end


-- PC:0x8C18E0F9080ADD73 Old:0xFFDDF8FA


function PED.CREATE_SYNCHRONIZED_SCENE(x, y, z, roll, pitch, yaw, p6)


  return Velora.invoke(0xA9CAE0,"int", x, y, z, roll, pitch, yaw, p6)


end


-- PC:0x62EC273D00187DCA Old:0xF3876894


function PED.CREATE_SYNCHRONIZED_SCENE_AT_MAP_OBJECT(x, y, z, radius, object)


  return Velora.invoke(0xA9CB10,"int", x, y, z, radius, object)


end


-- PC:0x25D39B935A038A26 Old:0x57A282F1


function PED.IS_SYNCHRONIZED_SCENE_RUNNING(sceneId)


  return Velora.invoke(0xA9CB40,"bool", sceneId)


end


-- PC:0x6ACF6B7225801CD7 Old:0x2EC2A0B2


function PED.SET_SYNCHRONIZED_SCENE_ORIGIN(sceneID, x, y, z, roll, pitch, yaw, p7)


  Velora.invoke(0xA9CB70,"void", sceneID, x, y, z, roll, pitch, yaw, p7)


end


-- PC:0x734292F4F0ABF6D0 Old:0xF5AB0D98


function PED.SET_SYNCHRONIZED_SCENE_PHASE(sceneID, phase)


  Velora.invoke(0xA9CC30,"void", sceneID, phase)


end


-- PC:0xE4A310B1D7FA73CC Old:0xB0B2C852


function PED.GET_SYNCHRONIZED_SCENE_PHASE(sceneID)


  return Velora.invoke(0xA9CCB0,"float", sceneID)


end


-- PC:0xB6C49F8A5E295A5D Old:0xF10112FD


function PED.SET_SYNCHRONIZED_SCENE_RATE(sceneID, rate)


  Velora.invoke(0xA9CCB0,"void", sceneID, rate)


end


-- PC:0xD80932D577274D40 Old:0x89365F0D


function PED.GET_SYNCHRONIZED_SCENE_RATE(sceneID)


  return Velora.invoke(0xA9CD60,"float", sceneID)


end


-- PC:0xD9A897A4C6C2974F Old:0x32ED9F82


function PED.SET_SYNCHRONIZED_SCENE_LOOPED(sceneID, toggle)


  Velora.invoke(0xA9CD60,"void", sceneID, toggle)


end


-- PC:0x62522002E0C391BA Old:0x47D87A84


function PED.IS_SYNCHRONIZED_SCENE_LOOPED(sceneID)


  return Velora.invoke(0xA9CDE0,"bool", sceneID)


end


-- PC:0x394B9CD12435C981 Old:0x2DE48DA1


function PED.SET_SYNCHRONIZED_SCENE_HOLD_LAST_FRAME(sceneID, toggle)


  Velora.invoke(0xA9CDE0,"void", sceneID, toggle)


end


-- PC:0x7F2F4F13AC5257EF Old:0x72CF2514


function PED.IS_SYNCHRONIZED_SCENE_HOLD_LAST_FRAME(sceneID)


  return Velora.invoke(0xA9CE70,"bool", sceneID)


end


-- PC:0x272E4723B56A3B96 Old:0xE9BA6189


function PED.ATTACH_SYNCHRONIZED_SCENE_TO_ENTITY(sceneID, entity, boneIndex)


  Velora.invoke(0xA9CE70,"void", sceneID, entity, boneIndex)


end


-- PC:0x6D38F1F04CBB37EA Old:0x52A1CAB2


function PED.DETACH_SYNCHRONIZED_SCENE(sceneID)


  Velora.invoke(0xA9CEE0,"void", sceneID)


end


-- PC:0xCD9CC7E200A52A6F Old:0xBF7F9035


function PED.TAKE_OWNERSHIP_OF_SYNCHRONIZED_SCENE(scene)


  Velora.invoke(0xA9CF10,"void", scene)


end


-- PC:0xF28965D04F570DCA Old:0x164DDEFF


function PED.FORCE_PED_MOTION_STATE(ped, motionStateHash, p2, p3, p4)


  return Velora.invoke(0xA9D010,"bool", ped, motionStateHash, p2, p3, p4)


end


function PED.GET_PED_CURRENT_MOVE_BLEND_RATIO(ped)


  return Velora.invoke(0xA9CF90,"bool", ped)


end


-- PC:0x433083750C5E064A Old:0xEAD0269A


function PED.SET_PED_MAX_MOVE_BLEND_RATIO(ped, value)


  Velora.invoke(0xA9D010,"void", ped, value)


end


-- PC:0x01A898D26E2333DD Old:0x383EC364


function PED.SET_PED_MIN_MOVE_BLEND_RATIO(ped, value)


  Velora.invoke(0xA9D060,"void", ped, value)


end


-- PC:0x085BF80FA50A39D1 Old:0x900008C6


function PED.SET_PED_MOVE_RATE_OVERRIDE(ped, value)


  Velora.invoke(0xA9D0C0,"void", ped, value)


end


function PED.SET_PED_MOVE_RATE_IN_WATER_OVERRIDE(ped, p1)


  Velora.invoke(0xA9D140,"void", ped, p1)


end


-- PC:0x46B05BCAE43856B0 Old:0x79543043


function PED.PED_HAS_SEXINESS_FLAG_SET(ped, sexinessFlag)


  return Velora.invoke(0xA9D340,"bool", ped, sexinessFlag)


end


-- PC:0xCFF869CBFA210D82 Old:0xCB716F68


function PED.GET_PED_NEARBY_VEHICLES(ped, sizeAndVehs)


  return Velora.invoke(0xA9D220,"int", ped, sizeAndVehs)


end


-- PC:0x23F8F5FC7E8C4A6B Old:0x4D3325F4


function PED.GET_PED_NEARBY_PEDS(ped, sizeAndPeds, ignore)


  return Velora.invoke(0xA9D250,"int", ped, sizeAndPeds, ignore)


end


-- PC:0x7350823473013C02 Old:0xF9FB4B71


function PED.HAVE_ALL_STREAMING_REQUESTS_COMPLETED(ped)


  return Velora.invoke(0xA9D280,"bool", ped)


end


-- PC:0x00E73468D085F745 Old:0x5AE7EDA2


function PED.IS_PED_USING_ACTION_MODE(ped)


  return Velora.invoke(0xA9D2E0,"bool", ped)


end


-- PC:0xD75ACCF5E0FB5367 Old:0x8802F696


function PED.SET_PED_USING_ACTION_MODE(ped, p1, p2, action)


  Velora.invoke(0xA9D340,"void", ped, p1, p2, action)


end


-- PC:0x781DE8FA214E87D2 Old:0x83BAE814


function PED.SET_MOVEMENT_MODE_OVERRIDE(ped, name)


  Velora.invoke(0xA9D360,"void", ped, name)


end


-- PC:0x364DF566EC833DE2 Old:0xB153E1B9


function PED.SET_PED_CAPSULE(ped, value)


  Velora.invoke(0xA9D3C0,"void", ped, value)


end


-- PC:0x4462658788425076 Old:0xFFE2667B


function PED.REGISTER_PEDHEADSHOT(ped)


  return Velora.invoke(0xA9D560,"int", ped)


end


function PED.REGISTER_PEDHEADSHOT_HIRES(ped)


  return Velora.invoke(0xA9D480,"int", ped)


end


-- PC:0x953563CE563143AF Old:0x4DD03628


function PED.REGISTER_PEDHEADSHOT_TRANSPARENT(ped)


  return Velora.invoke(0xA9D4F0,"int", ped)


end


-- PC:0x96B1361D9B24C2FF Old:0x0879AE45


function PED.UNREGISTER_PEDHEADSHOT(id)


  Velora.invoke(0xA9D560,"void", id)


end


-- PC:0xA0A9668F158129A2 Old:0x0B1080C4


function PED.IS_PEDHEADSHOT_VALID(id)


  return Velora.invoke(0xA9D660,"bool", id)


end


-- PC:0x7085228842B13A67 Old:0x761CD02E


function PED.IS_PEDHEADSHOT_READY(id)


  return Velora.invoke(0xA9D5C0,"bool", id)


end


-- PC:0xF0DAEF2F545BEE25 Old:0x10F2C023


function PED.REQUEST_PEDHEADSHOT_IMG_UPLOAD(id)


  return Velora.invoke(0xA9D620,"bool", id)


end


-- PC:0x5D517B27CF6ECD04 Old:0x0DBB2FA7


function PED.RELEASE_PEDHEADSHOT_IMG_UPLOAD(id)


  Velora.invoke(0xA9D660,"void", id)


end


-- PC:0xEBB376779A760AA8 Old:0x810158F8


function PED.IS_PEDHEADSHOT_IMG_UPLOAD_AVAILABLE()


  return Velora.invoke(0xA9D6E0,"bool")


end


-- PC:0x876928DDDFCCC9CD Old:0x05023F8F


function PED.HAS_PEDHEADSHOT_IMG_UPLOAD_FAILED()


  return Velora.invoke(0xA9D6A0,"bool")


end


-- PC:0xE8A169E666CBC541 Old:0xAA39FD6C


function PED.HAS_PEDHEADSHOT_IMG_UPLOAD_SUCCEEDED()


  return Velora.invoke(0xA9D6C0,"bool")


end


-- PC:0xC1F6EBF9A3D55538 Old:0xEF9142DB


function PED.SET_PED_HEATSCALE_OVERRIDE(ped, heatScale)


  Velora.invoke(0xA9D6E0,"void", ped, heatScale)


end


-- PC:0x600048C60D5C2C51 Old:0x0688DE64


function PED.DISABLE_PED_HEATSCALE_OVERRIDE(ped)


  Velora.invoke(0xA9D740,"void", ped)


end


-- PC:0x2DF9038C90AD5264 Old:0x909A1D76


function PED.SPAWNPOINTS_START_SEARCH(p0, p1, p2, p3, p4, interiorFlags, scale, duration)


  Velora.invoke(0xA9D780,"void", p0, p1, p2, p3, p4, interiorFlags, scale, duration)


end


-- PC:0xB2AFF10216DEFA2F Old:0x4AAD0ECB


function PED.SPAWNPOINTS_START_SEARCH_IN_ANGLED_AREA(x1, y1, z1, x2, y2, z2, width, interiorFlags, scale, duration)


  Velora.invoke(0xA9D800,"void", x1, y1, z1, x2, y2, z2, width, interiorFlags, scale, duration)


end


-- PC:0xFEE4A5459472A9F8 Old:0x492C9E46


function PED.SPAWNPOINTS_CANCEL_SEARCH()


  Velora.invoke(0xA9D8A0,"void")


end


-- PC:0x3C67506996001F5E Old:0x814A28F4


function PED.SPAWNPOINTS_IS_SEARCH_ACTIVE()


  return Velora.invoke(0xA9D970,"bool")


end


-- PC:0xA586FBEB32A53DBB Old:0x0B60D2BA


function PED.SPAWNPOINTS_IS_SEARCH_COMPLETE()


  return Velora.invoke(0xA9D8E0,"bool")


end


-- PC:0xF445DE8DA80A1792 Old:0x6B83ABDF


function PED.SPAWNPOINTS_IS_SEARCH_FAILED()


  return Velora.invoke(0xA9D910,"bool")


end


-- PC:0xA635C11B8C44AFC2 Old:0xF46B4DC8


function PED.SPAWNPOINTS_GET_NUM_SEARCH_RESULTS()


  return Velora.invoke(0xA9D940,"int")


end


-- PC:0x280C7E3AC7F56E90 Old:0x36A4AC65


function PED.SPAWNPOINTS_GET_SEARCH_RESULT(randomInt)


  Velora.invoke(0xA9D970,"void", randomInt)


end


-- PC:0xB782F8238512BAD5 Old:0xBA699DDF


function PED.SPAWNPOINTS_GET_SEARCH_RESULT_FLAGS(p0)


  Velora.invoke(0xA9DA00,"void", p0)


end


-- PC:0xC32779C16FCEECD9 Old:0x6FE5218C


function PED.SET_IK_TARGET(ped, ikIndex, entityLookAt, boneLookAt, offsetX, offsetY, offsetZ, p7, blendInDuration, blendOutDuration)


  Velora.invoke(0xA9DA60,"void", ped, ikIndex, entityLookAt, boneLookAt, offsetX, offsetY, offsetZ, p7, blendInDuration, blendOutDuration)


end


-- PC:0xED3C76ADFA6D07C4 Old:0xFB4000DC


function PED.FORCE_INSTANT_LEG_IK_SETUP(ped)


  Velora.invoke(0xA9DAA0,"void", ped)


end


-- PC:0x290E2780BB7AA598 Old:0x572BA553


function PED.REQUEST_ACTION_MODE_ASSET(asset)


  Velora.invoke(0xA9DB00,"void", asset)


end


-- PC:0xE4B5F4BF2CB24E65 Old:0xF7EB2BF1


function PED.HAS_ACTION_MODE_ASSET_LOADED(asset)


  return Velora.invoke(0xA9DBB0,"bool", asset)


end


-- PC:0x13E940F88470FA51 Old:0x3F480F92


function PED.REMOVE_ACTION_MODE_ASSET(asset)


  Velora.invoke(0xA9DBB0,"void", asset)


end


-- PC:0x2A0A62FCDEE16D4F Old:0x280A004A


function PED.REQUEST_STEALTH_MODE_ASSET(asset)


  Velora.invoke(0xA9DC30,"void", asset)


end


-- PC:0xE977FC5B08AF3441 Old:0x39245667


function PED.HAS_STEALTH_MODE_ASSET_LOADED(asset)


  return Velora.invoke(0xA9DCF0,"bool", asset)


end


-- PC:0x9219857D21F0E842 Old:0x8C0B243A


function PED.REMOVE_STEALTH_MODE_ASSET(asset)


  Velora.invoke(0xA9DCF0,"void", asset)


end


-- PC:0xDC2C5C242AAC342B Old:0x1D2B5C70


function PED.SET_PED_LOD_MULTIPLIER(ped, multiplier)


  Velora.invoke(0xA9DD80,"void", ped, multiplier)


end


-- PC:0xE861D0B05C7662B8 Old:0x2F9550C2


function PED.SET_PED_CAN_LOSE_PROPS_ON_DAMAGE(ped, toggle, p2)


  Velora.invoke(0xA9DDE0,"void", ped, toggle, p2)


end


-- PC:0x129466ED55140F8D Old:0x37DBC2AD


function PED.SET_FORCE_FOOTSTEP_UPDATE(ped, toggle)


  Velora.invoke(0xA9DE70,"void", ped, toggle)


end


-- PC:0xCB968B53FC7F916D Old:0xC0F1BC91


function PED.SET_FORCE_STEP_TYPE(ped, p1, type, p3)


  Velora.invoke(0xA9DEC0,"void", ped, p1, type, p3)


end


-- PC:0x68772DB2B2526F9F Old:0x1A464167


function PED.IS_ANY_HOSTILE_PED_NEAR_POINT(ped, x, y, z, radius)


  return Velora.invoke(0xA9DF60,"bool", ped, x, y, z, radius)


end


function PED.SET_PED_CAN_PLAY_IN_CAR_IDLES(ped, toggle)


  Velora.invoke(0xA9DF60,"void", ped, toggle)


end


-- PC:0x06087579E7AA85A9 Old:0xD0567D41


function PED.IS_TARGET_PED_IN_PERCEPTION_AREA(ped, targetPed, p2, p3, p4, p5)


  return Velora.invoke(0xA9E000,"bool", ped, targetPed, p2, p3, p4, p5)


end


-- PC:0xD8C3BE3EE94CAF2D Old:0x4BBE5E2C


function PED.SET_POP_CONTROL_SPHERE_THIS_FRAME(x, y, z, min, max)


  Velora.invoke(0xA9E000,"void", x, y, z, min, max)


end


-- PC:0xD33DAA36272177C4 Old:0xA89A53F2


function PED.FORCE_ZERO_MASS_IN_COLLISIONS(ped)


  Velora.invoke(0xA9E070,"void", ped)


end


function PED.SET_DISABLE_HIGH_FALL_DEATH(ped, toggle)


  Velora.invoke(0xA9E0B0,"void", ped, toggle)


end


function PED.SET_PED_PHONE_PALETTE_IDX(p0, p1)


  Velora.invoke(0xA9E100,"void", p0, p1)


end


function PED.SET_PED_STEER_BIAS(ped, value)


  Velora.invoke(0xA9E140,"void", ped, value)


end


function PED.IS_PED_SWITCHING_WEAPON(Ped)


  return Velora.invoke(0xA9E1F0,"bool", Ped)


end


function PED.SET_PED_TREATED_AS_FRIENDLY(p0, p1, p2)


  Velora.invoke(0xA9E1F0,"void", p0, p1, p2)


end


function PED.SET_DISABLE_PED_MAP_COLLISION(ped)


  Velora.invoke(0xA9E270,"void", ped)


end


function PED.ENABLE_MP_LIGHT(ped, toggle)


  Velora.invoke(0xA9E330,"void", ped, toggle)


end


function PED.GET_MP_LIGHT_ENABLED(ped)


  return Velora.invoke(0xA9E3E0,"bool", ped)


end


function PED.CLEAR_COVER_POINT_FOR_PED(ped)


  Velora.invoke(0xA9E3E0,"void", ped)


end


function PED.SET_ALLOW_STUNT_JUMP_CAMERA(ped, toggle)


  Velora.invoke(0xA9E430,"void", ped, toggle)


end


