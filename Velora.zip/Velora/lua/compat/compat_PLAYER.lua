-- compat_PLAYER.lua — AUTO GENERATO


-- PLAYER


PLAYER=PLAYER or {}


-- PC:0x43A66C31C68491C0 Old:0x6E31E993


function PLAYER.GET_PLAYER_PED(player)


  return Velora.invoke(0xAA93A0,"int", player)


end


-- PC:0x50FAC3A3E030A6E1 Old:0x6AC64990


function PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player)


  return Velora.invoke(0xAA9360,"int", player)


end


-- PC:0x00A1CADD00108836 Old:0x774A4C54


function PLAYER.SET_PLAYER_MODEL(player, model)


  Velora.invoke(0xAA93A0,"void", player, model)


end


-- PC:0x048189FAC643DEEE Old:0xBE515485


function PLAYER.CHANGE_PLAYER_PED(player, ped, p2, resetDamage)


  Velora.invoke(0xAA93B0,"void", player, ped, p2, resetDamage)


end


-- PC:0xE902EF951DCE178F Old:0x6EF43BBB


function PLAYER.GET_PLAYER_RGB_COLOUR(player)


  Velora.invoke(0xAA93E0,"void", player)


end


-- PC:0x407C7F91DDB46C16 Old:0x4C1B8867


function PLAYER.GET_NUMBER_OF_PLAYERS()


  return Velora.invoke(0xAA94B0,"int")


end


-- PC:0x37039302F4E0A008 Old:0x9873E404


function PLAYER.GET_PLAYER_TEAM(player)


  return Velora.invoke(0xAA9470,"int", player)


end


-- PC:0x0299FA38396A4940 Old:0x725ADCF2


function PLAYER.SET_PLAYER_TEAM(player, team)


  Velora.invoke(0xAA94B0,"void", player, team)


end


function PLAYER.GET_NUMBER_OF_PLAYERS_IN_TEAM(team)


  return Velora.invoke(0xAA9700,"int", team)


end


-- PC:0x085DEB493BE80812 Old:0x1CF7D7DA


function PLAYER.GET_WANTED_LEVEL_RADIUS(player)


  return Velora.invoke(0xAA9630,"float", player)


end


-- PC:0x0C92BA89F1AF26F8 Old:0x821F2D2C


function PLAYER.GET_PLAYER_WANTED_CENTRE_POSITION(player)


  local x,y,z=Velora.invoke(0xAA9660,"vector3", player)


  return {x=x,y=y,z=z}


end


-- PC:0x520E541A97A13354 Old:0xF261633A


function PLAYER.SET_PLAYER_WANTED_CENTRE_POSITION(player, p2, p3)


  Velora.invoke(0xAA9700,"void", player, p2, p3)


end


-- PC:0xFDD179EAF45B556C Old:0xD9783F6B


function PLAYER.GET_WANTED_LEVEL_THRESHOLD(wantedLevel)


  return Velora.invoke(0xAA97A0,"int", wantedLevel)


end


-- PC:0x39FF19C64EF7DA5B Old:0xB7A0914B


function PLAYER.SET_PLAYER_WANTED_LEVEL(player, wantedLevel, disableNoMission)


  Velora.invoke(0xAA97A0,"void", player, wantedLevel, disableNoMission)


end


-- PC:0x340E61DE7F471565 Old:0xED6F44F5


function PLAYER.SET_PLAYER_WANTED_LEVEL_NO_DROP(player, wantedLevel, p2)


  Velora.invoke(0xAA97C0,"void", player, wantedLevel, p2)


end


-- PC:0xE0A7D1E497FFCD6F Old:0xAF3AFD83


function PLAYER.SET_PLAYER_WANTED_LEVEL_NOW(player, p1)


  Velora.invoke(0xAA9880,"void", player, p1)


end


-- PC:0xAFAF86043E5874E9 Old:0xE13A71C7


function PLAYER.ARE_PLAYER_FLASHING_STARS_ABOUT_TO_DROP(player)


  return Velora.invoke(0xAA9A80,"bool", player)


end


-- PC:0x0A6EB355EE14A2DB Old:0x5E72AB72


function PLAYER.ARE_PLAYER_STARS_GREYED_OUT(player)


  return Velora.invoke(0xAA99B0,"bool", player)


end


function PLAYER.IS_WANTED_AND_HAS_BEEN_SEEN_BY_COPS(player)


  return Velora.invoke(0xAA9A10,"bool", player)


end


-- PC:0xDB172424876553F4 Old:0x48A18913


function PLAYER.SET_DISPATCH_COPS_FOR_PLAYER(player, toggle)


  Velora.invoke(0xAA9A80,"void", player, toggle)


end


-- PC:0x238DB2A2C23EE9EF Old:0x589A2661


function PLAYER.IS_PLAYER_WANTED_LEVEL_GREATER(player, wantedLevel)


  return Velora.invoke(0xAA9B40,"bool", player, wantedLevel)


end


-- PC:0xB302540597885499 Old:0x54EA5BCC


function PLAYER.CLEAR_PLAYER_WANTED_LEVEL(player)


  Velora.invoke(0xAA9B40,"void", player)


end


-- PC:0x424D4687FA1E5652 Old:0x140CA5A8


function PLAYER.IS_PLAYER_DEAD(player)


  return Velora.invoke(0xAA9C60,"bool", player)


end


-- PC:0xFA1E2BF8B10598F9 Old:0xED1D1662


function PLAYER.IS_PLAYER_PRESSING_HORN(player)


  return Velora.invoke(0xAA9C20,"bool", player)


end


-- PC:0x8D32347D6D4C40A2 Old:0xD17AFCD8


function PLAYER.SET_PLAYER_CONTROL(player, bHasControl, flags)


  Velora.invoke(0xAA9C60,"void", player, bHasControl, flags)


end


-- PC:0xE28E54788CE8F12D Old:0xBDCDD163


function PLAYER.GET_PLAYER_WANTED_LEVEL(player)


  return Velora.invoke(0xAA9CD0,"int", player)


end


-- PC:0xAA5F02DB48D704B9 Old:0x665A06F5


function PLAYER.SET_MAX_WANTED_LEVEL(maxWantedLevel)


  Velora.invoke(0xAA9CD0,"void", maxWantedLevel)


end


-- PC:0x43286D561B72B8BF Old:0x8E114B10


function PLAYER.SET_POLICE_RADAR_BLIPS(toggle)


  Velora.invoke(0xAA9CF0,"void", toggle)


end


-- PC:0x32C62AA929C2DA6A Old:0xE6DE71B7


function PLAYER.SET_POLICE_IGNORE_PLAYER(player, toggle)


  Velora.invoke(0xAA9D10,"void", player, toggle)


end


-- PC:0x5E9564D8246B909A Old:0xE15D777F


function PLAYER.IS_PLAYER_PLAYING(player)


  return Velora.invoke(0xAA9DC0,"bool", player)


end


-- PC:0x8EEDA153AD141BA4 Old:0xC915285E


function PLAYER.SET_EVERYONE_IGNORE_PLAYER(player, toggle)


  Velora.invoke(0xAA9DC0,"void", player, toggle)


end


-- PC:0x056E0FE8534C2949 Old:0x49EAE968


function PLAYER.SET_ALL_RANDOM_PEDS_FLEE(player, toggle)


  Velora.invoke(0xAA9E30,"void", player, toggle)


end


-- PC:0x471D2FF42A94B4F2 Old:0xBF974891


function PLAYER.SET_ALL_RANDOM_PEDS_FLEE_THIS_FRAME(player)


  Velora.invoke(0xAA9E80,"void", player)


end


-- PC:0xDE45D1A1EF45EE61 Old:0x274631FE


function PLAYER.SET_ALL_NEUTRAL_RANDOM_PEDS_FLEE(player, toggle)


  Velora.invoke(0xAA9EB0,"void", player, toggle)


end


-- PC:0xC3376F42B1FACCC6 Old:0x02DF7AF4


function PLAYER.SET_ALL_NEUTRAL_RANDOM_PEDS_FLEE_THIS_FRAME(player)


  Velora.invoke(0xAA9F10,"void", player)


end


function PLAYER.SET_LAW_PEDS_CAN_ATTACK_NON_WANTED_PLAYER_THIS_FRAME(player)


  Velora.invoke(0xAA9F40,"void", player)


end


-- PC:0x596976B02B6B5700 Old:0xA3D675ED


function PLAYER.SET_IGNORE_LOW_PRIORITY_SHOCKING_EVENTS(player, toggle)


  Velora.invoke(0xAA9F70,"void", player, toggle)


end


-- PC:0x020E5F00CDA207BA Old:0x1359292F


function PLAYER.SET_WANTED_LEVEL_MULTIPLIER(multiplier)


  Velora.invoke(0xAA9FC0,"void", multiplier)


end


-- PC:0x9B0BB33B04405E7A Old:0xB552626C


function PLAYER.SET_WANTED_LEVEL_DIFFICULTY(player, difficulty)


  Velora.invoke(0xAAA000,"void", player, difficulty)


end


-- PC:0xB9D0DD990DC141DD Old:0xA64C378D


function PLAYER.RESET_WANTED_LEVEL_DIFFICULTY(player)


  Velora.invoke(0xAAA050,"void", player)


end


function PLAYER.GET_WANTED_LEVEL_TIME_TO_ESCAPE()


  return Velora.invoke(0xAAA0B0,"int")


end


function PLAYER.SET_WANTED_LEVEL_HIDDEN_ESCAPE_TIME(player, wantedLevel, lossTime)


  Velora.invoke(0xAAA0B0,"void", player, wantedLevel, lossTime)


end


function PLAYER.RESET_WANTED_LEVEL_HIDDEN_ESCAPE_TIME(player)


  Velora.invoke(0xAAA100,"void", player)


end


-- PC:0xBF9BD71691857E48 Old:0x5F8A22A6


function PLAYER.START_FIRING_AMNESTY(duration)


  Velora.invoke(0xAAA140,"void", duration)


end


-- PC:0xE9B09589827545E7 Old:0xD8EB3A44


function PLAYER.REPORT_CRIME(player, crimeType, wantedLvlThresh)


  Velora.invoke(0xAAA1A0,"void", player, crimeType, wantedLvlThresh)


end


-- PC:0x9A987297ED8BD838 Old:0x59B5C2A2


function PLAYER.SUPPRESS_CRIME_THIS_FRAME(player, crimeType)


  Velora.invoke(0xAAA270,"void", player, crimeType)


end


-- PC:0xBC9490CA15AEA8FB Old:0x6B34A160


function PLAYER.UPDATE_WANTED_POSITION_THIS_FRAME(player)


  Velora.invoke(0xAAA2C0,"void", player)


end


-- PC:0x4669B3ED80F24B4E Old:0xB9FB142F


function PLAYER.SUPPRESS_LOSING_WANTED_LEVEL_IF_HIDDEN_THIS_FRAME(player)


  Velora.invoke(0xAAA2F0,"void", player)


end


function PLAYER.ALLOW_EVASION_HUD_IF_DISABLING_HIDDEN_EVASION_THIS_FRAME(player, p1)


  Velora.invoke(0xAAA320,"void", player, p1)


end


-- PC:0xAD73CE5A09E42D12 Old:0x85725848


function PLAYER.FORCE_START_HIDDEN_EVASION(player)


  Velora.invoke(0xAAA390,"void", player)


end


-- PC:0x36F1B38855F2A8DF Old:0x3A7E5FB6


function PLAYER.SUPPRESS_WITNESSES_CALLING_POLICE_THIS_FRAME(player)


  Velora.invoke(0xAAA3D0,"void", player)


end


-- PC:0xDC64D2C53493ED12 Old:0xD15C4B1C


function PLAYER.REPORT_POLICE_SPOTTED_PLAYER(player)


  Velora.invoke(0xAAA400,"void", player)


end


-- PC:0xB45EFF719D8427A6 Old:0xBF6993C7


function PLAYER.SET_LAW_RESPONSE_DELAY_OVERRIDE(p0)


  Velora.invoke(0xAAA490,"void", p0)


end


-- PC:0x0032A6DBA562C518 Old:0x47CAB814


function PLAYER.RESET_LAW_RESPONSE_DELAY_OVERRIDE()


  Velora.invoke(0xAAA4B0,"void")


end


-- PC:0xDE7465A27D403C06 Old:0x39E3CB3F


function PLAYER.CAN_PLAYER_START_MISSION(player)


  return Velora.invoke(0xAAA7A0,"bool", player)


end


-- PC:0x908CBECC2CAA3690 Old:0xBB77E9CD


function PLAYER.IS_PLAYER_READY_FOR_CUTSCENE(player)


  return Velora.invoke(0xAAA500,"bool", player)


end


-- PC:0x7912F7FC4F6264B6 Old:0xF3240B77


function PLAYER.IS_PLAYER_TARGETTING_ENTITY(player, entity)


  return Velora.invoke(0xAAA530,"bool", player, entity)


end


-- PC:0x13EDE1A5DBF797C9 Old:0xF6AAA2D7


function PLAYER.GET_PLAYER_TARGET_ENTITY(player)


  return Velora.invoke(0xAAA5D0,"bool", player)


end


-- PC:0x2E397FD2ECD37C87 Old:0x1DEC67B7


function PLAYER.IS_PLAYER_FREE_AIMING(player)


  return Velora.invoke(0xAAA630,"bool", player)


end


-- PC:0x3C06B5C839B38F7B Old:0x7D80EEAA


function PLAYER.IS_PLAYER_FREE_AIMING_AT_ENTITY(player, entity)


  return Velora.invoke(0xAAA680,"bool", player, entity)


end


-- PC:0x2975C866E6713290 Old:0x8866D9D0


function PLAYER.GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(player)


  return Velora.invoke(0xAAA730,"bool", player)


end


-- PC:0x29961D490E5814FD Old:0x74D42C03


function PLAYER.SET_PLAYER_LOCKON_RANGE_OVERRIDE(player, range)


  Velora.invoke(0xAAA7A0,"void", player, range)


end


-- PC:0x6E8834B52EC20C77 Old:0xF4D99685


function PLAYER.SET_PLAYER_CAN_DO_DRIVE_BY(player, toggle)


  Velora.invoke(0xAAA7F0,"void", player, toggle)


end


-- PC:0xD5E460AD7020A246 Old:0x71B305BB


function PLAYER.SET_PLAYER_CAN_BE_HASSLED_BY_GANGS(player, toggle)


  Velora.invoke(0xAAA840,"void", player, toggle)


end


-- PC:0xD465A8599DFF6814 Old:0x13CAFAFA


function PLAYER.SET_PLAYER_CAN_USE_COVER(player, toggle)


  Velora.invoke(0xAAA890,"void", player, toggle)


end


-- PC:0x462E0DB9B137DC5F Old:0x457F1E44


function PLAYER.GET_MAX_WANTED_LEVEL()


  return Velora.invoke(0xAAA940,"int")


end


-- PC:0x78CFE51896B6B8A4 Old:0x456DB50D


function PLAYER.IS_PLAYER_TARGETTING_ANYTHING(player)


  return Velora.invoke(0xAAA8F0,"bool", player)


end


-- PC:0xA01B8075D8B92DF4 Old:0x7DD7900C


function PLAYER.SET_PLAYER_SPRINT(player, toggle)


  Velora.invoke(0xAAA940,"void", player, toggle)


end


-- PC:0xA6F312FCCE9C1DFE Old:0xC0445A9C


function PLAYER.RESET_PLAYER_STAMINA(player)


  Velora.invoke(0xAAA990,"void", player)


end


-- PC:0xA352C1B864CAFD33 Old:0x62A93608


function PLAYER.RESTORE_PLAYER_STAMINA(player, p1)


  Velora.invoke(0xAAA9C0,"void", player, p1)


end


-- PC:0x3F9F16F8E65A7ED7 Old:0x47017C90


function PLAYER.GET_PLAYER_SPRINT_STAMINA_REMAINING(player)


  return Velora.invoke(0xAAADD0,"float", player)


end


-- PC:0x1885BC9B108B4C99 Old:0x40E80543


function PLAYER.GET_PLAYER_SPRINT_TIME_REMAINING(player)


  return Velora.invoke(0xAAAA70,"float", player)


end


-- PC:0xA1FCF8E6AF40B731 Old:0x1317125A


function PLAYER.GET_PLAYER_UNDERWATER_TIME_REMAINING(player)


  return Velora.invoke(0xAAAAE0,"float", player)


end


function PLAYER.SET_PLAYER_UNDERWATER_BREATH_PERCENT_REMAINING(player, time)


  return Velora.invoke(0xAAAB40,"float", player, time)


end


-- PC:0x0D127585F77030AF Old:0xA5EDCDE8


function PLAYER.GET_PLAYER_GROUP(player)


  return Velora.invoke(0xAAABB0,"int", player)


end


-- PC:0x92659B4CE1863CB3 Old:0x02A50657


function PLAYER.GET_PLAYER_MAX_ARMOUR(player)


  return Velora.invoke(0xAAABD0,"int", player)


end


-- PC:0x49C32D60007AFA47 Old:0x618857F2


function PLAYER.IS_PLAYER_CONTROL_ON(player)


  return Velora.invoke(0xAAAC10,"bool", player)


end


function PLAYER.GET_ARE_CAMERA_CONTROLS_DISABLED()


  return Velora.invoke(0xAAAC70,"bool")


end


-- PC:0x8A876A65283DD7D7 Old:0x61B00A84


function PLAYER.IS_PLAYER_SCRIPT_CONTROL_ON(player)


  return Velora.invoke(0xAAACB0,"bool", player)


end


-- PC:0x95E8F73DC65EFB9C Old:0x4A9E9AE0


function PLAYER.IS_PLAYER_CLIMBING(player)


  return Velora.invoke(0xAAAD00,"bool", player)


end


-- PC:0x388A47C51ABDAC8E Old:0x7F6A60D3


function PLAYER.IS_PLAYER_BEING_ARRESTED(player, atArresting)


  return Velora.invoke(0xAAAD40,"bool", player, atArresting)


end


-- PC:0x2D03E13C460760D6 Old:0x453C7CAB


function PLAYER.RESET_PLAYER_ARREST_STATE(player)


  Velora.invoke(0xAAADD0,"void", player)


end


-- PC:0xB6997A7EB3F5C8C0 Old:0xE2757AC1


function PLAYER.GET_PLAYERS_LAST_VEHICLE()


  return Velora.invoke(0xAAB0C0,"int")


end


-- PC:0xA5EDC40EF369B48D Old:0x309BBDC1


function PLAYER.GET_PLAYER_INDEX()


  return Velora.invoke(0xAAAE30,"int")


end


-- PC:0x41BD2A6B006AF756 Old:0x98DD98F1


function PLAYER.INT_TO_PLAYERINDEX(value)


  return Velora.invoke(0xAAAE70,"int", value)


end


-- PC:0x9EC6603812C24710 Old:0x98F3B274


function PLAYER.INT_TO_PARTICIPANTINDEX(value)


  return Velora.invoke(0xAAAE80,"int", value)


end


-- PC:0x5D35ECF3A81A0EE0 Old:0x6E9B8B9E


function PLAYER.GET_TIME_SINCE_PLAYER_HIT_VEHICLE(player)


  return Velora.invoke(0xAAAE90,"int", player)


end


-- PC:0xE36A25322DC35F42 Old:0xB6209195


function PLAYER.GET_TIME_SINCE_PLAYER_HIT_PED(player)


  return Velora.invoke(0xAAAED0,"int", player)


end


-- PC:0xD559D2BE9E37853B Old:0x8836E732


function PLAYER.GET_TIME_SINCE_PLAYER_DROVE_ON_PAVEMENT(player)


  return Velora.invoke(0xAAAF10,"int", player)


end


-- PC:0xDB89591E290D9182 Old:0x9F27D00E


function PLAYER.GET_TIME_SINCE_PLAYER_DROVE_AGAINST_TRAFFIC(player)


  return Velora.invoke(0xAAAF50,"int", player)


end


-- PC:0xDCCFD3F106C36AB4 Old:0x85C7E232


function PLAYER.IS_PLAYER_FREE_FOR_AMBIENT_TASK(player)


  return Velora.invoke(0xAAAF90,"bool", player)


end


-- PC:0x4F8644AF03D0E0D6 Old:0x8AEA886C


function PLAYER.PLAYER_ID()


  return Velora.invoke(0xAAAFC0,"int")


end


-- PC:0xD80958FC74E988A6 Old:0xFA92E226


function PLAYER.PLAYER_PED_ID()


  return Velora.invoke(0xAAB000,"int")


end


-- PC:0xEE68096F9F37341E Old:0x8DD5B838


function PLAYER.NETWORK_PLAYER_ID_TO_INT()


  return Velora.invoke(0xAAB040,"int")


end


-- PC:0xC968670BFACE42D9 Old:0x4B37333C


function PLAYER.HAS_FORCE_CLEANUP_OCCURRED(cleanupFlags)


  return Velora.invoke(0xAAB080,"bool", cleanupFlags)


end


-- PC:0xBC8983F38F78ED51 Old:0xFDAAEA2B


function PLAYER.FORCE_CLEANUP(cleanupFlags)


  Velora.invoke(0xAAB0C0,"void", cleanupFlags)


end


-- PC:0x4C68DDDDF0097317 Old:0x04256C73


function PLAYER.FORCE_CLEANUP_FOR_ALL_THREADS_WITH_THIS_NAME(name, cleanupFlags)


  Velora.invoke(0xAAB100,"void", name, cleanupFlags)


end


-- PC:0xF745B37630DF176B Old:0x882D3EB3


function PLAYER.FORCE_CLEANUP_FOR_THREAD_WITH_THIS_ID(id, cleanupFlags)


  Velora.invoke(0xAAB130,"void", id, cleanupFlags)


end


-- PC:0x9A41CF4674A12272 Old:0x39AA9FC8


function PLAYER.GET_CAUSE_OF_MOST_RECENT_FORCE_CLEANUP()


  return Velora.invoke(0xAAB1A0,"int")


end


-- PC:0x8026FF78F208978A Old:0xA454DD29


function PLAYER.SET_PLAYER_MAY_ONLY_ENTER_THIS_VEHICLE(player, vehicle)


  Velora.invoke(0xAAB1A0,"void", player, vehicle)


end


-- PC:0x1DE37BBF9E9CC14A Old:0xAF7AFCC4


function PLAYER.SET_PLAYER_MAY_NOT_ENTER_ANY_VEHICLE(player)


  Velora.invoke(0xAAB1B0,"void", player)


end


-- PC:0xBEC7076D64130195 Old:0x822BC992


function PLAYER.GIVE_ACHIEVEMENT_TO_PLAYER(achievementId)


  return Velora.invoke(0xAAB2F0,"bool", achievementId)


end


function PLAYER.SET_ACHIEVEMENT_PROGRESS(achievementId, progress)


  return Velora.invoke(0xAAB220,"bool", achievementId, progress)


end


function PLAYER.GET_ACHIEVEMENT_PROGRESS(achievementId)


  return Velora.invoke(0xAAB250,"int", achievementId)


end


-- PC:0x867365E111A3B6EB Old:0x136A5BE9


function PLAYER.HAS_ACHIEVEMENT_BEEN_PASSED(achievementId)


  return Velora.invoke(0xAAB280,"bool", achievementId)


end


-- PC:0xF25D331DC2627BBC Old:0x9FAB6729


function PLAYER.IS_PLAYER_ONLINE()


  return Velora.invoke(0xAAB2B0,"bool")


end


-- PC:0x74556E1420867ECA Old:0x8F72FAD0


function PLAYER.IS_PLAYER_LOGGING_IN_NP()


  return Velora.invoke(0xAAB2E0,"bool")


end


-- PC:0x94DD7888C10A979E Old:0x4264CED2


function PLAYER.DISPLAY_SYSTEM_SIGNIN_UI(p0)


  Velora.invoke(0xAAB2F0,"void", p0)


end


-- PC:0x5D511E3867C87139 Old:0xE495B6DA


function PLAYER.IS_SYSTEM_UI_BEING_DISPLAYED()


  return Velora.invoke(0xAAB320,"bool")


end


-- PC:0x239528EACDC3E7DE Old:0xDFB9A2A2


function PLAYER.SET_PLAYER_INVINCIBLE(player, toggle)


  Velora.invoke(0xAAB320,"void", player, toggle)


end


-- PC:0xB721981B2B939E07 Old:0x680C90EE


function PLAYER.GET_PLAYER_INVINCIBLE(player)


  return Velora.invoke(0xAAB3F0,"bool", player)


end


function PLAYER.GET_PLAYER_DEBUG_INVINCIBLE(player)


  return Velora.invoke(0xAAB3E0,"bool", player)


end


function PLAYER.SET_PLAYER_INVINCIBLE_BUT_HAS_REACTIONS(player, toggle)


  Velora.invoke(0xAAB3F0,"void", player, toggle)


end


-- PC:0xCAC57395B151135F Old:0x00563E0D


function PLAYER.SET_PLAYER_CAN_COLLECT_DROPPED_MONEY(player, p1)


  Velora.invoke(0xAAB460,"void", player, p1)


end


-- PC:0xF3AC26D3CC576528 Old:0x6255F3B4


function PLAYER.REMOVE_PLAYER_HELMET(player, p2)


  Velora.invoke(0xAAB4B0,"void", player, p2)


end


-- PC:0x3C49C870E66F0A28 Old:0xC7B4D7AC


function PLAYER.GIVE_PLAYER_RAGDOLL_CONTROL(player, toggle)


  Velora.invoke(0xAAB500,"void", player, toggle)


end


-- PC:0x5C8B2F450EE4328E Old:0x0B270E0F


function PLAYER.SET_PLAYER_LOCKON(player, toggle)


  Velora.invoke(0xAAB560,"void", player, toggle)


end


-- PC:0xB1906895227793F3 Old:0x61CAE253


function PLAYER.SET_PLAYER_TARGETING_MODE(targetMode)


  Velora.invoke(0xAAB5A0,"void", targetMode)


end


-- PC:0x5702B917B99DB1CD Old:0x772DA539


function PLAYER.SET_PLAYER_TARGET_LEVEL(targetLevel)


  Velora.invoke(0xAAB610,"void", targetLevel)


end


function PLAYER.GET_IS_USING_FPS_THIRD_PERSON_COVER()


  return Velora.invoke(0xAAB640,"bool")


end


function PLAYER.GET_IS_USING_HOOD_CAMERA()


  return Velora.invoke(0xDEADBEEF,"bool")


end


-- PC:0xF0B67A4DE6AB5F98 Old:0x1D31CBBD


function PLAYER.CLEAR_PLAYER_HAS_DAMAGED_AT_LEAST_ONE_PED(player)


  Velora.invoke(0xAAB640,"void", player)


end


-- PC:0x20CE80B0C2BF4ACC Old:0x14F52453


function PLAYER.HAS_PLAYER_DAMAGED_AT_LEAST_ONE_PED(player)


  return Velora.invoke(0xAAB6C0,"bool", player)


end


-- PC:0x4AACB96203D11A31 Old:0x7E3BFBC5


function PLAYER.CLEAR_PLAYER_HAS_DAMAGED_AT_LEAST_ONE_NON_ANIMAL_PED(player)


  Velora.invoke(0xAAB6C0,"void", player)


end


-- PC:0xE4B90F367BD81752 Old:0xA3707DFC


function PLAYER.HAS_PLAYER_DAMAGED_AT_LEAST_ONE_NON_ANIMAL_PED(player)


  return Velora.invoke(0xAAB740,"bool", player)


end


-- PC:0xCA7DC8329F0A1E9E Old:0xF20F72E5


function PLAYER.SET_AIR_DRAG_MULTIPLIER_FOR_PLAYERS_VEHICLE(player, multiplier)


  Velora.invoke(0xAAB740,"void", player, multiplier)


end


-- PC:0xA91C6F0FF7D16A13 Old:0xB986FF47


function PLAYER.SET_SWIM_MULTIPLIER_FOR_PLAYER(player, multiplier)


  Velora.invoke(0xAAB7A0,"void", player, multiplier)


end


-- PC:0x6DB47AA77FD94E09 Old:0x825423C2


function PLAYER.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(player, multiplier)


  Velora.invoke(0xAAB800,"void", player, multiplier)


end


-- PC:0x5063F92F07C2A316 Old:0x62824EF4


function PLAYER.GET_TIME_SINCE_LAST_ARREST()


  return Velora.invoke(0xAAB8C0,"int")


end


-- PC:0xC7034807558DDFCA Old:0x24BC5AC0


function PLAYER.GET_TIME_SINCE_LAST_DEATH()


  return Velora.invoke(0xAAB890,"int")


end


-- PC:0xAEBF081FFC0A0E5E Old:0xF23277F3


function PLAYER.ASSISTED_MOVEMENT_CLOSE_ROUTE()


  Velora.invoke(0xAAB8C0,"void")


end


-- PC:0x8621390F0CDCFE1F Old:0xD04568B9


function PLAYER.ASSISTED_MOVEMENT_FLUSH_ROUTE()


  Velora.invoke(0xAAB910,"void")


end


-- PC:0x0FEE4F80AC44A726 Old:0x94E42E2E


function PLAYER.SET_PLAYER_FORCED_AIM(player, toggle)


  Velora.invoke(0xAAB940,"void", player, toggle)


end


-- PC:0x75E7D505F2B15902 Old:0xB0C576CB


function PLAYER.SET_PLAYER_FORCED_ZOOM(player, toggle)


  Velora.invoke(0xAAB980,"void", player, toggle)


end


-- PC:0x7651BC64AE59E128 Old:0x374F42F0


function PLAYER.SET_PLAYER_FORCE_SKIP_AIM_INTRO(player, toggle)


  Velora.invoke(0xAAB9D0,"void", player, toggle)


end


-- PC:0x5E6CC07646BBEAB8 Old:0x30CB28CB


function PLAYER.DISABLE_PLAYER_FIRING(player, toggle)


  Velora.invoke(0xAABA20,"void", player, toggle)


end


function PLAYER.DISABLE_PLAYER_THROW_GRENADE_WHILE_USING_GUN()


  Velora.invoke(0xAABAB0,"void")


end


-- PC:0x2E8AABFA40A84F8C Old:0xCCD937E7


function PLAYER.SET_DISABLE_AMBIENT_MELEE_MOVE(player, toggle)


  Velora.invoke(0xAABAD0,"void", player, toggle)


end


-- PC:0x77DFCCF5948B8C71 Old:0xC6C3C53B


function PLAYER.SET_PLAYER_MAX_ARMOUR(player, value)


  Velora.invoke(0xAABB90,"void", player, value)


end


function PLAYER.SPECIAL_ABILITY_ACTIVATE(player, p1)


  Velora.invoke(0xAABBD0,"void", player, p1)


end


function PLAYER.SET_SPECIAL_ABILITY_MP(player, p1, p2)


  Velora.invoke(0xAABC30,"void", player, p1, p2)


end


function PLAYER.SPECIAL_ABILITY_DEACTIVATE_MP(player, p1)


  Velora.invoke(0xAABCA0,"void", player, p1)


end


-- PC:0xD6A953C6D1492057 Old:0x80C2AB09


function PLAYER.SPECIAL_ABILITY_DEACTIVATE(player, p1)


  Velora.invoke(0xAABCB0,"void", player, p1)


end


-- PC:0x9CB5CE07A3968D5A Old:0x0751908A


function PLAYER.SPECIAL_ABILITY_DEACTIVATE_FAST(player, p1)


  Velora.invoke(0xAABD10,"void", player, p1)


end


-- PC:0x375F0E738F861A94 Old:0xA7D8BCD3


function PLAYER.SPECIAL_ABILITY_RESET(player, p1)


  Velora.invoke(0xAABD80,"void", player, p1)


end


-- PC:0xC9A763D8FE87436A Old:0x4136829A


function PLAYER.SPECIAL_ABILITY_CHARGE_ON_MISSION_FAILED(player, p1)


  Velora.invoke(0xAABDE0,"void", player, p1)


end


-- PC:0x2E7B9B683481687D Old:0x6F463F56


function PLAYER.SPECIAL_ABILITY_CHARGE_SMALL(player, p1, p2, p3)


  Velora.invoke(0xAABE40,"void", player, p1, p2, p3)


end


-- PC:0xF113E3AA9BC54613 Old:0xAB55D8F3


function PLAYER.SPECIAL_ABILITY_CHARGE_MEDIUM(player, p1, p2, p3)


  Velora.invoke(0xAABE70,"void", player, p1, p2, p3)


end


-- PC:0xF733F45FA4497D93 Old:0xF440C04D


function PLAYER.SPECIAL_ABILITY_CHARGE_LARGE(player, p1, p2, p3)


  Velora.invoke(0xAABEA0,"void", player, p1, p2, p3)


end


-- PC:0xED481732DFF7E997 Old:0x5FEE98A2


function PLAYER.SPECIAL_ABILITY_CHARGE_CONTINUOUS(player, p1, p2)


  Velora.invoke(0xAABED0,"void", player, p1, p2)


end


-- PC:0xB7B0870EB531D08D Old:0x72429998


function PLAYER.SPECIAL_ABILITY_CHARGE_ABSOLUTE(player, p1, p2, p3)


  Velora.invoke(0xAABF50,"void", player, p1, p2, p3)


end


-- PC:0xA0696A65F009EE18 Old:0x8C7E68C1


function PLAYER.SPECIAL_ABILITY_CHARGE_NORMALIZED(player, normalizedValue, p2, p3)


  Velora.invoke(0xAABFD0,"void", player, normalizedValue, p2, p3)


end


-- PC:0x3DACA8DDC6FD4980 Old:0xB71589DA


function PLAYER.SPECIAL_ABILITY_FILL_METER(player, p1, p2)


  Velora.invoke(0xAAC060,"void", player, p1, p2)


end


-- PC:0x1D506DBBBC51E64B Old:0x9F80F6DF


function PLAYER.SPECIAL_ABILITY_DEPLETE_METER(player, p1, p2)


  Velora.invoke(0xAAC0E0,"void", player, p1, p2)


end


-- PC:0x6A09D0D590A47D13 Old:0x1B7BB388


function PLAYER.SPECIAL_ABILITY_LOCK(playerModel, p1)


  Velora.invoke(0xAAC160,"void", playerModel, p1)


end


-- PC:0xF145F3BE2EFA9A3B Old:0x1FDB2919


function PLAYER.SPECIAL_ABILITY_UNLOCK(playerModel, p1)


  Velora.invoke(0xAAC180,"void", playerModel, p1)


end


-- PC:0xC6017F6A6CDFA694 Old:0xC9C75E82


function PLAYER.IS_SPECIAL_ABILITY_UNLOCKED(playerModel)


  return Velora.invoke(0xAAC2B0,"bool", playerModel)


end


-- PC:0x3E5F7FC85D854E15 Old:0x1B17E334


function PLAYER.IS_SPECIAL_ABILITY_ACTIVE(player, p1)


  return Velora.invoke(0xAAC1D0,"bool", player, p1)


end


-- PC:0x05A1FE504B7F2587 Old:0x2E19D7F6


function PLAYER.IS_SPECIAL_ABILITY_METER_FULL(player, p1)


  return Velora.invoke(0xAAC240,"bool", player, p1)


end


-- PC:0x181EC197DAEFE121 Old:0xC86C1B4E


function PLAYER.ENABLE_SPECIAL_ABILITY(player, toggle, p2)


  Velora.invoke(0xAAC2B0,"void", player, toggle, p2)


end


-- PC:0xB1D200FE26AEF3CB Old:0xC01238CC


function PLAYER.IS_SPECIAL_ABILITY_ENABLED(player, p1)


  return Velora.invoke(0xAAC390,"bool", player, p1)


end


-- PC:0xA49C426ED0CA4AB7 Old:0xFF1BC556


function PLAYER.SET_SPECIAL_ABILITY_MULTIPLIER(multiplier)


  Velora.invoke(0xAAC390,"void", multiplier)


end


-- PC:0xFFEE8FA29AB9A18E Old:0x5D0FE25B


function PLAYER.UPDATE_SPECIAL_ABILITY_FROM_STAT(player, p1)


  Velora.invoke(0xAAC3B0,"void", player, p1)


end


-- PC:0x5FC472C501CCADB3 Old:0x46E7E31D


function PLAYER.GET_IS_PLAYER_DRIVING_ON_HIGHWAY(player)


  return Velora.invoke(0xAAC560,"bool", player)


end


-- PC:0xF10B44FD479D69F3 Old:0x1E359CC8


function PLAYER.GET_IS_PLAYER_DRIVING_WRECKLESS(player, p1)


  return Velora.invoke(0xAAC490,"bool", player, p1)


end


-- PC:0xDD2620B7B9D16FF1 Old:0x8CB53C9F


function PLAYER.GET_IS_MOPPING_AREA_FREE_IN_FRONT_OF_PLAYER(player, p1)


  return Velora.invoke(0xAAC530,"bool", player, p1)


end


-- PC:0xAD15F075A4DA0FDE Old:0xC552E06C


function PLAYER.START_PLAYER_TELEPORT(player, x, y, z, heading, p5, findCollisionLand, p7)


  Velora.invoke(0xAAC560,"void", player, x, y, z, heading, p5, findCollisionLand, p7)


end


function PLAYER.UPDATE_PLAYER_TELEPORT(player)


  return Velora.invoke(0xAAC5F0,"bool", player)


end


-- PC:0xC449EDED9D73009C Old:0x86AB8DBB


function PLAYER.STOP_PLAYER_TELEPORT()


  Velora.invoke(0xAAC5F0,"void")


end


-- PC:0x02B15662D7F8886F Old:0x3A11D118


function PLAYER.IS_PLAYER_TELEPORT_ACTIVE()


  return Velora.invoke(0xAAC670,"bool")


end


-- PC:0x2F395D61F3A1F877 Old:0xC3B02362


function PLAYER.GET_PLAYER_CURRENT_STEALTH_NOISE(player)


  return Velora.invoke(0xAAC620,"float", player)


end


-- PC:0x5DB660B38DD98A31 Old:0x45514731


function PLAYER.SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER(player, regenRate)


  Velora.invoke(0xAAC670,"void", player, regenRate)


end


function PLAYER.GET_PLAYER_HEALTH_RECHARGE_MAX_PERCENT(player)


  return Velora.invoke(0xAAC710,"float", player)


end


function PLAYER.SET_PLAYER_HEALTH_RECHARGE_MAX_PERCENT(player, limit)


  Velora.invoke(0xAAC710,"void", player, limit)


end


function PLAYER.DISABLE_PLAYER_HEALTH_RECHARGE(player)


  Velora.invoke(0xAAC770,"void", player)


end


function PLAYER.SET_PLAYER_FALL_DISTANCE_TO_TRIGGER_RAGDOLL_OVERRIDE(player, p1)


  Velora.invoke(0xAAC7A0,"void", player, p1)


end


-- PC:0xCE07B9F7817AADA3 Old:0xB02C2F39


function PLAYER.SET_PLAYER_WEAPON_DAMAGE_MODIFIER(player, modifier)


  Velora.invoke(0xAAC7F0,"void", player, modifier)


end


-- PC:0x2D83BC011CA14A3C Old:0xAE446344


function PLAYER.SET_PLAYER_WEAPON_DEFENSE_MODIFIER(player, modifier)


  Velora.invoke(0xAAC840,"void", player, modifier)


end


function PLAYER.SET_PLAYER_WEAPON_MINIGUN_DEFENSE_MODIFIER(player, modifier)


  Velora.invoke(0xAAC890,"void", player, modifier)


end


-- PC:0x4A3DC7ECCC321032 Old:0x362E69AD


function PLAYER.SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(player, modifier, p2)


  Velora.invoke(0xAAC8E0,"void", player, modifier, p2)


end


-- PC:0xAE540335B4ABC4E2 Old:0x9F3D577F


function PLAYER.SET_PLAYER_MELEE_WEAPON_DEFENSE_MODIFIER(player, modifier)


  Velora.invoke(0xAAC940,"void", player, modifier)


end


-- PC:0xA50E117CDDF82F0C Old:0x823ECA63


function PLAYER.SET_PLAYER_VEHICLE_DAMAGE_MODIFIER(player, modifier)


  Velora.invoke(0xAAC990,"void", player, modifier)


end


-- PC:0x4C60E6EFDAFF2462 Old:0xA16626C7


function PLAYER.SET_PLAYER_VEHICLE_DEFENSE_MODIFIER(player, modifier)


  Velora.invoke(0xAAC9E0,"void", player, modifier)


end


function PLAYER.SET_PLAYER_MAX_EXPLOSIVE_DAMAGE(player, p1)


  Velora.invoke(0xAACA30,"void", player, p1)


end


function PLAYER.SET_PLAYER_EXPLOSIVE_DAMAGE_MODIFIER(player, p1)


  Velora.invoke(0xAACA80,"void", player, p1)


end


function PLAYER.SET_PLAYER_WEAPON_TAKEDOWN_DEFENSE_MODIFIER(player, p1)


  Velora.invoke(0xAACAD0,"void", player, p1)


end


-- PC:0xA3D0E54541D9A5E5 Old:0x8EA12EDB


function PLAYER.SET_PLAYER_PARACHUTE_TINT_INDEX(player, tintIndex)


  Velora.invoke(0xAACB20,"void", player, tintIndex)


end


-- PC:0x75D3F7A1B0D9B145 Old:0x432B0509


function PLAYER.GET_PLAYER_PARACHUTE_TINT_INDEX(player)


  Velora.invoke(0xAACB60,"void", player)


end


-- PC:0xAF04C87F5DC1DF38 Old:0x70689638


function PLAYER.SET_PLAYER_RESERVE_PARACHUTE_TINT_INDEX(player, index)


  Velora.invoke(0xAACBA0,"void", player, index)


end


-- PC:0xD5A016BC3C09CF40 Old:0x77B8EF01


function PLAYER.GET_PLAYER_RESERVE_PARACHUTE_TINT_INDEX(player)


  Velora.invoke(0xAACBE0,"void", player)


end


-- PC:0x93B0FB27C9A04060 Old:0xD79D5D1B


function PLAYER.SET_PLAYER_PARACHUTE_PACK_TINT_INDEX(player, tintIndex)


  Velora.invoke(0xAACC20,"void", player, tintIndex)


end


-- PC:0x6E9C742F340CE5A2 Old:0x4E418E13


function PLAYER.GET_PLAYER_PARACHUTE_PACK_TINT_INDEX(player)


  Velora.invoke(0xAACC60,"void", player)


end


-- PC:0x7DDAB28D31FAC363 Old:0xA3E4798E


function PLAYER.SET_PLAYER_HAS_RESERVE_PARACHUTE(player)


  Velora.invoke(0xAACCA0,"void", player)


end


-- PC:0x5DDFE2FF727F3CA3 Old:0x30DA1DA1


function PLAYER.GET_PLAYER_HAS_RESERVE_PARACHUTE(player)


  return Velora.invoke(0xAACD10,"bool", player)


end


-- PC:0xF401B182DBA8AF53 Old:0x832DEB7A


function PLAYER.SET_PLAYER_CAN_LEAVE_PARACHUTE_SMOKE_TRAIL(player, enabled)


  Velora.invoke(0xAACD10,"void", player, enabled)


end


-- PC:0x8217FD371A4625CF Old:0x14FE9264


function PLAYER.SET_PLAYER_PARACHUTE_SMOKE_TRAIL_COLOR(player, r, g, b)


  Velora.invoke(0xAACD60,"void", player, r, g, b)


end


-- PC:0xEF56DBABD3CD4887 Old:0xF66E5CDD


function PLAYER.GET_PLAYER_PARACHUTE_SMOKE_TRAIL_COLOR(player)


  Velora.invoke(0xAACE10,"void", player)


end


function PLAYER.SET_PLAYER_PHONE_PALETTE_IDX(player, flags)


  Velora.invoke(0xAACE90,"void", player, flags)


end


-- PC:0xDB89EF50FF25FCE9 Old:0x15786DD1


function PLAYER.SET_PLAYER_NOISE_MULTIPLIER(player, multiplier)


  Velora.invoke(0xAACEC0,"void", player, multiplier)


end


-- PC:0xB2C1A29588A9F47C Old:0x8D2D89C4


function PLAYER.SET_PLAYER_SNEAKING_NOISE_MULTIPLIER(player, multiplier)


  Velora.invoke(0xAACF10,"void", player, multiplier)


end


-- PC:0xF297383AA91DCA29 Old:0x1C70B2EB


function PLAYER.CAN_PED_HEAR_PLAYER(player, ped)


  return Velora.invoke(0xAAD010,"bool", player, ped)


end


-- PC:0x477D5D63E63ECA5D Old:0x0D77CC34


function PLAYER.SIMULATE_PLAYER_INPUT_GAIT(player, amount, gaitType, speed, p4, p5)


  Velora.invoke(0xAAD010,"void", player, amount, gaitType, speed, p4, p5)


end


-- PC:0x19531C47A2ABD691 Old:0x4A701EE1


function PLAYER.RESET_PLAYER_INPUT_GAIT(player)


  Velora.invoke(0xAAD0C0,"void", player)


end


-- PC:0x9F343285A00B4BB6 Old:0xA97C2059


function PLAYER.SET_AUTO_GIVE_PARACHUTE_WHEN_ENTER_PLANE(player, toggle)


  Velora.invoke(0xAAD100,"void", player, toggle)


end


-- PC:0xD2B315B6689D537D Old:0xA25D767E


function PLAYER.SET_AUTO_GIVE_SCUBA_GEAR_WHEN_EXIT_VEHICLE(player, toggle)


  Velora.invoke(0xAAD150,"void", player, toggle)


end


-- PC:0x4E9021C1FCDD507A Old:0x3D26105F


function PLAYER.SET_PLAYER_STEALTH_PERCEPTION_MODIFIER(player, value)


  Velora.invoke(0xAAD1A0,"void", player, value)


end


-- PC:0x690A61A6D13583F6 Old:0x1D371529


function PLAYER.IS_REMOTE_PLAYER_IN_NON_CLONED_VEHICLE(player)


  return Velora.invoke(0xAAD240,"bool", player)


end


-- PC:0x9EDD76E87D5D51BA Old:0xE30A64DC


function PLAYER.INCREASE_PLAYER_JUMP_SUPPRESSION_RANGE(player)


  Velora.invoke(0xAAD240,"void", player)


end


-- PC:0xC54C95DA968EC5B5 Old:0xF1E0CAFC


function PLAYER.SET_PLAYER_SIMULATE_AIMING(player, toggle)


  Velora.invoke(0xAAD270,"void", player, toggle)


end


-- PC:0x749FADDF97DFE930 Old:0xF7A0F00F


function PLAYER.SET_PLAYER_CLOTH_PIN_FRAMES(player, p1)


  Velora.invoke(0xAAD2B0,"void", player, p1)


end


-- PC:0x9F7BBA2EA6372500 Old:0xB8209F16


function PLAYER.SET_PLAYER_CLOTH_PACKAGE_INDEX(index)


  Velora.invoke(0xAAD2F0,"void", index)


end


-- PC:0x14D913B777DFF5DA Old:0x8D9FD4D1


function PLAYER.SET_PLAYER_CLOTH_LOCK_COUNTER(value)


  Velora.invoke(0xAAD320,"void", value)


end


-- PC:0xED51733DC73AED51 Old:0xECD12E60


function PLAYER.PLAYER_ATTACH_VIRTUAL_BOUND(p0, p1, p2, p3, p4, p5, p6, p7)


  Velora.invoke(0xAAD350,"void", p0, p1, p2, p3, p4, p5, p6, p7)


end


-- PC:0x1DD5897E2FA6E7C9 Old:0x96100EA4


function PLAYER.PLAYER_DETACH_VIRTUAL_BOUND()


  Velora.invoke(0xAAD370,"void")


end


-- PC:0xD705740BB0A1CF4C Old:0x4A01B76A


function PLAYER.HAS_PLAYER_BEEN_SPOTTED_IN_STOLEN_VEHICLE(player)


  return Velora.invoke(0xAAD510,"bool", player)


end


-- PC:0x38D28DA81E4E9BF9 Old:0x013B4F72


function PLAYER.IS_PLAYER_BATTLE_AWARE(player)


  return Velora.invoke(0xAAD420,"bool", player)


end


-- PC:0xBC0753C9CA14B506 Old:0x9DF75B2A


function PLAYER.GET_PLAYER_RECEIVED_BATTLE_EVENT_RECENTLY(player, p1, p2)


  return Velora.invoke(0xAAD4A0,"bool", player, p1, p2)


end


-- PC:0x5006D96C995A5827 Old:0x64DDB07D


function PLAYER.EXTEND_WORLD_BOUNDARY_FOR_PLAYER(x, y, z)


  Velora.invoke(0xAAD510,"void", x, y, z)


end


-- PC:0xDA1DF03D5A315F4E Old:0xA97C2F6C


function PLAYER.RESET_WORLD_BOUNDARY_FOR_PLAYER()


  Velora.invoke(0xAAD570,"void")


end


-- PC:0x4EC12697209F2196 Old:0x9765E71D


function PLAYER.IS_PLAYER_RIDING_TRAIN(player)


  return Velora.invoke(0xAAD680,"bool", player)


end


-- PC:0xD55DDFB47991A294 Old:0xFEA40B6C


function PLAYER.HAS_PLAYER_LEFT_THE_WORLD(player)


  return Velora.invoke(0xAAD630,"bool", player)


end


-- PC:0xFF300C7649724A0B Old:0xAD8383FA


function PLAYER.SET_PLAYER_LEAVE_PED_BEHIND(player, toggle)


  Velora.invoke(0xAAD680,"void", player, toggle)


end


-- PC:0xD9284A8C0D48352C Old:0x9254249D


function PLAYER.SET_PLAYER_PARACHUTE_VARIATION_OVERRIDE(player, p1, p2, p3, p4)


  Velora.invoke(0xAAD6D0,"void", player, p1, p2, p3, p4)


end


-- PC:0x0F4CC924CF8C7B21 Old:0xFD60F5AB


function PLAYER.CLEAR_PLAYER_PARACHUTE_VARIATION_OVERRIDE(player)


  Velora.invoke(0xAAD740,"void", player)


end


-- PC:0x977DB4641F6FC3DB Old:0x5D382498


function PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(player, model)


  Velora.invoke(0xAAD770,"void", player, model)


end


function PLAYER.SET_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player, model)


  Velora.invoke(0xAAD7B0,"void", player, model)


end


function PLAYER.GET_PLAYER_PARACHUTE_MODEL_OVERRIDE(player)


  return Velora.invoke(0xAAD870,"int", player)


end


function PLAYER.GET_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player)


  return Velora.invoke(0xAAD830,"int", player)


end


-- PC:0x8753997EB5F6EE3F Old:0x6FF034BB


function PLAYER.CLEAR_PLAYER_PARACHUTE_MODEL_OVERRIDE(player)


  Velora.invoke(0xAAD870,"void", player)


end


function PLAYER.CLEAR_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player)


  Velora.invoke(0xAAD8B0,"void", player)


end


-- PC:0xDC80A4C2F18A2B64 Old:0xA877FF5E


function PLAYER.SET_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(player, model)


  Velora.invoke(0xAAD8F0,"void", player, model)


end


-- PC:0x10C54E4389C12B42 Old:0xBB62AAC5


function PLAYER.CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(player)


  Velora.invoke(0xAAD930,"void", player)


end


-- PC:0xC142BE3BB9CE125F Old:0x8C6E611D


function PLAYER.DISABLE_PLAYER_VEHICLE_REWARDS(player)


  Velora.invoke(0xAAD970,"void", player)


end


-- PC:0x2F7CEB6520288061 Old:0x2849D4B2


function PLAYER.SET_PLAYER_SPECTATED_VEHICLE_RADIO_OVERRIDE(p0)


  Velora.invoke(0xAAD9A0,"void", p0)


end


-- PC:0x5DC40A8869C22141 Old:0x7A6B0EF8


function PLAYER.SET_PLAYER_BLUETOOTH_STATE(player, state)


  Velora.invoke(0xAAD9E0,"void", player, state)


end


-- PC:0x65FAEE425DE637B0 Old:0xEA01BD4A


function PLAYER.IS_PLAYER_BLUETOOTH_ENABLE(player)


  return Velora.invoke(0xAADA80,"bool", player)


end


function PLAYER.DISABLE_CAMERA_VIEW_MODE_CYCLE(player)


  Velora.invoke(0xAADA80,"void", player)


end


-- PC:0x56105E599CAB0EFA Old:0x0098D244


function PLAYER.GET_PLAYER_FAKE_WANTED_LEVEL(player)


  return Velora.invoke(0xAADB10,"int", player)


end


function PLAYER.SET_PLAYER_CAN_DAMAGE_PLAYER(player1, player2, toggle)


  Velora.invoke(0xAADB10,"void", player1, player2, toggle)


end


function PLAYER.SET_APPLY_WAYPOINT_OF_PLAYER(player, hudColor)


  Velora.invoke(0xAADB90,"void", player, hudColor)


end


function PLAYER.IS_PLAYER_VEHICLE_WEAPON_TOGGLED_TO_NON_HOMING(p0)


  return Velora.invoke(0xAADC10,"bool", p0)


end


function PLAYER.SET_PLAYER_VEHICLE_WEAPON_TO_NON_HOMING(p0)


  Velora.invoke(0xAADC10,"void", p0)


end


function PLAYER.SET_PLAYER_HOMING_DISABLED_FOR_ALL_VEHICLE_WEAPONS(p0, p1)


  Velora.invoke(0xAADC70,"void", p0, p1)


end


function PLAYER.ADD_PLAYER_TARGETABLE_ENTITY(player, entity)


  Velora.invoke(0xAADCF0,"void", player, entity)


end


function PLAYER.REMOVE_PLAYER_TARGETABLE_ENTITY(player, entity)


  Velora.invoke(0xAADD60,"void", player, entity)


end


function PLAYER.SET_PLAYER_PREVIOUS_VARIATION_DATA(player, p1, p2, p3, p4, p5)


  Velora.invoke(0xAADDD0,"void", player, p1, p2, p3, p4, p5)


end


function PLAYER.REMOVE_SCRIPT_FIRE_POSITION()


  Velora.invoke(0xAADE50,"void")


end


function PLAYER.SET_SCRIPT_FIRE_POSITION(coordX, coordY, coordZ)


  Velora.invoke(0xAADE90,"void", coordX, coordY, coordZ)


end


