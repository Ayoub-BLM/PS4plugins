-- compat_NETWORK.lua — AUTO GENERATO


-- NETWORK


NETWORK=NETWORK or {}


-- PC:0x054354A99211EB96 Old:0xADD0B40F


function NETWORK.NETWORK_IS_SIGNED_IN()


  return Velora.invoke(0xA49D50,"bool")


end


-- PC:0x1077788E268557C2 Old:0x6E5BDCE2


function NETWORK.NETWORK_IS_SIGNED_ONLINE()


  return Velora.invoke(0xA49D70,"bool")


end


function NETWORK.NETWORK_IS_NP_AVAILABLE()


  return Velora.invoke(0xA49DA0,"bool")


end


function NETWORK.NETWORK_IS_NP_PENDING()


  return Velora.invoke(0xA49DE0,"bool")


end


function NETWORK.NETWORK_GET_NP_UNAVAILABLE_REASON()


  return Velora.invoke(0xA49E20,"int")


end


function NETWORK.NETWORK_IS_CONNETED_TO_NP_PRESENCE()


  return Velora.invoke(0xA49E60,"bool")


end


function NETWORK.NETWORK_IS_LOGGED_IN_TO_PSN()


  return Velora.invoke(0xA49EA0,"bool")


end


-- PC:0x85443FF4C328F53B Old:0x3FB40673


function NETWORK.NETWORK_HAS_VALID_ROS_CREDENTIALS()


  return Velora.invoke(0xA49EE0,"bool")


end


-- PC:0x8D11E61A4ABF49CC Old:0xBDC8F63E


function NETWORK.NETWORK_IS_REFRESHING_ROS_CREDENTIALS()


  return Velora.invoke(0xA49F10,"bool")


end


-- PC:0x9A4CF4F48AD77302 Old:0xC7FF5AFC


function NETWORK.NETWORK_IS_CLOUD_AVAILABLE()


  return Velora.invoke(0xA49F40,"bool")


end


-- PC:0x67A5589628E0CFF6 Old:0x66EC713F


function NETWORK.NETWORK_HAS_SOCIAL_CLUB_ACCOUNT()


  return Velora.invoke(0xA49F70,"bool")


end


-- PC:0xBA9775570DB788CF Old:0x358D1D77


function NETWORK.NETWORK_ARE_SOCIAL_CLUB_POLICIES_CURRENT()


  return Velora.invoke(0xA49F90,"bool")


end


-- PC:0x8DB296B814EDDA07 Old:0xE46AC10F


function NETWORK.NETWORK_IS_HOST()


  return Velora.invoke(0xA49FD0,"bool")


end


function NETWORK.NETWORK_GET_HOST_PLAYER_INDEX()


  return Velora.invoke(0xA49FF0,"int")


end


function NETWORK.NETWORK_WAS_GAME_SUSPENDED()


  return Velora.invoke(0xA4A020,"bool")


end


-- PC:0x25CB5A9F37BFD063 Old:0xEF63BFDF


function NETWORK.NETWORK_HAVE_ONLINE_PRIVILEGES()


  return Velora.invoke(0xA4A030,"bool")


end


function NETWORK.NETWORK_HAS_AGE_RESTRICTIONS()


  return Velora.invoke(0xA4A070,"bool")


end


-- PC:0x72D918C99BCACC54 Old:0x1F88819D


function NETWORK.NETWORK_HAVE_USER_CONTENT_PRIVILEGES(p0)


  return Velora.invoke(0xA4A0A0,"bool", p0)


end


-- PC:0xAEEF48CDF5B6CE7C Old:0x2D817A5E


function NETWORK.NETWORK_HAVE_COMMUNICATION_PRIVILEGES(p0, player)


  return Velora.invoke(0xA4A0C0,"bool", p0, player)


end


function NETWORK.NETWORK_CHECK_ONLINE_PRIVILEGES(p0, p1)


  return Velora.invoke(0xA4A160,"bool", p0, p1)


end


-- PC:0x595F028698072DD9 Old:0xBB54AA3D


function NETWORK.NETWORK_CHECK_USER_CONTENT_PRIVILEGES(p0, p1, p2)


  return Velora.invoke(0xA4A190,"bool", p0, p1, p2)


end


-- PC:0x83F28CE49FBBFFBA Old:0xA79E5B05


function NETWORK.NETWORK_CHECK_COMMUNICATION_PRIVILEGES(p0, p1, p2)


  return Velora.invoke(0xA4A1C0,"bool", p0, p1, p2)


end


function NETWORK.NETWORK_CHECK_TEXT_COMMUNICATION_PRIVILEGES(p0, p1, p2)


  return Velora.invoke(0xA4A1F0,"bool", p0, p1, p2)


end


function NETWORK.NETWORK_IS_USING_ONLINE_PROMOTION()


  return Velora.invoke(0xA4A220,"bool")


end


function NETWORK.NETWORK_SHOULD_SHOW_PROMOTION_ALERT_SCREEN()


  return Velora.invoke(0xA4A260,"bool")


end


-- PC:0x76BF03FADBF154F5 Old:0xEB864288


function NETWORK.NETWORK_HAS_SOCIAL_NETWORKING_SHARING_PRIV()


  return Velora.invoke(0xA4A290,"bool")


end


-- PC:0x9614B71F8ADB982B Old:0xAB07CBBE


function NETWORK.NETWORK_GET_AGE_GROUP()


  return Velora.invoke(0xA4A2C0,"int")


end


function NETWORK.NETWORK_CHECK_PRIVILEGES(p0, p1, p2)


  return Velora.invoke(0xA4A2E0,"bool", p0, p1, p2)


end


function NETWORK.NETWORK_IS_PRIVILEGE_CHECK_IN_PROGRESS()


  return Velora.invoke(0xA4A350,"bool")


end


function NETWORK.NETWORK_SET_PRIVILEGE_CHECK_RESULT_NOT_NEEDED()


  Velora.invoke(0xA4A370,"void")


end


function NETWORK.NETWORK_RESOLVE_PRIVILEGE_USER_CONTENT()


  return Velora.invoke(0xA4A3F0,"bool")


end


function NETWORK.NETWORK_HAVE_PLATFORM_SUBSCRIPTION()


  return Velora.invoke(0xA4A390,"bool")


end


function NETWORK.NETWORK_IS_PLATFORM_SUBSCRIPTION_CHECK_PENDING()


  return Velora.invoke(0xA4A3C0,"bool")


end


function NETWORK.NETWORK_SHOW_ACCOUNT_UPGRADE_UI()


  Velora.invoke(0xA4A3F0,"void")


end


function NETWORK.NETWORK_IS_SHOWING_SYSTEM_UI_OR_RECENTLY_REQUESTED_UPSELL()


  return Velora.invoke(0xA4A480,"bool")


end


function NETWORK.NETWORK_NEED_TO_START_NEW_GAME_BUT_BLOCKED()


  return Velora.invoke(0xA4A430,"bool")


end


-- PC:0x580CE4438479CC61 Old:0x60E1FEDF


function NETWORK.NETWORK_CAN_BAIL()


  return Velora.invoke(0xA4A460,"bool")


end


-- PC:0x95914459A87EBA28 Old:0x87D79A04


function NETWORK.NETWORK_BAIL()


  Velora.invoke(0xA4A480,"void")


end


-- PC:0x283B6062A2C01E9B Old:0x96E28FE2


function NETWORK.NETWORK_ON_RETURN_TO_SINGLE_PLAYER()


  Velora.invoke(0xA4A540,"void")


end


function NETWORK.NETWORK_TRANSITION_START(p0, p1, p2, p3)


  return Velora.invoke(0xA4AB80,"bool", p0, p1, p2, p3)


end


function NETWORK.NETWORK_TRANSITION_ADD_STAGE(hash, p1, p2, state, p4)


  return Velora.invoke(0xA4A570,"bool", hash, p1, p2, state, p4)


end


function NETWORK.NETWORK_TRANSITION_FINISH(p0, p1, p2)


  return Velora.invoke(0xA4A590,"bool", p0, p1, p2)


end


-- PC:0xAF50DA1A3F8B1BA4 Old:0xA520B982


function NETWORK.NETWORK_CAN_ACCESS_MULTIPLAYER()


  return Velora.invoke(0xA4A5B0,"bool")


end


-- PC:0x9747292807126EDA Old:0x05518C0F


function NETWORK.NETWORK_IS_MULTIPLAYER_DISABLED()


  return Velora.invoke(0xA4A6A0,"bool")


end


-- PC:0x7E782A910C362C25 Old:0x4A23B9C9


function NETWORK.NETWORK_CAN_ENTER_MULTIPLAYER()


  return Velora.invoke(0xA4A6C0,"bool")


end


function NETWORK.NETWORK_SESSION_DO_FREEROAM_QUICKMATCH(p0, p1, p2, maxPlayers)


  return Velora.invoke(0xA4A6F0,"bool", p0, p1, p2, maxPlayers)


end


function NETWORK.NETWORK_SESSION_DO_FRIEND_MATCHMAKING(p0, p1, maxPlayers)


  return Velora.invoke(0xA4A740,"bool", p0, p1, maxPlayers)


end


function NETWORK.NETWORK_SESSION_DO_CREW_MATCHMAKING(crewId, p1, p2, maxPlayers)


  return Velora.invoke(0xA4A7A0,"bool", crewId, p1, p2, maxPlayers)


end


function NETWORK.NETWORK_SESSION_DO_ACTIVITY_QUICKMATCH(p0, p1, p2, p3, p4)


  return Velora.invoke(0xA4A8A0,"bool", p0, p1, p2, p3, p4)


end


-- PC:0x6F3D4ED9BEE4E61D Old:0x6716460F


function NETWORK.NETWORK_SESSION_HOST(p0, maxPlayers, p2)


  return Velora.invoke(0xA4A910,"bool", p0, maxPlayers, p2)


end


-- PC:0xED34C0C02C098BB7 Old:0x8AC9EA19


function NETWORK.NETWORK_SESSION_HOST_CLOSED(p0, maxPlayers)


  return Velora.invoke(0xA4A970,"bool", p0, maxPlayers)


end


-- PC:0xB9CFD27A5D578D83 Old:0x26864403


function NETWORK.NETWORK_SESSION_HOST_FRIENDS_ONLY(p0, maxPlayers)


  return Velora.invoke(0xA4A9D0,"bool", p0, maxPlayers)


end


-- PC:0xFBCFA2EA2E206890 Old:0x56E75FE4


function NETWORK.NETWORK_SESSION_IS_CLOSED_FRIENDS()


  return Velora.invoke(0xA4AA30,"bool")


end


-- PC:0x74732C6CA90DA2B4 Old:0xA95299B9


function NETWORK.NETWORK_SESSION_IS_CLOSED_CREW()


  return Velora.invoke(0xA4AA60,"bool")


end


-- PC:0xF3929C2379B60CCE Old:0x3D2C1916


function NETWORK.NETWORK_SESSION_IS_SOLO()


  return Velora.invoke(0xA4AA90,"bool")


end


-- PC:0xCEF70AA5B3F89BA1 Old:0xDB67785D


function NETWORK.NETWORK_SESSION_IS_PRIVATE()


  return Velora.invoke(0xA4AAC0,"bool")


end


-- PC:0xA02E59562D711006 Old:0xBCACBEA2


function NETWORK.NETWORK_SESSION_END(p0, p1)


  return Velora.invoke(0xDEADBEEF,"bool", p0, p1)


end


function NETWORK.NETWORK_SESSION_LEAVE(p0)


  return Velora.invoke(0xA4AB40,"bool", p0)


end


-- PC:0xFA8904DC5F304220 Old:0x1E20138A


function NETWORK.NETWORK_SESSION_KICK_PLAYER(player)


  Velora.invoke(0xA4AB80,"void", player)


end


-- PC:0xD6D09A6F32F49EF1 Old:0x8A559D26


function NETWORK.NETWORK_SESSION_GET_KICK_VOTE(player)


  return Velora.invoke(0xA4ACC0,"bool", player)


end


function NETWORK.NETWORK_SESSION_RESERVE_SLOTS_TRANSITION(p0, p1, p2)


  return Velora.invoke(0xA4AC30,"bool", p0, p1, p2)


end


-- PC:0x59DF79317F85A7E0 Old:0x6CDAA7D2


function NETWORK.NETWORK_JOIN_PREVIOUSLY_FAILED_SESSION()


  return Velora.invoke(0xA4AC60,"bool")


end


-- PC:0xFFE1E5B792D92B34 Old:0xBF21818E


function NETWORK.NETWORK_JOIN_PREVIOUSLY_FAILED_TRANSITION()


  return Velora.invoke(0xA4AC90,"bool")


end


-- PC:0x49EC8030F5015F8B Old:0x3C3E2AB6


function NETWORK.NETWORK_SESSION_SET_MATCHMAKING_GROUP(matchmakingGroup)


  Velora.invoke(0xA4ACC0,"void", matchmakingGroup)


end


-- PC:0x8B6A4DD0AF9CE215 Old:0x5F29A7E0


function NETWORK.NETWORK_SESSION_SET_MATCHMAKING_GROUP_MAX(playerType, playerCount)


  Velora.invoke(0xA4ACE0,"void", playerType, playerCount)


end


-- PC:0x56CE820830EF040B Old:0x36EAD960


function NETWORK.NETWORK_SESSION_GET_MATCHMAKING_GROUP_FREE(p0)


  return Velora.invoke(0xA4AD50,"int", p0)


end


-- PC:0xCAE55F48D3D7875C Old:0x5BE529F7


function NETWORK.NETWORK_SESSION_ADD_ACTIVE_MATCHMAKING_GROUP(groupId)


  Velora.invoke(0xA4AD50,"void", groupId)


end


-- PC:0xF49ABC20D8552257 Old:0x454C7B67


function NETWORK.NETWORK_SESSION_SET_UNIQUE_CREW_LIMIT(p0)


  Velora.invoke(0xA4AD70,"void", p0)


end


-- PC:0x4811BBAC21C5FCD5 Old:0xE5961511


function NETWORK.NETWORK_SESSION_SET_UNIQUE_CREW_LIMIT_TRANSITION(p0)


  Velora.invoke(0xA4ADC0,"void", p0)


end


-- PC:0x5539C3EBF104A53A Old:0xAE396263


function NETWORK.NETWORK_SESSION_SET_UNIQUE_CREW_ONLY_CREWS_TRANSITION(p0)


  Velora.invoke(0xA4ADE0,"void", p0)


end


-- PC:0x702BC4D605522539 Old:0x913FD7D6


function NETWORK.NETWORK_SESSION_SET_CREW_LIMIT_MAX_MEMBERS_TRANSITION(p0)


  Velora.invoke(0xA4AE10,"void", p0)


end


-- PC:0x3F52E880AAF6C8CA Old:0xB3D9A67F


function NETWORK.NETWORK_SESSION_SET_MATCHMAKING_PROPERTY_ID(p0)


  Velora.invoke(0xA4AE30,"void", p0)


end


-- PC:0xF1EEA2DDA9FFA69D Old:0x6CC062FC


function NETWORK.NETWORK_SESSION_SET_MATCHMAKING_MENTAL_STATE(p0)


  Velora.invoke(0xA4AE50,"void", p0)


end


function NETWORK.NETWORK_SESSION_SET_NUM_BOSSES(num)


  Velora.invoke(0xA4AE80,"void", num)


end


-- PC:0x1153FA02A659051C Old:0x57F9BC83


function NETWORK.NETWORK_SESSION_SET_SCRIPT_VALIDATE_JOIN()


  Velora.invoke(0xA4AE90,"void")


end


-- PC:0xC19F6C8E7865A6FF Old:0xF3768F90


function NETWORK.NETWORK_SESSION_VALIDATE_JOIN(p0)


  Velora.invoke(0xA4AEA0,"void", p0)


end


-- PC:0x236406F60CF216D6 Old:0x0EC62629


function NETWORK.NETWORK_ADD_FOLLOWERS(p1)


  Velora.invoke(0xA4AEC0,"void", p1)


end


-- PC:0x058F43EC59A8631A Old:0x5E557307


function NETWORK.NETWORK_CLEAR_FOLLOWERS()


  Velora.invoke(0xA4AED0,"void")


end


-- PC:0x6D03BFBD643B2A02 Old:0x74E8C53E


function NETWORK.NETWORK_GET_GLOBAL_MULTIPLAYER_CLOCK()


  Velora.invoke(0xA4AEE0,"void")


end


-- PC:0x600F8CB31C7AAB6E Old:0x959E43A3


function NETWORK.NETWORK_SESSION_SET_GAMEMODE(p0)


  Velora.invoke(0xA4AF00,"void", p0)


end


function NETWORK.NETWORK_SESSION_GET_HOST_AIM_PREFERENCE()


  return Velora.invoke(0xA4B160,"int")


end


-- PC:0xE532D6811B3A4D2A Old:0x7771AB83


function NETWORK.NETWORK_FIND_GAMERS_IN_CREW(crewId)


  return Velora.invoke(0xA4AF30,"bool", crewId)


end


-- PC:0xF7B2CFDE5C9F700D Old:0xA13045D4


function NETWORK.NETWORK_FIND_MATCHED_GAMERS(attribute, fallbackLimit, lowerLimit, upperLimit)


  return Velora.invoke(0xA4B000,"bool", attribute, fallbackLimit, lowerLimit, upperLimit)


end


-- PC:0xDDDF64C91BFCF0AA Old:0xA6DAA79F


function NETWORK.NETWORK_IS_FINDING_GAMERS()


  return Velora.invoke(0xA4B040,"bool")


end


-- PC:0xF9B83B77929D8863 Old:0xBEDC4503


function NETWORK.NETWORK_DID_FIND_GAMERS_SUCCEED()


  return Velora.invoke(0xA4B060,"bool")


end


-- PC:0xA1B043EE79A916FB Old:0xF4B80C7E


function NETWORK.NETWORK_GET_NUM_FOUND_GAMERS()


  return Velora.invoke(0xA4B080,"int")


end


-- PC:0x9DCFF2AFB68B3476 Old:0xA08C9141


function NETWORK.NETWORK_GET_FOUND_GAMER(p0, p1)


  return Velora.invoke(0xA4B0A0,"bool", p0, p1)


end


-- PC:0x6D14CCEE1B40381A Old:0x6AA9A154


function NETWORK.NETWORK_CLEAR_FOUND_GAMERS()


  Velora.invoke(0xA4B160,"void")


end


-- PC:0x85A0EF54A500882C Old:0x42BD0780


function NETWORK.NETWORK_QUEUE_GAMER_FOR_STATUS(p0)


  return Velora.invoke(0xA4B300,"bool", p0)


end


-- PC:0x2CC848A861D01493 Old:0xBEB98840


function NETWORK.NETWORK_GET_GAMER_STATUS_FROM_QUEUE()


  return Velora.invoke(0xA4B1F0,"bool")


end


-- PC:0x94A8394D150B013A Old:0x08029970


function NETWORK.NETWORK_IS_GETTING_GAMER_STATUS()


  return Velora.invoke(0xA4B210,"bool")


end


-- PC:0x5AE17C6B0134B7F1 Old:0xC871E745


function NETWORK.NETWORK_DID_GET_GAMER_STATUS_SUCCEED()


  return Velora.invoke(0xA4B230,"bool")


end


-- PC:0x02A8BEC6FD9AF660 Old:0xB5ABC4B4


function NETWORK.NETWORK_GET_GAMER_STATUS_RESULT(p0, p1)


  return Velora.invoke(0xA4B250,"bool", p0, p1)


end


-- PC:0x86E0660E4F5C956D Old:0x3F7EDBBD


function NETWORK.NETWORK_CLEAR_GET_GAMER_STATUS()


  Velora.invoke(0xA4B300,"void")


end


-- PC:0xC6F8AB8A4189CF3A Old:0x3D6360B5


function NETWORK.NETWORK_SESSION_JOIN_INVITE()


  Velora.invoke(0xA4B310,"void")


end


-- PC:0x2FBF47B1B36D36F9 Old:0x20317535


function NETWORK.NETWORK_SESSION_CANCEL_INVITE()


  Velora.invoke(0xA4B320,"void")


end


-- PC:0xA29177F7703B5644 Old:0x3FD49D3B


function NETWORK.NETWORK_SESSION_FORCE_CANCEL_INVITE()


  Velora.invoke(0xA4B350,"void")


end


-- PC:0xAC8C7B9B88C4A668 Old:0x0C207D6E


function NETWORK.NETWORK_HAS_PENDING_INVITE()


  return Velora.invoke(0xA4B440,"bool")


end


-- PC:0xC42DD763159F3461 Old:0xFBBAC350


function NETWORK.NETWORK_HAS_CONFIRMED_INVITE()


  return Velora.invoke(0xA4B3C0,"bool")


end


-- PC:0x62A0296C1BB1CEB3 Old:0x0907A6BF


function NETWORK.NETWORK_REQUEST_INVITE_CONFIRMED_EVENT()


  return Velora.invoke(0xA4B3F0,"bool")


end


-- PC:0x23DFB504655D0CE4 Old:0x6A0BEA60


function NETWORK.NETWORK_SESSION_WAS_INVITED()


  return Velora.invoke(0xA4B420,"bool")


end


-- PC:0xE57397B4A3429DD0 Old:0xE9C6B3FD


function NETWORK.NETWORK_SESSION_GET_INVITER(gamerHandle)


  Velora.invoke(0xA4B440,"void", gamerHandle)


end


-- PC:0xD313DE83394AF134 Old:0x3EA9D44C


function NETWORK.NETWORK_SESSION_IS_AWAITING_INVITE_RESPONSE()


  return Velora.invoke(0xA4B4D0,"bool")


end


-- PC:0xBDB6F89C729CF388 Old:0x9374523F


function NETWORK.NETWORK_SESSION_IS_DISPLAYING_INVITE_CONFIRMATION()


  return Velora.invoke(0xA4B4A0,"bool")


end


-- PC:0xA0682D67EF1FBA3D Old:0x323DC78C


function NETWORK.NETWORK_SUPPRESS_INVITE(toggle)


  Velora.invoke(0xA4B4D0,"void", toggle)


end


-- PC:0x34F9E9049454A7A0 Old:0xD156FD1A


function NETWORK.NETWORK_BLOCK_INVITES(toggle)


  Velora.invoke(0xA4B4F0,"void", toggle)


end


-- PC:0xCFEB8AF24FC1D0BB Old:0x8AB4890B


function NETWORK.NETWORK_BLOCK_JOIN_QUEUE_INVITES(toggle)


  Velora.invoke(0xA4B510,"void", toggle)


end


function NETWORK.NETWORK_SET_CAN_RECEIVE_RS_INVITES(p0)


  Velora.invoke(0xA4B530,"void", p0)


end


-- PC:0xF814FEC6A19FD6E0 Old:0x32B7A076


function NETWORK.NETWORK_STORE_INVITE_THROUGH_RESTART()


  Velora.invoke(0xA4B550,"void")


end


-- PC:0x6B07B9CE4D390375 Old:0x0FCE995D


function NETWORK.NETWORK_ALLOW_INVITE_PROCESS_IN_PLAYER_SWITCH(p0)


  Velora.invoke(0xA4B560,"void", p0)


end


-- PC:0x7AC752103856FB20 Old:0xA639DCA2


function NETWORK.NETWORK_SET_SCRIPT_READY_FOR_EVENTS(toggle)


  Velora.invoke(0xA4B580,"void", toggle)


end


-- PC:0x74698374C45701D2 Old:0x70ED476A


function NETWORK.NETWORK_IS_OFFLINE_INVITE_PENDING()


  return Velora.invoke(0xA4B5C0,"bool")


end


-- PC:0x140E6A44870A11CE Old:0x50507BED


function NETWORK.NETWORK_CLEAR_OFFLINE_INVITE_PENDING()


  Velora.invoke(0xA4B5C0,"void")


end


-- PC:0xC74C33FCA52856D5 Old:0xF3B1CA85


function NETWORK.NETWORK_SESSION_HOST_SINGLE_PLAYER(p0)


  Velora.invoke(0xA4B610,"void", p0)


end


-- PC:0x3442775428FD2DAA Old:0xC692F86A


function NETWORK.NETWORK_SESSION_LEAVE_SINGLE_PLAYER()


  Velora.invoke(0xA4B630,"void")


end


-- PC:0x10FAB35428CCC9D7 Old:0x09B88E3E


function NETWORK.NETWORK_IS_GAME_IN_PROGRESS()


  return Velora.invoke(0xA4B750,"bool")


end


-- PC:0xD83C2B94E7508980 Old:0x715CB8C4


function NETWORK.NETWORK_IS_SESSION_ACTIVE()


  return Velora.invoke(0xA4B660,"bool")


end


-- PC:0xCA97246103B63917 Old:0x4BC4105E


function NETWORK.NETWORK_IS_IN_SESSION()


  return Velora.invoke(0xA4B680,"bool")


end


-- PC:0x9DE624D2FC4B603F Old:0x9D854A37


function NETWORK.NETWORK_IS_SESSION_STARTED()


  return Velora.invoke(0xA4B6B0,"bool")


end


-- PC:0xF4435D66A8E2905E Old:0x8592152D


function NETWORK.NETWORK_IS_SESSION_BUSY()


  return Velora.invoke(0xA4B6D0,"bool")


end


-- PC:0x4EEBC3694E49C572 Old:0xE1FCCDBA


function NETWORK.NETWORK_CAN_SESSION_END()


  return Velora.invoke(0xA4B6F0,"bool")


end


function NETWORK.NETWORK_GET_GAME_MODE()


  return Velora.invoke(0xA4B710,"int")


end


-- PC:0x271CC6AB59EBF9A5 Old:0x7017257D


function NETWORK.NETWORK_SESSION_MARK_VISIBLE(toggle)


  Velora.invoke(0xA4B750,"void", toggle)


end


-- PC:0xBA416D68C631496A Old:0x4977AC28


function NETWORK.NETWORK_SESSION_IS_VISIBLE()


  return Velora.invoke(0xA4B7E0,"bool")


end


-- PC:0xA73667484D7037C3 Old:0xE6EEF8AF


function NETWORK.NETWORK_SESSION_BLOCK_JOIN_REQUESTS(toggle)


  Velora.invoke(0xA4B7E0,"void", toggle)


end


-- PC:0xB4AB419E0D86ACAE Old:0x6BB93227


function NETWORK.NETWORK_SESSION_CHANGE_SLOTS(slots, p1)


  Velora.invoke(0xA4B830,"void", slots, p1)


end


-- PC:0x53AFD64C6758F2F9 Old:0xE642F2FD


function NETWORK.NETWORK_SESSION_GET_PRIVATE_SLOTS()


  return Velora.invoke(0xA4B900,"int")


end


-- PC:0x9C1556705F864230 Old:0x345C2980


function NETWORK.NETWORK_SESSION_VOICE_HOST()


  return Velora.invoke(0xA4B8A0,"bool")


end


-- PC:0x6793E42BE02B575D Old:0xE566C7DA


function NETWORK.NETWORK_SESSION_VOICE_LEAVE()


  return Velora.invoke(0xA4B8D0,"bool")


end


-- PC:0xABD5E88B8A2D3DB2 Old:0x9DFD89E6


function NETWORK.NETWORK_SESSION_VOICE_CONNECT_TO_PLAYER(gamerHandle)


  Velora.invoke(0xA4B900,"void", gamerHandle)


end


-- PC:0x7F8413B7FC2AA6B9 Old:0x075321B5


function NETWORK.NETWORK_SESSION_VOICE_RESPOND_TO_REQUEST(p0, p1)


  Velora.invoke(0xA4B980,"void", p0, p1)


end


-- PC:0x5B8ED3DB018927B1 Old:0x6EFC2FD0


function NETWORK.NETWORK_SESSION_VOICE_SET_TIMEOUT(timeout)


  Velora.invoke(0xA4B9A0,"void", timeout)


end


-- PC:0x855BC38818F6F684 Old:0x60AA4AA1


function NETWORK.NETWORK_SESSION_IS_IN_VOICE_SESSION()


  return Velora.invoke(0xA4BAE0,"bool")


end


function NETWORK.NETWORK_SESSION_IS_VOICE_SESSION_ACTIVE()


  return Velora.invoke(0xA4B9F0,"bool")


end


-- PC:0xEF0912DDF7C4CB4B Old:0x132CA01E


function NETWORK.NETWORK_SESSION_IS_VOICE_SESSION_BUSY()


  return Velora.invoke(0xA4BA20,"bool")


end


-- PC:0x3A214F2EC889B100 Old:0xAFFEA720


function NETWORK.NETWORK_SEND_TEXT_MESSAGE(message, gamerHandle)


  return Velora.invoke(0xA4BA50,"bool", message, gamerHandle)


end


-- PC:0x75138790B4359A74 Old:0xFC9AD060


function NETWORK.NETWORK_SET_ACTIVITY_SPECTATOR(toggle)


  Velora.invoke(0xA4BAE0,"void", toggle)


end


-- PC:0x12103B9E0C9F92FB Old:0xAF329720


function NETWORK.NETWORK_IS_ACTIVITY_SPECTATOR()


  return Velora.invoke(0xA4BB20,"bool")


end


-- PC:0x0E4F77F7B9D74D84 Old:0x04CB2AB4


function NETWORK.NETWORK_SET_ACTIVITY_PLAYER_MAX(p0)


  Velora.invoke(0xA4BB20,"void", p0)


end


-- PC:0x9D277B76D1D12222 Old:0x74E0BC0A


function NETWORK.NETWORK_SET_ACTIVITY_SPECTATOR_MAX(maxSpectators)


  Velora.invoke(0xA4BB40,"void", maxSpectators)


end


-- PC:0x73E2B500410DA5A2 Old:0x31F951FD


function NETWORK.NETWORK_GET_ACTIVITY_PLAYER_NUM(p0)


  return Velora.invoke(0xA4BEC0,"int", p0)


end


-- PC:0x2763BBAA72A7BCB9 Old:0x58F1DF7D


function NETWORK.NETWORK_IS_ACTIVITY_SPECTATOR_FROM_HANDLE(gamerHandle)


  return Velora.invoke(0xA4BBA0,"bool", gamerHandle)


end


-- PC:0xA60BB5CE242BB254 Old:0x146764FB


function NETWORK.NETWORK_HOST_TRANSITION(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)


  return Velora.invoke(0xA4BC30,"bool", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)


end


-- PC:0x71FB0EBCD4915D56 Old:0x2FF65C0B


function NETWORK.NETWORK_DO_TRANSITION_QUICKMATCH(p0, p1, p2, p3, p4, p5)


  return Velora.invoke(0xA4BD00,"bool", p0, p1, p2, p3, p4, p5)


end


-- PC:0xA091A5E44F0072E5 Old:0x47D61C99


function NETWORK.NETWORK_DO_TRANSITION_QUICKMATCH_ASYNC(p0, p1, p2, p3, p4, p5)


  return Velora.invoke(0xA4BDA0,"bool", p0, p1, p2, p3, p4, p5)


end


-- PC:0x9C4AB58491FDC98A Old:0x5CE60A11


function NETWORK.NETWORK_DO_TRANSITION_QUICKMATCH_WITH_GROUP(p0, p1, p2, p3, p4, p5, p6, p7)


  return Velora.invoke(0xA4BE40,"bool", p0, p1, p2, p3, p4, p5, p6, p7)


end


-- PC:0xA06509A691D12BE4 Old:0x0D7E5CF9


function NETWORK.NETWORK_JOIN_GROUP_ACTIVITY()


  return Velora.invoke(0xA4BE90,"bool")


end


-- PC:0x1888694923EF4591 Old:0x157D44D3


function NETWORK.NETWORK_CLEAR_GROUP_ACTIVITY()


  Velora.invoke(0xA4BEC0,"void")


end


-- PC:0xB13E88E655E5A3BC Old:0x36A5F2DA


function NETWORK.NETWORK_RETAIN_ACTIVITY_GROUP()


  Velora.invoke(0xA4BED0,"void")


end


-- PC:0x6512765E3BE78C50 Old:0x95FFACF8


function NETWORK.NETWORK_IS_TRANSITION_CLOSED_FRIENDS()


  return Velora.invoke(0xA4BFD0,"bool")


end


-- PC:0x0DBD5D7E3C5BEC3B Old:0xB97A966B


function NETWORK.NETWORK_IS_TRANSITION_CLOSED_CREW()


  return Velora.invoke(0xA4BF10,"bool")


end


-- PC:0x5DC577201723960A Old:0x063DC4A5


function NETWORK.NETWORK_IS_TRANSITION_SOLO()


  return Velora.invoke(0xA4BF40,"bool")


end


-- PC:0x5A6AA44FF8E931E6 Old:0x104DDE8D


function NETWORK.NETWORK_IS_TRANSITION_PRIVATE()


  return Velora.invoke(0xA4BF70,"bool")


end


function NETWORK.NETWORK_GET_NUM_TRANSITION_NON_ASYNC_GAMERS()


  return Velora.invoke(0xA4BFA0,"int")


end


-- PC:0x261E97AD7BCF3D40 Old:0x7EF353E1


function NETWORK.NETWORK_MARK_AS_PREFERRED_ACTIVITY(p0)


  Velora.invoke(0xA4BFD0,"void", p0)


end


-- PC:0x39917E1B4CB0F911 Old:0xF60986FC


function NETWORK.NETWORK_MARK_AS_WAITING_ASYNC(p0)


  Velora.invoke(0xA4BFF0,"void", p0)


end


function NETWORK.NETWORK_SET_IN_PROGRESS_FINISH_TIME(p0)


  Velora.invoke(0xA4C010,"void", p0)


end


-- PC:0xEF26739BCD9907D5 Old:0x1DD01FE7


function NETWORK.NETWORK_SET_TRANSITION_CREATOR_HANDLE(p0)


  Velora.invoke(0xA4C030,"void", p0)


end


-- PC:0xFB3272229A82C759 Old:0x8BB336F7


function NETWORK.NETWORK_CLEAR_TRANSITION_CREATOR_HANDLE()


  Velora.invoke(0xA4C0B0,"void")


end


-- PC:0x4A595C32F77DFF76 Old:0x5332E645


function NETWORK.NETWORK_INVITE_GAMERS_TO_TRANSITION(p0, p1)


  return Velora.invoke(0xA4C140,"bool", p0, p1)


end


-- PC:0xCA2C8073411ECDB6 Old:0x17F1C69D


function NETWORK.NETWORK_SET_GAMER_INVITED_TO_TRANSITION(gamerHandle)


  Velora.invoke(0xA4C140,"void", gamerHandle)


end


-- PC:0xD23A1A815D21DB19 Old:0x3A3599B7


function NETWORK.NETWORK_LEAVE_TRANSITION()


  return Velora.invoke(0xA4C250,"bool")


end


-- PC:0x2DCF46CB1A4F0884 Old:0xE3570BA2


function NETWORK.NETWORK_LAUNCH_TRANSITION()


  return Velora.invoke(0xA4C210,"bool")


end


-- PC:0xA2E9C1AB8A92E8CD Old:0x8D014B23


function NETWORK.NETWORK_SET_DO_NOT_LAUNCH_FROM_JOIN_AS_MIGRATED_HOST(toggle)


  Velora.invoke(0xA4C250,"void", toggle)


end


function NETWORK.NETWORK_CANCEL_TRANSITION_MATCHMAKING()


  Velora.invoke(0xA4C270,"void")


end


-- PC:0xEAA572036990CD1B Old:0xB59D74CA


function NETWORK.NETWORK_BAIL_TRANSITION(p0, p1, p2)


  Velora.invoke(0xA4C280,"void", p0, p1, p2)


end


-- PC:0x3E9BB38102A589B0 Old:0x1B2114D2


function NETWORK.NETWORK_DO_TRANSITION_TO_GAME(p0, maxPlayers)


  return Velora.invoke(0xA4C420,"bool", p0, maxPlayers)


end


-- PC:0x4665F51EFED00034 Old:0x58AFBE63


function NETWORK.NETWORK_DO_TRANSITION_TO_NEW_GAME(p0, maxPlayers, p2)


  return Velora.invoke(0xA4C2E0,"bool", p0, maxPlayers, p2)


end


-- PC:0x3AAD8B2FCA1E289F Old:0xC7CB8ADF


function NETWORK.NETWORK_DO_TRANSITION_TO_FREEMODE(p0, p1, p2, players, p4)


  return Velora.invoke(0xA4C320,"bool", p0, p1, p2, players, p4)


end


-- PC:0x9E80A5BA8109F974 Old:0xAD13375E


function NETWORK.NETWORK_DO_TRANSITION_TO_NEW_FREEMODE(p0, p1, players, p3, p4, p5)


  return Velora.invoke(0xA4C360,"bool", p0, p1, players, p3, p4, p5)


end


-- PC:0x9D7696D8F4FA6CB7 Old:0x17146B2B


function NETWORK.NETWORK_IS_TRANSITION_TO_GAME()


  return Velora.invoke(0xA4C3B0,"bool")


end


-- PC:0x73B000F7FBC55829 Old:0x31F19263


function NETWORK.NETWORK_GET_TRANSITION_MEMBERS(data, dataCount)


  return Velora.invoke(0xA4C3F0,"int", data, dataCount)


end


-- PC:0x521638ADA1BA0D18 Old:0xCEE79711


function NETWORK.NETWORK_APPLY_TRANSITION_PARAMETER(p0, p1)


  Velora.invoke(0xA4C420,"void", p0, p1)


end


-- PC:0xEBEFC2E77084F599 Old:0xE0C28DB5


function NETWORK.NETWORK_APPLY_TRANSITION_PARAMETER_STRING(p0, string, p2)


  Velora.invoke(0xA4C440,"void", p0, string, p2)


end


-- PC:0x31D1D2B858D25E6B Old:0x468B0884


function NETWORK.NETWORK_SEND_TRANSITION_GAMER_INSTRUCTION(gamerHandle, p1, p2, p3, p4)


  return Velora.invoke(0xA4C7F0,"bool", gamerHandle, p1, p2, p3, p4)


end


-- PC:0x5728BB6D63E3FF1D Old:0x03383F57


function NETWORK.NETWORK_MARK_TRANSITION_GAMER_AS_FULLY_JOINED(p0)


  return Velora.invoke(0xA4C540,"bool", p0)


end


-- PC:0x0B824797C9BF2159 Old:0x0C0900BC


function NETWORK.NETWORK_IS_TRANSITION_HOST()


  return Velora.invoke(0xA4C5E0,"bool")


end


-- PC:0x6B5C83BA3EFE6A10 Old:0x0E2854C4


function NETWORK.NETWORK_IS_TRANSITION_HOST_FROM_HANDLE(gamerHandle)


  return Velora.invoke(0xA4C610,"bool", gamerHandle)


end


-- PC:0x65042B9774C4435E Old:0x73098D40


function NETWORK.NETWORK_GET_TRANSITION_HOST(gamerHandle)


  return Velora.invoke(0xA4C6C0,"bool", gamerHandle)


end


-- PC:0x68049AEFF83D8F0A Old:0xC3CDB626


function NETWORK.NETWORK_IS_IN_TRANSITION()


  return Velora.invoke(0xA4C750,"bool")


end


-- PC:0x53FA83401D9C07FE Old:0x7917E111


function NETWORK.NETWORK_IS_TRANSITION_STARTED()


  return Velora.invoke(0xA4C770,"bool")


end


-- PC:0x520F3282A53D26B7 Old:0xA357A2C6


function NETWORK.NETWORK_IS_TRANSITION_BUSY()


  return Velora.invoke(0xA4C790,"bool")


end


-- PC:0x292564C735375EDF Old:0x8262C70E


function NETWORK.NETWORK_IS_TRANSITION_MATCHMAKING()


  return Velora.invoke(0xA4C7B0,"bool")


end


-- PC:0xC571D0E77D8BBC29 Old:0x4F4BB300


function NETWORK.NETWORK_IS_TRANSITION_LEAVE_POSTPONED()


  return Velora.invoke(0xA4C7D0,"bool")


end


function NETWORK.NETWORK_TRANSITION_SET_IN_PROGRESS(p0)


  Velora.invoke(0xA4C7F0,"void", p0)


end


function NETWORK.NETWORK_TRANSITION_SET_CONTENT_CREATOR(p0)


  Velora.invoke(0xA4C820,"void", p0)


end


function NETWORK.NETWORK_TRANSITION_SET_ACTIVITY_ISLAND(p0)


  Velora.invoke(0xA4C840,"void", p0)


end


-- PC:0x2B3A8F7CA3A38FDE Old:0xC71E607B


function NETWORK.NETWORK_OPEN_TRANSITION_MATCHMAKING()


  Velora.invoke(0xA4C870,"void")


end


-- PC:0x43F4DBA69710E01E Old:0x82D32D07


function NETWORK.NETWORK_CLOSE_TRANSITION_MATCHMAKING()


  Velora.invoke(0xA4C890,"void")


end


-- PC:0x37A4494483B9F5C9 Old:0xC901AA9F


function NETWORK.NETWORK_IS_TRANSITION_OPEN_TO_MATCHMAKING()


  return Velora.invoke(0xA4C8E0,"bool")


end


-- PC:0x0C978FDA19692C2C Old:0x4AF0ADF5


function NETWORK.NETWORK_SET_TRANSITION_VISIBILITY_LOCK(p0, p1)


  Velora.invoke(0xA4C8E0,"void", p0, p1)


end


-- PC:0xD0A484CB2F829FBE Old:0xF637166E


function NETWORK.NETWORK_IS_TRANSITION_VISIBILITY_LOCKED()


  return Velora.invoke(0xA4C940,"bool")


end


-- PC:0x30DE938B516F0AD2 Old:0xCCA9C022


function NETWORK.NETWORK_SET_TRANSITION_ACTIVITY_ID(p0)


  Velora.invoke(0xA4C940,"void", p0)


end


-- PC:0xEEEDA5E6D7080987 Old:0x1E5F6AEF


function NETWORK.NETWORK_CHANGE_TRANSITION_SLOTS(p0, p1)


  Velora.invoke(0xA4C990,"void", p0, p1)


end


-- PC:0x973D76AA760A6CB6 Old:0x0532DDD2


function NETWORK.NETWORK_TRANSITION_BLOCK_JOIN_REQUESTS(p0)


  Velora.invoke(0xA4C9F0,"void", p0)


end


-- PC:0x9AC9CCBFA8C29795 Old:0x4ABD1E59


function NETWORK.NETWORK_HAS_PLAYER_STARTED_TRANSITION(player)


  return Velora.invoke(0xA4CCA0,"bool", player)


end


-- PC:0x2615AA2A695930C1 Old:0xCDEBCCE7


function NETWORK.NETWORK_ARE_TRANSITION_DETAILS_VALID(p0)


  return Velora.invoke(0xA4CA90,"bool", p0)


end


-- PC:0x9D060B08CD63321A Old:0xB054EC4B


function NETWORK.NETWORK_JOIN_TRANSITION(player)


  return Velora.invoke(0xA4CAF0,"bool", player)


end


-- PC:0x7284A47B3540E6CF Old:0x4F41DF6B


function NETWORK.NETWORK_HAS_INVITED_GAMER_TO_TRANSITION(p0)


  return Velora.invoke(0xA4CB50,"bool", p0)


end


-- PC:0x3F9990BF5F22759C Old:0x00F26CDC


function NETWORK.NETWORK_HAS_TRANSITION_INVITE_BEEN_ACKED(p0)


  return Velora.invoke(0xA4CBE0,"bool", p0)


end


-- PC:0x05095437424397FA Old:0x577DAA8A


function NETWORK.NETWORK_IS_ACTIVITY_SESSION()


  return Velora.invoke(0xA4CC70,"bool")


end


function NETWORK.NETWORK_DISABLE_REALTIME_MULTIPLAYER()


  Velora.invoke(0xA4CCA0,"void")


end


-- PC:0x4A9FDE3A5A6D0437 Old:0x18F03AFD


function NETWORK.NETWORK_SET_PRESENCE_SESSION_INVITES_BLOCKED(toggle)


  Velora.invoke(0xA4CCB0,"void", toggle)


end


-- PC:0xC3C7A6AFDB244624 Old:0x8B99B72B


function NETWORK.NETWORK_SEND_INVITE_VIA_PRESENCE(gamerHandle, p1, dataCount, p3)


  return Velora.invoke(0xA4D2A0,"bool", gamerHandle, p1, dataCount, p3)


end


-- PC:0xC116FF9B4D488291 Old:0x877C0E1C


function NETWORK.NETWORK_SEND_TRANSITION_INVITE_VIA_PRESENCE(gamerHandle, p1, dataCount, p3)


  return Velora.invoke(0xA4CDB0,"bool", gamerHandle, p1, dataCount, p3)


end


function NETWORK.NETWORK_SEND_IMPORTANT_TRANSITION_INVITE_VIA_PRESENCE(gamerHandle, p1, dataCount, p3)


  return Velora.invoke(0xA4CE80,"bool", gamerHandle, p1, dataCount, p3)


end


-- PC:0x742B58F723233ED9 Old:0x5E832444


function NETWORK.NETWORK_GET_PRESENCE_INVITE_INDEX_BY_ID(p0)


  return Velora.invoke(0xA4CF50,"int", p0)


end


-- PC:0xCEFA968912D0F78D Old:0x3FDA00F3


function NETWORK.NETWORK_GET_NUM_PRESENCE_INVITES()


  return Velora.invoke(0xA4CF80,"int")


end


-- PC:0xFA91550DF9318B22 Old:0xE5DA4CED


function NETWORK.NETWORK_ACCEPT_PRESENCE_INVITE(p0)


  return Velora.invoke(0xA4CFB0,"bool", p0)


end


-- PC:0xF0210268DB0974B1 Old:0x93C665FA


function NETWORK.NETWORK_REMOVE_PRESENCE_INVITE(p0)


  return Velora.invoke(0xA4CFE0,"bool", p0)


end


-- PC:0xDFF09646E12EC386 Old:0xD50DF46C


function NETWORK.NETWORK_GET_PRESENCE_INVITE_ID(p0)


  return Velora.invoke(0xA4D010,"int", p0)


end


-- PC:0x38D5B0FEBB086F75 Old:0xB2451429


function NETWORK.NETWORK_GET_PRESENCE_INVITE_HANDLE(p0, p1)


  return Velora.invoke(0xA4D070,"bool", p0, p1)


end


-- PC:0x26E1CD96B0903D60 Old:0xC5E0C989


function NETWORK.NETWORK_GET_PRESENCE_INVITE_SESSION_ID(p0)


  return Velora.invoke(0xA4D100,"int", p0)


end


-- PC:0xD39B3FFF8FFDD5BF Old:0x51B2D848


function NETWORK.NETWORK_GET_PRESENCE_INVITE_PLAYLIST_LENGTH(p0)


  return Velora.invoke(0xA4D150,"int", p0)


end


-- PC:0x728C4CC7920CD102 Old:0x4677C656


function NETWORK.NETWORK_GET_PRESENCE_INVITE_PLAYLIST_CURRENT(p0)


  return Velora.invoke(0xA4D180,"int", p0)


end


-- PC:0x3DBF2DF0AEB7D289 Old:0xF5E3401C


function NETWORK.NETWORK_GET_PRESENCE_INVITE_FROM_ADMIN(p0)


  return Velora.invoke(0xA4D1B0,"bool", p0)


end


-- PC:0x8806CEBFABD3CE05 Old:0x7D593B4C


function NETWORK.NETWORK_GET_PRESENCE_INVITE_IS_TOURNAMENT(p0)


  return Velora.invoke(0xA4D1E0,"bool", p0)


end


-- PC:0x76D9B976C4C09FDE Old:0xE96CFE7D


function NETWORK.NETWORK_HAS_FOLLOW_INVITE()


  return Velora.invoke(0xA4D210,"bool")


end


-- PC:0xC88156EBB786F8D5 Old:0xAB969F00


function NETWORK.NETWORK_ACTION_FOLLOW_INVITE()


  return Velora.invoke(0xA4D240,"bool")


end


-- PC:0x439BFDE3CD0610F6 Old:0x3242F952


function NETWORK.NETWORK_CLEAR_FOLLOW_INVITE()


  return Velora.invoke(0xA4D270,"bool")


end


-- PC:0xEBF8284D8CADEB53 Old:0x9773F36A


function NETWORK.NETWORK_REMOVE_AND_CANCEL_ALL_INVITES()


  Velora.invoke(0xA4D2A0,"void")


end


-- PC:0x7524B431B2E6F7EE Old:0xFDE84CB7


function NETWORK.NETWORK_REMOVE_TRANSITION_INVITE(p0)


  Velora.invoke(0xA4D2B0,"void", p0)


end


-- PC:0x726E0375C7A26368 Old:0xF7134E73


function NETWORK.NETWORK_REMOVE_ALL_TRANSITION_INVITE()


  Velora.invoke(0xA4D330,"void")


end


-- PC:0xF083835B70BA9BFE Old:0xC47352E7


function NETWORK.NETWORK_REMOVE_AND_CANCEL_ALL_TRANSITION_INVITES()


  Velora.invoke(0xA4D340,"void")


end


-- PC:0x9D80CD1D0E6327DE Old:0x52FB8074


function NETWORK.NETWORK_INVITE_GAMERS(p0, p1, p2, p3)


  return Velora.invoke(0xA4D670,"bool", p0, p1, p2, p3)


end


-- PC:0x4D86CD31E8976ECE Old:0xEC651BC0


function NETWORK.NETWORK_HAS_INVITED_GAMER(p0)


  return Velora.invoke(0xA4D380,"bool", p0)


end


function NETWORK.NETWORK_HAS_MADE_INVITE_DECISION(gamerHandle)


  return Velora.invoke(0xA4D420,"bool", gamerHandle)


end


function NETWORK.NETWORK_GET_INVITE_REPLY_STATUS(p0)


  return Velora.invoke(0xA4D4B0,"int", p0)


end


-- PC:0x74881E6BCAE2327C Old:0x72BA00CE


function NETWORK.NETWORK_GET_CURRENTLY_SELECTED_GAMER_HANDLE_FROM_INVITE_MENU(p0)


  return Velora.invoke(0xA4D540,"bool", p0)


end


-- PC:0x7206F674F2A3B1BB Old:0xFD95899E


function NETWORK.NETWORK_SET_CURRENTLY_SELECTED_GAMER_HANDLE_FROM_INVITE_MENU(p0)


  return Velora.invoke(0xA4D5A0,"bool", p0)


end


-- PC:0x66F010A4B031A331 Old:0x11378777


function NETWORK.NETWORK_SET_INVITE_ON_CALL_FOR_INVITE_MENU(p0)


  Velora.invoke(0xA4D670,"void", p0)


end


-- PC:0x44B37CDCAE765AAE Old:0x13301529


function NETWORK.NETWORK_CHECK_DATA_MANAGER_SUCCEEDED_FOR_HANDLE(p0, gamerHandle)


  return Velora.invoke(0xA4D800,"bool", p0, gamerHandle)


end


function NETWORK.NETWORK_CHECK_DATA_MANAGER_FOR_HANDLE(p0, gamerHandle)


  return Velora.invoke(0xA4D740,"bool", p0, gamerHandle)


end


-- PC:0x0D77A82DC2D0DA59 Old:0x0808D4CC


function NETWORK.NETWORK_SET_INVITE_FAILED_MESSAGE_FOR_INVITE_MENU(p0, p1)


  Velora.invoke(0xA4D800,"void", p0, p1)


end


-- PC:0xCBBD7C4991B64809 Old:0xCE40F423


function NETWORK.FILLOUT_PM_PLAYER_LIST(gamerHandle, p1, p2)


  return Velora.invoke(0xA4DAC0,"bool", gamerHandle, p1, p2)


end


-- PC:0x716B6DB9D1886106 Old:0xB8DF604E


function NETWORK.FILLOUT_PM_PLAYER_LIST_WITH_NAMES(p0, p1, p2, p3)


  return Velora.invoke(0xA4D840,"bool", p0, p1, p2, p3)


end


-- PC:0xE26CCFF8094D8C74 Old:0xF49C1533


function NETWORK.REFRESH_PLAYER_LIST_STATS(p0)


  return Velora.invoke(0xA4D870,"bool", p0)


end


function NETWORK.NETWORK_SET_CURRENT_DATA_MANAGER_HANDLE(p0)


  return Velora.invoke(0xA4D8A0,"bool", p0)


end


-- PC:0x2FC5650B0271CB57 Old:0xA812B6CB


function NETWORK.NETWORK_IS_IN_PLATFORM_PARTY()


  return Velora.invoke(0xA4D950,"bool")


end


function NETWORK.NETWORK_GET_PLATFORM_PARTY_MEMBER_COUNT()


  return Velora.invoke(0xA4D970,"int")


end


-- PC:0x120364DE2845DAF8 Old:0xF30E5814


function NETWORK.NETWORK_GET_PLATFORM_PARTY_MEMBERS(data, dataSize)


  return Velora.invoke(0xA4D990,"int", data, dataSize)


end


-- PC:0xFD8B834A8BA05048 Old:0xC6609191


function NETWORK.NETWORK_IS_IN_PLATFORM_PARTY_CHAT()


  return Velora.invoke(0xA4D9C0,"bool")


end


-- PC:0x8DE9945BCC9AEC52 Old:0x51367B34


function NETWORK.NETWORK_IS_CHATTING_IN_PLATFORM_PARTY(gamerHandle)


  return Velora.invoke(0xA4D9E0,"bool", gamerHandle)


end


-- PC:0x2BF66D2E7414F686 Old:0x9156EFC0


function NETWORK.NETWORK_CAN_QUEUE_FOR_PREVIOUS_SESSION_JOIN()


  return Velora.invoke(0xA4DA60,"bool")


end


-- PC:0x14922ED3E38761F0 Old:0x8FA6EE0E


function NETWORK.NETWORK_IS_QUEUING_FOR_SESSION_JOIN()


  return Velora.invoke(0xA4DA90,"bool")


end


function NETWORK.NETWORK_CLEAR_QUEUED_JOIN_REQUEST()


  Velora.invoke(0xA4DAC0,"void")


end


-- PC:0xFA2888E3833C8E96 Old:0x7F70C15A


function NETWORK.NETWORK_SEND_QUEUED_JOIN_REQUEST()


  Velora.invoke(0xA4DAD0,"void")


end


-- PC:0x25D990F8E0E3F13C Old:0x4FD83F5B


function NETWORK.NETWORK_REMOVE_ALL_QUEUED_JOIN_REQUESTS()


  Velora.invoke(0xA4DAE0,"void")


end


-- PC:0xF1B84178F8674195 Old:0x41702C8A


function NETWORK.NETWORK_SEED_RANDOM_NUMBER_GENERATOR(seed)


  Velora.invoke(0xA4DAF0,"void", seed)


end


-- PC:0x599E4FA1F87EB5FF Old:0x208DD848


function NETWORK.NETWORK_GET_RANDOM_INT()


  return Velora.invoke(0xA4DE20,"int")


end


-- PC:0xE30CF56F1EFA5F43 Old:0xF9B6426D


function NETWORK.NETWORK_GET_RANDOM_INT_RANGED(rangeStart, rangeEnd)


  return Velora.invoke(0xA4DB70,"int", rangeStart, rangeEnd)


end


-- PC:0x655B91F1495A9090 Old:0xA51DC214


function NETWORK.NETWORK_PLAYER_IS_CHEATER()


  return Velora.invoke(0xA4DC50,"bool")


end


-- PC:0x172F75B6EE2233BA Old:0x1720ABA6


function NETWORK.NETWORK_PLAYER_GET_CHEATER_REASON()


  return Velora.invoke(0xA4DCA0,"int")


end


-- PC:0x19D8DA0E5A68045A Old:0xA19708E3


function NETWORK.NETWORK_PLAYER_IS_BADSPORT()


  return Velora.invoke(0xA4DCD0,"bool")


end


-- PC:0x46FB3ED415C7641C Old:0xF9A51B92


function NETWORK.TRIGGER_PLAYER_CRC_HACKER_CHECK(player, p1, scriptHash)


  return Velora.invoke(0xDEADBEEF,"bool", player, p1, scriptHash)


end


function NETWORK.TRIGGER_TUNING_CRC_HACKER_CHECK(player, p1, p2)


  return Velora.invoke(0xDEADBEEF,"bool", player, p1, p2)


end


function NETWORK.TRIGGER_FILE_CRC_HACKER_CHECK(player, p1)


  return Velora.invoke(0xDEADBEEF,"bool", player, p1)


end


function NETWORK.REMOTE_CHEATER_PLAYER_DETECTED(player, a, b)


  return Velora.invoke(0xA4DD00,"bool", player, a, b)


end


-- PC:0xEC5E3AF5289DCA81 Old:0x4C2C6B6A


function NETWORK.BAD_SPORT_PLAYER_LEFT_DETECTED(gamerHandle, event, amountReceived)


  return Velora.invoke(0xA4DD70,"bool", gamerHandle, event, amountReceived)


end


function NETWORK.NETWORK_ADD_INVALID_OBJECT_MODEL(modelHash)


  Velora.invoke(0xA4DE20,"void", modelHash)


end


function NETWORK.NETWORK_REMOVE_INVALID_OBJECT_MODEL(modelHash)


  Velora.invoke(0xA4DEA0,"void", modelHash)


end


function NETWORK.NETWORK_CLEAR_INVALID_OBJECT_MODELS()


  Velora.invoke(0xA4DF20,"void")


end


-- PC:0xE66C690248F11150 Old:0x4818ACD0


function NETWORK.NETWORK_APPLY_PED_SCAR_DATA(ped, p1)


  Velora.invoke(0xA4DF40,"void", ped, p1)


end


-- PC:0x1CA59E306ECB80A5 Old:0x470810ED


function NETWORK.NETWORK_SET_THIS_SCRIPT_IS_NETWORK_SCRIPT(maxNumMissionParticipants, p1, instanceId)


  Velora.invoke(0xA4DFA0,"void", maxNumMissionParticipants, p1, instanceId)


end


function NETWORK.NETWORK_TRY_TO_SET_THIS_SCRIPT_IS_NETWORK_SCRIPT(p0, p1, p2)


  return Velora.invoke(0xA4E170,"bool", p0, p1, p2)


end


-- PC:0x2910669969E9535E Old:0xD9BF6549


function NETWORK.NETWORK_GET_THIS_SCRIPT_IS_NETWORK_SCRIPT()


  return Velora.invoke(0xA4E0A0,"bool")


end


-- PC:0xA6C90FBC38E395EE Old:0xCCD8C02D


function NETWORK.NETWORK_GET_MAX_NUM_PARTICIPANTS()


  return Velora.invoke(0xA4E0D0,"int")


end


-- PC:0x18D0456E86604654 Old:0x3E25A3C5


function NETWORK.NETWORK_GET_NUM_PARTICIPANTS()


  return Velora.invoke(0xA4E110,"int")


end


-- PC:0x57D158647A6BFABF Old:0x2BE9235A


function NETWORK.NETWORK_GET_SCRIPT_STATUS()


  return Velora.invoke(0xA4E150,"int")


end


-- PC:0x3E9B2F01C50DF595 Old:0xDAF3B0AE


function NETWORK.NETWORK_REGISTER_HOST_BROADCAST_VARIABLES(numVars, debugName)


  Velora.invoke(0xA4E170,"void", numVars, debugName)


end


-- PC:0x3364AA97340CA215 Old:0xBE3D32B4


function NETWORK.NETWORK_REGISTER_PLAYER_BROADCAST_VARIABLES(numVars, debugName)


  Velora.invoke(0xA4E190,"void", numVars, debugName)


end


function NETWORK.NETWORK_REGISTER_HIGH_FREQUENCY_HOST_BROADCAST_VARIABLES(p0, p1, p2)


  Velora.invoke(0xA4E1B0,"void", p0, p1, p2)


end


function NETWORK.NETWORK_REGISTER_HIGH_FREQUENCY_PLAYER_BROADCAST_VARIABLES(p0, p1, p2)


  Velora.invoke(0xA4E1D0,"void", p0, p1, p2)


end


-- PC:0x64F62AFB081E260D Old:0xA71A1D2A


function NETWORK.NETWORK_FINISH_BROADCASTING_DATA()


  Velora.invoke(0xA4E1F0,"void")


end


-- PC:0x5D10B3795F3FC886 Old:0x0B739F53


function NETWORK.NETWORK_HAS_RECEIVED_HOST_BROADCAST_DATA()


  return Velora.invoke(0xA4E980,"bool")


end


-- PC:0x24FB80D107371267 Old:0xBE1C1506


function NETWORK.NETWORK_GET_PLAYER_INDEX(player)


  return Velora.invoke(0xA4E510,"int", player)


end


-- PC:0x1B84DF6AF2A46938 Old:0xC4D91094


function NETWORK.NETWORK_GET_PARTICIPANT_INDEX(index)


  return Velora.invoke(0xA4E5E0,"int", index)


end


-- PC:0x6C0E2E0125610278 Old:0x40DBF464


function NETWORK.NETWORK_GET_PLAYER_INDEX_FROM_PED(ped)


  return Velora.invoke(0xA4E660,"int", ped)


end


-- PC:0xA4A79DD2D9600654 Old:0xF7952E62


function NETWORK.NETWORK_GET_NUM_CONNECTED_PLAYERS()


  return Velora.invoke(0xA4E6F0,"int")


end


-- PC:0x93DC1BE4E1ABE9D1 Old:0x168EE2C2


function NETWORK.NETWORK_IS_PLAYER_CONNECTED(player)


  return Velora.invoke(0xA4E710,"bool", player)


end


-- PC:0xCF61D4B4702EE9EB Old:0xF4F13B06


function NETWORK.NETWORK_GET_TOTAL_NUM_PLAYERS()


  return Velora.invoke(0xA4E770,"int")


end


-- PC:0x6FF8FF40B6357D45 Old:0x4E2C348B


function NETWORK.NETWORK_IS_PARTICIPANT_ACTIVE(p0)


  return Velora.invoke(0xA4E790,"bool", p0)


end


-- PC:0xB8DFD30D6973E135 Old:0x43657B17


function NETWORK.NETWORK_IS_PLAYER_ACTIVE(player)


  return Velora.invoke(0xA4E7D0,"bool", player)


end


-- PC:0x3CA58F6CB7CBD784 Old:0xB08B6992


function NETWORK.NETWORK_IS_PLAYER_A_PARTICIPANT(player)


  return Velora.invoke(0xA4E800,"bool", player)


end


-- PC:0x83CD99A1E6061AB5 Old:0x6970BA94


function NETWORK.NETWORK_IS_HOST_OF_THIS_SCRIPT()


  return Velora.invoke(0xA4E840,"bool")


end


-- PC:0xC7B4D79B01FA7A5C Old:0x89EA7B54


function NETWORK.NETWORK_GET_HOST_OF_THIS_SCRIPT()


  return Velora.invoke(0xA4E870,"int")


end


-- PC:0x1D6A14F1F9A736FC Old:0x9C95D0BB


function NETWORK.NETWORK_GET_HOST_OF_SCRIPT(scriptName, instance_id, position_hash)


  return Velora.invoke(0xA4E8B0,"int", scriptName, instance_id, position_hash)


end


-- PC:0x3B3D11CD9FFCDFC9 Old:0x3083FAD7


function NETWORK.NETWORK_SET_MISSION_FINISHED()


  Velora.invoke(0xA4E980,"void")


end


-- PC:0x9D40DF90FAD26098 Old:0x4A65250C


function NETWORK.NETWORK_IS_SCRIPT_ACTIVE(scriptName, instance_id, p2, position_hash)


  return Velora.invoke(0xA4ED90,"bool", scriptName, instance_id, p2, position_hash)


end


function NETWORK.NETWORK_IS_SCRIPT_ACTIVE_BY_HASH(scriptHash, p1, p2, p3)


  return Velora.invoke(0xA4EAC0,"bool", scriptHash, p1, p2, p3)


end


function NETWORK.NETWORK_IS_THREAD_A_NETWORK_SCRIPT(threadId)


  return Velora.invoke(0xA4EB80,"bool", threadId)


end


-- PC:0x3658E8CD94FC121A Old:0x8F7D9F46


function NETWORK.NETWORK_GET_NUM_SCRIPT_PARTICIPANTS(scriptName, instance_id, position_hash)


  return Velora.invoke(0xA4EBD0,"int", scriptName, instance_id, position_hash)


end


-- PC:0x638A3A81733086DB Old:0xDB8B5D71


function NETWORK.NETWORK_GET_INSTANCE_ID_OF_THIS_SCRIPT()


  return Velora.invoke(0xA4ECE0,"int")


end


function NETWORK.NETWORK_GET_POSITION_HASH_OF_THIS_SCRIPT()


  return Velora.invoke(0xA4ED20,"int")


end


-- PC:0x1AD5B71586B94820 Old:0xCEA55F4C


function NETWORK.NETWORK_IS_PLAYER_A_PARTICIPANT_ON_SCRIPT(player, script, instance_id)


  return Velora.invoke(0xA4ED60,"bool", player, script, instance_id)


end


-- PC:0x2302C0264EA58D31 Old:0x8DCFE77D


function NETWORK.NETWORK_PREVENT_SCRIPT_HOST_MIGRATION()


  Velora.invoke(0xA4ED90,"void")


end


-- PC:0x741A3D8380319A81 Old:0x331D9A27


function NETWORK.NETWORK_REQUEST_TO_BE_HOST_OF_THIS_SCRIPT()


  Velora.invoke(0xA4EDC0,"void")


end


-- PC:0x90986E8876CE0A83 Old:0x9C35A221


function NETWORK.PARTICIPANT_ID()


  return Velora.invoke(0xA4EFD0,"int")


end


-- PC:0x57A3BDDAD8E5AA0A Old:0x907498B0


function NETWORK.PARTICIPANT_ID_TO_INT()


  return Velora.invoke(0xA4EE40,"int")


end


function NETWORK.NETWORK_GET_KILLER_OF_PLAYER(player)


  return Velora.invoke(0xA4EE70,"int", player)


end


-- PC:0x7A1ADEEF01740A24 Old:0x4FCA6436


function NETWORK.NETWORK_GET_DESTROYER_OF_NETWORK_ID(netId)


  return Velora.invoke(0xA4EEE0,"int", netId)


end


function NETWORK.NETWORK_GET_DESTROYER_OF_ENTITY(entity)


  return Velora.invoke(0xA4EF10,"int", entity)


end


function NETWORK.NETWORK_GET_ASSISTED_KILL_OF_ENTITY(player, entity)


  return Velora.invoke(0xA4EF40,"bool", player, entity)


end


-- PC:0x4CACA84440FA26F6 Old:0x28A45454


function NETWORK.NETWORK_GET_ASSISTED_DAMAGE_OF_ENTITY(player, entity)


  return Velora.invoke(0xA4EF70,"bool", player, entity)


end


-- PC:0x42B2DAA6B596F5F8 Old:0xA7E7E04F


function NETWORK.NETWORK_GET_ENTITY_KILLER_OF_PLAYER(player)


  return Velora.invoke(0xA4EFA0,"int", player)


end


function NETWORK.NETWORK_SET_CURRENT_PUBLIC_CONTENT_ID(missionId)


  Velora.invoke(0xA4EFD0,"void", missionId)


end


function NETWORK.NETWORK_SET_CURRENT_CHAT_OPTION(newChatOption)


  Velora.invoke(0xA4F010,"void", newChatOption)


end


function NETWORK.NETWORK_SET_CURRENT_SPAWN_LOCATION_OPTION(mpSettingSpawn)


  Velora.invoke(0xA4F040,"void", mpSettingSpawn)


end


function NETWORK.NETWORK_SET_VEHICLE_DRIVEN_IN_TEST_DRIVE(toggle)


  Velora.invoke(0xA4F070,"void", toggle)


end


-- PC:0xEA23C49EAA83ACFB Old:0xF1F9D4B4


function NETWORK.NETWORK_RESURRECT_LOCAL_PLAYER(x, y, z, heading, p4, changetime, p6, p7, p8)


  Velora.invoke(0xA4F0E0,"void", x, y, z, heading, p4, changetime, p6, p7, p8)


end


-- PC:0x2D95C7E2D7E07307 Old:0xFEA9B85C


function NETWORK.NETWORK_SET_LOCAL_PLAYER_INVINCIBLE_TIME(time)


  Velora.invoke(0xA4F110,"void", time)


end


-- PC:0x8A8694B48715B000 Old:0x8DE13B36


function NETWORK.NETWORK_IS_LOCAL_PLAYER_INVINCIBLE()


  return Velora.invoke(0xA4F190,"bool")


end


-- PC:0x9DD368BF06983221 Old:0x8D27280E


function NETWORK.NETWORK_DISABLE_INVINCIBLE_FLASHING(player, toggle)


  Velora.invoke(0xA4F190,"void", player, toggle)


end


function NETWORK.NETWORK_PATCH_POST_CUTSCENE_HS4F_TUN_ENT(ped)


  Velora.invoke(0xA4F1E0,"void", ped)


end


-- PC:0x524FF0AEFF9C3973 Old:0xB72F086D


function NETWORK.NETWORK_SET_LOCAL_PLAYER_SYNC_LOOK_AT(toggle)


  Velora.invoke(0xA4F240,"void", toggle)


end


-- PC:0xB07D3185E11657A5 Old:0xEDA68956


function NETWORK.NETWORK_HAS_ENTITY_BEEN_REGISTERED_WITH_THIS_THREAD(entity)


  return Velora.invoke(0xA4F450,"bool", entity)


end


-- PC:0xA11700682F3AD45C Old:0x9E35DAB6


function NETWORK.NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity)


  return Velora.invoke(0xA4F2E0,"int", entity)


end


-- PC:0xCE4E5D9B0A4FF560 Old:0x5B912C3F


function NETWORK.NETWORK_GET_ENTITY_FROM_NETWORK_ID(netId)


  return Velora.invoke(0xA4F340,"int", netId)


end


-- PC:0xC7827959479DCC78 Old:0xD7F934F4


function NETWORK.NETWORK_GET_ENTITY_IS_NETWORKED(entity)


  return Velora.invoke(0xA4F380,"bool", entity)


end


-- PC:0x0991549DE4D64762 Old:0x813353ED


function NETWORK.NETWORK_GET_ENTITY_IS_LOCAL(entity)


  return Velora.invoke(0xA4F3E0,"bool", entity)


end


-- PC:0x06FAACD625D80CAA Old:0x31A630A4


function NETWORK.NETWORK_REGISTER_ENTITY_AS_NETWORKED(entity)


  Velora.invoke(0xA4F450,"void", entity)


end


-- PC:0x7368E683BB9038D6 Old:0x5C645F64


function NETWORK.NETWORK_UNREGISTER_NETWORKED_ENTITY(entity)


  Velora.invoke(0xA4F520,"void", entity)


end


-- PC:0x38CE16C96BD11344 Old:0xB8D2C99E


function NETWORK.NETWORK_DOES_NETWORK_ID_EXIST(netId)


  return Velora.invoke(0xA4FB70,"bool", netId)


end


-- PC:0x18A47D074708FD68 Old:0x1E2E3177


function NETWORK.NETWORK_DOES_ENTITY_EXIST_WITH_NETWORK_ID(netId)


  return Velora.invoke(0xA4F600,"bool", netId)


end


-- PC:0xA670B3662FAFFBD0 Old:0x9262A60A


function NETWORK.NETWORK_REQUEST_CONTROL_OF_NETWORK_ID(netId)


  return Velora.invoke(0xA4F640,"bool", netId)


end


-- PC:0x4D36070FE0215186 Old:0x92E77D21


function NETWORK.NETWORK_HAS_CONTROL_OF_NETWORK_ID(netId)


  return Velora.invoke(0xA4F6B0,"bool", netId)


end


function NETWORK.NETWORK_IS_NETWORK_ID_REMOTELY_CONTROLLED(netId)


  return Velora.invoke(0xA4F730,"bool", netId)


end


-- PC:0xB69317BF5E782347 Old:0xA05FEBD7


function NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(entity)


  return Velora.invoke(0xA4F780,"bool", entity)


end


-- PC:0x870DDFD5A4A796E4 Old:0xF60DAAF6


function NETWORK.NETWORK_REQUEST_CONTROL_OF_DOOR(doorID)


  return Velora.invoke(0xA4F7B0,"bool", doorID)


end


-- PC:0x01BF60A500E28887 Old:0x005FD797


function NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(entity)


  return Velora.invoke(0xA4F820,"bool", entity)


end


-- PC:0x5BC9495F0B3B6FA6 Old:0xF7784FC8


function NETWORK.NETWORK_HAS_CONTROL_OF_PICKUP(pickup)


  return Velora.invoke(0xA4F890,"bool", pickup)


end


-- PC:0xCB3C68ADB06195DF Old:0x136326EC


function NETWORK.NETWORK_HAS_CONTROL_OF_DOOR(doorHash)


  return Velora.invoke(0xA4F8C0,"bool", doorHash)


end


-- PC:0xC01E93FAC20C3346 Old:0xD14D9C07


function NETWORK.NETWORK_IS_DOOR_NETWORKED(doorHash)


  return Velora.invoke(0xA4F910,"bool", doorHash)


end


-- PC:0xB4C94523F023419C Old:0xF17634EB


function NETWORK.VEH_TO_NET(vehicle)


  return Velora.invoke(0xA4F950,"int", vehicle)


end


-- PC:0x0EDEC3C276198689 Old:0x86A0B759


function NETWORK.PED_TO_NET(ped)


  return Velora.invoke(0xA4F9B0,"int", ped)


end


-- PC:0x99BFDC94A603E541 Old:0x1E05F29F


function NETWORK.OBJ_TO_NET(object)


  return Velora.invoke(0xA4FA10,"int", object)


end


-- PC:0x367B936610BA360C Old:0x7E02FAEA


function NETWORK.NET_TO_VEH(netHandle)


  return Velora.invoke(0xA4FA70,"int", netHandle)


end


-- PC:0xBDCD95FC216A8B3E Old:0x87717DD4


function NETWORK.NET_TO_PED(netHandle)


  return Velora.invoke(0xA4FAB0,"int", netHandle)


end


-- PC:0xD8515F5FEA14CB3F Old:0x27AA14D8


function NETWORK.NET_TO_OBJ(netHandle)


  return Velora.invoke(0xA4FAF0,"int", netHandle)


end


-- PC:0xBFFEAB45A9A9094A Old:0x5E149683


function NETWORK.NET_TO_ENT(netHandle)


  return Velora.invoke(0xA4FB30,"int", netHandle)


end


-- PC:0xE86051786B66CD8E Old:0x08023B16


function NETWORK.NETWORK_GET_LOCAL_HANDLE(gamerHandle, gamerHandleSize)


  Velora.invoke(0xA4FB70,"void", gamerHandle, gamerHandleSize)


end


-- PC:0xDCD51DD8F87AEC5C Old:0x74C2C1B7


function NETWORK.NETWORK_HANDLE_FROM_USER_ID(userId, gamerHandle, gamerHandleSize)


  Velora.invoke(0xA4FBB0,"void", userId, gamerHandle, gamerHandleSize)


end


-- PC:0xA0FD21BED61E5C4C Old:0x9BFC9FE2


function NETWORK.NETWORK_HANDLE_FROM_MEMBER_ID(memberId, gamerHandle, gamerHandleSize)


  Velora.invoke(0xA4FC30,"void", memberId, gamerHandle, gamerHandleSize)


end


-- PC:0x388EB2B86C73B6B3 Old:0xD3498917


function NETWORK.NETWORK_HANDLE_FROM_PLAYER(player, gamerHandle, gamerHandleSize)


  Velora.invoke(0xA4FCB0,"void", player, gamerHandle, gamerHandleSize)


end


-- PC:0xBC1D768F2F5D6C05 Old:0xF8D7AF3B


function NETWORK.NETWORK_HASH_FROM_PLAYER_HANDLE(player)


  return Velora.invoke(0xA4FDF0,"int", player)


end


-- PC:0x58575AC3CF2CA8EC Old:0x5AC9F04D


function NETWORK.NETWORK_HASH_FROM_GAMER_HANDLE(gamerHandle)


  return Velora.invoke(0xA4FD40,"int", gamerHandle)


end


-- PC:0xD45CB817D7E177D2 Old:0x3B0BB3A3


function NETWORK.NETWORK_HANDLE_FROM_FRIEND(friendIndex, gamerHandle, gamerHandleSize)


  Velora.invoke(0xA4FDF0,"void", friendIndex, gamerHandle, gamerHandleSize)


end


-- PC:0x9F0C0A981D73FA56 Old:0xEBA00C2A


function NETWORK.NETWORK_GAMERTAG_FROM_HANDLE_START(gamerHandle)


  return Velora.invoke(0xA503C0,"bool", gamerHandle)


end


-- PC:0xB071E27958EF4CF0 Old:0xF000828E


function NETWORK.NETWORK_GAMERTAG_FROM_HANDLE_PENDING()


  return Velora.invoke(0xA4FEB0,"bool")


end


-- PC:0xFD00798DBA7523DD Old:0x89C2B5EA


function NETWORK.NETWORK_GAMERTAG_FROM_HANDLE_SUCCEEDED()


  return Velora.invoke(0xA4FEC0,"bool")


end


function NETWORK.NETWORK_DISPLAYNAMES_FROM_HANDLES_START(p0, p1)


  return Velora.invoke(0xA4FF80,"int", p0, p1)


end


function NETWORK.NETWORK_GET_DISPLAYNAMES_FROM_HANDLES(p0, p1, p2)


  return Velora.invoke(0xA50080,"int", p0, p1, p2)


end


-- PC:0x57DBA049E110F217 Old:0x45975AE3


function NETWORK.NETWORK_ARE_HANDLES_THE_SAME(gamerHandle1, gamerHandle2)


  return Velora.invoke(0xA50190,"bool", gamerHandle1, gamerHandle2)


end


-- PC:0x6F79B93B0A8E4133 Old:0xF0996C6E


function NETWORK.NETWORK_IS_HANDLE_VALID(gamerHandle, gamerHandleSize)


  return Velora.invoke(0xA50240,"bool", gamerHandle, gamerHandleSize)


end


-- PC:0xCE5F689CF5A0A49D Old:0x2E96EF1E


function NETWORK.NETWORK_GET_PLAYER_FROM_GAMER_HANDLE(gamerHandle)


  return Velora.invoke(0xA50270,"int", gamerHandle)


end


-- PC:0x0F10B05DDF8D16E9 Old:0x59127716


function NETWORK.NETWORK_IS_GAMER_IN_MY_SESSION(gamerHandle)


  return Velora.invoke(0xA50330,"bool", gamerHandle)


end


-- PC:0x859ED1CEA343FCA8 Old:0xF00A20B0


function NETWORK.NETWORK_SHOW_PROFILE_UI(gamerHandle)


  Velora.invoke(0xA503C0,"void", gamerHandle)


end


-- PC:0x544ABDDA3B409B6D Old:0xF6659045


function NETWORK.NETWORK_PLAYER_IS_ROCKSTAR_DEV(player)


  return Velora.invoke(0xA504E0,"bool", player)


end


-- PC:0x565E430DB3B05BEC Old:0xD265B049


function NETWORK.NETWORK_PLAYER_INDEX_IS_CHEATER(player)


  return Velora.invoke(0xA50530,"bool", player)


end


function NETWORK.NETWORK_ENTITY_GET_OBJECT_ID(entity)


  return Velora.invoke(0xA505B0,"int", entity)


end


function NETWORK.NETWORK_GET_ENTITY_FROM_OBJECT_ID(p0)


  return Velora.invoke(0xA50620,"int", p0)


end


-- PC:0x7E58745504313A2E Old:0x95481343


function NETWORK.NETWORK_IS_INACTIVE_PROFILE(p0)


  return Velora.invoke(0xA50680,"bool", p0)


end


-- PC:0xAFEBB0D5D8F687D2 Old:0x048171BC


function NETWORK.NETWORK_GET_MAX_FRIENDS()


  return Velora.invoke(0xA50740,"int")


end


-- PC:0x203F1CFD823B27A4 Old:0xA396ACDE


function NETWORK.NETWORK_GET_FRIEND_COUNT()


  return Velora.invoke(0xA50750,"int")


end


-- PC:0x425A44533437B64D Old:0xE0A42430


function NETWORK.NETWORK_IS_FRIEND_ONLINE(name)


  return Velora.invoke(0xA50800,"bool", name)


end


function NETWORK.NETWORK_IS_FRIEND_HANDLE_ONLINE(gamerHandle)


  return Velora.invoke(0xA50850,"bool", gamerHandle)


end


-- PC:0x2EA9A3BEDF3F17B8 Old:0xC54365C2


function NETWORK.NETWORK_IS_FRIEND_IN_SAME_TITLE(friendName)


  return Velora.invoke(0xA50880,"bool", friendName)


end


-- PC:0x57005C18827F3A28 Old:0x400BDDD9


function NETWORK.NETWORK_IS_FRIEND_IN_MULTIPLAYER(friendName)


  return Velora.invoke(0xA50900,"bool", friendName)


end


-- PC:0x1A24A179F9B31654 Old:0x2DA4C282


function NETWORK.NETWORK_IS_FRIEND(gamerHandle)


  return Velora.invoke(0xA50950,"bool", gamerHandle)


end


-- PC:0x0BE73DA6984A6E33 Old:0x5C85FF81


function NETWORK.NETWORK_IS_PENDING_FRIEND(p0)


  return Velora.invoke(0xA509E0,"bool", p0)


end


-- PC:0x6EA101606F6E4D81 Old:0xBB7EC8C4


function NETWORK.NETWORK_IS_ADDING_FRIEND()


  return Velora.invoke(0xA509F0,"bool")


end


-- PC:0x8E02D73914064223 Old:0x20E5B3EE


function NETWORK.NETWORK_ADD_FRIEND(gamerHandle, message)


  return Velora.invoke(0xA50A10,"bool", gamerHandle, message)


end


-- PC:0xBAD8F2A42B844821 Old:0x94AE7172


function NETWORK.NETWORK_IS_FRIEND_INDEX_ONLINE(friendIndex)


  return Velora.invoke(0xA50AA0,"bool", friendIndex)


end


-- PC:0x1B857666604B1A74 Old:0x76A9FEB6


function NETWORK.NETWORK_SET_PLAYER_IS_PASSIVE(toggle)


  Velora.invoke(0xA50AF0,"void", toggle)


end


-- PC:0x82377B65E943F72D Old:0xB802B671


function NETWORK.NETWORK_GET_PLAYER_OWNS_WAYPOINT(player)


  return Velora.invoke(0xA50BD0,"bool", player)


end


-- PC:0xC927EC229934AF60 Old:0x009E68F3


function NETWORK.NETWORK_CAN_SET_WAYPOINT()


  return Velora.invoke(0xA50BA0,"bool")


end


function NETWORK.NETWORK_IGNORE_REMOTE_WAYPOINTS()


  Velora.invoke(0xA50BD0,"void")


end


function NETWORK.NETWORK_IS_PLAYER_ON_BLOCKLIST(gamerHandle)


  return Velora.invoke(0xA50F20,"bool", gamerHandle)


end


-- PC:0xB309EBEA797E001F Old:0x5C0AB2A9


function NETWORK.NETWORK_SET_SCRIPT_AUTOMUTED(p0)


  return Velora.invoke(0xA50E90,"bool", p0)


end


-- PC:0x26F07DD83A5F7F98 Old:0x9A176B6E


function NETWORK.NETWORK_HAS_AUTOMUTE_OVERRIDE()


  return Velora.invoke(0xA50EB0,"bool")


end


-- PC:0xE870F9F1F7B4F1FA Old:0xA7DC5657


function NETWORK.NETWORK_HAS_HEADSET()


  return Velora.invoke(0xA50EE0,"bool")


end


-- PC:0x7D395EA61622E116 Old:0x5C05B7E1


function NETWORK.NETWORK_SET_LOOK_AT_TALKERS(p0)


  Velora.invoke(0xA50F20,"void", p0)


end


function NETWORK.NETWORK_IS_PUSH_TO_TALK_ACTIVE()


  return Velora.invoke(0xA51AA0,"bool")


end


-- PC:0xF2FD55CB574BCC55 Old:0xD036DA4A


function NETWORK.NETWORK_GAMER_HAS_HEADSET(gamerHandle)


  return Velora.invoke(0xA50F60,"bool", gamerHandle)


end


-- PC:0x71C33B22606CD88A Old:0x99B58DBC


function NETWORK.NETWORK_IS_GAMER_TALKING(gamerHandle)


  return Velora.invoke(0xA50FF0,"bool", gamerHandle)


end


function NETWORK.NETWORK_PERMISSIONS_HAS_GAMER_RECORD(gamerHandle)


  return Velora.invoke(0xA51020,"bool", gamerHandle)


end


-- PC:0x8F5D1AD832AEB06C Old:0xD05EB7F6


function NETWORK.NETWORK_CAN_COMMUNICATE_WITH_GAMER(gamerHandle)


  return Velora.invoke(0xA510B0,"bool", gamerHandle)


end


function NETWORK.NETWORK_CAN_TEXT_CHAT_WITH_GAMER(gamerHandle)


  return Velora.invoke(0xA51150,"bool", gamerHandle)


end


-- PC:0xCE60DE011B6C7978 Old:0x001B4046


function NETWORK.NETWORK_IS_GAMER_MUTED_BY_ME(gamerHandle)


  return Velora.invoke(0xA511E0,"bool", gamerHandle)


end


-- PC:0xDF02A2C93F1F26DA Old:0x7685B333


function NETWORK.NETWORK_AM_I_MUTED_BY_GAMER(gamerHandle)


  return Velora.invoke(0xA51270,"bool", gamerHandle)


end


-- PC:0xE944C4F5AF1B5883 Old:0x3FDCC8D7


function NETWORK.NETWORK_IS_GAMER_BLOCKED_BY_ME(gamerHandle)


  return Velora.invoke(0xA51300,"bool", gamerHandle)


end


-- PC:0x15337C7C268A27B2 Old:0xD19B312C


function NETWORK.NETWORK_AM_I_BLOCKED_BY_GAMER(gamerHandle)


  return Velora.invoke(0xA51390,"bool", gamerHandle)


end


function NETWORK.NETWORK_CAN_VIEW_GAMER_USER_CONTENT(gamerHandle)


  return Velora.invoke(0xA51420,"bool", gamerHandle)


end


function NETWORK.NETWORK_HAS_VIEW_GAMER_USER_CONTENT_RESULT(gamerHandle)


  return Velora.invoke(0xA514B0,"bool", gamerHandle)


end


function NETWORK.NETWORK_CAN_PLAY_MULTIPLAYER_WITH_GAMER(gamerHandle)


  return Velora.invoke(0xA515D0,"bool", gamerHandle)


end


function NETWORK.NETWORK_CAN_GAMER_PLAY_MULTIPLAYER_WITH_ME(gamerHandle)


  return Velora.invoke(0xA51660,"bool", gamerHandle)


end


function NETWORK.NETWORK_CAN_SEND_LOCAL_INVITE(gamerHandle)


  return Velora.invoke(0xA516F0,"bool", gamerHandle)


end


function NETWORK.NETWORK_CAN_RECEIVE_LOCAL_INVITE(gamerHandle)


  return Velora.invoke(0xA51770,"bool", gamerHandle)


end


-- PC:0x031E11F3D447647E Old:0xDA9FD9DB


function NETWORK.NETWORK_IS_PLAYER_TALKING(player)


  return Velora.invoke(0xA51800,"bool", player)


end


-- PC:0x3FB99A8B08D18FD6 Old:0x451FB6B6


function NETWORK.NETWORK_PLAYER_HAS_HEADSET(player)


  return Velora.invoke(0xA51860,"bool", player)


end


-- PC:0x8C71288AE68EDE39 Old:0x7A21050E


function NETWORK.NETWORK_IS_PLAYER_MUTED_BY_ME(player)


  return Velora.invoke(0xA518C0,"bool", player)


end


-- PC:0x9D6981DFC91A8604 Old:0xE128F2B0


function NETWORK.NETWORK_AM_I_MUTED_BY_PLAYER(player)


  return Velora.invoke(0xA51920,"bool", player)


end


-- PC:0x57AF1F8E27483721 Old:0xAE4F4560


function NETWORK.NETWORK_IS_PLAYER_BLOCKED_BY_ME(player)


  return Velora.invoke(0xA51980,"bool", player)


end


-- PC:0x87F395D957D4353D Old:0x953EF45E


function NETWORK.NETWORK_AM_I_BLOCKED_BY_PLAYER(player)


  return Velora.invoke(0xA519E0,"bool", player)


end


-- PC:0x21A1684A25C2867F Old:0xF2F67014


function NETWORK.NETWORK_GET_PLAYER_LOUDNESS(player)


  return Velora.invoke(0xA51A40,"float", player)


end


-- PC:0xCBF12D65F95AD686 Old:0x67555C66


function NETWORK.NETWORK_SET_TALKER_PROXIMITY(value)


  Velora.invoke(0xA51AA0,"void", value)


end


-- PC:0x84F0F13120B4E098 Old:0x19991ADD


function NETWORK.NETWORK_GET_TALKER_PROXIMITY()


  return Velora.invoke(0xA51AF0,"float")


end


-- PC:0xBABEC9E69A91C57B Old:0x8011247F


function NETWORK.NETWORK_SET_VOICE_ACTIVE(toggle)


  Velora.invoke(0xA51AF0,"void", toggle)


end


-- PC:0xCFEB46DCD7D8D5EB Old:0x1A3EA6CD


function NETWORK.NETWORK_REMAIN_IN_GAME_CHAT(p0)


  Velora.invoke(0xA51B10,"void", p0)


end


-- PC:0xAF66059A131AA269 Old:0xCAB21090


function NETWORK.NETWORK_OVERRIDE_TRANSITION_CHAT(p0)


  Velora.invoke(0xA51B30,"void", p0)


end


-- PC:0xD5B4883AC32F24C3 Old:0x3813019A


function NETWORK.NETWORK_SET_TEAM_ONLY_CHAT(toggle)


  Velora.invoke(0xA51B50,"void", toggle)


end


function NETWORK.NETWORK_SET_SCRIPT_CONTROLLING_TEAMS(p0)


  Velora.invoke(0xA51B70,"void", p0)


end


function NETWORK.NETWORK_SET_SAME_TEAM_AS_LOCAL_PLAYER(p0, p1)


  return Velora.invoke(0xA51B90,"bool", p0, p1)


end


-- PC:0x6F697A66CE78674E Old:0xC8CC9E75


function NETWORK.NETWORK_OVERRIDE_TEAM_RESTRICTIONS(team, toggle)


  Velora.invoke(0xA51B90,"void", team, toggle)


end


-- PC:0x70DA3BF8DACD3210 Old:0xA0FD42D3


function NETWORK.NETWORK_SET_OVERRIDE_SPECTATOR_MODE(toggle)


  Velora.invoke(0xA51BC0,"void", toggle)


end


-- PC:0x3C5C1E2C2FF814B1 Old:0xC9DDA85B


function NETWORK.NETWORK_SET_OVERRIDE_TUTORIAL_SESSION_CHAT(toggle)


  Velora.invoke(0xA51BE0,"void", toggle)


end


-- PC:0x9D7AFCBF21C51712 Old:0xE5219410


function NETWORK.NETWORK_SET_PROXIMITY_AFFECTS_TEAM(toggle)


  Velora.invoke(0xA51C00,"void", toggle)


end


-- PC:0xF46A1E03E8755980 Old:0xD33AFF79


function NETWORK.NETWORK_SET_NO_SPECTATOR_CHAT(toggle)


  Velora.invoke(0xA51C20,"void", toggle)


end


-- PC:0x6A5D89D7769A40D8 Old:0x4FFEFE43


function NETWORK.NETWORK_SET_IGNORE_SPECTATOR_CHAT_LIMITS_SAME_TEAM(toggle)


  Velora.invoke(0xA51C40,"void", toggle)


end


-- PC:0x3039AE5AD2C9C0C4 Old:0x74EE2D8B


function NETWORK.NETWORK_OVERRIDE_CHAT_RESTRICTIONS(player, toggle)


  Velora.invoke(0xA51C60,"void", player, toggle)


end


-- PC:0x97DD4C5944CC2E6A Old:0x6C344AE3


function NETWORK.NETWORK_OVERRIDE_SEND_RESTRICTIONS(player, toggle)


  Velora.invoke(0xA51CC0,"void", player, toggle)


end


-- PC:0x57B192B4D4AD23D5 Old:0x2F98B405


function NETWORK.NETWORK_OVERRIDE_SEND_RESTRICTIONS_ALL(toggle)


  Velora.invoke(0xA51CF0,"void", toggle)


end


-- PC:0xDDF73E2B1FEC5AB4 Old:0x95F1C60D


function NETWORK.NETWORK_OVERRIDE_RECEIVE_RESTRICTIONS(player, toggle)


  Velora.invoke(0xA51D10,"void", player, toggle)


end


-- PC:0x0FF2862B61A58AF9 Old:0x1BCD3DDF


function NETWORK.NETWORK_OVERRIDE_RECEIVE_RESTRICTIONS_ALL(toggle)


  Velora.invoke(0xA51D40,"void", toggle)


end


-- PC:0xEF6212C2EFEF1A23 Old:0x3974879F


function NETWORK.NETWORK_SET_VOICE_CHANNEL(channel)


  Velora.invoke(0xA51D60,"void", channel)


end


-- PC:0xE036A705F989E049 Old:0x9ECF722A


function NETWORK.NETWORK_CLEAR_VOICE_CHANNEL()


  Velora.invoke(0xA51DB0,"void")


end


-- PC:0xDBD2056652689917 Old:0xF1E84832


function NETWORK.NETWORK_APPLY_VOICE_PROXIMITY_OVERRIDE(x, y, z)


  Velora.invoke(0xA51DE0,"void", x, y, z)


end


-- PC:0xF03755696450470C Old:0x7F9B9052


function NETWORK.NETWORK_CLEAR_VOICE_PROXIMITY_OVERRIDE()


  Velora.invoke(0xA51E70,"void")


end


-- PC:0x5E3AA4CA2B6FB0EE Old:0x7BBEA8CF


function NETWORK.NETWORK_ENABLE_VOICE_BANDWIDTH_RESTRICTION(player)


  Velora.invoke(0xA51EA0,"void", player)


end


-- PC:0xCA575C391FEA25CC Old:0xE797A4B6


function NETWORK.NETWORK_DISABLE_VOICE_BANDWIDTH_RESTRICTION(player)


  Velora.invoke(0xA51F00,"void", player)


end


-- PC:0xADB57E5B663CCA8B Old:0x92268BB5


function NETWORK.NETWORK_GET_MUTE_COUNT_FOR_PLAYER(p0)


  Velora.invoke(0xA51F60,"void", p0)


end


function NETWORK.NETWORK_SET_SPECTATOR_TO_NON_SPECTATOR_TEXT_CHAT(toggle)


  Velora.invoke(0xA51FB0,"void", toggle)


end


function NETWORK.NETWORK_TEXT_CHAT_IS_TYPING()


  return Velora.invoke(0xA51FD0,"bool")


end


-- PC:0x593850C16A36B692 Old:0x92B7351C


function NETWORK.SHUTDOWN_AND_LAUNCH_SINGLE_PLAYER_GAME()


  Velora.invoke(0xA51FD0,"void")


end


function NETWORK.SHUTDOWN_AND_LOAD_MOST_RECENT_SAVE()


  return Velora.invoke(0xA52030,"bool")


end


-- PC:0xF808475FA571D823 Old:0x6BAF95FA


function NETWORK.NETWORK_SET_FRIENDLY_FIRE_OPTION(toggle)


  Velora.invoke(0xA52030,"void", toggle)


end


-- PC:0x1DCCACDCFC569362 Old:0x932A6CED


function NETWORK.NETWORK_SET_RICH_PRESENCE(p0, p1, p2, p3)


  Velora.invoke(0xA52050,"void", p0, p1, p2, p3)


end


-- PC:0x3E200C2BCF4164EB Old:0x017E6777


function NETWORK.NETWORK_SET_RICH_PRESENCE_STRING(p0, textLabel)


  Velora.invoke(0xA52060,"void", p0, textLabel)


end


-- PC:0x5ED0356A0CE3A34F Old:0xE1F86C6A


function NETWORK.NETWORK_GET_TIMEOUT_TIME()


  return Velora.invoke(0xA52090,"int")


end


-- PC:0x9769F811D1785B03 Old:0xBE6A30C3


function NETWORK.NETWORK_LEAVE_PED_BEHIND_BEFORE_WARP(player, x, y, z, p4, p5)


  Velora.invoke(0xA52090,"void", player, x, y, z, p4, p5)


end


-- PC:0xBF22E0F32968E967 Old:0x22E03AD0


function NETWORK.NETWORK_LEAVE_PED_BEHIND_BEFORE_CUTSCENE(player, p1)


  Velora.invoke(0xA520C0,"void", player, p1)


end


-- PC:0x715135F4B82AC90D Old:0xCEAE5AFC


function NETWORK.REMOVE_ALL_STICKY_BOMBS_FROM_ENTITY(entity, ped)


  Velora.invoke(0xA520E0,"void", entity, ped)


end


function NETWORK.NETWORK_KEEP_ENTITY_COLLISION_DISABLED_AFTER_ANIM_SCENE(p0, p1)


  Velora.invoke(0xA52170,"void", p0, p1)


end


function NETWORK.NETWORK_IS_ANY_PLAYER_NEAR(p0, p1, p2, p3, p4, p5, p6)


  return Velora.invoke(0xA52370,"bool", p0, p1, p2, p3, p4, p5, p6)


end


-- PC:0x579CCED0265D4896 Old:0xF5F4BD95


function NETWORK.NETWORK_CLAN_SERVICE_IS_VALID()


  return Velora.invoke(0xA52220,"bool")


end


-- PC:0xB124B57F571D8F18 Old:0xAB8319A3


function NETWORK.NETWORK_CLAN_PLAYER_IS_ACTIVE(gamerHandle)


  return Velora.invoke(0xA52250,"bool", gamerHandle)


end


-- PC:0xEEE6EACBE8874FBA Old:0x6EE4A282


function NETWORK.NETWORK_CLAN_PLAYER_GET_DESC(clanDesc, bufferSize, gamerHandle)


  return Velora.invoke(0xA52300,"bool", clanDesc, bufferSize, gamerHandle)


end


-- PC:0x7543BB439F63792B Old:0x54E79E9C


function NETWORK.NETWORK_CLAN_IS_ROCKSTAR_CLAN(clanDesc, bufferSize)


  return Velora.invoke(0xA52330,"bool", clanDesc, bufferSize)


end


-- PC:0xF45352426FF3A4F0 Old:0xF633805A


function NETWORK.NETWORK_CLAN_GET_UI_FORMATTED_TAG(clanDesc, bufferSize, formattedTag)


  Velora.invoke(0xA52370,"void", clanDesc, bufferSize, formattedTag)


end


-- PC:0x1F471B79ACC90BEF Old:0x807B3450


function NETWORK.NETWORK_CLAN_GET_LOCAL_MEMBERSHIPS_COUNT()


  return Velora.invoke(0xA527E0,"int")


end


-- PC:0x48DE78AF2C8885B8 Old:0x3369DD1F


function NETWORK.NETWORK_CLAN_GET_MEMBERSHIP_DESC(memberDesc, p1)


  return Velora.invoke(0xA52420,"bool", memberDesc, p1)


end


-- PC:0xA989044E70010ABE Old:0x8E8CB520


function NETWORK.NETWORK_CLAN_DOWNLOAD_MEMBERSHIP(gamerHandle)


  return Velora.invoke(0xA52450,"bool", gamerHandle)


end


-- PC:0x5B9E023DC6EBEDC0 Old:0x1FDB590F


function NETWORK.NETWORK_CLAN_DOWNLOAD_MEMBERSHIP_PENDING(p0)


  return Velora.invoke(0xA52480,"bool", p0)


end


-- PC:0xB3F64A6A91432477 Old:0x83ED8E08


function NETWORK.NETWORK_CLAN_ANY_DOWNLOAD_MEMBERSHIP_PENDING()


  return Velora.invoke(0xA524B0,"bool")


end


-- PC:0xBB6E6FEE99D866B2 Old:0x40202867


function NETWORK.NETWORK_CLAN_REMOTE_MEMBERSHIPS_ARE_IN_CACHE()


  return Velora.invoke(0xA52500,"bool")


end


-- PC:0xAAB11F6C4ADBC2C1 Old:0x25924010


function NETWORK.NETWORK_CLAN_GET_MEMBERSHIP_COUNT()


  return Velora.invoke(0xA52530,"int")


end


-- PC:0x48A59CF88D43DF0E Old:0x48914F6A


function NETWORK.NETWORK_CLAN_GET_MEMBERSHIP_VALID(p1)


  return Velora.invoke(0xA52560,"bool", p1)


end


-- PC:0xC8BC2011F67B3411 Old:0xCDC4A590


function NETWORK.NETWORK_CLAN_GET_MEMBERSHIP(clanMembership, p2)


  return Velora.invoke(0xA52590,"bool", clanMembership, p2)


end


-- PC:0x9FAAA4F4FC71F87F Old:0x79C916C5


function NETWORK.NETWORK_CLAN_JOIN(clanDesc)


  return Velora.invoke(0xA525C0,"bool", clanDesc)


end


-- PC:0x729E3401F0430686 Old:0xBDA90BAC


function NETWORK.NETWORK_CLAN_CREWINFO_GET_STRING_VALUE(animDict, animName)


  return Velora.invoke(0xA525F0,"bool", animDict, animName)


end


-- PC:0x2B51EDBEFC301339 Old:0x8E952B12


function NETWORK.NETWORK_CLAN_CREWINFO_GET_CREWRANKTITLE(p0, p1)


  return Velora.invoke(0xA52640,"bool", p0, p1)


end


-- PC:0xC32EA7A2F6CA7557 Old:0x966C90FD


function NETWORK.NETWORK_CLAN_HAS_CREWINFO_METADATA_BEEN_RECEIVED()


  return Velora.invoke(0xA52690,"bool")


end


-- PC:0x5835D9CD92E83184 Old:0xBA672146


function NETWORK.NETWORK_CLAN_GET_EMBLEM_TXD_NAME(netHandle, txdName)


  return Velora.invoke(0xA526D0,"bool", netHandle, txdName)


end


-- PC:0x13518FF1C6B28938 Old:0x7963FA4D


function NETWORK.NETWORK_CLAN_REQUEST_EMBLEM(p0)


  return Velora.invoke(0xA52700,"bool", p0)


end


-- PC:0xA134777FF7F33331 Old:0x88B13CDC


function NETWORK.NETWORK_CLAN_IS_EMBLEM_READY(p0, p1)


  return Velora.invoke(0xA52730,"bool", p0, p1)


end


-- PC:0x113E6E3E50E286B0 Old:0xD6E3D5EA


function NETWORK.NETWORK_CLAN_RELEASE_EMBLEM(p0)


  Velora.invoke(0xA527E0,"void", p0)


end


-- PC:0x9AA46BADAD0E27ED Old:0xE22445DA


function NETWORK.NETWORK_GET_PRIMARY_CLAN_DATA_CLEAR()


  return Velora.invoke(0xA528A0,"bool")


end


-- PC:0x042E4B70B93E6054 Old:0x455DDF5C


function NETWORK.NETWORK_GET_PRIMARY_CLAN_DATA_CANCEL()


  Velora.invoke(0xA528A0,"void")


end


-- PC:0xCE86D8191B762107 Old:0x89DB0EC7


function NETWORK.NETWORK_GET_PRIMARY_CLAN_DATA_START(p0, p1)


  return Velora.invoke(0xA52960,"bool", p0, p1)


end


-- PC:0xB5074DB804E28CE7 Old:0xA4EF02F3


function NETWORK.NETWORK_GET_PRIMARY_CLAN_DATA_PENDING()


  return Velora.invoke(0xA528F0,"bool")


end


-- PC:0x5B4F04F19376A0BA Old:0x068A054E


function NETWORK.NETWORK_GET_PRIMARY_CLAN_DATA_SUCCESS()


  return Velora.invoke(0xA52910,"bool")


end


-- PC:0xC080FF658B2E41DA Old:0x9B8631EB


function NETWORK.NETWORK_GET_PRIMARY_CLAN_DATA_NEW(p0, p1)


  return Velora.invoke(0xA52930,"bool", p0, p1)


end


-- PC:0x299EEB23175895FC Old:0x47C8E5FF


function NETWORK.SET_NETWORK_ID_CAN_MIGRATE(netId, toggle)


  Velora.invoke(0xA52960,"void", netId, toggle)


end


-- PC:0xE05E81A888FA63C8 Old:0x68D486B2


function NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(netId, toggle)


  Velora.invoke(0xA52980,"void", netId, toggle)


end


-- PC:0xA8A024587329F36A Old:0x4D15FDB1


function NETWORK.SET_NETWORK_ID_ALWAYS_EXISTS_FOR_PLAYER(netId, player, toggle)


  Velora.invoke(0xA529A0,"void", netId, player, toggle)


end


function NETWORK.SET_NETWORK_ID_CAN_BE_REASSIGNED(netId, toggle)


  Velora.invoke(0xA529C0,"void", netId, toggle)


end


-- PC:0xD830567D88A1E873 Old:0xDE8C0DB8


function NETWORK.NETWORK_SET_ENTITY_CAN_BLEND(entity, toggle)


  Velora.invoke(0xA529E0,"void", entity, toggle)


end


function NETWORK.NETWORK_SET_OBJECT_CAN_BLEND_WHEN_FIXED(object, toggle)


  Velora.invoke(0xA52A40,"void", object, toggle)


end


-- PC:0xF1CA12B18AEF5298 Old:0x09CBC4B0


function NETWORK.NETWORK_SET_ENTITY_ONLY_EXISTS_FOR_PARTICIPANTS(entity, toggle)


  Velora.invoke(0xA52AB0,"void", entity, toggle)


end


-- PC:0xA6928482543022B4 Old:0x199E75EF


function NETWORK.SET_NETWORK_ID_VISIBLE_IN_CUTSCENE(netId, p1, p2)


  Velora.invoke(0xA52B30,"void", netId, p1, p2)


end


function NETWORK.SET_NETWORK_ID_VISIBLE_IN_CUTSCENE_HACK(netId, p1, p2)


  Velora.invoke(0xA52B50,"void", netId, p1, p2)


end


function NETWORK.SET_NETWORK_ID_VISIBLE_IN_CUTSCENE_REMAIN_HACK(p0, p1)


  Velora.invoke(0xA52B70,"void", p0, p1)


end


-- PC:0xAAA553E7DD28A457 Old:0xFD0F7EDD


function NETWORK.SET_NETWORK_CUTSCENE_ENTITIES(toggle)


  Velora.invoke(0xA52B90,"void", toggle)


end


function NETWORK.ARE_CUTSCENE_ENTITIES_NETWORKED()


  return Velora.invoke(0xA52BC0,"bool")


end


-- PC:0x3FA36981311FA4FF Old:0x00AE4E17


function NETWORK.SET_NETWORK_ID_PASS_CONTROL_IN_TUTORIAL(netId, state)


  Velora.invoke(0xA52BC0,"void", netId, state)


end


-- PC:0xA1607996431332DF Old:0xEA5176C0


function NETWORK.IS_NETWORK_ID_OWNED_BY_PARTICIPANT(netId)


  return Velora.invoke(0xA52C90,"bool", netId)


end


function NETWORK.SET_REMOTE_PLAYER_VISIBLE_IN_CUTSCENE(player, locallyVisible)


  Velora.invoke(0xA52C90,"void", player, locallyVisible)


end


-- PC:0xD1065D68947E7B6E Old:0x59F3479B


function NETWORK.SET_LOCAL_PLAYER_VISIBLE_IN_CUTSCENE(p0, p1)


  Velora.invoke(0xA52D00,"void", p0, p1)


end


-- PC:0xE5F773C1A1D9D168 Old:0x764F6222


function NETWORK.SET_LOCAL_PLAYER_INVISIBLE_LOCALLY(bIncludePlayersVehicle)


  Velora.invoke(0xA52D80,"void", bIncludePlayersVehicle)


end


-- PC:0x7619364C82D3BF14 Old:0x324B56DB


function NETWORK.SET_LOCAL_PLAYER_VISIBLE_LOCALLY(bIncludePlayersVehicle)


  Velora.invoke(0xA52E20,"void", bIncludePlayersVehicle)


end


-- PC:0x12B37D54667DB0B8 Old:0x18227209


function NETWORK.SET_PLAYER_INVISIBLE_LOCALLY(player, bIncludePlayersVehicle)


  Velora.invoke(0xA52EC0,"void", player, bIncludePlayersVehicle)


end


-- PC:0xFAA10F1FAFB11AF2 Old:0xBA2BB4B4


function NETWORK.SET_PLAYER_VISIBLE_LOCALLY(player, bIncludePlayersVehicle)


  Velora.invoke(0xA52F60,"void", player, bIncludePlayersVehicle)


end


-- PC:0x416DBD4CD6ED8DD2 Old:0x8FA7CEBD


function NETWORK.FADE_OUT_LOCAL_PLAYER(p0)


  Velora.invoke(0xA53010,"void", p0)


end


-- PC:0xDE564951F95E09ED Old:0x47EDEE56


function NETWORK.NETWORK_FADE_OUT_ENTITY(entity, normal, slow)


  Velora.invoke(0xA53090,"void", entity, normal, slow)


end


-- PC:0x1F4ED342ACEFE62D Old:0x9B9FCD02


function NETWORK.NETWORK_FADE_IN_ENTITY(entity, state, p2)


  Velora.invoke(0xA530B0,"void", entity, state, p2)


end


-- PC:0x631DC5DFF4B110E3 Old:0x065C597B


function NETWORK.NETWORK_IS_PLAYER_FADING(player)


  return Velora.invoke(0xA53230,"bool", player)


end


-- PC:0x422F32CC7E56ABAD Old:0xB5087ACF


function NETWORK.NETWORK_IS_ENTITY_FADING(entity)


  return Velora.invoke(0xA53150,"bool", entity)


end


-- PC:0xE73092F4157CD126 Old:0xE0A619BD


function NETWORK.IS_PLAYER_IN_CUTSCENE(player)


  return Velora.invoke(0xA531D0,"bool", player)


end


-- PC:0xE0031D3C8F36AB82 Old:0xDBFB067B


function NETWORK.SET_ENTITY_VISIBLE_IN_CUTSCENE(p0, p1, p2)


  Velora.invoke(0xA53230,"void", p0, p1, p2)


end


-- PC:0xE135A9FF3F5D05D8 Old:0x51ADCC5F


function NETWORK.SET_ENTITY_LOCALLY_INVISIBLE(entity)


  Velora.invoke(0xA532E0,"void", entity)


end


-- PC:0x241E289B5C059EDC Old:0x235A57B3


function NETWORK.SET_ENTITY_LOCALLY_VISIBLE(entity)


  Velora.invoke(0xA53340,"void", entity)


end


-- PC:0x6E192E33AD436366 Old:0x597063BA


function NETWORK.IS_DAMAGE_TRACKER_ACTIVE_ON_NETWORK_ID(netID)


  return Velora.invoke(0xA533E0,"bool", netID)


end


-- PC:0xD45B1FFCCD52FF19 Old:0x95D07BA5


function NETWORK.ACTIVATE_DAMAGE_TRACKER_ON_NETWORK_ID(netID, toggle)


  Velora.invoke(0xA533E0,"void", netID, toggle)


end


function NETWORK.IS_DAMAGE_TRACKER_ACTIVE_ON_PLAYER(player)


  return Velora.invoke(0xA53470,"bool", player)


end


function NETWORK.ACTIVATE_DAMAGE_TRACKER_ON_PLAYER(player, toggle)


  Velora.invoke(0xA53470,"void", player, toggle)


end


-- PC:0xD82CF8E64C8729D8 Old:0x23C5274E


function NETWORK.IS_SPHERE_VISIBLE_TO_ANOTHER_MACHINE(p0, p1, p2, p3)


  return Velora.invoke(0xA53650,"bool", p0, p1, p2, p3)


end


-- PC:0xDC3A310219E5DA62 Old:0xE9FCFB32


function NETWORK.IS_SPHERE_VISIBLE_TO_PLAYER(p0, p1, p2, p3, p4)


  return Velora.invoke(0xA53590,"bool", p0, p1, p2, p3, p4)


end


-- PC:0x4E5C93BD0C32FBF8 Old:0x391DF4F3


function NETWORK.RESERVE_NETWORK_MISSION_OBJECTS(amount)


  Velora.invoke(0xA53650,"void", amount)


end


-- PC:0xB60FEBA45333D36F Old:0x54998C37


function NETWORK.RESERVE_NETWORK_MISSION_PEDS(amount)


  Velora.invoke(0xA53660,"void", amount)


end


-- PC:0x76B02E21ED27A469 Old:0x5062875E


function NETWORK.RESERVE_NETWORK_MISSION_VEHICLES(amount)


  Velora.invoke(0xA53670,"void", amount)


end


function NETWORK.RESERVE_LOCAL_NETWORK_MISSION_OBJECTS(amount)


  Velora.invoke(0xA53680,"void", amount)


end


function NETWORK.RESERVE_LOCAL_NETWORK_MISSION_PEDS(amount)


  Velora.invoke(0xA53690,"void", amount)


end


function NETWORK.RESERVE_LOCAL_NETWORK_MISSION_VEHICLES(amount)


  Velora.invoke(0xA536A0,"void", amount)


end


-- PC:0x800DD4721A8B008B Old:0x7F85DFDE


function NETWORK.CAN_REGISTER_MISSION_OBJECTS(amount)


  return Velora.invoke(0xA53DC0,"bool", amount)


end


-- PC:0xBCBF4FEF9FA5D781 Old:0xCCAA5CE9


function NETWORK.CAN_REGISTER_MISSION_PEDS(amount)


  return Velora.invoke(0xA53730,"bool", amount)


end


-- PC:0x7277F1F2E085EE74 Old:0x818B6830


function NETWORK.CAN_REGISTER_MISSION_VEHICLES(amount)


  return Velora.invoke(0xA537B0,"bool", amount)


end


function NETWORK.CAN_REGISTER_MISSION_PICKUPS(amount)


  return Velora.invoke(0xA53850,"bool", amount)


end


function NETWORK.CAN_REGISTER_MISSION_DOORS(p0)


  return Velora.invoke(0xA538D0,"bool", p0)


end


-- PC:0x69778E7564BADE6D Old:0x83794008


function NETWORK.CAN_REGISTER_MISSION_ENTITIES(ped_amt, vehicle_amt, object_amt, pickup_amt)


  return Velora.invoke(0xA53920,"bool", ped_amt, vehicle_amt, object_amt, pickup_amt)


end


-- PC:0xAA81B5F10BC43AC2 Old:0x16A80CD6


function NETWORK.GET_NUM_RESERVED_MISSION_OBJECTS(p0, p1)


  return Velora.invoke(0xA53A00,"int", p0, p1)


end


-- PC:0x1F13D5AE5CB17E17 Old:0x6C25975C


function NETWORK.GET_NUM_RESERVED_MISSION_PEDS(p0, p1)


  return Velora.invoke(0xA53AC0,"int", p0, p1)


end


-- PC:0xCF3A965906452031 Old:0xA9A308F3


function NETWORK.GET_NUM_RESERVED_MISSION_VEHICLES(p0, p1)


  return Velora.invoke(0xA53B80,"int", p0, p1)


end


-- PC:0x12B6281B6C6706C0 Old:0x603FA104


function NETWORK.GET_NUM_CREATED_MISSION_OBJECTS(p0)


  return Velora.invoke(0xA53C40,"int", p0)


end


-- PC:0xCB215C4B56A7FAE7 Old:0xD8FEC4F8


function NETWORK.GET_NUM_CREATED_MISSION_PEDS(p0)


  return Velora.invoke(0xA53CC0,"int", p0)


end


-- PC:0x0CD9AB83489430EA Old:0x20527695


function NETWORK.GET_NUM_CREATED_MISSION_VEHICLES(p0)


  return Velora.invoke(0xA53D40,"int", p0)


end


function NETWORK.GET_RESERVED_MISSION_ENTITIES_IN_AREA(x, y, z, p3, out1, out2, out3)


  Velora.invoke(0xA53DC0,"void", x, y, z, p3, out1, out2, out3)


end


-- PC:0xC7BE335216B5EC7C Old:0x8687E285


function NETWORK.GET_MAX_NUM_NETWORK_OBJECTS()


  return Velora.invoke(0xA53F00,"int")


end


-- PC:0x0C1F7D49C39D2289 Old:0x744AC008


function NETWORK.GET_MAX_NUM_NETWORK_PEDS()


  return Velora.invoke(0xA53ED0,"int")


end


-- PC:0x0AFCE529F69B21FF Old:0xC3A12135


function NETWORK.GET_MAX_NUM_NETWORK_VEHICLES()


  return Velora.invoke(0xA53EE0,"int")


end


-- PC:0xA72835064DD63E4C Old:0x6A036061


function NETWORK.GET_MAX_NUM_NETWORK_PICKUPS()


  return Velora.invoke(0xA53EF0,"int")


end


function NETWORK.NETWORK_SET_OBJECT_SCOPE_DISTANCE(object, range)


  Velora.invoke(0xA53F00,"void", object, range)


end


function NETWORK.NETWORK_ALLOW_CLONING_WHILE_IN_TUTORIAL(p0, p1)


  Velora.invoke(0xA53F60,"void", p0, p1)


end


function NETWORK.NETWORK_SET_TASK_CUTSCENE_INSCOPE_MULTIPLER(p0)


  Velora.invoke(0xA53FE0,"void", p0)


end


-- PC:0x7A5487FE9FAA6B48 Old:0x998103C2


function NETWORK.GET_NETWORK_TIME()


  return Velora.invoke(0xA543E0,"int")


end


-- PC:0x89023FBBF9200E9F Old:0x98AA48E5


function NETWORK.GET_NETWORK_TIME_ACCURATE()


  return Velora.invoke(0xA54130,"int")


end


-- PC:0x46718ACEEDEAFC84 Old:0x4538C4A2


function NETWORK.HAS_NETWORK_TIME_STARTED()


  return Velora.invoke(0xA541C0,"bool")


end


-- PC:0x017008CCDAD48503 Old:0x2E079AE6


function NETWORK.GET_TIME_OFFSET(timeA, timeB)


  return Velora.invoke(0xA541F0,"int", timeA, timeB)


end


-- PC:0xCB2CF5148012C8D0 Old:0x50EF8FC6


function NETWORK.IS_TIME_LESS_THAN(timeA, timeB)


  return Velora.invoke(0xA54200,"bool", timeA, timeB)


end


-- PC:0xDE350F8651E4346C Old:0xBBB6DF61


function NETWORK.IS_TIME_MORE_THAN(timeA, timeB)


  return Velora.invoke(0xA54220,"bool", timeA, timeB)


end


-- PC:0xF5BC95857BD6D512 Old:0x8B4D1C06


function NETWORK.IS_TIME_EQUAL_TO(timeA, timeB)


  return Velora.invoke(0xA54240,"bool", timeA, timeB)


end


-- PC:0xA2C6FC031D46FFF0 Old:0x5666A837


function NETWORK.GET_TIME_DIFFERENCE(timeA, timeB)


  return Velora.invoke(0xA54260,"int", timeA, timeB)


end


-- PC:0x9A73240B49945C76 Old:0xF2FDF2E0


function NETWORK.GET_CLOUD_TIME_AS_INT()


  return Velora.invoke(0xA543C0,"int")


end


-- PC:0xAC97AF97FA68E5D5 Old:0xBB7CCE49


function NETWORK.CONVERT_POSIX_TIME(posixTime, timeStructure)


  Velora.invoke(0xA543E0,"void", posixTime, timeStructure)


end


-- PC:0x423DE3854BB50894 Old:0x5C4C8458


function NETWORK.NETWORK_SET_IN_SPECTATOR_MODE(toggle, playerPed)


  Velora.invoke(0xA54480,"void", toggle, playerPed)


end


-- PC:0x419594E137637120 Old:0x54058F5F


function NETWORK.NETWORK_SET_IN_SPECTATOR_MODE_EXTENDED(toggle, playerPed, p2)


  Velora.invoke(0xA544F0,"void", toggle, playerPed, p2)


end


-- PC:0xFC18DB55AE19E046 Old:0xA7E36020


function NETWORK.NETWORK_SET_IN_FREE_CAM_MODE(toggle)


  Velora.invoke(0xA54560,"void", toggle)


end


-- PC:0x5C707A667DF8B9FA Old:0x64235620


function NETWORK.NETWORK_SET_ANTAGONISTIC_TO_PLAYER(toggle, player)


  Velora.invoke(0xA545B0,"void", toggle, player)


end


-- PC:0x048746E388762E11 Old:0x3EAD9DB8


function NETWORK.NETWORK_IS_IN_SPECTATOR_MODE()


  return Velora.invoke(0xA54620,"bool")


end


-- PC:0x9CA5DE655269FEC4 Old:0x8434CB43


function NETWORK.NETWORK_SET_IN_MP_CUTSCENE(p0, p1)


  Velora.invoke(0xA54620,"void", p0, p1)


end


-- PC:0x6CC27C9FA2040220 Old:0x4BB33316


function NETWORK.NETWORK_IS_IN_MP_CUTSCENE()


  return Velora.invoke(0xA546B0,"bool")


end


-- PC:0x63F9EE203C3619F2 Old:0x56F961E4


function NETWORK.NETWORK_IS_PLAYER_IN_MP_CUTSCENE(player)


  return Velora.invoke(0xA54660,"bool", player)


end


function NETWORK.NETWORK_HIDE_PROJECTILE_IN_CUTSCENE()


  Velora.invoke(0xA546B0,"void")


end


-- PC:0xEC51713AB6EC36E8 Old:0x2C30912D


function NETWORK.SET_NETWORK_VEHICLE_RESPOT_TIMER(netId, time, p2, p3)


  Velora.invoke(0xA546C0,"void", netId, time, p2, p3)


end


function NETWORK.IS_NETWORK_VEHICLE_RUNNING_RESPOT_TIMER(networkID)


  return Velora.invoke(0xA54780,"bool", networkID)


end


-- PC:0x6274C4712850841E Old:0xEA235081


function NETWORK.SET_NETWORK_VEHICLE_AS_GHOST(vehicle, toggle)


  Velora.invoke(0xA54780,"void", vehicle, toggle)


end


function NETWORK.SET_NETWORK_VEHICLE_MAX_POSITION_DELTA_MULTIPLIER(vehicle, multiplier)


  Velora.invoke(0xA547E0,"void", vehicle, multiplier)


end


function NETWORK.SET_NETWORK_ENABLE_HIGH_SPEED_EDGE_FALL_DETECTION(vehicle, toggle)


  Velora.invoke(0xA548B0,"void", vehicle, toggle)


end


function NETWORK.SET_LOCAL_PLAYER_AS_GHOST(toggle, p1)


  Velora.invoke(0xA54970,"void", toggle, p1)


end


function NETWORK.IS_ENTITY_A_GHOST(entity)


  return Velora.invoke(0xA54A00,"bool", entity)


end


function NETWORK.SET_NON_PARTICIPANTS_OF_THIS_SCRIPT_AS_GHOSTS(p0)


  Velora.invoke(0xA54A00,"void", p0)


end


function NETWORK.SET_REMOTE_PLAYER_AS_GHOST(player, p1)


  Velora.invoke(0xA54A70,"void", player, p1)


end


function NETWORK.SET_GHOST_ALPHA(alpha)


  Velora.invoke(0xA54B20,"void", alpha)


end


function NETWORK.RESET_GHOST_ALPHA()


  Velora.invoke(0xA54BB0,"void")


end


function NETWORK.SET_ENTITY_GHOSTED_FOR_GHOST_PLAYERS(entity, toggle)


  Velora.invoke(0xA54BC0,"void", entity, toggle)


end


function NETWORK.SET_INVERT_GHOSTING(p0)


  Velora.invoke(0xA54C30,"void", p0)


end


function NETWORK.IS_ENTITY_IN_GHOST_COLLISION(entity)


  return Velora.invoke(0xA54DF0,"bool", entity)


end


-- PC:0x77758139EC9B66C7 Old:0x4DD46DAE


function NETWORK.USE_PLAYER_COLOUR_INSTEAD_OF_TEAM_COLOUR(toggle)


  Velora.invoke(0xA54DF0,"void", toggle)


end


-- PC:0x7CD6BC4C2BBDD526 Old:0xB06FE3FE


function NETWORK.NETWORK_CREATE_SYNCHRONISED_SCENE(x, y, z, xRot, yRot, zRot, rotationOrder, useOcclusionPortal, looped, p9, animTime, p11)


  return Velora.invoke(0xA54E60,"int", x, y, z, xRot, yRot, zRot, rotationOrder, useOcclusionPortal, looped, p9, animTime, p11)


end


-- PC:0x742A637471BCECD9 Old:0xB386713E


function NETWORK.NETWORK_ADD_PED_TO_SYNCHRONISED_SCENE(ped, netScene, animDict, animnName, speed, speedMultiplier, duration, flag, playbackRate, p9)


  Velora.invoke(0xA54E60,"void", ped, netScene, animDict, animnName, speed, speedMultiplier, duration, flag, playbackRate, p9)


end


function NETWORK.NETWORK_ADD_PED_TO_SYNCHRONISED_SCENE_WITH_IK(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)


  Velora.invoke(0xA54F40,"void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)


end


-- PC:0xF2404D68CBC855FA Old:0x10DD636C


function NETWORK.NETWORK_ADD_ENTITY_TO_SYNCHRONISED_SCENE(entity, netScene, animDict, animName, speed, speedMulitiplier, flag)


  Velora.invoke(0xA55020,"void", entity, netScene, animDict, animName, speed, speedMulitiplier, flag)


end


function NETWORK.NETWORK_ADD_MAP_ENTITY_TO_SYNCHRONISED_SCENE(netScene, modelHash, x, y, z, p5, p6, p7, p8, flags)


  Velora.invoke(0xA550E0,"void", netScene, modelHash, x, y, z, p5, p6, p7, p8, flags)


end


-- PC:0xCF8BD3B0BD6D42D7 Old:0xBFFE8B5C


function NETWORK.NETWORK_ADD_SYNCHRONISED_SCENE_CAMERA(netScene, animDict, animName)


  Velora.invoke(0xA55160,"void", netScene, animDict, animName)


end


-- PC:0x478DCBD2A98B705A Old:0x3FE5B222


function NETWORK.NETWORK_ATTACH_SYNCHRONISED_SCENE_TO_ENTITY(netScene, entity, bone)


  Velora.invoke(0xA551E0,"void", netScene, entity, bone)


end


-- PC:0x9A1B3FCDB36C8697 Old:0xA9DFDC40


function NETWORK.NETWORK_START_SYNCHRONISED_SCENE(netScene)


  Velora.invoke(0xA552A0,"void", netScene)


end


-- PC:0xC254481A4574CB2F Old:0x97B1CDF6


function NETWORK.NETWORK_STOP_SYNCHRONISED_SCENE(netScene)


  Velora.invoke(0xA55310,"void", netScene)


end


-- PC:0x02C40BF885C567B6 Old:0x16AED87B


function NETWORK.NETWORK_GET_LOCAL_SCENE_FROM_NETWORK_ID(netId)


  return Velora.invoke(0xA553C0,"int", netId)


end


-- PC:0xC9B43A33D09CADA7 Old:0xC3AA2EC7


function NETWORK.NETWORK_FORCE_LOCAL_USE_OF_SYNCED_SCENE_CAMERA(netScene)


  Velora.invoke(0xA553C0,"void", netScene)


end


function NETWORK.NETWORK_ALLOW_REMOTE_SYNCED_SCENE_LOCAL_PLAYER_REQUESTS(p0)


  Velora.invoke(0xA55430,"void", p0)


end


-- PC:0xFB1F9381E80FA13F Old:0x0679CE71


function NETWORK.NETWORK_FIND_LARGEST_BUNCH_OF_PLAYERS(p0, p1)


  return Velora.invoke(0xA555B0,"bool", p0, p1)


end


-- PC:0x5A6FFA2433E2F14C Old:0xC62E77B3


function NETWORK.NETWORK_START_RESPAWN_SEARCH_FOR_PLAYER(player, x, y, z, radius, p5, p6, p7, flags)


  return Velora.invoke(0xA554D0,"bool", player, x, y, z, radius, p5, p6, p7, flags)


end


-- PC:0x4BA92A18502BCA61 Old:0x74D6B13C


function NETWORK.NETWORK_START_RESPAWN_SEARCH_IN_ANGLED_AREA_FOR_PLAYER(player, x1, y1, z1, x2, y2, z2, width, p8, p9, p10, flags)


  return Velora.invoke(0xA55510,"bool", player, x1, y1, z1, x2, y2, z2, width, p8, p9, p10, flags)


end


-- PC:0x3C891A251567DFCE Old:0x90700C7D


function NETWORK.NETWORK_QUERY_RESPAWN_RESULTS(p0)


  return Velora.invoke(0xA55550,"int", p0)


end


-- PC:0xFB8F2A6F3DF08CBE Old:0x44BFB619


function NETWORK.NETWORK_CANCEL_RESPAWN_SEARCH()


  Velora.invoke(0xA555B0,"void")


end


-- PC:0x371EA43692861CF1 Old:0xDDFE9FBC


function NETWORK.NETWORK_GET_RESPAWN_RESULT(randomInt)


  Velora.invoke(0xA555C0,"void", randomInt)


end


-- PC:0x6C34F1208B8923FD Old:0x03287FD2


function NETWORK.NETWORK_GET_RESPAWN_RESULT_FLAGS(p0)


  return Velora.invoke(0xA55650,"int", p0)


end


-- PC:0x17E0198B3882C2CB Old:0x408A9436


function NETWORK.NETWORK_START_SOLO_TUTORIAL_SESSION()


  Velora.invoke(0xA55650,"void")


end


-- PC:0xFB680D403909DC70 Old:0xFFB2ADA1


function NETWORK.NETWORK_ALLOW_GANG_TO_JOIN_TUTORIAL_SESSION(teamId, instanceId)


  Velora.invoke(0xA55680,"void", teamId, instanceId)


end


-- PC:0xD0AFAFF5A51D72F7 Old:0xBA57E53E


function NETWORK.NETWORK_END_TUTORIAL_SESSION()


  Velora.invoke(0xA556D0,"void")


end


-- PC:0xADA24309FE08DACF Old:0x34DD7B28


function NETWORK.NETWORK_IS_IN_TUTORIAL_SESSION()


  return Velora.invoke(0xA55870,"bool")


end


-- PC:0xB37E4E6A2388CA7B Old:0x755A2B3E


function NETWORK.NETWORK_WAITING_POP_CLEAR_TUTORIAL_SESSION()


  return Velora.invoke(0xA55740,"bool")


end


-- PC:0x35F0B98A8387274D Old:0xA003C40B


function NETWORK.NETWORK_IS_TUTORIAL_SESSION_CHANGE_PENDING()


  return Velora.invoke(0xA55780,"bool")


end


-- PC:0x3B39236746714134 Old:0x5E1020CC


function NETWORK.NETWORK_GET_PLAYER_TUTORIAL_SESSION_INSTANCE(player)


  return Velora.invoke(0xA557C0,"int", player)


end


-- PC:0x9DE986FC9A87C474 Old:0xE66A0B40


function NETWORK.NETWORK_ARE_PLAYERS_IN_SAME_TUTORIAL_SESSION(player, index)


  return Velora.invoke(0xA55810,"bool", player, index)


end


function NETWORK.NETWORK_BLOCK_PROXY_MIGRATION_BETWEEN_TUTORIAL_SESSIONS(p0)


  Velora.invoke(0xA55870,"void", p0)


end


-- PC:0xBBDF066252829606 Old:0x72052DB3


function NETWORK.NETWORK_CONCEAL_PLAYER(player, toggle, p2)


  Velora.invoke(0xA558A0,"void", player, toggle, p2)


end


-- PC:0x919B3C98ED8292F9 Old:0xB0313590


function NETWORK.NETWORK_IS_PLAYER_CONCEALED(player)


  return Velora.invoke(0xA55940,"bool", player)


end


function NETWORK.NETWORK_CONCEAL_ENTITY(entity, toggle)


  Velora.invoke(0xA55940,"void", entity, toggle)


end


function NETWORK.NETWORK_IS_ENTITY_CONCEALED(entity)


  return Velora.invoke(0xA55A20,"bool", entity)


end


-- PC:0xE679E3E06E363892 Old:0xC077BCD6


function NETWORK.NETWORK_OVERRIDE_CLOCK_TIME(hours, minutes, seconds)


  Velora.invoke(0xA55A20,"void", hours, minutes, seconds)


end


function NETWORK.NETWORK_OVERRIDE_CLOCK_RATE(ms)


  Velora.invoke(0xA55A40,"void", ms)


end


-- PC:0xD972DF67326F966E Old:0xC4AEAF49


function NETWORK.NETWORK_CLEAR_CLOCK_TIME_OVERRIDE()


  Velora.invoke(0xA55A50,"void")


end


-- PC:0xD7C95D322FF57522 Old:0x2465296D


function NETWORK.NETWORK_IS_CLOCK_TIME_OVERRIDDEN()


  return Velora.invoke(0xA55D40,"bool")


end


-- PC:0x494C8FB299290269 Old:0x51030E5B


function NETWORK.NETWORK_ADD_ENTITY_AREA(x1, y1, z1, x2, y2, z2)


  return Velora.invoke(0xA55AF0,"int", x1, y1, z1, x2, y2, z2)


end


-- PC:0x376C6375BA60293A Old:0xCD69BEA1


function NETWORK.NETWORK_ADD_ENTITY_ANGLED_AREA(x1, y1, z1, x2, y2, z2, width)


  return Velora.invoke(0xA55B20,"int", x1, y1, z1, x2, y2, z2, width)


end


-- PC:0x25B99872D588A101 Old:0x4C2C2B12


function NETWORK.NETWORK_ADD_CLIENT_ENTITY_AREA(x1, y1, z1, x2, y2, z2)


  return Velora.invoke(0xA55B50,"int", x1, y1, z1, x2, y2, z2)


end


function NETWORK.NETWORK_ADD_CLIENT_ENTITY_ANGLED_AREA(x1, y1, z1, x2, y2, z2, radius)


  return Velora.invoke(0xA55B80,"int", x1, y1, z1, x2, y2, z2, radius)


end


-- PC:0x93CF869BAA0C4874 Old:0xEAB97F25


function NETWORK.NETWORK_REMOVE_ENTITY_AREA(areaHandle)


  return Velora.invoke(0xA55BB0,"bool", areaHandle)


end


-- PC:0xE64A3CA08DFA37A9 Old:0x69956127


function NETWORK.NETWORK_ENTITY_AREA_DOES_EXIST(areaHandle)


  return Velora.invoke(0xA55CB0,"bool", areaHandle)


end


-- PC:0x4DF7CFFF471A7FB1 Old:0xCB1CD6D3


function NETWORK.NETWORK_ENTITY_AREA_HAVE_ALL_REPLIED(areaHandle)


  return Velora.invoke(0xA55CE0,"bool", areaHandle)


end


-- PC:0x4A2D4E8BF4265B0F Old:0xC6D53AA0


function NETWORK.NETWORK_ENTITY_AREA_IS_OCCUPIED(areaHandle)


  return Velora.invoke(0xA55D10,"bool", areaHandle)


end


-- PC:0x2B1813ABA29016C5 Old:0x155465EE


function NETWORK.NETWORK_USE_HIGH_PRECISION_BLENDING(netID, toggle)


  Velora.invoke(0xA55D40,"void", netID, toggle)


end


function NETWORK.NETWORK_SET_CUSTOM_ARENA_BALL_PARAMS(netId)


  Velora.invoke(0xA55DA0,"void", netId)


end


function NETWORK.NETWORK_ENTITY_USE_HIGH_PRECISION_ROTATION(netId, toggle)


  Velora.invoke(0xA55E00,"void", netId, toggle)


end


-- PC:0x924426BFFD82E915 Old:0x98EFB921


function NETWORK.NETWORK_REQUEST_CLOUD_BACKGROUND_SCRIPTS()


  return Velora.invoke(0xA55EC0,"bool")


end


-- PC:0x8132C0EB8B2B3293 Old:0x20AB933A


function NETWORK.NETWORK_IS_CLOUD_BACKGROUND_SCRIPT_REQUEST_PENDING()


  return Velora.invoke(0xA55E90,"bool")


end


-- PC:0x42FB3B532D526E6C Old:0xD760CAD5


function NETWORK.NETWORK_REQUEST_CLOUD_TUNABLES()


  Velora.invoke(0xA55EC0,"void")


end


-- PC:0x0467C11ED88B7D28 Old:0x47978D7F


function NETWORK.NETWORK_IS_TUNABLE_CLOUD_REQUEST_PENDING()


  return Velora.invoke(0xA56700,"bool")


end


-- PC:0x10BD227A753B0D84 Old:0x231CFD12


function NETWORK.NETWORK_GET_TUNABLE_CLOUD_CRC()


  return Velora.invoke(0xA55F00,"int")


end


-- PC:0x85E5F8B9B898B20A Old:0x9FCE9C9A


function NETWORK.NETWORK_DOES_TUNABLE_EXIST(tunableContext, tunableName)


  return Velora.invoke(0xA561B0,"bool", tunableContext, tunableName)


end


-- PC:0x8BE1146DFD5D4468 Old:0xE4B3726A


function NETWORK.NETWORK_ACCESS_TUNABLE_INT(tunableContext, tunableName)


  return Velora.invoke(0xA56220,"bool", tunableContext, tunableName)


end


-- PC:0xE5608CA7BC163A5F Old:0x41E8912A


function NETWORK.NETWORK_ACCESS_TUNABLE_FLOAT(tunableContext, tunableName)


  return Velora.invoke(0xA562A0,"bool", tunableContext, tunableName)


end


-- PC:0xAA6A47A573ABB75A Old:0x8A04E1FE


function NETWORK.NETWORK_ACCESS_TUNABLE_BOOL(tunableContext, tunableName)


  return Velora.invoke(0xA56320,"bool", tunableContext, tunableName)


end


-- PC:0xE4E53E1419D81127 Old:0x25915CB9


function NETWORK.NETWORK_DOES_TUNABLE_EXIST_HASH(tunableContext, tunableName)


  return Velora.invoke(0xA563C0,"bool", tunableContext, tunableName)


end


function NETWORK.NETWORK_ACCESS_TUNABLE_MODIFICATION_DETECTION_CLEAR()


  return Velora.invoke(0xA56410,"bool")


end


-- PC:0x40FCE03E50E8DBE8 Old:0xB2E83B75


function NETWORK.NETWORK_ACCESS_TUNABLE_INT_HASH(tunableContext, tunableName)


  return Velora.invoke(0xA56440,"bool", tunableContext, tunableName)


end


function NETWORK.NETWORK_ACCESS_TUNABLE_INT_MODIFICATION_DETECTION_REGISTRATION_HASH(contextHash, nameHash)


  return Velora.invoke(0xA564A0,"bool", contextHash, nameHash)


end


-- PC:0x972BC203BBC4C4D5 Old:0x3972551F


function NETWORK.NETWORK_ACCESS_TUNABLE_FLOAT_HASH(tunableContext, tunableName)


  return Velora.invoke(0xA564E0,"bool", tunableContext, tunableName)


end


function NETWORK.NETWORK_ACCESS_TUNABLE_FLOAT_MODIFICATION_DETECTION_REGISTRATION_HASH(contextHash, nameHash)


  return Velora.invoke(0xA56540,"bool", contextHash, nameHash)


end


-- PC:0xEA16B69D93D71A45 Old:0x18867C61


function NETWORK.NETWORK_ACCESS_TUNABLE_BOOL_HASH(tunableContext, tunableName)


  return Velora.invoke(0xA56580,"bool", tunableContext, tunableName)


end


function NETWORK.NETWORK_ACCESS_TUNABLE_BOOL_MODIFICATION_DETECTION_REGISTRATION_HASH(contextHash, nameHash)


  return Velora.invoke(0xA56600,"bool", contextHash, nameHash)


end


-- PC:0xC7420099936CE286 Old:0x8AFE3D90


function NETWORK.NETWORK_TRY_ACCESS_TUNABLE_BOOL_HASH(tunableContext, tunableName, defaultValue)


  return Velora.invoke(0xA56640,"bool", tunableContext, tunableName, defaultValue)


end


-- PC:0x187382F8A3E0A6C3 Old:0xA78571CA


function NETWORK.NETWORK_GET_CONTENT_MODIFIER_LIST_ID(contentHash)


  return Velora.invoke(0xA566A0,"int", contentHash)


end


-- PC:0x7DB53B37A2F211A0 Old:0x053BB329


function NETWORK.NETWORK_GET_BONE_ID_OF_FATAL_HIT()


  return Velora.invoke(0xA566D0,"int")


end


-- PC:0x72433699B4E6DD64 Old:0x3914463F


function NETWORK.NETWORK_RESET_BODY_TRACKER()


  Velora.invoke(0xA56700,"void")


end


-- PC:0xD38C4A6D047C019D Old:0x17CBC608


function NETWORK.NETWORK_GET_NUMBER_BODY_TRACKER_HITS()


  return Velora.invoke(0xA568A0,"int")


end


-- PC:0x2E0BF682CC778D49 Old:0xBFAA349B


function NETWORK.NETWORK_HAS_BONE_BEEN_HIT_BY_KILLER(boneIndex)


  return Velora.invoke(0xA56750,"bool", boneIndex)


end


-- PC:0x0EDE326D47CD0F3E Old:0xBEB7281A


function NETWORK.NETWORK_SET_ATTRIBUTE_DAMAGE_TO_PLAYER(ped, player)


  return Velora.invoke(0xA567E0,"bool", ped, player)


end


function NETWORK.NETWORK_TRIGGER_DAMAGE_EVENT_FOR_ZERO_DAMAGE(entity, toggle)


  Velora.invoke(0xA568A0,"void", entity, toggle)


end


function NETWORK.NETWORK_TRIGGER_DAMAGE_EVENT_FOR_ZERO_WEAPON_HASH(entity, toggle)


  Velora.invoke(0xA56980,"void", entity, toggle)


end


function NETWORK.NETWORK_SET_NO_LONGER_NEEDED(entity, toggle)


  Velora.invoke(0xA569F0,"void", entity, toggle)


end


-- PC:0x301A42153C9AD707 Old:0x0E1B38AE


function NETWORK.NETWORK_EXPLODE_VEHICLE(vehicle, isAudible, isInvisible, netId)


  return Velora.invoke(0xA56A30,"bool", vehicle, isAudible, isInvisible, netId)


end


-- PC:0x2A5E0621DD815A9A Old:0x955B31BF


function NETWORK.NETWORK_EXPLODE_HELI(vehicle, isAudible, isInvisible, netId)


  Velora.invoke(0xA56A30,"void", vehicle, isAudible, isInvisible, netId)


end


-- PC:0xCD71A4ECAB22709E Old:0xBC54371B


function NETWORK.NETWORK_USE_LOGARITHMIC_BLENDING_THIS_FRAME(entity)


  Velora.invoke(0xA56A60,"void", entity)


end


-- PC:0xA7E30DE9272B6D49 Old:0x644141C5


function NETWORK.NETWORK_OVERRIDE_COORDS_AND_HEADING(entity, x, y, z, heading)


  Velora.invoke(0xA56AC0,"void", entity, x, y, z, heading)


end


function NETWORK.NETWORK_ENABLE_EXTRA_VEHICLE_ORIENTATION_BLEND_CHECKS(netId, toggle)


  Velora.invoke(0xA56BA0,"void", netId, toggle)


end


-- PC:0x407091CF6037118E Old:0x9F82917F


function NETWORK.NETWORK_DISABLE_PROXIMITY_MIGRATION(netID)


  Velora.invoke(0xA56C20,"void", netID)


end


-- PC:0x1775961C2FBBCB5C Old:0x5A74E873


function NETWORK.NETWORK_SET_PROPERTY_ID(id)


  Velora.invoke(0xDEADBEEF,"void", id)


end


-- PC:0xC2B82527CA77053E Old:0x38BC35C8


function NETWORK.NETWORK_CLEAR_PROPERTY_ID()


  Velora.invoke(0xDEADBEEF,"void")


end


-- PC:0x367EF5E2F439B4C6 Old:0x53C9563C


function NETWORK.NETWORK_SET_PLAYER_MENTAL_STATE(p0)


  Velora.invoke(0xA56C70,"void", p0)


end


-- PC:0x94538037EE44F5CF Old:0x6B97075B


function NETWORK.NETWORK_SET_MINIMUM_RANK_FOR_MISSION(p0)


  Velora.invoke(0xA56CB0,"void", p0)


end


-- PC:0xBD0BE0BFC927EAC1 Old:0x94AB35A9


function NETWORK.NETWORK_CACHE_LOCAL_PLAYER_HEAD_BLEND_DATA()


  Velora.invoke(0xA56CD0,"void")


end


-- PC:0x237D5336A9A54108 Old:0x7B2A0337


function NETWORK.NETWORK_HAS_CACHED_PLAYER_HEAD_BLEND_DATA(player)


  return Velora.invoke(0xA56E10,"bool", player)


end


-- PC:0x99B72C7ABDE5C910 Old:0x99F58A07


function NETWORK.NETWORK_APPLY_CACHED_PLAYER_HEAD_BLEND_DATA(ped, player)


  return Velora.invoke(0xA56D20,"bool", ped, player)


end


-- PC:0xF2EAC213D5EA0623 Old:0x965EA007


function NETWORK.GET_NUM_COMMERCE_ITEMS()


  return Velora.invoke(0xA56DD0,"int")


end


-- PC:0xEA14EEF5B7CD2C30 Old:0xEEFC8A55


function NETWORK.IS_COMMERCE_DATA_VALID()


  return Velora.invoke(0xA56DF0,"bool")


end


-- PC:0xB606E6CC59664972 Old:0x866D1B67


function NETWORK.TRIGGER_COMMERCE_DATA_FETCH(p0)


  Velora.invoke(0xA56E10,"void", p0)


end


-- PC:0x1D4DC17C38FEAFF0 Old:0xED4A272F


function NETWORK.IS_COMMERCE_DATA_FETCH_IN_PROGRESS()


  return Velora.invoke(0xA57080,"bool")


end


-- PC:0x2A7776C709904AB0 Old:0x1CF89DA5


function NETWORK.GET_COMMERCE_ITEM_NUM_CATS(index)


  return Velora.invoke(0xA56FA0,"int", index)


end


-- PC:0x58C21165F6545892 Old:0x365C50EE


function NETWORK.OPEN_COMMERCE_STORE(p0, p1, p2)


  Velora.invoke(0xA57080,"void", p0, p1, p2)


end


-- PC:0x2EAC52B4019E2782 Old:0x25E2DBA9


function NETWORK.IS_COMMERCE_STORE_OPEN()


  return Velora.invoke(0xA570C0,"bool")


end


-- PC:0x9641A9FF718E9C5E Old:0xC1F6443B


function NETWORK.SET_STORE_ENABLED(toggle)


  Velora.invoke(0xA570C0,"void", toggle)


end


-- PC:0xA2F952104FC6DD4B Old:0x1FDC75DC


function NETWORK.REQUEST_COMMERCE_ITEM_IMAGE(index)


  return Velora.invoke(0xA57110,"bool", index)


end


-- PC:0x72D0706CD6CCDB58 Old:0xCA7A0A49


function NETWORK.RELEASE_ALL_COMMERCE_ITEM_IMAGES()


  Velora.invoke(0xA57110,"void")


end


-- PC:0x883D79C4071E18B3 Old:0xD32FA11F


function NETWORK.IS_STORE_AVAILABLE_TO_USER()


  return Velora.invoke(0xA57190,"bool")


end


-- PC:0x265635150FB0D82E Old:0xA7FA70AE


function NETWORK.DELAY_MP_STORE_OPEN()


  Velora.invoke(0xA571E0,"void")


end


-- PC:0x444C4525ECE0A4B9 Old:0xCC7DCE24


function NETWORK.RESET_STORE_NETWORK_GAME_TRACKING()


  Velora.invoke(0xA571F0,"void")


end


-- PC:0x59328EB08C5CEB2B Old:0x70F6D3AD


function NETWORK.IS_USER_OLD_ENOUGH_TO_ACCESS_STORE()


  return Velora.invoke(0xA57240,"bool")


end


-- PC:0xFAE628F1E9ADB239 Old:0xD59A822B


function NETWORK.SET_LAST_VIEWED_SHOP_ITEM(p0, p1, p2)


  Velora.invoke(0xA57240,"void", p0, p1, p2)


end


function NETWORK.GET_USER_PREMIUM_ACCESS()


  return Velora.invoke(0xA57380,"int")


end


function NETWORK.GET_USER_STARTER_ACCESS()


  return Velora.invoke(0xA57290,"int")


end


-- PC:0xC64DED7EF0D2FE37 Old:0x2B7B57B3


function NETWORK.CLOUD_DELETE_MEMBER_FILE(p0)


  return Velora.invoke(0xA572C0,"int", p0)


end


-- PC:0x4C61B39930D045DA Old:0xBAF52DD8


function NETWORK.CLOUD_HAS_REQUEST_COMPLETED(requestId)


  return Velora.invoke(0xA57320,"bool", requestId)


end


-- PC:0x3A3D5568AF297CD5 Old:0x9B9AFFF1


function NETWORK.CLOUD_DID_REQUEST_SUCCEED(requestId)


  return Velora.invoke(0xA57350,"bool", requestId)


end


-- PC:0x4F18196C8D38768D Old:0xC38E9DB0


function NETWORK.CLOUD_CHECK_AVAILABILITY()


  Velora.invoke(0xA57380,"void")


end


-- PC:0xC7ABAC5DE675EE3B Old:0x32A4EB22


function NETWORK.CLOUD_IS_CHECKING_AVAILABILITY()


  return Velora.invoke(0xA57580,"bool")


end


-- PC:0x0B0CC10720653F3B Old:0x9262744C


function NETWORK.CLOUD_GET_AVAILABILITY_CHECK_RESULT()


  return Velora.invoke(0xA573B0,"bool")


end


function NETWORK.GET_CONTENT_TO_LOAD_TYPE()


  return Velora.invoke(0xA573E0,"int")


end


function NETWORK.GET_IS_LAUNCH_FROM_LIVE_AREA()


  return Velora.invoke(0xA574E0,"bool")


end


function NETWORK.GET_IS_LIVE_AREA_LAUNCH_WITH_CONTENT()


  return Velora.invoke(0xA57520,"bool")


end


function NETWORK.CLEAR_SERVICE_EVENT_ARGUMENTS()


  Velora.invoke(0xA57580,"void")


end


-- PC:0x152D90E4C1B4738A Old:0x08243B79


function NETWORK.UGC_COPY_CONTENT(p0, p1)


  return Velora.invoke(0xA576D0,"bool", p0, p1)


end


-- PC:0x9FEDF86898F100E9 Old:0x798D6C27


function NETWORK.UGC_IS_CREATING()


  return Velora.invoke(0xA575E0,"bool")


end


-- PC:0x5E24341A7F92A74B Old:0xE69E8D0D


function NETWORK.UGC_HAS_CREATE_FINISHED()


  return Velora.invoke(0xA57610,"bool")


end


-- PC:0x24E4E51FC16305F9 Old:0x742075FE


function NETWORK.UGC_DID_CREATE_SUCCEED()


  return Velora.invoke(0xA57640,"bool")


end


-- PC:0xFBC5E768C7A77A6A Old:0xCE569932


function NETWORK.UGC_GET_CREATE_RESULT()


  return Velora.invoke(0xA57670,"int")


end


-- PC:0x17440AA15D1D3739 Old:0x133FF2D5


function NETWORK.UGC_CLEAR_CREATE_RESULT()


  Velora.invoke(0xA576D0,"void")


end


-- PC:0x9BF438815F5D96EA Old:0xCBA7242F


function NETWORK.UGC_QUERY_MY_CONTENT(p0, p1, p2, p3, p4, p5)


  return Velora.invoke(0xA58020,"bool", p0, p1, p2, p3, p4, p5)


end


function NETWORK.UGC_QUERY_BY_CATEGORY(p0, p1, p2, p3, p4, p5)


  return Velora.invoke(0xA577B0,"bool", p0, p1, p2, p3, p4, p5)


end


-- PC:0x158EC424F35EC469 Old:0xDED82A6E


function NETWORK.UGC_QUERY_BY_CONTENT_ID(contentId, latestVersion, contentTypeName)


  return Velora.invoke(0xA57840,"bool", contentId, latestVersion, contentTypeName)


end


-- PC:0xC7397A83F7A2A462 Old:0x47B3C35E


function NETWORK.UGC_QUERY_BY_CONTENT_IDS(data, count, latestVersion, contentTypeName)


  return Velora.invoke(0xA57900,"bool", data, count, latestVersion, contentTypeName)


end


-- PC:0x6D4CB481FAC835E8 Old:0x40CF0783


function NETWORK.UGC_QUERY_MOST_RECENTLY_CREATED_CONTENT(offset, count, contentTypeName, p3)


  return Velora.invoke(0xA57A20,"bool", offset, count, contentTypeName, p3)


end


-- PC:0xD5A4B59980401588 Old:0x4609D596


function NETWORK.UGC_GET_BOOKMARKED_CONTENT(p0, p1, p2, p3)


  return Velora.invoke(0xA57AC0,"bool", p0, p1, p2, p3)


end


-- PC:0x3195F8DD0D531052 Old:0x4C2C0D1F


function NETWORK.UGC_GET_MY_CONTENT(p0, p1, p2, p3)


  return Velora.invoke(0xA57B20,"bool", p0, p1, p2, p3)


end


-- PC:0xF9E1CCAE8BA4C281 Old:0x9EFBD5D1


function NETWORK.UGC_GET_FRIEND_CONTENT(p0, p1, p2, p3)


  return Velora.invoke(0xA57B90,"bool", p0, p1, p2, p3)


end


-- PC:0x9F6E2821885CAEE2 Old:0xA6D8B798


function NETWORK.UGC_GET_CREW_CONTENT(p0, p1, p2, p3, p4)


  return Velora.invoke(0xA57BF0,"bool", p0, p1, p2, p3, p4)


end


-- PC:0x678BB03C1A3BD51E Old:0x67E74842


function NETWORK.UGC_GET_GET_BY_CATEGORY(p0, p1, p2, p3, p4)


  return Velora.invoke(0xA57C50,"bool", p0, p1, p2, p3, p4)


end


-- PC:0x815E5E3073DA1D67 Old:0xE123C7AC


function NETWORK.UGC_GET_GET_BY_CONTENT_ID(contentId, contentTypeName)


  return Velora.invoke(0xA57CD0,"bool", contentId, contentTypeName)


end


-- PC:0xB8322EEB38BE7C26 Old:0x22C33603


function NETWORK.UGC_GET_GET_BY_CONTENT_IDS(data, dataCount, contentTypeName)


  return Velora.invoke(0xA57D80,"bool", data, dataCount, contentTypeName)


end


-- PC:0xA7862BC5ED1DFD7E Old:0x37F5BD93


function NETWORK.UGC_GET_MOST_RECENTLY_CREATED_CONTENT(p0, p1, p2, p3)


  return Velora.invoke(0xA57EA0,"bool", p0, p1, p2, p3)


end


-- PC:0x97A770BEEF227E2B Old:0x1CFB3F51


function NETWORK.UGC_GET_MOST_RECENTLY_PLAYED_CONTENT(p0, p1, p2, p3)


  return Velora.invoke(0xA57F00,"bool", p0, p1, p2, p3)


end


-- PC:0x5324A0E3E4CE3570 Old:0x87D1E6BD


function NETWORK.UGC_GET_TOP_RATED_CONTENT(p0, p1, p2, p3)


  return Velora.invoke(0xA57F60,"bool", p0, p1, p2, p3)


end


-- PC:0xE9B99B6853181409 Old:0x021D5A94


function NETWORK.UGC_CANCEL_QUERY()


  Velora.invoke(0xA58020,"void")


end


-- PC:0xD53ACDBEF24A46E8 Old:0x4908A514


function NETWORK.UGC_IS_GETTING()


  return Velora.invoke(0xA581B0,"bool")


end


-- PC:0x02ADA21EA2F6918F Old:0x50296140


function NETWORK.UGC_HAS_GET_FINISHED()


  return Velora.invoke(0xA58060,"bool")


end


-- PC:0x941E5306BCD7C2C7 Old:0x3970B0DA


function NETWORK.UGC_DID_GET_SUCCEED()


  return Velora.invoke(0xA58090,"bool")


end


-- PC:0xC87E740D9F3872CC Old:0xC1487110


function NETWORK.UGC_WAS_QUERY_FORCE_CANCELLED()


  return Velora.invoke(0xA580C0,"bool")


end


-- PC:0xEDF7F927136C224B Old:0xCC2356E3


function NETWORK.UGC_GET_QUERY_RESULT()


  return Velora.invoke(0xA580F0,"int")


end


-- PC:0xE0A6138401BCB837 Old:0x2DE69817


function NETWORK.UGC_GET_CONTENT_NUM()


  return Velora.invoke(0xA58120,"int")


end


-- PC:0x769951E2455E2EB5 Old:0x81BD8D3B


function NETWORK.UGC_GET_CONTENT_TOTAL()


  return Velora.invoke(0xA58150,"int")


end


-- PC:0x3A17A27D75C74887 Old:0x8E1D8F78


function NETWORK.UGC_GET_CONTENT_HASH()


  return Velora.invoke(0xA58180,"int")


end


-- PC:0xBA96394A0EECFA65 Old:0x0D35DD93


function NETWORK.UGC_CLEAR_QUERY_RESULTS()


  Velora.invoke(0xA581B0,"void")


end


function NETWORK.UGC_GET_CONTENT_CREATOR_GAMER_HANDLE(p0, p1)


  return Velora.invoke(0xA581F0,"bool", p0, p1)


end


function NETWORK.UGC_GET_CONTENT_CREATED_BY_LOCAL_PLAYER(p0)


  return Velora.invoke(0xA58280,"bool", p0)


end


-- PC:0xAEAB987727C5A8A4 Old:0x9FEEAA9C


function NETWORK.UGC_GET_CONTENT_IS_USING_SC_NICKNAME(p0)


  return Velora.invoke(0xA582E0,"bool", p0)


end


-- PC:0xA7BAB11E7C9C6C5A Old:0x5E8A7559


function NETWORK.UGC_GET_CONTENT_CATEGORY(p0)


  return Velora.invoke(0xA58310,"int", p0)


end


-- PC:0x7CF0448787B23758 Old:0x91534C6E


function NETWORK.UGC_GET_CONTENT_DESCRIPTION_HASH(p0)


  return Velora.invoke(0xA58400,"int", p0)


end


-- PC:0xCFD115B373C0DF63 Old:0xA19A238D


function NETWORK.UGC_GET_CONTENT_UPDATED_DATE(p0, p1)


  Velora.invoke(0xA58470,"void", p0, p1)


end


-- PC:0x37025B27D9B658B1 Old:0xFF7D44E6


function NETWORK.UGC_GET_CONTENT_FILE_VERSION(p0, p1)


  return Velora.invoke(0xA58970,"int", p0, p1)


end


function NETWORK.UGC_GET_CONTENT_HAS_LO_RES_PHOTO(p0)


  return Velora.invoke(0xA58530,"bool", p0)


end


function NETWORK.UGC_GET_CONTENT_HAS_HI_RES_PHOTO(p0)


  return Velora.invoke(0xA58560,"bool", p0)


end


-- PC:0x32DD916F3F7C9672 Old:0xA2C5BD9D


function NETWORK.UGC_GET_CONTENT_LANGUAGE(p0)


  return Velora.invoke(0xA58590,"int", p0)


end


-- PC:0x3054F114121C21EA Old:0xA850DDE1


function NETWORK.UGC_GET_CONTENT_IS_PUBLISHED(p0)


  return Velora.invoke(0xA585C0,"bool", p0)


end


-- PC:0xA9240A96C74CCA13 Old:0x8F6754AE


function NETWORK.UGC_GET_CONTENT_IS_VERIFIED(p0)


  return Velora.invoke(0xA585F0,"bool", p0)


end


-- PC:0x1ACCFBA3D8DAB2EE Old:0x1E34953F


function NETWORK.UGC_GET_CONTENT_RATING(p0, p1)


  return Velora.invoke(0xA58620,"float", p0, p1)


end


-- PC:0x759299C5BB31D2A9 Old:0x771FE190


function NETWORK.UGC_GET_CONTENT_RATING_COUNT(p0, p1)


  return Velora.invoke(0xA58650,"int", p0, p1)


end


-- PC:0x87E5C46C187FE0AE Old:0x3276D9D3


function NETWORK.UGC_GET_CONTENT_RATING_POSITIVE_COUNT(p0, p1)


  return Velora.invoke(0xA58680,"int", p0, p1)


end


-- PC:0x4E548C0D7AE39FF9 Old:0x41A0FB02


function NETWORK.UGC_GET_CONTENT_RATING_NEGATIVE_COUNT(p0, p1)


  return Velora.invoke(0xA586B0,"int", p0, p1)


end


-- PC:0x70EA8DA57840F9BE Old:0x11DC0F27


function NETWORK.UGC_GET_CONTENT_HAS_PLAYER_RECORD(p0)


  return Velora.invoke(0xA586E0,"bool", p0)


end


-- PC:0x993CBE59D350D225 Old:0x0DEB3F5A


function NETWORK.UGC_GET_CONTENT_HAS_PLAYER_BOOKMARKED(p0)


  return Velora.invoke(0xA58710,"bool", p0)


end


-- PC:0x171DF6A0C07FB3DC Old:0x84315226


function NETWORK.UGC_REQUEST_CONTENT_DATA_FROM_INDEX(p0, p1)


  return Velora.invoke(0xA58740,"int", p0, p1)


end


-- PC:0x7FD2990AF016795E Old:0x38FC2EEB


function NETWORK.UGC_REQUEST_CONTENT_DATA_FROM_PARAMS(contentTypeName, contentId, p2, p3, p4)


  return Velora.invoke(0xA58780,"int", contentTypeName, contentId, p2, p3, p4)


end


-- PC:0x5E0165278F6339EE Old:0x1C4F9FDB


function NETWORK.UGC_REQUEST_CACHED_DESCRIPTION(p0)


  return Velora.invoke(0xA58800,"int", p0)


end


-- PC:0x2D5DC831176D0114 Old:0xA69AE16C


function NETWORK.UGC_IS_DESCRIPTION_REQUEST_IN_PROGRESS(p0)


  return Velora.invoke(0xA58830,"bool", p0)


end


-- PC:0xEBFA8D50ADDC54C4 Old:0xF50BC67A


function NETWORK.UGC_HAS_DESCRIPTION_REQUEST_FINISHED(p0)


  return Velora.invoke(0xA58860,"bool", p0)


end


-- PC:0x162C23CA83ED0A62 Old:0xB3BBD241


function NETWORK.UGC_DID_DESCRIPTION_REQUEST_SUCCEED(p0)


  return Velora.invoke(0xA58890,"bool", p0)


end


-- PC:0x5A34CD9C3C5BEC44 Old:0x346B506C


function NETWORK.UGC_RELEASE_CACHED_DESCRIPTION(p0)


  return Velora.invoke(0xA58940,"bool", p0)


end


-- PC:0x68103E2247887242 Old:0x0095DB71


function NETWORK.UGC_RELEASE_ALL_CACHED_DESCRIPTIONS()


  Velora.invoke(0xA58970,"void")


end


-- PC:0x1DE0F5F50D723CAA Old:0xAD334B40


function NETWORK.UGC_PUBLISH(contentId, baseContentId, contentTypeName)


  return Velora.invoke(0xA58C50,"bool", contentId, baseContentId, contentTypeName)


end


-- PC:0x274A1519DFC1094F Old:0x980D45D7


function NETWORK.UGC_SET_BOOKMARKED(contentId, bookmarked, contentTypeName)


  return Velora.invoke(0xA58A30,"bool", contentId, bookmarked, contentTypeName)


end


-- PC:0xD05D1A6C74DA3498 Old:0x48CCC328


function NETWORK.UGC_SET_DELETED(p0, p1, p2)


  return Velora.invoke(0xA58B30,"bool", p0, p1, p2)


end


-- PC:0x45E816772E93A9DB Old:0x8E664EFD


function NETWORK.UGC_IS_MODIFYING()


  return Velora.invoke(0xA58B90,"bool")


end


-- PC:0x299EF3C576773506 Old:0x611E0BE2


function NETWORK.UGC_HAS_MODIFY_FINISHED()


  return Velora.invoke(0xA58BC0,"bool")


end


-- PC:0x793FF272D5B365F4 Old:0xF0211AC1


function NETWORK.UGC_DID_MODIFY_SUCCEED()


  return Velora.invoke(0xA58BF0,"bool")


end


-- PC:0x5A0A3D1A186A5508 Old:0x1F0DD8AF


function NETWORK.UGC_GET_MODIFY_RESULT()


  return Velora.invoke(0xA58C20,"int")


end


-- PC:0xA1E5E0204A6FCC70 Old:0x405ECA16


function NETWORK.UGC_CLEAR_MODIFY_RESULT()


  Velora.invoke(0xA58C50,"void")


end


-- PC:0xB746D20B17F2A229 Old:0x9567392B


function NETWORK.UGC_GET_CREATORS_BY_USER_ID(p0, p1)


  return Velora.invoke(0xA58DD0,"bool", p0, p1)


end


-- PC:0x63B406D7884BFA95 Old:0xF79FFF3C


function NETWORK.UGC_HAS_QUERY_CREATORS_FINISHED()


  return Velora.invoke(0xA58D10,"bool")


end


-- PC:0x4D02279C83BE69FE Old:0xA7F3F82B


function NETWORK.UGC_DID_QUERY_CREATORS_SUCCEED()


  return Velora.invoke(0xA58D40,"bool")


end


-- PC:0x597F8DBA9B206FC7 Old:0x410C61D1


function NETWORK.UGC_GET_CREATOR_NUM()


  return Velora.invoke(0xA58D70,"int")


end


-- PC:0x5CAE833B0EE0C500 Old:0x0D4F845D


function NETWORK.UGC_LOAD_OFFLINE_QUERY(p0)


  return Velora.invoke(0xA58DA0,"bool", p0)


end


-- PC:0x61A885D3F7CFEE9A Old:0xE13C1F7F


function NETWORK.UGC_CLEAR_OFFLINE_QUERY()


  Velora.invoke(0xA58DD0,"void")


end


-- PC:0xF98DDE0A8ED09323 Old:0x213C6D36


function NETWORK.UGC_SET_QUERY_DATA_FROM_OFFLINE(p0)


  Velora.invoke(0xA58DE0,"void", p0)


end


-- PC:0xFD75DABC0957BF33 Old:0x511E6F50


function NETWORK.UGC_SET_USING_OFFLINE_CONTENT(p0)


  Velora.invoke(0xA58E00,"void", p0)


end


-- PC:0xF53E48461B71EECB Old:0xB4668B23


function NETWORK.UGC_IS_LANGUAGE_SUPPORTED(p0)


  return Velora.invoke(0xA591A0,"bool", p0)


end


-- PC:0x098AB65B9ED9A9EC Old:0x30B51753


function NETWORK.FACEBOOK_POST_COMPLETED_HEIST(heistName, cashEarned, xpEarned)


  return Velora.invoke(0xA58E50,"bool", heistName, cashEarned, xpEarned)


end


-- PC:0xDC48473142545431 Old:0x02DAD93F


function NETWORK.FACEBOOK_POST_CREATE_CHARACTER()


  return Velora.invoke(0xA58E60,"bool")


end


-- PC:0x0AE1F1653B554AB9 Old:0x2D947814


function NETWORK.FACEBOOK_POST_COMPLETED_MILESTONE(milestoneId)


  return Velora.invoke(0xA58E70,"bool", milestoneId)


end


-- PC:0x62B9FEC9A11F10EF Old:0x37A28C26


function NETWORK.FACEBOOK_HAS_POST_COMPLETED()


  return Velora.invoke(0xA58E80,"bool")


end


-- PC:0xA75E2B6733DA5142 Old:0x11E8B5CD


function NETWORK.FACEBOOK_DID_POST_SUCCEED()


  return Velora.invoke(0xA58E90,"bool")


end


-- PC:0x43865688AE10F0D7 Old:0x429AEAB3


function NETWORK.FACEBOOK_CAN_POST_TO_FACEBOOK()


  return Velora.invoke(0xA58EA0,"bool")


end


-- PC:0x16160DA74A8E74A2 Old:0xAD546CC3


function NETWORK.TEXTURE_DOWNLOAD_REQUEST(gamerHandle, filePath, name, p3)


  return Velora.invoke(0xA58EB0,"int", gamerHandle, filePath, name, p3)


end


-- PC:0x0B203B4AFDE53A4F Old:0x1856D008


function NETWORK.TITLE_TEXTURE_DOWNLOAD_REQUEST(filePath, name, p2)


  return Velora.invoke(0xA59010,"int", filePath, name, p2)


end


-- PC:0x308F96458B7087CC Old:0x68C9AF69


function NETWORK.UGC_TEXTURE_DOWNLOAD_REQUEST(p0, p1, p2, p3, p4, p5)


  return Velora.invoke(0xA590D0,"int", p0, p1, p2, p3, p4, p5)


end


-- PC:0x487EB90B98E9FB19 Old:0xEE8D9E70


function NETWORK.TEXTURE_DOWNLOAD_RELEASE(p0)


  Velora.invoke(0xA591A0,"void", p0)


end


-- PC:0x5776ED562C134687 Old:0xE4547765


function NETWORK.TEXTURE_DOWNLOAD_HAS_FAILED(p0)


  return Velora.invoke(0xA597A0,"bool", p0)


end


-- PC:0x8BD6C6DEA20E82C6 Old:0x03225BA3


function NETWORK.GET_STATUS_OF_TEXTURE_DOWNLOAD(p0)


  return Velora.invoke(0xA59220,"int", p0)


end


-- PC:0x60EDD13EB3AC1FF3 Old:0x4DEBC227


function NETWORK.NETWORK_CHECK_ROS_LINK_WENTDOWN_NOT_NET()


  return Velora.invoke(0xA59270,"bool")


end


function NETWORK.NETWORK_SHOULD_SHOW_STRICT_NAT_WARNING()


  return Velora.invoke(0xA592E0,"bool")


end


-- PC:0xEFFB25453D8600F9 Old:0x5C065D55


function NETWORK.NETWORK_IS_CABLE_CONNECTED()


  return Velora.invoke(0xA592F0,"bool")


end


-- PC:0x66B59CFFD78467AF Old:0x0CA1167F


function NETWORK.NETWORK_HAVE_SCS_PRIVATE_MSG_PRIV()


  return Velora.invoke(0xA59310,"bool")


end


-- PC:0x606E4D3E3CCCF3EB Old:0x424C6E27


function NETWORK.NETWORK_HAVE_ROS_SOCIAL_CLUB_PRIV()


  return Velora.invoke(0xA59370,"bool")


end


-- PC:0x8020A73847E0CA7D Old:0xD3BBE42F


function NETWORK.NETWORK_HAVE_ROS_BANNED_PRIV()


  return Velora.invoke(0xA593D0,"bool")


end


-- PC:0xA0AD7E2AF5349F61 Old:0xBDBB5948


function NETWORK.NETWORK_HAVE_ROS_CREATE_TICKET_PRIV()


  return Velora.invoke(0xA59410,"bool")


end


-- PC:0x5F91D5D0B36AA310 Old:0x97287D68


function NETWORK.NETWORK_HAVE_ROS_MULTIPLAYER_PRIV()


  return Velora.invoke(0xA59470,"bool")


end


-- PC:0x422D396F80A96547 Old:0xC6EA802E


function NETWORK.NETWORK_HAVE_ROS_LEADERBOARD_WRITE_PRIV()


  return Velora.invoke(0xA594D0,"bool")


end


-- PC:0xA699957E60D80214 Old:0xFD261E30


function NETWORK.NETWORK_HAS_ROS_PRIVILEGE(index)


  return Velora.invoke(0xA59530,"bool", index)


end


-- PC:0xC22912B1D85F26B1 Old:0x8570DD34


function NETWORK.NETWORK_HAS_ROS_PRIVILEGE_END_DATE(privilege, timeData)


  return Velora.invoke(0xA595B0,"bool", privilege, timeData)


end


function NETWORK.NETWORK_HAS_ROS_PRIVILEGE_PLAYED_LAST_GEN()


  return Velora.invoke(0xA595E0,"bool")


end


function NETWORK.NETWORK_HAS_ROS_PRIVILEGE_SPECIAL_EDITION_CONTENT()


  return Velora.invoke(0xA59640,"bool")


end


function NETWORK.NETWORK_START_COMMUNICATION_PERMISSIONS_CHECK(p0)


  return Velora.invoke(0xDEADBEEF,"int", p0)


end


function NETWORK.NETWORK_START_USER_CONTENT_PERMISSIONS_CHECK(netHandle)


  return Velora.invoke(0xA59790,"int", netHandle)


end


-- PC:0x9465E683B12D3F6B Old:0x273C6180


function NETWORK.NETWORK_SKIP_RADIO_RESET_NEXT_CLOSE()


  Velora.invoke(0xA597A0,"void")


end


function NETWORK.NETWORK_SKIP_RADIO_RESET_NEXT_OPEN()


  Velora.invoke(0xA597B0,"void")


end


function NETWORK.NETWORK_SKIP_RADIO_WARNING()


  return Velora.invoke(0xA597D0,"bool")


end


-- PC:0xB7C7F6AD6424304B Old:0x371BBA08


function NETWORK.NETWORK_FORCE_LOCAL_PLAYER_SCAR_SYNC()


  Velora.invoke(0xA597D0,"void")


end


-- PC:0xC505036A35AFD01B Old:0xA100CC97


function NETWORK.NETWORK_DISABLE_LEAVE_REMOTE_PED_BEHIND(toggle)


  Velora.invoke(0xA597F0,"void", toggle)


end


-- PC:0x267C78C60E806B9A Old:0xBB2D33D3


function NETWORK.NETWORK_ALLOW_REMOTE_ATTACHMENT_MODIFICATION(entity, toggle)


  Velora.invoke(0xA59840,"void", entity, toggle)


end


function NETWORK.NETWORK_SHOW_CHAT_RESTRICTION_MSC(player)


  Velora.invoke(0xA59890,"void", player)


end


function NETWORK.NETWORK_SHOW_PSN_UGC_RESTRICTION()


  Velora.invoke(0xA598E0,"void")


end


function NETWORK.NETWORK_IS_TITLE_UPDATE_REQUIRED()


  return Velora.invoke(0xA59990,"bool")


end


function NETWORK.NETWORK_QUIT_MP_TO_DESKTOP()


  Velora.invoke(0xA59990,"void")


end


function NETWORK.NETWORK_IS_CONNECTED_VIA_RELAY(player)


  return Velora.invoke(0xA59C10,"bool", player)


end


function NETWORK.NETWORK_GET_AVERAGE_LATENCY(player)


  return Velora.invoke(0xA59A00,"float", player)


end


function NETWORK.NETWORK_GET_AVERAGE_PING(player)


  return Velora.invoke(0xA59A50,"float", player)


end


function NETWORK.NETWORK_GET_AVERAGE_PACKET_LOSS(player)


  return Velora.invoke(0xA59AA0,"float", player)


end


function NETWORK.NETWORK_GET_NUM_UNACKED_RELIABLES(player)


  return Velora.invoke(0xA59AF0,"int", player)


end


function NETWORK.NETWORK_GET_UNRELIABLE_RESEND_COUNT(player)


  return Velora.invoke(0xA59B50,"int", player)


end


function NETWORK.NETWORK_GET_HIGHEST_RELIABLE_RESEND_COUNT(player)


  return Velora.invoke(0xA59BB0,"int", player)


end


function NETWORK.NETWORK_REPORT_CODE_TAMPER()


  Velora.invoke(0xA59C10,"void")


end


function NETWORK.NETWORK_GET_LAST_ENTITY_POS_RECEIVED_OVER_NETWORK(entity)


  local x,y,z=Velora.invoke(0xA59F90,"vector3", entity)


  return {x=x,y=y,z=z}


end


function NETWORK.NETWORK_GET_LAST_PLAYER_POS_RECEIVED_OVER_NETWORK(player)


  local x,y,z=Velora.invoke(0xA59D30,"vector3", player)


  return {x=x,y=y,z=z}


end


function NETWORK.NETWORK_GET_LAST_VEL_RECEIVED_OVER_NETWORK(entity)


  local x,y,z=Velora.invoke(0xA59E00,"vector3", entity)


  return {x=x,y=y,z=z}


end


function NETWORK.NETWORK_GET_PREDICTED_VELOCITY(entity)


  local x,y,z=Velora.invoke(0xA59EC0,"vector3", entity)


  return {x=x,y=y,z=z}


end


function NETWORK.NETWORK_DUMP_NET_IF_CONFIG()


  Velora.invoke(0xA59F90,"void")


end


function NETWORK.NETWORK_GET_SIGNALLING_INFO(p0)


  Velora.invoke(0xA59FA0,"void", p0)


end


function NETWORK.NETWORK_GET_NET_STATISTICS_INFO(p0)


  Velora.invoke(0xA59FB0,"void", p0)


end


function NETWORK.NETWORK_GET_PLAYER_ACCOUNT_ID(player)


  return Velora.invoke(0xA5A010,"int", player)


end


function NETWORK.NETWORK_UGC_NAV(p0, p1)


  Velora.invoke(0xA5A010,"void", p0, p1)


end


