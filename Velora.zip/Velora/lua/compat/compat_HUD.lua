-- compat_HUD.lua — AUTO GENERATO


-- HUD


HUD=HUD or {}


-- PC:0xABA17D7CE615ADBF Old:0xCB7C8994


function HUD.BEGIN_TEXT_COMMAND_BUSYSPINNER_ON(string)


  Velora.invoke(0x9DFAC0,"void", string)


end


-- PC:0xBD12F8228410D9B4 Old:0x903F5EE4


function HUD.END_TEXT_COMMAND_BUSYSPINNER_ON(busySpinnerType)


  Velora.invoke(0x9DFAD0,"void", busySpinnerType)


end


-- PC:0x10D373323E5B9C0D Old:0x94119534


function HUD.BUSYSPINNER_OFF()


  Velora.invoke(0x9DFAE0,"void")


end


-- PC:0xC65AB383CD91DF98 Old:0x71077FBD


function HUD.PRELOAD_BUSYSPINNER()


  Velora.invoke(0x9DFAF0,"void")


end


-- PC:0xD422FCC5F239A915 Old:0xB8B3A5D0


function HUD.BUSYSPINNER_IS_ON()


  return Velora.invoke(0x9DFB40,"bool")


end


-- PC:0xB2A592B04648A9CB Old:0x3AF34DEF


function HUD.BUSYSPINNER_IS_DISPLAYING()


  return Velora.invoke(0x9DFB20,"bool")


end


function HUD.DISABLE_PAUSEMENU_SPINNER(p0)


  Velora.invoke(0x9DFB40,"void", p0)


end


function HUD.SET_MOUSE_CURSOR_THIS_FRAME()


  Velora.invoke(0x9DFB50,"void")


end


function HUD.SET_MOUSE_CURSOR_STYLE(spriteId)


  Velora.invoke(0x9DFB60,"void", spriteId)


end


function HUD.SET_MOUSE_CURSOR_VISIBLE(toggle)


  Velora.invoke(0x9DFB70,"void", toggle)


end


function HUD.IS_MOUSE_ROLLED_OVER_INSTRUCTIONAL_BUTTONS()


  return Velora.invoke(0x9DFBA0,"bool")


end


function HUD.GET_MOUSE_EVENT(scaleformHandle, p1, p2, p3)


  return Velora.invoke(0x9DFB90,"bool", scaleformHandle, p1, p2, p3)


end


-- PC:0x6F1554B0CC2089FA Old:0xA7C8594B


function HUD.THEFEED_ONLY_SHOW_TOOLTIPS(toggle)


  Velora.invoke(0x9DFBA0,"void", toggle)


end


-- PC:0x55598D21339CB998 Old:0x1DA7E41A


function HUD.THEFEED_SET_SCRIPTED_MENU_HEIGHT(pos)


  Velora.invoke(0x9DFBF0,"void", pos)


end


function HUD.THEFEED_HIDE()


  Velora.invoke(0x9DFC20,"void")


end


-- PC:0x25F87B30C382FCA7 Old:0x1E63088A


function HUD.THEFEED_HIDE_THIS_FRAME()


  Velora.invoke(0x9DFC40,"void")


end


function HUD.THEFEED_SHOW()


  Velora.invoke(0x9DFC60,"void")


end


-- PC:0xA8FDB297A8D25FBA Old:0x5205C6F5


function HUD.THEFEED_FLUSH_QUEUE()


  Velora.invoke(0x9DFC80,"void")


end


-- PC:0xBE4390CB40B3E627 Old:0xECA8ACB9


function HUD.THEFEED_REMOVE_ITEM(notificationId)


  Velora.invoke(0x9DFCA0,"void", notificationId)


end


-- PC:0xA13C11E1B5C06BFC Old:0x520FCB6D


function HUD.THEFEED_FORCE_RENDER_ON()


  Velora.invoke(0x9DFCD0,"void")


end


-- PC:0x583049884A2EEE3C Old:0xC8BAB2F2


function HUD.THEFEED_FORCE_RENDER_OFF()


  Velora.invoke(0x9DFCF0,"void")


end


-- PC:0xFDB423997FA30340 Old:0x4D0449C6


function HUD.THEFEED_PAUSE()


  Velora.invoke(0x9DFD10,"void")


end


-- PC:0xE1CD1E48E025E661 Old:0xD3F40140


function HUD.THEFEED_RESUME()


  Velora.invoke(0x9DFD30,"void")


end


-- PC:0xA9CBFD40B3FA3010 Old:0xC5223796


function HUD.THEFEED_IS_PAUSED()


  return Velora.invoke(0x9DFD70,"bool")


end


-- PC:0xD4438C0564490E63 Old:0x709B4BCB


function HUD.THEFEED_REPORT_LOGO_ON()


  Velora.invoke(0x9DFD70,"void")


end


-- PC:0xB695E2CD0A2DA9EE Old:0x4A4A40A4


function HUD.THEFEED_REPORT_LOGO_OFF()


  Velora.invoke(0x9DFD90,"void")


end


-- PC:0x82352748437638CA Old:0x294405D4


function HUD.THEFEED_GET_LAST_SHOWN_PHONE_ACTIVATABLE_FEED_ID()


  return Velora.invoke(0x9DFDE0,"int")


end


-- PC:0x56C8B608CFD49854 Old:0xF881AB87


function HUD.THEFEED_AUTO_POST_GAMETIPS_ON()


  Velora.invoke(0x9DFDE0,"void")


end


-- PC:0xADED7F5748ACAFE6 Old:0x1D6859CA


function HUD.THEFEED_AUTO_POST_GAMETIPS_OFF()


  Velora.invoke(0x9DFE00,"void")


end


-- PC:0x92F0DA1E27DB96DC Old:0x07CE2EA4


function HUD.THEFEED_SET_BACKGROUND_COLOR_FOR_NEXT_POST(hudColorIndex)


  Velora.invoke(0x9DFE20,"void", hudColorIndex)


end


-- PC:0x17430B918701C342 Old:0xCF14D7F2


function HUD.THEFEED_SET_RGBA_PARAMETER_FOR_NEXT_MESSAGE(red, green, blue, alpha)


  Velora.invoke(0x9DFE50,"void", red, green, blue, alpha)


end


-- PC:0x17AD8C9706BDD88A Old:0x24A97AF8


function HUD.THEFEED_SET_FLASH_DURATION_PARAMETER_FOR_NEXT_MESSAGE(count)


  Velora.invoke(0x9DFEB0,"void", count)


end


-- PC:0x4A0C7C9BB10ABB36 Old:0x44018EDB


function HUD.THEFEED_SET_VIBRATE_PARAMETER_FOR_NEXT_MESSAGE(toggle)


  Velora.invoke(0x9DFEE0,"void", toggle)


end


-- PC:0xFDD85225B2DEA55E Old:0xA4524B23


function HUD.THEFEED_RESET_ALL_PARAMETERS()


  Velora.invoke(0x9DFF10,"void")


end


-- PC:0xFDEC055AB549E328 Old:0xAFA1148B


function HUD.THEFEED_FREEZE_NEXT_POST()


  Velora.invoke(0x9DFF30,"void")


end


-- PC:0x80FE4F3AB4E1B62A Old:0x3CD4307C


function HUD.THEFEED_CLEAR_FROZEN_POST()


  Velora.invoke(0x9DFF50,"void")


end


function HUD.THEFEED_SET_SNAP_FEED_ITEM_POSITIONS(p0)


  Velora.invoke(0xDEADBEEF,"void", p0)


end


-- PC:0x317EBA71D7543F52 Old:0x6A3F747D


function HUD.THEFEED_UPDATE_ITEM_TEXTURE(txdString1, txnString1, txdString2, txnString2)


  Velora.invoke(0x9DFF70,"void", txdString1, txnString1, txdString2, txnString2)


end


-- PC:0x202709F4C58A0424 Old:0x574EE85C


function HUD.BEGIN_TEXT_COMMAND_THEFEED_POST(text)


  Velora.invoke(0x9DFFC0,"void", text)


end


-- PC:0x2B7E9A4EAAA93C89 Old:0xED130FA1


function HUD.END_TEXT_COMMAND_THEFEED_POST_STATS(statTitle, iconEnum, stepVal, barValue, isImportant, pictureTextureDict, pictureTextureName)


  return Velora.invoke(0x9E0630,"int", statTitle, iconEnum, stepVal, barValue, isImportant, pictureTextureDict, pictureTextureName)


end


-- PC:0x1CCD9A37359072CF Old:0xE7E3C98B


function HUD.END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT(txdName, textureName, flash, iconType, sender, subject)


  return Velora.invoke(0x9E0010,"int", txdName, textureName, flash, iconType, sender, subject)


end


function HUD.END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT_SUBTITLE_LABEL(txdName, textureName, flash, iconType, sender, subject)


  return Velora.invoke(0x9E0080,"int", txdName, textureName, flash, iconType, sender, subject)


end


-- PC:0x1E6611149DB3DB6B Old:0x0EB382B7


function HUD.END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT_TU(txdName, textureName, flash, iconType, sender, subject, duration)


  return Velora.invoke(0x9E0130,"int", txdName, textureName, flash, iconType, sender, subject, duration)


end


-- PC:0x5CBF7BADE20DB93E Old:0x3E807FE3


function HUD.END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT_WITH_CREW_TAG(txdName, textureName, flash, iconType, sender, subject, duration, clanTag)


  return Velora.invoke(0x9E01A0,"int", txdName, textureName, flash, iconType, sender, subject, duration, clanTag)


end


-- PC:0x531B84E7DA981FB6 Old:0xDEB491C8


function HUD.END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT_WITH_CREW_TAG_AND_ADDITIONAL_ICON(txdName, textureName, flash, iconType1, sender, subject, duration, clanTag, iconType2, p9)


  return Velora.invoke(0x9E0210,"int", txdName, textureName, flash, iconType1, sender, subject, duration, clanTag, iconType2, p9)


end


-- PC:0x2ED7843F8F801023 Old:0x08F7AF78


function HUD.END_TEXT_COMMAND_THEFEED_POST_TICKER(blink, p1)


  return Velora.invoke(0x9E0280,"int", blink, p1)


end


-- PC:0x44FA03975424A0EE Old:0x57B8D0D4


function HUD.END_TEXT_COMMAND_THEFEED_POST_TICKER_FORCED(blink, p1)


  return Velora.invoke(0x9E02C0,"int", blink, p1)


end


-- PC:0x378E809BF61EC840 Old:0x02BCAF9B


function HUD.END_TEXT_COMMAND_THEFEED_POST_TICKER_WITH_TOKENS(blink, p1)


  return Velora.invoke(0x9E0330,"int", blink, p1)


end


-- PC:0xAA295B6F28BD587D Old:0x02DED2B8


function HUD.END_TEXT_COMMAND_THEFEED_POST_AWARD(textureDict, textureName, rpBonus, colorOverlay, titleLabel)


  return Velora.invoke(0x9E0370,"int", textureDict, textureName, rpBonus, colorOverlay, titleLabel)


end


-- PC:0x97C9E4E7024A8F2C Old:0xA9CCEF66


function HUD.END_TEXT_COMMAND_THEFEED_POST_CREWTAG(p0, p1, p3, isLeader, unk0, clanDesc, R, G, B)


  return Velora.invoke(0x9E03A0,"int", p0, p1, p3, isLeader, unk0, clanDesc, R, G, B)


end


-- PC:0x137BC35589E34E1E Old:0x88B9B909


function HUD.END_TEXT_COMMAND_THEFEED_POST_CREWTAG_WITH_GAME_NAME(p0, p1, p3, isLeader, unk0, clanDesc, playerName, R, G, B)


  return Velora.invoke(0x9E0420,"int", p0, p1, p3, isLeader, unk0, clanDesc, playerName, R, G, B)


end


-- PC:0x33EE12743CCD6343 Old:0xE05E7052


function HUD.END_TEXT_COMMAND_THEFEED_POST_UNLOCK(gxtLabel1, p1, gxtLabel2)


  return Velora.invoke(0x9E04B0,"int", gxtLabel1, p1, gxtLabel2)


end


-- PC:0xC8F3AAF93D0600BF Old:0x4FA43BA4


function HUD.END_TEXT_COMMAND_THEFEED_POST_UNLOCK_TU(gxtLabel1, p1, gxtLabel2, p3)


  return Velora.invoke(0x9E04E0,"int", gxtLabel1, p1, gxtLabel2, p3)


end


-- PC:0x7AE0589093A2E088 Old:0x8C90D22F


function HUD.END_TEXT_COMMAND_THEFEED_POST_UNLOCK_TU_WITH_COLOR(p0, p1, p2, p3, p4, p5)


  return Velora.invoke(0x9E0520,"int", p0, p1, p2, p3, p4, p5)


end


-- PC:0xF020C96915705B3A Old:0x8E319AB8


function HUD.END_TEXT_COMMAND_THEFEED_POST_MPTICKER(blink, p1)


  return Velora.invoke(0x9E0560,"int", blink, p1)


end


function HUD.END_TEXT_COMMAND_THEFEED_POST_CREW_RANKUP_WITH_LITERAL_FLAG(p0, p1, p2, p3, p4)


  return Velora.invoke(0x9E05A0,"int", p0, p1, p2, p3, p4)


end


-- PC:0xB6871B0555B02996 Old:0x5E93FBFA


function HUD.END_TEXT_COMMAND_THEFEED_POST_VERSUS_TU(txdName1, textureName1, count1, txdName2, textureName2, count2, hudColor1, hudColor2)


  return Velora.invoke(0x9E05E0,"int", txdName1, textureName1, count1, txdName2, textureName2, count2, hudColor1, hudColor2)


end


function HUD.END_TEXT_COMMAND_THEFEED_POST_REPLAY(type, image, text)


  return Velora.invoke(0xDEADBEEF,"int", type, image, text)


end


function HUD.END_TEXT_COMMAND_THEFEED_POST_REPLAY_INPUT(type, button, text)


  return Velora.invoke(0xDEADBEEF,"int", type, button, text)


end


-- PC:0xB87A37EEB7FAA67D Old:0xF42C43C7


function HUD.BEGIN_TEXT_COMMAND_PRINT(GxtEntry)


  Velora.invoke(0x9E0630,"void", GxtEntry)


end


-- PC:0x9D77056A530643F6 Old:0x38F82261


function HUD.END_TEXT_COMMAND_PRINT(duration, drawImmediately)


  Velora.invoke(0x9E0640,"void", duration, drawImmediately)


end


-- PC:0x853648FD1063A213 Old:0xDD524A11


function HUD.BEGIN_TEXT_COMMAND_IS_MESSAGE_DISPLAYED(text)


  Velora.invoke(0x9E0660,"void", text)


end


-- PC:0x8A9BA1AB3E237613 Old:0x672EFB45


function HUD.END_TEXT_COMMAND_IS_MESSAGE_DISPLAYED()


  return Velora.invoke(0x9E0690,"bool")


end


-- PC:0x25FBB336DF1804CB Old:0x3E35563E


function HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT(text)


  Velora.invoke(0x9E0690,"void", text)


end


-- PC:0xCD015E5BB0D96A57 Old:0x6F8350CE


function HUD.END_TEXT_COMMAND_DISPLAY_TEXT(x, y)


  Velora.invoke(0x9E06C0,"void", x, y)


end


-- PC:0x54CE8AC98E120CAB Old:0x51E7A037


function HUD.BEGIN_TEXT_COMMAND_GET_SCREEN_WIDTH_OF_DISPLAY_TEXT(text)


  Velora.invoke(0x9E0710,"void", text)


end


-- PC:0x85F061DA64ED2F67 Old:0xD12A643A


function HUD.END_TEXT_COMMAND_GET_SCREEN_WIDTH_OF_DISPLAY_TEXT(p0)


  return Velora.invoke(0x9E0750,"float", p0)


end


-- PC:0x521FB041D93DD0E4 Old:0x94B82066


function HUD.BEGIN_TEXT_COMMAND_GET_NUMBER_OF_LINES_FOR_STRING(entry)


  Velora.invoke(0x9E0750,"void", entry)


end


-- PC:0x9040DFB09BE75706 Old:0xAA318785


function HUD.END_TEXT_COMMAND_GET_NUMBER_OF_LINES_FOR_STRING(x, y)


  return Velora.invoke(0x9E0790,"int", x, y)


end


-- PC:0x8509B634FBE7DA11 Old:0xB245FC10


function HUD.BEGIN_TEXT_COMMAND_DISPLAY_HELP(inputType)


  Velora.invoke(0x9E0790,"void", inputType)


end


-- PC:0x238FFE5C7B0498A6 Old:0xB59B530D


function HUD.END_TEXT_COMMAND_DISPLAY_HELP(p0, loop, beep, shape)


  Velora.invoke(0x9E07A0,"void", p0, loop, beep, shape)


end


-- PC:0x0A24DA3A41B718F5 Old:0x00E20F2D


function HUD.BEGIN_TEXT_COMMAND_IS_THIS_HELP_MESSAGE_BEING_DISPLAYED(labelName)


  Velora.invoke(0x9E07D0,"void", labelName)


end


-- PC:0x10BDDBFC529428DD Old:0xF63A13EC


function HUD.END_TEXT_COMMAND_IS_THIS_HELP_MESSAGE_BEING_DISPLAYED(p0)


  return Velora.invoke(0x9E0810,"bool", p0)


end


-- PC:0xF9113A30DE5C6670 Old:0xF4C211F6


function HUD.BEGIN_TEXT_COMMAND_SET_BLIP_NAME(textLabel)


  Velora.invoke(0x9E0810,"void", textLabel)


end


-- PC:0xBC38B49BCB83BC9B Old:0xE8E59820


function HUD.END_TEXT_COMMAND_SET_BLIP_NAME(blip)


  Velora.invoke(0x9E0820,"void", blip)


end


-- PC:0x23D69E0465570028 Old:0x0E103475


function HUD.BEGIN_TEXT_COMMAND_ADD_DIRECTLY_TO_PREVIOUS_BRIEFS(p0)


  Velora.invoke(0x9E0830,"void", p0)


end


-- PC:0xCFDBDF5AE59BA0F4 Old:0x2944A6C5


function HUD.END_TEXT_COMMAND_ADD_DIRECTLY_TO_PREVIOUS_BRIEFS(p0)


  Velora.invoke(0x9E0840,"void", p0)


end


-- PC:0xE124FA80A759019C Old:0x550665AE


function HUD.BEGIN_TEXT_COMMAND_CLEAR_PRINT(text)


  Velora.invoke(0x9E0860,"void", text)


end


-- PC:0xFCC75460ABA29378 Old:0x67785AF2


function HUD.END_TEXT_COMMAND_CLEAR_PRINT()


  Velora.invoke(0x9E0870,"void")


end


-- PC:0x8F9EE5687F8EECCD Old:0xBF855650


function HUD.BEGIN_TEXT_COMMAND_OVERRIDE_BUTTON_TEXT(gxtEntry)


  Velora.invoke(0x9E0880,"void", gxtEntry)


end


-- PC:0xA86911979638106F Old:0x6E7FDA1C


function HUD.END_TEXT_COMMAND_OVERRIDE_BUTTON_TEXT(p0)


  Velora.invoke(0x9E0890,"void", p0)


end


-- PC:0x03B504CF259931BC Old:0xFE272A57


function HUD.ADD_TEXT_COMPONENT_INTEGER(value)


  Velora.invoke(0x9E08A0,"void", value)


end


-- PC:0xE7DCB5B874BCD96E Old:0x24D78013


function HUD.ADD_TEXT_COMPONENT_FLOAT(value, decimalPlaces)


  Velora.invoke(0x9E08B0,"void", value, decimalPlaces)


end


-- PC:0xC63CD5D2920ACBE7 Old:0xDCE05406


function HUD.ADD_TEXT_COMPONENT_SUBSTRING_TEXT_LABEL(labelName)


  Velora.invoke(0x9E08C0,"void", labelName)


end


-- PC:0x17299B63C7683A2B Old:0x150E03B6


function HUD.ADD_TEXT_COMPONENT_SUBSTRING_TEXT_LABEL_HASH_KEY(gxtEntryHash)


  Velora.invoke(0x9E08D0,"void", gxtEntryHash)


end


-- PC:0x80EAD8E2E1D5D52E Old:0x5DE98F0A


function HUD.ADD_TEXT_COMPONENT_SUBSTRING_BLIP_NAME(blip)


  Velora.invoke(0x9E08E0,"void", blip)


end


-- PC:0x6C188BE134E074AA Old:0x27A244D8


function HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text)


  Velora.invoke(0x9E08F0,"void", text)


end


-- PC:0x1115F16B8AB9E8BF Old:0x135B3CD0


function HUD.ADD_TEXT_COMPONENT_SUBSTRING_TIME(timestamp, flags)


  Velora.invoke(0x9E0900,"void", timestamp, flags)


end


-- PC:0x0E4C749FF9DE9CC4 Old:0x12929BDF


function HUD.ADD_TEXT_COMPONENT_FORMATTED_INTEGER(value, commaSeparated)


  Velora.invoke(0x9E0910,"void", value, commaSeparated)


end


-- PC:0x761B77454205A61D Old:0x65E1D404


function HUD.ADD_TEXT_COMPONENT_SUBSTRING_PHONE_NUMBER(p0, p1)


  Velora.invoke(0x9E0920,"void", p0, p1)


end


-- PC:0x94CF4AC034C9C986 Old:0xC736999E


function HUD.ADD_TEXT_COMPONENT_SUBSTRING_WEBSITE(website)


  Velora.invoke(0x9E09B0,"void", website)


end


-- PC:0x5F68520888E69014 Old:0x0829A799


function HUD.ADD_TEXT_COMPONENT_SUBSTRING_KEYBOARD_DISPLAY(string)


  Velora.invoke(0x9E09C0,"void", string)


end


-- PC:0x39BBF623FC803EAC Old:0x6F1A1901


function HUD.SET_COLOUR_OF_NEXT_TEXT_COMPONENT(hudColor)


  Velora.invoke(0x9E09D0,"void", hudColor)


end


-- PC:0xCC33FA791322B9D9 Old:0x216CB1C5


function HUD.CLEAR_PRINTS()


  Velora.invoke(0x9E0B10,"void")


end


-- PC:0x9D292F73ADBD9313 Old:0x9F75A929


function HUD.CLEAR_BRIEF()


  Velora.invoke(0x9E0B20,"void")


end


-- PC:0x6178F68A87A4D3A0 Old:0x9E5D9198


function HUD.CLEAR_ALL_HELP_MESSAGES()


  Velora.invoke(0x9E0B40,"void")


end


-- PC:0xCF708001E1E536DD Old:0x06878327


function HUD.CLEAR_THIS_PRINT(p0)


  Velora.invoke(0x9E0B50,"void", p0)


end


-- PC:0x2CEA2839313C09AC Old:0xA869A238


function HUD.CLEAR_SMALL_PRINTS()


  Velora.invoke(0x9E0CD0,"void")


end


-- PC:0x1C7302E725259789 Old:0x96F74838


function HUD.DOES_TEXT_BLOCK_EXIST(gxt)


  return Velora.invoke(0x9E0D20,"bool", gxt)


end


-- PC:0x71A78003C8E71424 Old:0x9FA9175B


function HUD.REQUEST_ADDITIONAL_TEXT(gxt, slot)


  Velora.invoke(0x9E0D20,"void", gxt, slot)


end


-- PC:0x6009F9F1AE90D8A6 Old:0xF4D27EBE


function HUD.REQUEST_ADDITIONAL_TEXT_FOR_DLC(gxt, slot)


  Velora.invoke(0x9E0D40,"void", gxt, slot)


end


-- PC:0x02245FE4BED318B8 Old:0xB0E56045


function HUD.HAS_ADDITIONAL_TEXT_LOADED(slot)


  return Velora.invoke(0x9E0D90,"bool", slot)


end


-- PC:0x2A179DF17CCF04CD Old:0x518141E0


function HUD.CLEAR_ADDITIONAL_TEXT(p0, p1)


  Velora.invoke(0x9E0D90,"void", p0, p1)


end


-- PC:0x8B6817B71B85EBF0 Old:0xF079E4EB


function HUD.IS_STREAMING_ADDITIONAL_TEXT(p0)


  return Velora.invoke(0x9E10A0,"bool", p0)


end


-- PC:0xADBF060E2B30C5BC Old:0x80A52040


function HUD.HAS_THIS_ADDITIONAL_TEXT_LOADED(gxt, slot)


  return Velora.invoke(0x9E0DE0,"bool", gxt, slot)


end


-- PC:0x7984C03AA5CC2F41 Old:0x6A77FE8D


function HUD.IS_MESSAGE_BEING_DISPLAYED()


  return Velora.invoke(0x9E0E10,"bool")


end


-- PC:0xAC09CA973C564252 Old:0x6ECAE560


function HUD.DOES_TEXT_LABEL_EXIST(gxt)


  return Velora.invoke(0x9E0E30,"bool", gxt)


end


-- PC:0x801BD273D3A23F74 Old:0xA4CA7BE5


function HUD.GET_LENGTH_OF_STRING_WITH_THIS_TEXT_LABEL(gxt)


  return Velora.invoke(0x9E0ED0,"int", gxt)


end


-- PC:0xF030907CCBB8A9FD Old:0x99379D55


function HUD.GET_LENGTH_OF_LITERAL_STRING(string)


  return Velora.invoke(0x9E0F20,"int", string)


end


-- PC:0x43E4111189E54F0E Old:0x7DBC0764


function HUD.GET_LENGTH_OF_LITERAL_STRING_IN_BYTES(string)


  return Velora.invoke(0x9E0F50,"int", string)


end


-- PC:0x1930DFA731813EC4 Old:0xC3BC1B4F


function HUD.IS_HUD_PREFERENCE_SWITCHED_ON()


  return Velora.invoke(0x9E1040,"bool")


end


-- PC:0x9EB6522EA68F22FE Old:0x14AEAA28


function HUD.IS_RADAR_PREFERENCE_SWITCHED_ON()


  return Velora.invoke(0x9E1060,"bool")


end


-- PC:0xAD6DACA4BA53E0A4 Old:0x63BA19F5


function HUD.IS_SUBTITLE_PREFERENCE_SWITCHED_ON()


  return Velora.invoke(0x9E1080,"bool")


end


-- PC:0xA6294919E56FF02A Old:0xD10E4E31


function HUD.DISPLAY_HUD(toggle)


  Velora.invoke(0x9E10A0,"void", toggle)


end


-- PC:0x7669F9E39DC17063 Old:0xC380AC85


function HUD.DISPLAY_HUD_WHEN_NOT_IN_STATE_OF_PLAY_THIS_FRAME()


  Velora.invoke(0x9E10D0,"void")


end


-- PC:0x402F9ED62087E898 Old:0xC47AB1B0


function HUD.DISPLAY_HUD_WHEN_PAUSED_THIS_FRAME()


  Velora.invoke(0x9E10F0,"void")


end


-- PC:0xA0EBB943C300E693 Old:0x52816BD4


function HUD.DISPLAY_RADAR(toggle)


  Velora.invoke(0x9E1110,"void", toggle)


end


function HUD.SET_FAKE_SPECTATOR_MODE(toggle)


  Velora.invoke(0x9E1140,"void", toggle)


end


function HUD.GET_FAKE_SPECTATOR_MODE()


  return Velora.invoke(0x9E11C0,"bool")


end


-- PC:0xA86478C6958735C5 Old:0x40BADA1D


function HUD.IS_HUD_HIDDEN()


  return Velora.invoke(0x9E1170,"bool")


end


-- PC:0x157F93B036700462 Old:0x1AB3B954


function HUD.IS_RADAR_HIDDEN()


  return Velora.invoke(0x9E1190,"bool")


end


-- PC:0xAF754F20EB5CD51A Old:0x9CD18314


function HUD.IS_MINIMAP_RENDERING()


  return Velora.invoke(0x9E11B0,"bool")


end


function HUD.USE_VEHICLE_TARGETING_RETICULE(p0)


  Velora.invoke(0x9E11C0,"void", p0)


end


function HUD.ADD_VALID_VEHICLE_HIT_HASH(p0)


  Velora.invoke(0x9E1200,"void", p0)


end


function HUD.CLEAR_VALID_VEHICLE_HIT_HASHES()


  Velora.invoke(0x9E12B0,"void")


end


-- PC:0x4F7D8A9BFB0B43E9 Old:0x3E160C90


function HUD.SET_BLIP_ROUTE(blip, enabled)


  Velora.invoke(0x9E12F0,"void", blip, enabled)


end


function HUD.CLEAR_ALL_BLIP_ROUTES()


  Velora.invoke(0x9E1310,"void")


end


-- PC:0x837155CD2F63DA09 Old:0xDDE7C65C


function HUD.SET_BLIP_ROUTE_COLOUR(blip, colour)


  Velora.invoke(0x9E1320,"void", blip, colour)


end


function HUD.SET_FORCE_SHOW_GPS(toggle)


  Velora.invoke(0x9E1340,"void", toggle)


end


function HUD.SET_USE_SET_DESTINATION_IN_PAUSE_MAP(toggle)


  Velora.invoke(0x9E1360,"void", toggle)


end


function HUD.SET_BLOCK_WANTED_FLASH(disabled)


  Velora.invoke(0x9E1380,"void", disabled)


end


-- PC:0x60296AF4BA14ABC5 Old:0xB58B25BD


function HUD.ADD_NEXT_MESSAGE_TO_PREVIOUS_BRIEFS(p0)


  Velora.invoke(0x9E13A0,"void", p0)


end


-- PC:0x57D760D55F54E071 Old:0x9854485F


function HUD.FORCE_NEXT_MESSAGE_TO_PREVIOUS_BRIEFS_LIST(p0)


  Velora.invoke(0x9E13C0,"void", p0)


end


-- PC:0xBD12C5EEE184C337 Old:0xDCA3F423


function HUD.SET_RADAR_ZOOM_PRECISE(zoom)


  Velora.invoke(0x9E13E0,"void", zoom)


end


-- PC:0x096EF57A0C999BBA Old:0x2A50D1A6


function HUD.SET_RADAR_ZOOM(zoomLevel)


  Velora.invoke(0x9E1420,"void", zoomLevel)


end


-- PC:0xF98E4B3E56AFC7B1 Old:0x25EC28C0


function HUD.SET_RADAR_ZOOM_TO_BLIP(blip, zoom)


  Velora.invoke(0x9E14D0,"void", blip, zoom)


end


-- PC:0xCB7CC0D58405AD41 Old:0x09CF1CE5


function HUD.SET_RADAR_ZOOM_TO_DISTANCE(zoom)


  Velora.invoke(0x9E15A0,"void", zoom)


end


-- PC:0xD2049635DEB9C375 Old:0xE8D3A910


function HUD.UPDATE_RADAR_ZOOM_TO_BLIP()


  Velora.invoke(0x9E15E0,"void")


end


-- PC:0x7C9C91AB74A0360F Old:0x63F66A0B


function HUD.GET_HUD_COLOUR(hudColorIndex)


  Velora.invoke(0x9E15F0,"void", hudColorIndex)


end


-- PC:0xD68A5FF8A3A89874 Old:0x0E41E45C


function HUD.SET_SCRIPT_VARIABLE_HUD_COLOUR(r, g, b, a)


  Velora.invoke(0x9E1650,"void", r, g, b, a)


end


-- PC:0x16A304E6CB2BFAB9 Old:0x6BE3ACA8


function HUD.SET_SECOND_SCRIPT_VARIABLE_HUD_COLOUR(r, g, b, a)


  Velora.invoke(0x9E1670,"void", r, g, b, a)


end


-- PC:0x1CCC708F0F850613 Old:0x3B216749


function HUD.REPLACE_HUD_COLOUR(hudColorIndex, hudColorIndex2)


  Velora.invoke(0x9E1690,"void", hudColorIndex, hudColorIndex2)


end


-- PC:0xF314CF4F0211894E Old:0xF6E7E92B


function HUD.REPLACE_HUD_COLOUR_WITH_RGBA(hudColorIndex, r, g, b, a)


  Velora.invoke(0x9E16D0,"void", hudColorIndex, r, g, b, a)


end


function HUD.SET_ABILITY_BAR_VISIBILITY(visible)


  Velora.invoke(0x9E1700,"void", visible)


end


function HUD.SET_ALLOW_ABILITY_BAR(toggle)


  Velora.invoke(0x9E1720,"void", toggle)


end


-- PC:0x02CFBA0C9E9275CE Old:0x3648960D


function HUD.FLASH_ABILITY_BAR(millisecondsToFlash)


  Velora.invoke(0x9E1750,"void", millisecondsToFlash)


end


-- PC:0x9969599CCFF5D85E Old:0x24E53FD8


function HUD.SET_ABILITY_BAR_VALUE(p0, p1)


  Velora.invoke(0x9E1760,"void", p0, p1)


end


-- PC:0xA18AFB39081B6A1F Old:0x629F866B


function HUD.FLASH_WANTED_DISPLAY(p0)


  Velora.invoke(0x9E1780,"void", p0)


end


-- PC:0xBA8D65C1C65702E5 Old:0x58612465


function HUD.FORCE_OFF_WANTED_STAR_FLASH(toggle)


  Velora.invoke(0x9E17A0,"void", toggle)


end


function HUD.SET_CUSTOM_MP_HUD_COLOR(hudColorId)


  Velora.invoke(0x9E17C0,"void", hudColorId)


end


-- PC:0xDB88A37483346780 Old:0x3330175B


function HUD.GET_RENDERED_CHARACTER_HEIGHT(size, font)


  return Velora.invoke(0x9E18D0,"float", size, font)


end


-- PC:0x07C837F9A01C34C9 Old:0xB6E15B23


function HUD.SET_TEXT_SCALE(scale, size)


  Velora.invoke(0x9E18D0,"void", scale, size)


end


-- PC:0xBE6B23FFA53FB442 Old:0xE54DD2C8


function HUD.SET_TEXT_COLOUR(red, green, blue, alpha)


  Velora.invoke(0x9E18F0,"void", red, green, blue, alpha)


end


-- PC:0xC02F4DBFB51D988B Old:0xE26D39A1


function HUD.SET_TEXT_CENTRE(align)


  Velora.invoke(0x9E1930,"void", align)


end


-- PC:0x6B3C4650BC8BEE47 Old:0x45B60520


function HUD.SET_TEXT_RIGHT_JUSTIFY(toggle)


  Velora.invoke(0x9E1950,"void", toggle)


end


-- PC:0x4E096588B13FFECA Old:0x68CDFA60


function HUD.SET_TEXT_JUSTIFICATION(justifyType)


  Velora.invoke(0x9E1970,"void", justifyType)


end


-- PC:0x63145D9C883A1A70 Old:0x6F60AB54


function HUD.SET_TEXT_WRAP(start, p_end)


  Velora.invoke(0x9E19A0,"void", start, p_end)


end


-- PC:0xA50ABC31E3CDFAFF Old:0x98CE21D4


function HUD.SET_TEXT_LEADING(p0)


  Velora.invoke(0x9E19C0,"void", p0)


end


-- PC:0x038C1F517D7FDCF8 Old:0xF49D8A08


function HUD.SET_TEXT_PROPORTIONAL(p0)


  Velora.invoke(0x9E19E0,"void", p0)


end


-- PC:0x66E0276CC5F6B9DA Old:0x80BC530D


function HUD.SET_TEXT_FONT(fontType)


  Velora.invoke(0x9E19F0,"void", fontType)


end


-- PC:0x1CA3E9EAC9D93E5E Old:0xE2A11511


function HUD.SET_TEXT_DROP_SHADOW()


  Velora.invoke(0x9E1A10,"void")


end


-- PC:0x465C84BC39F1C351 Old:0xE6587517


function HUD.SET_TEXT_DROPSHADOW(distance, r, g, b, a)


  Velora.invoke(0x9E1A20,"void", distance, r, g, b, a)


end


-- PC:0x2513DFB0FB8400FE Old:0xC753412F


function HUD.SET_TEXT_OUTLINE()


  Velora.invoke(0x9E1A40,"void")


end


-- PC:0x441603240D202FA6 Old:0x3F1A5DAB


function HUD.SET_TEXT_EDGE(p0, r, g, b, a)


  Velora.invoke(0x9E1A50,"void", p0, r, g, b, a)


end


-- PC:0x5F15302936E07111 Old:0xC5C3B7F3


function HUD.SET_TEXT_RENDER_ID(renderId)


  Velora.invoke(0x9E1A60,"void", renderId)


end


-- PC:0x52F0982D7FD156B6 Old:0x8188935F


function HUD.GET_DEFAULT_SCRIPT_RENDERTARGET_RENDER_ID()


  return Velora.invoke(0x9E1C20,"int")


end


-- PC:0x57D9C12635E25CE3 Old:0xFAE5D6F0


function HUD.REGISTER_NAMED_RENDERTARGET(name, p1)


  return Velora.invoke(0x9E1AE0,"bool", name, p1)


end


-- PC:0x78DCDC15C9F116B4 Old:0x284057F5


function HUD.IS_NAMED_RENDERTARGET_REGISTERED(name)


  return Velora.invoke(0x9E1BA0,"bool", name)


end


-- PC:0xE9F6FFE837354DD4 Old:0xD3F6C892


function HUD.RELEASE_NAMED_RENDERTARGET(name)


  return Velora.invoke(0x9E1BE0,"bool", name)


end


-- PC:0xF6C09E276AEB3F2D Old:0x6844C4B9


function HUD.LINK_NAMED_RENDERTARGET(modelHash)


  Velora.invoke(0x9E1C20,"void", modelHash)


end


-- PC:0x1A6478B61C6BDC3B Old:0xF9D7A401


function HUD.GET_NAMED_RENDERTARGET_RENDER_ID(name)


  return Velora.invoke(0x9E1DD0,"int", name)


end


-- PC:0x113750538FA31298 Old:0x8B52601F


function HUD.IS_NAMED_RENDERTARGET_LINKED(modelHash)


  return Velora.invoke(0x9E1D10,"bool", modelHash)


end


-- PC:0x8DFCED7A656F8802 Old:0xE6D85741


function HUD.CLEAR_HELP(toggle)


  Velora.invoke(0x9E1DD0,"void", toggle)


end


-- PC:0xDAD37F45428801AE Old:0x4B3C9CA9


function HUD.IS_HELP_MESSAGE_ON_SCREEN()


  return Velora.invoke(0x9E1EB0,"bool")


end


-- PC:0x214CD562A939246A Old:0x812CBE0E


function HUD.HAS_SCRIPT_HIDDEN_HELP_THIS_FRAME()


  return Velora.invoke(0x9E1E50,"bool")


end


-- PC:0x4D79439A6B55AC67 Old:0xA65F262A


function HUD.IS_HELP_MESSAGE_BEING_DISPLAYED()


  return Velora.invoke(0x9E1E70,"bool")


end


-- PC:0x327EDEEEAC55C369 Old:0x3E50AE92


function HUD.IS_HELP_MESSAGE_FADING_OUT()


  return Velora.invoke(0x9E1E90,"bool")


end


function HUD.SET_HELP_MESSAGE_STYLE(style, hudColor, alpha, p3, p4)


  Velora.invoke(0x9E1EB0,"void", style, hudColor, alpha, p3, p4)


end


-- PC:0x4A9923385BDB9DAD Old:0x87871CE0


function HUD.GET_STANDARD_BLIP_ENUM_ID()


  return Velora.invoke(0x9E2380,"int")


end


-- PC:0x186E5D252FA50E7D Old:0xB9827942


function HUD.GET_WAYPOINT_BLIP_ENUM_ID()


  return Velora.invoke(0x9E1EE0,"int")


end


-- PC:0x9A3FF3DE163034E8 Old:0x144020FA


function HUD.GET_NUMBER_OF_ACTIVE_BLIPS()


  return Velora.invoke(0x9E1EF0,"int")


end


-- PC:0x14F96AA50D6FBEA7 Old:0x9356E92F


function HUD.GET_NEXT_BLIP_INFO_ID(blipSprite)


  return Velora.invoke(0x9E1F60,"int", blipSprite)


end


-- PC:0x1BEDE233E6CD2A1F Old:0x64C0273D


function HUD.GET_FIRST_BLIP_INFO_ID(blipSprite)


  return Velora.invoke(0x9E1F80,"int", blipSprite)


end


function HUD.GET_CLOSEST_BLIP_INFO_ID(blipSprite)


  return Velora.invoke(0x9E1FB0,"int", blipSprite)


end


-- PC:0xFA7C7F0AADF25D09 Old:0xB7374A66


function HUD.GET_BLIP_INFO_ID_COORD(blip)


  local x,y,z=Velora.invoke(0x9E1FD0,"vector3", blip)


  return {x=x,y=y,z=z}


end


-- PC:0x1E314167F701DC3B Old:0xD0FC19F4


function HUD.GET_BLIP_INFO_ID_DISPLAY(blip)


  return Velora.invoke(0x9E2080,"int", blip)


end


-- PC:0xBE9B0959FFD0779B Old:0x501D7B4E


function HUD.GET_BLIP_INFO_ID_TYPE(blip)


  return Velora.invoke(0x9E20C0,"int", blip)


end


-- PC:0x4BA4E2553AFEDC2C Old:0xA068C40B


function HUD.GET_BLIP_INFO_ID_ENTITY_INDEX(blip)


  return Velora.invoke(0x9E2100,"int", blip)


end


-- PC:0xBC8DBDCA2436F7E8 Old:0x005A2A47


function HUD.GET_BLIP_FROM_ENTITY(entity)


  return Velora.invoke(0x9E2180,"int", entity)


end


-- PC:0x46818D79B1F7499A Old:0x4626756C


function HUD.ADD_BLIP_FOR_RADIUS(posX, posY, posZ, radius)


  return Velora.invoke(0x9E21A0,"int", posX, posY, posZ, radius)


end


function HUD.ADD_BLIP_FOR_AREA(x, y, z, width, height)


  return Velora.invoke(0x9E2260,"int", x, y, z, width, height)


end


-- PC:0x5CDE92C702A8FCE7 Old:0x30822554


function HUD.ADD_BLIP_FOR_ENTITY(entity)


  return Velora.invoke(0x9E2290,"int", entity)


end


-- PC:0xBE339365C863BD36 Old:0x16693C3A


function HUD.ADD_BLIP_FOR_PICKUP(pickup)


  return Velora.invoke(0x9E22B0,"int", pickup)


end


-- PC:0x5A039BB0BCA604B6 Old:0xC6F43D0E


function HUD.ADD_BLIP_FOR_COORD(x, y, z)


  return Velora.invoke(0x9E22D0,"int", x, y, z)


end


-- PC:0x72DD432F3CDFC0EE Old:0xBF25E7B2


function HUD.TRIGGER_SONAR_BLIP(posX, posY, posZ, radius, p4)


  Velora.invoke(0x9E2380,"void", posX, posY, posZ, radius, p4)


end


-- PC:0x60734CC207C9833C Old:0xE7E1E32B


function HUD.ALLOW_SONAR_BLIPS(toggle)


  Velora.invoke(0x9E23F0,"void", toggle)


end


-- PC:0xAE2AF67E9D9AF65D Old:0x680A34D4


function HUD.SET_BLIP_COORDS(blip, posX, posY, posZ)


  Velora.invoke(0x9E2410,"void", blip, posX, posY, posZ)


end


-- PC:0x586AFE3FF72D996E Old:0xEF6FF47B


function HUD.GET_BLIP_COORDS(blip)


  local x,y,z=Velora.invoke(0x9E2560,"vector3", blip)


  return {x=x,y=y,z=z}


end


-- PC:0xDF735600A4696DAF Old:0x8DBBB0B9


function HUD.SET_BLIP_SPRITE(blip, spriteId)


  Velora.invoke(0x9E2560,"void", blip, spriteId)


end


-- PC:0x1FC877464A04FC4F Old:0x72FF2E73


function HUD.GET_BLIP_SPRITE(blip)


  return Velora.invoke(0x9E25C0,"int", blip)


end


function HUD.SET_COP_BLIP_SPRITE(p0, p1)


  Velora.invoke(0x9E25C0,"void", p0, p1)


end


function HUD.SET_COP_BLIP_SPRITE_AS_STANDARD()


  Velora.invoke(0x9E25E0,"void")


end


-- PC:0xEAA0FFE120D92784 Old:0xAC8A5461


function HUD.SET_BLIP_NAME_FROM_TEXT_FILE(blip, gxtEntry)


  Velora.invoke(0x9E2600,"void", blip, gxtEntry)


end


-- PC:0x127DE7B20C60A6A3 Old:0x03A0B8F9


function HUD.SET_BLIP_NAME_TO_PLAYER_NAME(blip, player)


  Velora.invoke(0x9E2640,"void", blip, player)


end


-- PC:0x45FF974EEE1C8734 Old:0xA791FCCD


function HUD.SET_BLIP_ALPHA(blip, alpha)


  Velora.invoke(0x9E2680,"void", blip, alpha)


end


-- PC:0x970F608F0EE6C885 Old:0x297AF6C8


function HUD.GET_BLIP_ALPHA(blip)


  return Velora.invoke(0x9E2700,"int", blip)


end


-- PC:0x2AEE8F8390D2298C Old:0xA5999031


function HUD.SET_BLIP_FADE(blip, opacity, duration)


  Velora.invoke(0x9E2700,"void", blip, opacity, duration)


end


function HUD.GET_BLIP_FADE_DIRECTION(blip)


  return Velora.invoke(0x9E2760,"int", blip)


end


-- PC:0xF87683CDF73C3F6E Old:0x6B8F44FE


function HUD.SET_BLIP_ROTATION(blip, rotation)


  Velora.invoke(0x9E2760,"void", blip, rotation)


end


function HUD.SET_BLIP_ROTATION_WITH_FLOAT(blip, heading)


  Velora.invoke(0x9E2780,"void", blip, heading)


end


function HUD.GET_BLIP_ROTATION(blip)


  return Velora.invoke(0x9E27E0,"int", blip)


end


-- PC:0xD3CD6FD297AE87CC Old:0x8D5DF611


function HUD.SET_BLIP_FLASH_TIMER(blip, duration)


  Velora.invoke(0x9E27E0,"void", blip, duration)


end


-- PC:0xAA51DB313C010A7E Old:0xEAF67377


function HUD.SET_BLIP_FLASH_INTERVAL(blip, p1)


  Velora.invoke(0x9E2800,"void", blip, p1)


end


-- PC:0x03D7FB09E75D6B7E Old:0xBB3C5A41


function HUD.SET_BLIP_COLOUR(blip, color)


  Velora.invoke(0x9E2820,"void", blip, color)


end


-- PC:0x14892474891E09EB Old:0xC6384D32


function HUD.SET_BLIP_SECONDARY_COLOUR(blip, r, g, b)


  Velora.invoke(0x9E2840,"void", blip, r, g, b)


end


-- PC:0xDF729E8D20CF7327 Old:0xDD6A1E54


function HUD.GET_BLIP_COLOUR(blip)


  return Velora.invoke(0x9E2A60,"int", blip)


end


-- PC:0x729B5F1EFBC0AAEE Old:0xE88B4BC2


function HUD.GET_BLIP_HUD_COLOUR(blip)


  return Velora.invoke(0x9E2900,"int", blip)


end


-- PC:0xDA5F8727EB75B926 Old:0x1226765A


function HUD.IS_BLIP_SHORT_RANGE(blip)


  return Velora.invoke(0x9E29A0,"bool", blip)


end


-- PC:0xE41CA53051197A27 Old:0x258CBA3A


function HUD.IS_BLIP_ON_MINIMAP(blip)


  return Velora.invoke(0x9E29E0,"bool", blip)


end


-- PC:0xDD2238F57B977751 Old:0x3E47F357


function HUD.DOES_BLIP_HAVE_GPS_ROUTE(blip)


  return Velora.invoke(0x9E2A20,"bool", blip)


end


-- PC:0x54318C915D27E4CE Old:0x43996428


function HUD.SET_BLIP_HIDDEN_ON_LEGEND(blip, toggle)


  Velora.invoke(0x9E2A60,"void", blip, toggle)


end


-- PC:0xE2590BC29220CEBB Old:0xD5842BFF


function HUD.SET_BLIP_HIGH_DETAIL(blip, toggle)


  Velora.invoke(0x9E2A80,"void", blip, toggle)


end


-- PC:0x24AC0137444F9FD5 Old:0x802FB686


function HUD.SET_BLIP_AS_MISSION_CREATOR_BLIP(blip, toggle)


  Velora.invoke(0x9E2AA0,"void", blip, toggle)


end


-- PC:0x26F49BF3381D933D Old:0x24ACC4E9


function HUD.IS_MISSION_CREATOR_BLIP(blip)


  return Velora.invoke(0x9E2B90,"bool", blip)


end


-- PC:0x5C90988E7C8E1AF4 Old:0xFFD7476C


function HUD.GET_NEW_SELECTED_MISSION_CREATOR_BLIP()


  return Velora.invoke(0x9E2B00,"int")


end


-- PC:0x4167EFE0527D706E Old:0xC5EB849A


function HUD.IS_HOVERING_OVER_MISSION_CREATOR_BLIP()


  return Velora.invoke(0x9E2B40,"bool")


end


-- PC:0xF1A6C18B35BCADE6 Old:0xA2CAAB4F


function HUD.SHOW_START_MISSION_INSTRUCTIONAL_BUTTON(toggle)


  Velora.invoke(0x9E2B90,"void", toggle)


end


function HUD.SHOW_CONTACT_INSTRUCTIONAL_BUTTON(toggle)


  Velora.invoke(0x9E2BE0,"void", toggle)


end


function HUD.RELOAD_MAP_MENU()


  Velora.invoke(0x9E2C80,"void")


end


function HUD.SET_BLIP_MARKER_LONG_DISTANCE(p0, p1)


  Velora.invoke(0x9E2CA0,"void", p0, p1)


end


-- PC:0xB14552383D39CE3E Old:0xC0047F15


function HUD.SET_BLIP_FLASHES(blip, toggle)


  Velora.invoke(0x9E2CC0,"void", blip, toggle)


end


-- PC:0x2E8D9498C56DD0D1 Old:0x1A81202B


function HUD.SET_BLIP_FLASHES_ALTERNATE(blip, toggle)


  Velora.invoke(0x9E2CE0,"void", blip, toggle)


end


-- PC:0xA5E41FD83AD6CEF0 Old:0x52E111D7


function HUD.IS_BLIP_FLASHING(blip)


  return Velora.invoke(0x9E2D40,"bool", blip)


end


-- PC:0xBE8BE4FE60E27B72 Old:0x5C67725E


function HUD.SET_BLIP_AS_SHORT_RANGE(blip, toggle)


  Velora.invoke(0x9E2D40,"void", blip, toggle)


end


-- PC:0xD38744167B2FA257 Old:0x1E6EC434


function HUD.SET_BLIP_SCALE(blip, scale)


  Velora.invoke(0x9E2D60,"void", blip, scale)


end


function HUD.SET_BLIP_SCALE_2D(blip, xScale, yScale)


  Velora.invoke(0x9E2D80,"void", blip, xScale, yScale)


end


-- PC:0xAE9FC9EF6A9FAC79 Old:0xCE87DA6F


function HUD.SET_BLIP_PRIORITY(blip, priority)


  Velora.invoke(0x9E2DF0,"void", blip, priority)


end


-- PC:0x9029B2F3DA924928 Old:0x2B521F91


function HUD.SET_BLIP_DISPLAY(blip, displayId)


  Velora.invoke(0x9E2E10,"void", blip, displayId)


end


-- PC:0x234CDD44D996FD9A Old:0xEF72F533


function HUD.SET_BLIP_CATEGORY(blip, index)


  Velora.invoke(0x9E2E30,"void", blip, index)


end


-- PC:0x86A652570E5F25DD Old:0xD8C3C1CD


function HUD.REMOVE_BLIP(blip)


  Velora.invoke(0x9E2E50,"void", blip)


end


-- PC:0x6F6F290102C02AB4 Old:0xF290CFD8


function HUD.SET_BLIP_AS_FRIENDLY(blip, toggle)


  Velora.invoke(0x9E2EC0,"void", blip, toggle)


end


-- PC:0x742D6FD43115AF73 Old:0x44253855


function HUD.PULSE_BLIP(blip)


  Velora.invoke(0x9E2EE0,"void", blip)


end


-- PC:0xA3C0B359DCB848B6 Old:0x7BFC66C6


function HUD.SHOW_NUMBER_ON_BLIP(blip, number)


  Velora.invoke(0x9E2F00,"void", blip, number)


end


-- PC:0x532CFF637EF80148 Old:0x0B6D610D


function HUD.HIDE_NUMBER_ON_BLIP(blip)


  Velora.invoke(0x9E2F30,"void", blip)


end


-- PC:0x75A16C3DA34F1245 Old:0x1D99F676


function HUD.SHOW_HEIGHT_ON_BLIP(blip, toggle)


  Velora.invoke(0x9E2F50,"void", blip, toggle)


end


-- PC:0x74513EA3E505181E Old:0x3DCF0092


function HUD.SHOW_TICK_ON_BLIP(blip, toggle)


  Velora.invoke(0x9E2F70,"void", blip, toggle)


end


function HUD.SHOW_GOLD_TICK_ON_BLIP(blip, toggle)


  Velora.invoke(0x9E2F90,"void", blip, toggle)


end


function HUD.SHOW_FOR_SALE_ICON_ON_BLIP(blip, toggle)


  Velora.invoke(0x9E2FB0,"void", blip, toggle)


end


-- PC:0x5FBCA48327B914DF Old:0xD1C3D71B


function HUD.SHOW_HEADING_INDICATOR_ON_BLIP(blip, toggle)


  Velora.invoke(0x9E2FD0,"void", blip, toggle)


end


-- PC:0xB81656BC81FE24D1 Old:0x8DE82C15


function HUD.SHOW_OUTLINE_INDICATOR_ON_BLIP(blip, toggle)


  Velora.invoke(0x9E2FF0,"void", blip, toggle)


end


-- PC:0x23C3EB807312F01A Old:0x4C8F02B4


function HUD.SHOW_FRIEND_INDICATOR_ON_BLIP(blip, toggle)


  Velora.invoke(0x9E3010,"void", blip, toggle)


end


-- PC:0xDCFB5D4DB8BF367E Old:0xABBE1E45


function HUD.SHOW_CREW_INDICATOR_ON_BLIP(blip, toggle)


  Velora.invoke(0x9E3030,"void", blip, toggle)


end


-- PC:0xC4278F70131BAA6D Old:0x6AA6A1CC


function HUD.SET_BLIP_EXTENDED_HEIGHT_THRESHOLD(blip, toggle)


  Velora.invoke(0x9E3050,"void", blip, toggle)


end


function HUD.SET_BLIP_SHORT_HEIGHT_THRESHOLD(p0, p1)


  Velora.invoke(0x9E3070,"void", p0, p1)


end


-- PC:0x2C9F302398E13141 Old:0xCA95C487


function HUD.SET_BLIP_USE_HEIGHT_INDICATOR_ON_EDGE(blip, p1)


  Velora.invoke(0x9E3090,"void", blip, p1)


end


-- PC:0x2B6D467DAB714E8D Old:0xC575F0BC


function HUD.SET_BLIP_AS_MINIMAL_ON_EDGE(blip, toggle)


  Velora.invoke(0x9E30B0,"void", blip, toggle)


end


-- PC:0x25615540D894B814 Old:0x40E25DB8


function HUD.SET_RADIUS_BLIP_EDGE(blip, toggle)


  Velora.invoke(0x9E30D0,"void", blip, toggle)


end


-- PC:0xA6DB27D19ECBB7DA Old:0xAE92DD96


function HUD.DOES_BLIP_EXIST(blip)


  return Velora.invoke(0x9E3120,"bool", blip)


end


-- PC:0xA7E4E2D361C2627F Old:0xB3496E1B


function HUD.SET_WAYPOINT_OFF()


  Velora.invoke(0x9E3120,"void")


end


-- PC:0xD8E694757BCEA8E9 Old:0x62BABF2C


function HUD.DELETE_WAYPOINTS_FROM_THIS_PLAYER()


  Velora.invoke(0x9E3130,"void")


end


-- PC:0x81FA173F170560D1 Old:0xB395D753


function HUD.REFRESH_WAYPOINT()


  Velora.invoke(0x9E3150,"void")


end


-- PC:0x1DD1F58F493F1DA5 Old:0x5E4DF47B


function HUD.IS_WAYPOINT_ACTIVE()


  return Velora.invoke(0x9E3190,"bool")


end


-- PC:0xFE43368D2AA4F2FC Old:0x8444E1F0


function HUD.SET_NEW_WAYPOINT(x, y)


  Velora.invoke(0x9E3190,"void", x, y)


end


-- PC:0xB203913733F27884 Old:0x72BEE6DF


function HUD.SET_BLIP_BRIGHT(blip, toggle)


  Velora.invoke(0x9E3250,"void", blip, toggle)


end


-- PC:0x13127EC3665E8EE1 Old:0xFF545AD8


function HUD.SET_BLIP_SHOW_CONE(blip, toggle, hudColorIndex)


  Velora.invoke(0x9E3270,"void", blip, toggle, hudColorIndex)


end


-- PC:0xC594B315EDF2D4AF Old:0x41B0D022


function HUD.REMOVE_COP_BLIP_FROM_PED(ped)


  Velora.invoke(0x9E32C0,"void", ped)


end


function HUD.SETUP_FAKE_CONE_DATA(blip, p1, p2, p3, p4, p5, p6, p7, p8)


  Velora.invoke(0x9E3310,"void", blip, p1, p2, p3, p4, p5, p6, p7, p8)


end


function HUD.REMOVE_FAKE_CONE_DATA(blip)


  Velora.invoke(0x9E3350,"void", blip)


end


function HUD.CLEAR_FAKE_CONE_ARRAY()


  Velora.invoke(0x9E3360,"void")


end


-- PC:0x75A9A10948D1DEA6 Old:0x419DCDC4


function HUD.SET_MINIMAP_COMPONENT(componentId, toggle, overrideColor)


  return Velora.invoke(0x9E3400,"bool", componentId, toggle, overrideColor)


end


function HUD.SET_MINIMAP_SONAR_SWEEP(toggle)


  Velora.invoke(0x9E3400,"void", toggle)


end


function HUD.SHOW_ACCOUNT_PICKER()


  Velora.invoke(0x9E3420,"void")


end


-- PC:0xDCD4EC3F419D02FA Old:0xAB93F020


function HUD.GET_MAIN_PLAYER_BLIP_ID()


  return Velora.invoke(0x9E3470,"int")


end


function HUD.SET_PM_WARNINGSCREEN_ACTIVE(p0)


  Velora.invoke(0x9E3470,"void", p0)


end


-- PC:0x4B0311D3CDC4648F Old:0x35087963


function HUD.HIDE_LOADING_ON_FADE_THIS_FRAME()


  Velora.invoke(0x9E3490,"void")


end


-- PC:0x59E727A1C9D3E31A Old:0x6F2626E1


function HUD.SET_RADAR_AS_INTERIOR_THIS_FRAME(interior, x, y, z, zoom)


  Velora.invoke(0x9E34A0,"void", interior, x, y, z, zoom)


end


function HUD.SET_INSIDE_VERY_SMALL_INTERIOR(toggle)


  Velora.invoke(0x9E34F0,"void", toggle)


end


function HUD.SET_INSIDE_VERY_LARGE_INTERIOR(toggle)


  Velora.invoke(0x9E3510,"void", toggle)


end


-- PC:0xE81B7D2A3DAB2D81 Old:0x39ABB10E


function HUD.SET_RADAR_AS_EXTERIOR_THIS_FRAME()


  Velora.invoke(0x9E3530,"void")


end


-- PC:0x77E2DD177910E1CF Old:0x54E75C7D


function HUD.SET_FAKE_PAUSEMAP_PLAYER_POSITION_THIS_FRAME(x, y)


  Velora.invoke(0x9E3540,"void", x, y)


end


function HUD.SET_FAKE_GPS_PLAYER_POSITION_THIS_FRAME(x, y, p2)


  Velora.invoke(0x9E3560,"void", x, y, p2)


end


-- PC:0x9049FE339D5F6F6F Old:0x199DED14


function HUD.IS_PAUSEMAP_IN_INTERIOR_MODE()


  return Velora.invoke(0x9E35A0,"bool")


end


-- PC:0x5FBAE526203990C9 Old:0x1A4318F7


function HUD.HIDE_MINIMAP_EXTERIOR_MAP_THIS_FRAME()


  Velora.invoke(0x9E35A0,"void")


end


-- PC:0x20FE7FDFEEAD38C0 Old:0xCE36E3FE


function HUD.HIDE_MINIMAP_INTERIOR_MAP_THIS_FRAME()


  Velora.invoke(0x9E35B0,"void")


end


function HUD.SET_USE_ISLAND_MAP(toggle)


  Velora.invoke(0x9E35C0,"void", toggle)


end


-- PC:0x6D14BFDC33B34F55 Old:0x334EFD46


function HUD.DONT_TILT_MINIMAP_THIS_FRAME()


  Velora.invoke(0x9E35F0,"void")


end


function HUD.DONT_ZOOM_MINIMAP_WHEN_RUNNING_THIS_FRAME()


  Velora.invoke(0x9E3600,"void")


end


-- PC:0x55F5A5F07134DE60 Old:0x7A569F78


function HUD.DONT_ZOOM_MINIMAP_WHEN_SNIPING_THIS_FRAME()


  Velora.invoke(0x9E3610,"void")


end


-- PC:0xC3B07BA00A83B0F1 Old:0xF016E08F


function HUD.SET_WIDESCREEN_FORMAT(p0)


  Velora.invoke(0x9E3620,"void", p0)


end


-- PC:0x276B6CE369C33678 Old:0x489FDD41


function HUD.DISPLAY_AREA_NAME(toggle)


  Velora.invoke(0x9E3640,"void", toggle)


end


-- PC:0x96DEC8D5430208B7 Old:0x0049DF83


function HUD.DISPLAY_CASH(toggle)


  Velora.invoke(0x9E3660,"void", toggle)


end


-- PC:0x170F541E1CADD1DE Old:0x6253B9D7


function HUD.USE_FAKE_MP_CASH(toggle)


  Velora.invoke(0x9E3680,"void", toggle)


end


-- PC:0x0772DF77852C2E30 Old:0xE319F90B


function HUD.CHANGE_FAKE_MP_CASH(cash, bank)


  Velora.invoke(0x9E36A0,"void", cash, bank)


end


-- PC:0xA5E78BA2B1331C55 Old:0x60693CEE


function HUD.DISPLAY_AMMO_THIS_FRAME(display)


  Velora.invoke(0x9E36B0,"void", display)


end


-- PC:0x73115226F4814E62 Old:0xBC6C73CB


function HUD.DISPLAY_SNIPER_SCOPE_THIS_FRAME()


  Velora.invoke(0x9E36D0,"void")


end


-- PC:0x719FF505F097FD20 Old:0xB75D4AD2


function HUD.HIDE_HUD_AND_RADAR_THIS_FRAME()


  Velora.invoke(0x9E36E0,"void")


end


-- PC:0xE67C6DFD386EA5E7 Old:0x5476B9FD


function HUD.ALLOW_DISPLAY_OF_MULTIPLAYER_CASH_TEXT(allow)


  Velora.invoke(0x9E36F0,"void", allow)


end


-- PC:0xC2D15BEF167E27BC Old:0xF4F3C796


function HUD.SET_MULTIPLAYER_WALLET_CASH()


  Velora.invoke(0x9E3710,"void")


end


-- PC:0x95CF81BD06EE1887 Old:0x7BFFE82F


function HUD.REMOVE_MULTIPLAYER_WALLET_CASH()


  Velora.invoke(0x9E3730,"void")


end


-- PC:0xDD21B55DF695CD0A Old:0x2C842D03


function HUD.SET_MULTIPLAYER_BANK_CASH()


  Velora.invoke(0x9E3750,"void")


end


-- PC:0xC7C6789AA1CFEDD0 Old:0x728B4EF4


function HUD.REMOVE_MULTIPLAYER_BANK_CASH()


  Velora.invoke(0x9E3770,"void")


end


-- PC:0xFD1D220394BCB824 Old:0xA8DB435E


function HUD.SET_MULTIPLAYER_HUD_CASH(p0, p1)


  Velora.invoke(0x9E3790,"void", p0, p1)


end


-- PC:0x968F270E39141ECA Old:0x07BF4A7D


function HUD.REMOVE_MULTIPLAYER_HUD_CASH()


  Velora.invoke(0x9E37A0,"void")


end


-- PC:0xD46923FC481CA285 Old:0xF3807BED


function HUD.HIDE_HELP_TEXT_THIS_FRAME()


  Velora.invoke(0x9E37D0,"void")


end


function HUD.IS_IME_IN_PROGRESS()


  return Velora.invoke(0x9E37F0,"bool")


end


-- PC:0x960C9FF8F616E41C Old:0x18E3360A


function HUD.DISPLAY_HELP_TEXT_THIS_FRAME(message, p1)


  Velora.invoke(0x9E37F0,"void", message, p1)


end


-- PC:0xEB354E5376BC81A7 Old:0x1EFFB02A


function HUD.HUD_FORCE_WEAPON_WHEEL(show)


  Velora.invoke(0x9E3850,"void", show)


end


function HUD.HUD_FORCE_SPECIAL_VEHICLE_WEAPON_WHEEL()


  Velora.invoke(0x9E3870,"void")


end


-- PC:0x0AFC4AF510774B47 Old:0xB26FED2B


function HUD.HUD_SUPPRESS_WEAPON_WHEEL_RESULTS_THIS_FRAME()


  Velora.invoke(0x9E3880,"void")


end


-- PC:0xA48931185F0536FE Old:0x22E9F555


function HUD.HUD_GET_WEAPON_WHEEL_CURRENTLY_HIGHLIGHTED()


  return Velora.invoke(0x9E38B0,"int")


end


-- PC:0x72C1056D678BB7D8 Old:0x83B608A0


function HUD.HUD_SET_WEAPON_WHEEL_TOP_SLOT(weaponHash)


  Velora.invoke(0x9E38B0,"void", weaponHash)


end


function HUD.HUD_GET_WEAPON_WHEEL_TOP_SLOT(weaponTypeIndex)


  return Velora.invoke(0x9E3960,"int", weaponTypeIndex)


end


-- PC:0x14C9FDCC41F81F63 Old:0xE70D1F43


function HUD.HUD_SHOWING_CHARACTER_SWITCH_SELECTION(toggle)


  Velora.invoke(0x9E3960,"void", toggle)


end


-- PC:0x5B440763A4C8D15B Old:0x60539BAB


function HUD.SET_GPS_FLAGS(p0, p1)


  Velora.invoke(0x9E3980,"void", p0, p1)


end


-- PC:0x21986729D6A3A830 Old:0x056AFCE6


function HUD.CLEAR_GPS_FLAGS()


  Velora.invoke(0x9E39B0,"void")


end


-- PC:0x1EAC5F91BCBC5073 Old:0xFB9BABF5


function HUD.SET_RACE_TRACK_RENDER(toggle)


  Velora.invoke(0x9E39D0,"void", toggle)


end


-- PC:0x7AA5B4CE533C858B Old:0x40C59829


function HUD.CLEAR_GPS_RACE_TRACK()


  Velora.invoke(0x9E39F0,"void")


end


-- PC:0xDB34E8D56FC13B08 Old:0x7F93799B


function HUD.START_GPS_CUSTOM_ROUTE(hudColor, displayOnFoot, followPlayer)


  Velora.invoke(0x9E3A00,"void", hudColor, displayOnFoot, followPlayer)


end


-- PC:0x311438A071DD9B1A Old:0xEEBDFE55


function HUD.ADD_POINT_TO_GPS_CUSTOM_ROUTE(x, y, z)


  Velora.invoke(0x9E3A20,"void", x, y, z)


end


-- PC:0x900086F371220B6F Old:0xDA0AF00E


function HUD.SET_GPS_CUSTOM_ROUTE_RENDER(toggle, radarThickness, mapThickness)


  Velora.invoke(0x9E3A80,"void", toggle, radarThickness, mapThickness)


end


-- PC:0xE6DE0561D9232A64 Old:0xCF2E3E24


function HUD.CLEAR_GPS_CUSTOM_ROUTE()


  Velora.invoke(0x9E3AA0,"void")


end


-- PC:0x3D3D15AF7BCAAF83 Old:0xC3DCBEDB


function HUD.START_GPS_MULTI_ROUTE(hudColor, routeFromPlayer, displayOnFoot)


  Velora.invoke(0x9E3AC0,"void", hudColor, routeFromPlayer, displayOnFoot)


end


-- PC:0xA905192A6781C41B Old:0xFE485135


function HUD.ADD_POINT_TO_GPS_MULTI_ROUTE(x, y, z)


  Velora.invoke(0x9E3AE0,"void", x, y, z)


end


-- PC:0x3DDA37128DD1ACA8 Old:0xE87CBE4C


function HUD.SET_GPS_MULTI_ROUTE_RENDER(toggle)


  Velora.invoke(0x9E3B40,"void", toggle)


end


-- PC:0x67EEDEA1B9BAFD94 Old:0x0D9969E4


function HUD.CLEAR_GPS_MULTI_ROUTE()


  Velora.invoke(0x9E3B60,"void")


end


-- PC:0xFF4FB7C8CDFA3DA7 Old:0x0B9C7FC2


function HUD.CLEAR_GPS_PLAYER_WAYPOINT()


  Velora.invoke(0x9E3B70,"void")


end


-- PC:0x320D0E0D936A0E9B Old:0xE991F733


function HUD.SET_GPS_FLASHES(toggle)


  Velora.invoke(0x9E3B90,"void", toggle)


end


function HUD.SET_PLAYER_ICON_COLOUR(color)


  Velora.invoke(0x9E3BB0,"void", color)


end


-- PC:0xF2DD778C22B15BDA Old:0xB8359952


function HUD.FLASH_MINIMAP_DISPLAY()


  Velora.invoke(0x9E3BC0,"void")


end


-- PC:0x6B1DE27EE78E6A19 Old:0x79A6CAF6


function HUD.FLASH_MINIMAP_DISPLAY_WITH_COLOR(hudColorIndex)


  Velora.invoke(0x9E3BD0,"void", hudColorIndex)


end


-- PC:0x6AFDFB93754950C7 Old:0xC68D47C4


function HUD.TOGGLE_STEALTH_RADAR(toggle)


  Velora.invoke(0x9E3BE0,"void", toggle)


end


-- PC:0x1A5CD7752DD28CD3 Old:0xD5BFCADB


function HUD.SET_MINIMAP_IN_SPECTATOR_MODE(toggle, ped)


  Velora.invoke(0x9E3C00,"void", toggle, ped)


end


-- PC:0x5F28ECF5FC84772F Old:0x68DCAE10


function HUD.SET_MISSION_NAME(p0, name)


  Velora.invoke(0x9E3C70,"void", p0, name)


end


-- PC:0xE45087D85F468BC2 Old:0x8D9A1734


function HUD.SET_MISSION_NAME_FOR_UGC_MISSION(p0, name)


  Velora.invoke(0x9E3C90,"void", p0, name)


end


-- PC:0x817B86108EB94E51 Old:0xD2161E77


function HUD.SET_DESCRIPTION_FOR_UGC_MISSION_EIGHT_STRINGS(p0, p1, p2, p3, p4, p5, p6, p7, p8)


  Velora.invoke(0x9E3D00,"void", p0, p1, p2, p3, p4, p5, p6, p7, p8)


end


-- PC:0x58FADDED207897DC Old:0xA41C3B62


function HUD.SET_MINIMAP_BLOCK_WAYPOINT(toggle)


  Velora.invoke(0x9E3D50,"void", toggle)


end


-- PC:0x9133955F1A2DA957 Old:0x02F5F1D1


function HUD.SET_MINIMAP_IN_PROLOGUE(toggle)


  Velora.invoke(0x9E3D70,"void", toggle)


end


-- PC:0xF8DEE0A5600CBB93 Old:0xD8D77733


function HUD.SET_MINIMAP_HIDE_FOW(toggle)


  Velora.invoke(0x9E3DA0,"void", toggle)


end


-- PC:0xE0130B41D3CF4574 Old:0xA4098ACC


function HUD.GET_MINIMAP_FOW_DISCOVERY_RATIO()


  return Velora.invoke(0x9E3E50,"float")


end


-- PC:0x6E31B91145873922 Old:0x65B705F6


function HUD.GET_MINIMAP_FOW_COORDINATE_IS_REVEALED(x, y, z)


  return Velora.invoke(0x9E3DE0,"bool", x, y, z)


end


function HUD.SET_MINIMAP_FOW_DO_NOT_UPDATE(p0)


  Velora.invoke(0x9E3E50,"void", p0)


end


-- PC:0x0923DBF87DFF735E Old:0xE010F081


function HUD.SET_MINIMAP_FOW_REVEAL_COORDINATE(x, y, z)


  Velora.invoke(0x9E3E70,"void", x, y, z)


end


-- PC:0x71BDB63DBAF8DA59 Old:0x5133A750


function HUD.SET_MINIMAP_GOLF_COURSE(hole)


  Velora.invoke(0x9E3EC0,"void", hole)


end


-- PC:0x35EDD5B2E3FF01C0 Old:0x20FD3E87


function HUD.SET_MINIMAP_GOLF_COURSE_OFF()


  Velora.invoke(0x9E3ED0,"void")


end


-- PC:0x299FAEBB108AE05B Old:0xDEC733E4


function HUD.LOCK_MINIMAP_ANGLE(angle)


  Velora.invoke(0x9E3EE0,"void", angle)


end


-- PC:0x8183455E16C42E3A Old:0x742043F9


function HUD.UNLOCK_MINIMAP_ANGLE()


  Velora.invoke(0x9E3F00,"void")


end


-- PC:0x1279E861A329E73F Old:0xB9632A91


function HUD.LOCK_MINIMAP_POSITION(x, y)


  Velora.invoke(0x9E3F10,"void", x, y)


end


-- PC:0x3E93E06DB8EF1F30 Old:0x5E8E6F54


function HUD.UNLOCK_MINIMAP_POSITION()


  Velora.invoke(0x9E3F30,"void")


end


-- PC:0xD201F3FF917A506D Old:0x0308EDF6


function HUD.SET_FAKE_MINIMAP_MAX_ALTIMETER_HEIGHT(altitude, p1, p2)


  Velora.invoke(0x9E3F50,"void", altitude, p1, p2)


end


-- PC:0x3F5CC444DCAAA8F2 Old:0x7FB6FB2A


function HUD.SET_HEALTH_HUD_DISPLAY_VALUES(health, capacity, wasAdded)


  Velora.invoke(0x9E3F80,"void", health, capacity, wasAdded)


end


-- PC:0x975D66A0BC17064C Old:0xF07D8CEF


function HUD.SET_MAX_HEALTH_HUD_DISPLAY(maximumValue)


  Velora.invoke(0x9E3FA0,"void", maximumValue)


end


-- PC:0x06A320535F5F0248 Old:0x827F14DE


function HUD.SET_MAX_ARMOUR_HUD_DISPLAY(maximumValue)


  Velora.invoke(0x9E3FB0,"void", maximumValue)


end


-- PC:0x231C8F89D0539D8F Old:0x08EB83D2


function HUD.SET_BIGMAP_ACTIVE(toggleBigMap, showFullMap)


  Velora.invoke(0x9E3FC0,"void", toggleBigMap, showFullMap)


end


-- PC:0xBC4C9EA5391ECC0D Old:0x6214631F


function HUD.IS_HUD_COMPONENT_ACTIVE(id)


  return Velora.invoke(0x9E4070,"bool", id)


end


-- PC:0xDD100EB17A94FF65 Old:0x2B86F382


function HUD.IS_SCRIPTED_HUD_COMPONENT_ACTIVE(id)


  return Velora.invoke(0x9E4030,"bool", id)


end


-- PC:0xE374C498D8BADC14 Old:0x31ABA127


function HUD.HIDE_SCRIPTED_HUD_COMPONENT_THIS_FRAME(id)


  Velora.invoke(0x9E4070,"void", id)


end


function HUD.SHOW_SCRIPTED_HUD_COMPONENT_THIS_FRAME(id)


  Velora.invoke(0x9E4090,"void", id)


end


-- PC:0x09C0403ED9A751C2 Old:0xE8C8E535


function HUD.IS_SCRIPTED_HUD_COMPONENT_HIDDEN_THIS_FRAME(id)


  return Velora.invoke(0x9E40F0,"bool", id)


end


-- PC:0x6806C51AD12B83B8 Old:0xDB2D0762


function HUD.HIDE_HUD_COMPONENT_THIS_FRAME(id)


  Velora.invoke(0x9E40F0,"void", id)


end


-- PC:0x0B4DF1FA60C0E664 Old:0x95E1546E


function HUD.SHOW_HUD_COMPONENT_THIS_FRAME(id)


  Velora.invoke(0x9E4150,"void", id)


end


-- PC:0xA4DEDE28B1814289 Old:0x52746FE1


function HUD.HIDE_STREET_AND_CAR_NAMES_THIS_FRAME()


  Velora.invoke(0x9E4170,"void")


end


-- PC:0x12782CE0A636E9F0 Old:0xBE27AA3F


function HUD.RESET_RETICULE_VALUES()


  Velora.invoke(0x9E4180,"void")


end


-- PC:0x450930E616475D0D Old:0xD15B46DA


function HUD.RESET_HUD_COMPONENT_VALUES(id)


  Velora.invoke(0x9E4190,"void", id)


end


-- PC:0xAABB1F56E2A17CED Old:0x2F3A0D15


function HUD.SET_HUD_COMPONENT_POSITION(id, x, y)


  Velora.invoke(0x9E41B0,"void", id, x, y)


end


-- PC:0x223CA69A8C4417FD Old:0x080DCED6


function HUD.GET_HUD_COMPONENT_POSITION(id)


  local x,y,z=Velora.invoke(0x9E42D0,"vector3", id)


  return {x=x,y=y,z=z}


end


-- PC:0xB57D8DD645CFA2CF Old:0x5BBCC934


function HUD.CLEAR_REMINDER_MESSAGE()


  Velora.invoke(0x9E42D0,"void")


end


-- PC:0xF9904D11F1ACBEC3 Old:0xFE9A39F8


function HUD.GET_HUD_SCREEN_POSITION_FROM_WORLD_POSITION(worldX, worldY, worldZ)


  return Velora.invoke(0x9E4380,"int", worldX, worldY, worldZ)


end


-- PC:0x523A590C1A3CC0D3 Old:0x10DE5150


function HUD.OPEN_REPORTUGC_MENU()


  Velora.invoke(0x9E4380,"void")


end


-- PC:0xEE4C0E6DBC6F2C6F Old:0x67649EE0


function HUD.FORCE_CLOSE_REPORTUGC_MENU()


  Velora.invoke(0x9E43B0,"void")


end


-- PC:0x9135584D09A3437E Old:0x9D2C94FA


function HUD.IS_REPORTUGC_MENU_OPEN()


  return Velora.invoke(0x9E44B0,"bool")


end


-- PC:0x2432784ACA090DA4 Old:0x45472FD5


function HUD.IS_FLOATING_HELP_TEXT_ON_SCREEN(hudIndex)


  return Velora.invoke(0x9E4440,"bool", hudIndex)


end


-- PC:0x7679CC1BCEBE3D4C Old:0x198F32D7


function HUD.SET_FLOATING_HELP_TEXT_SCREEN_POSITION(hudIndex, x, y)


  Velora.invoke(0x9E44B0,"void", hudIndex, x, y)


end


-- PC:0x784BA7E0ECEB4178 Old:0x93045157


function HUD.SET_FLOATING_HELP_TEXT_WORLD_POSITION(hudIndex, x, y, z)


  Velora.invoke(0x9E4510,"void", hudIndex, x, y, z)


end


-- PC:0xB094BC1DB4018240 Old:0x18B012B7


function HUD.SET_FLOATING_HELP_TEXT_TO_ENTITY(hudIndex, entity, offsetX, offsetY)


  Velora.invoke(0x9E4570,"void", hudIndex, entity, offsetX, offsetY)


end


-- PC:0x788E7FD431BD67F1 Old:0x97852A82


function HUD.SET_FLOATING_HELP_TEXT_STYLE(hudIndex, p1, p2, p3, p4, p5)


  Velora.invoke(0x9E4610,"void", hudIndex, p1, p2, p3, p4, p5)


end


-- PC:0x50085246ABD3FEFA Old:0xB181F88F


function HUD.CLEAR_FLOATING_HELP(hudIndex, p1)


  Velora.invoke(0x9E4630,"void", hudIndex, p1)


end


-- PC:0x6DD05E9D83EFA4C9 Old:0xC969F2D0


function HUD.CREATE_MP_GAMER_TAG_WITH_CREW_COLOR(player, username, pointedClanTag, isRockstarClan, clanTag, clanFlag, r, g, b)


  Velora.invoke(0x9E4650,"void", player, username, pointedClanTag, isRockstarClan, clanTag, clanFlag, r, g, b)


end


-- PC:0x6E0EB3EB47C8D7AA Old:0xEFD2564A


function HUD.IS_MP_GAMER_TAG_MOVIE_ACTIVE()


  return Velora.invoke(0x9E4890,"bool")


end


-- PC:0xBFEFE3321A3F5015 Old:0xF5CD2AA4


function HUD.CREATE_FAKE_MP_GAMER_TAG(ped, username, pointedClanTag, isRockstarClan, clanTag, clanFlag)


  return Velora.invoke(0x9E4760,"int", ped, username, pointedClanTag, isRockstarClan, clanTag, clanFlag)


end


-- PC:0x31698AA80E0223F8 Old:0x3D081FE4


function HUD.REMOVE_MP_GAMER_TAG(gamerTagId)


  Velora.invoke(0x9E4890,"void", gamerTagId)


end


-- PC:0x4E929E7A5796FD26 Old:0x60118951


function HUD.IS_MP_GAMER_TAG_ACTIVE(gamerTagId)


  return Velora.invoke(0x9E4910,"bool", gamerTagId)


end


-- PC:0x595B5178E412E199 Old:0x63959059


function HUD.IS_MP_GAMER_TAG_FREE(gamerTagId)


  return Velora.invoke(0x9E48E0,"bool", gamerTagId)


end


-- PC:0x63BB75ABEDC1F6A0 Old:0xD41DF479


function HUD.SET_MP_GAMER_TAG_VISIBILITY(gamerTagId, component, toggle, p3)


  Velora.invoke(0x9E4910,"void", gamerTagId, component, toggle, p3)


end


-- PC:0xEE76FF7E6A0166B0 Old:0x767DED29


function HUD.SET_ALL_MP_GAMER_TAGS_VISIBILITY(gamerTagId, toggle)


  Velora.invoke(0x9E4950,"void", gamerTagId, toggle)


end


-- PC:0xA67F9C46D612B6F1 Old:0xB01A5434


function HUD.SET_MP_GAMER_TAGS_SHOULD_USE_VEHICLE_HEALTH(gamerTagId, toggle)


  Velora.invoke(0x9E4980,"void", gamerTagId, toggle)


end


function HUD.SET_MP_GAMER_TAGS_SHOULD_USE_POINTS_HEALTH(gamerTagId, toggle)


  Velora.invoke(0x9E49B0,"void", gamerTagId, toggle)


end


function HUD.SET_MP_GAMER_TAGS_POINT_HEALTH(gamerTagId, value, maximumValue)


  Velora.invoke(0x9E49E0,"void", gamerTagId, value, maximumValue)


end


-- PC:0x613ED644950626AE Old:0x7E3AA40A


function HUD.SET_MP_GAMER_TAG_COLOUR(gamerTagId, component, hudColorIndex)


  Velora.invoke(0x9E4A10,"void", gamerTagId, component, hudColorIndex)


end


-- PC:0x3158C77A7E888AB4 Old:0x5777EC77


function HUD.SET_MP_GAMER_TAG_HEALTH_BAR_COLOUR(gamerTagId, hudColorIndex)


  Velora.invoke(0x9E4A40,"void", gamerTagId, hudColorIndex)


end


-- PC:0xD48FE545CD46F857 Old:0xF4418611


function HUD.SET_MP_GAMER_TAG_ALPHA(gamerTagId, component, alpha)


  Velora.invoke(0x9E4A70,"void", gamerTagId, component, alpha)


end


-- PC:0xCF228E2AA03099C3 Old:0x0EBB003F


function HUD.SET_MP_GAMER_TAG_WANTED_LEVEL(gamerTagId, wantedlvl)


  Velora.invoke(0x9E4AA0,"void", gamerTagId, wantedlvl)


end


function HUD.SET_MP_GAMER_TAG_NUM_PACKAGES(gamerTagId, p1)


  Velora.invoke(0x9E4AD0,"void", gamerTagId, p1)


end


-- PC:0xDEA2B8283BAA3944 Old:0x627A559B


function HUD.SET_MP_GAMER_TAG_NAME(gamerTagId, string)


  Velora.invoke(0x9E4B00,"void", gamerTagId, string)


end


-- PC:0xEB709A36958ABE0D Old:0xF11414C4


function HUD.IS_UPDATING_MP_GAMER_TAG_NAME_AND_CREW_DETAILS(gamerTagId)


  return Velora.invoke(0x9E4B70,"bool", gamerTagId)


end


-- PC:0x7B7723747CCB55B6 Old:0x939218AB


function HUD.SET_MP_GAMER_TAG_BIG_TEXT(gamerTagId, string)


  Velora.invoke(0x9E4B70,"void", gamerTagId, string)


end


-- PC:0x01A358D9128B7A86 Old:0xAB5B7C18


function HUD.GET_CURRENT_WEBPAGE_ID()


  return Velora.invoke(0x9E4BF0,"int")


end


-- PC:0x97D47996FC48CBAD Old:0x42A55B14


function HUD.GET_CURRENT_WEBSITE_ID()


  return Velora.invoke(0x9E4BB0,"int")


end


-- PC:0xE3B05614DCE1D014 Old:0xD217EE7E


function HUD.GET_GLOBAL_ACTIONSCRIPT_FLAG(flagIndex)


  return Velora.invoke(0x9E4BC0,"int", flagIndex)


end


-- PC:0xB99C4E4D9499DF29 Old:0x4C4C10CF


function HUD.RESET_GLOBAL_ACTIONSCRIPT_FLAG(flagIndex)


  Velora.invoke(0x9E4BF0,"void", flagIndex)


end


function HUD.IS_WARNING_MESSAGE_READY_FOR_CONTROL()


  return Velora.invoke(0x9E4C60,"bool")


end


-- PC:0x7B1776B3B53F8D74 Old:0xBE699BDE


function HUD.SET_WARNING_MESSAGE(titleMsg, flags, promptMsg, p3, p4, p5, p6, showBackground, errorCode)


  Velora.invoke(0x9E4C60,"void", titleMsg, flags, promptMsg, p3, p4, p5, p6, showBackground, errorCode)


end


-- PC:0xDC38CC1E35B6A5D7 Old:0x2DB9EAB5


function HUD.SET_WARNING_MESSAGE_WITH_HEADER(entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, showBackground, p7, p8, p9)


  Velora.invoke(0x9E4D80,"void", entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, showBackground, p7, p8, p9)


end


-- PC:0x701919482C74B5AB Old:0x749929D3


function HUD.SET_WARNING_MESSAGE_WITH_HEADER_AND_SUBSTRING_FLAGS(entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, additionalIntInfo, additionalTextInfoLine1, additionalTextInfoLine2, showBackground, errorCode)


  Velora.invoke(0x9E4DF0,"void", entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, additionalIntInfo, additionalTextInfoLine1, additionalTextInfoLine2, showBackground, errorCode)


end


function HUD.SET_WARNING_MESSAGE_WITH_HEADER_EXTENDED(entryHeader, entryLine1, flags, entryLine2, p4, p5, p6, p7, showBg, p9, p10)


  Velora.invoke(0x9E4E60,"void", entryHeader, entryLine1, flags, entryLine2, p4, p5, p6, p7, showBg, p9, p10)


end


function HUD.SET_WARNING_MESSAGE_WITH_HEADER_AND_SUBSTRING_FLAGS_EXTENDED(labelTitle, labelMessage, p2, p3, labelMessage2, p5, p6, p7, p8, p9, background, errorCode)


  Velora.invoke(0x9E4ED0,"void", labelTitle, labelMessage, p2, p3, labelMessage2, p5, p6, p7, p8, p9, background, errorCode)


end


function HUD.GET_WARNING_SCREEN_MESSAGE_HASH()


  return Velora.invoke(0x9E4FE0,"int")


end


function HUD.SET_WARNING_MESSAGE_OPTION_ITEMS(index, name, cash, rp, lvl, colour)


  return Velora.invoke(0x9E4F70,"bool", index, name, cash, rp, lvl, colour)


end


function HUD.SET_WARNING_MESSAGE_OPTION_HIGHLIGHT(p0)


  return Velora.invoke(0x9E4FB0,"bool", p0)


end


function HUD.REMOVE_WARNING_MESSAGE_OPTION_ITEMS()


  Velora.invoke(0x9E4FE0,"void")


end


-- PC:0xE18B138FABC53103 Old:0x94C834AD


function HUD.IS_WARNING_MESSAGE_ACTIVE()


  return Velora.invoke(0x9E5030,"bool")


end


-- PC:0x7792424AA0EAC32E Old:0x2F9A309C


function HUD.CLEAR_DYNAMIC_PAUSE_MENU_ERROR_MESSAGE()


  Velora.invoke(0x9E5030,"void")


end


-- PC:0x5354C5BA2EA868A4 Old:0xE4FD20D8


function HUD.CUSTOM_MINIMAP_SET_ACTIVE(toggle)


  Velora.invoke(0x9E5050,"void", toggle)


end


-- PC:0x1EAE6DD17B7A5EFA Old:0x13E7A5A9


function HUD.CUSTOM_MINIMAP_SET_BLIP_OBJECT(spriteId)


  Velora.invoke(0x9E5070,"void", spriteId)


end


-- PC:0x551DF99658DB6EE8 Old:0x786CA0A2


function HUD.CUSTOM_MINIMAP_CREATE_BLIP(x, y, z)


  return Velora.invoke(0x9E50F0,"int", x, y, z)


end


-- PC:0x2708FC083123F9FF Old:0xCBEC9369


function HUD.CUSTOM_MINIMAP_CLEAR_BLIPS()


  Velora.invoke(0x9E50F0,"void")


end


-- PC:0x1121BFA1A1A522A8 Old:0x3F4AFB13


function HUD.FORCE_SONAR_BLIPS_THIS_FRAME()


  return Velora.invoke(0x9E5120,"bool")


end


function HUD.GET_NORTH_BLID_INDEX()


  return Velora.invoke(0x9E5110,"int")


end


-- PC:0x82CEDC33687E1F50 Old:0x2F28F0A6


function HUD.DISPLAY_PLAYER_NAME_TAGS_ON_BLIPS(toggle)


  Velora.invoke(0x9E5120,"void", toggle)


end


-- PC:0x211C4EF450086857 Old:0x801D0D86


function HUD.DRAW_FRONTEND_BACKGROUND_THIS_FRAME()


  Velora.invoke(0x9E5140,"void")


end


-- PC:0xBF4F34A85CA2970C Old:0x317775DF


function HUD.DRAW_HUD_OVER_FADE_THIS_FRAME()


  Velora.invoke(0x9E5150,"void")


end


-- PC:0xEF01D36B9C9D0C7B Old:0x01D83872


function HUD.ACTIVATE_FRONTEND_MENU(menuhash, togglePause, component)


  Velora.invoke(0x9E5160,"void", menuhash, togglePause, component)


end


-- PC:0x10706DC6AD2D49C0 Old:0xB07DAF98


function HUD.RESTART_FRONTEND_MENU(menuHash, p1)


  Velora.invoke(0x9E51B0,"void", menuHash, p1)


end


-- PC:0x2309595AD6145265 Old:0x33D6868F


function HUD.GET_CURRENT_FRONTEND_MENU_VERSION()


  return Velora.invoke(0x9E5220,"int")


end


-- PC:0xDF47FC56C71569CF Old:0x1DCD878E


function HUD.SET_PAUSE_MENU_ACTIVE(toggle)


  Velora.invoke(0x9E5220,"void", toggle)


end


-- PC:0x6D3465A73092F0E6 Old:0xD86A029E


function HUD.DISABLE_FRONTEND_THIS_FRAME()


  Velora.invoke(0x9E5240,"void")


end


-- PC:0xBA751764F0821256 Old:0x7F349900


function HUD.SUPPRESS_FRONTEND_RENDERING_THIS_FRAME()


  Velora.invoke(0x9E5250,"void")


end


-- PC:0xCC3FDDED67BCFC63 Old:0x630CD8EE


function HUD.ALLOW_PAUSE_WHEN_NOT_IN_STATE_OF_PLAY_THIS_FRAME()


  Velora.invoke(0x9E5260,"void")


end


-- PC:0x745711A75AB09277 Old:0x81E1AD32


function HUD.SET_FRONTEND_ACTIVE(active)


  Velora.invoke(0x9E5270,"void", active)


end


-- PC:0xB0034A223497FFCB Old:0xD3600591


function HUD.IS_PAUSE_MENU_ACTIVE()


  return Velora.invoke(0x9E5390,"bool")


end


-- PC:0x2F057596F2BD0061 Old:0xC85C4487


function HUD.IS_STORE_PENDING_NETWORK_SHUTDOWN_TO_OPEN()


  return Velora.invoke(0x9E52C0,"bool")


end


-- PC:0x272ACD84970869C5 Old:0x92F50134


function HUD.GET_PAUSE_MENU_STATE()


  return Velora.invoke(0x9E52D0,"int")


end


function HUD.GET_PAUSE_MENU_POSITION()


  local x,y,z=Velora.invoke(0x9E52F0,"vector3")


  return {x=x,y=y,z=z}


end


-- PC:0x1C491717107431C7 Old:0x3C4CF4D9


function HUD.IS_PAUSE_MENU_RESTARTING()


  return Velora.invoke(0x9E5370,"bool")


end


-- PC:0x2162C446DFDF38FD Old:0x2DFD35C7


function HUD.FORCE_SCRIPTED_GFX_WHEN_FRONTEND_ACTIVE(p0)


  Velora.invoke(0x9E5390,"void", p0)


end


-- PC:0x77F16B447824DA6C Old:0x0A89336C


function HUD.PAUSE_MENUCEPTION_GO_DEEPER(page)


  Velora.invoke(0x9E53A0,"void", page)


end


-- PC:0xCDCA26E80FAECB8F Old:0xC84BE309


function HUD.PAUSE_MENUCEPTION_THE_KICK()


  Velora.invoke(0x9E53B0,"void")


end


function HUD.PAUSE_TOGGLE_FULLSCREEN_MAP(p0)


  Velora.invoke(0x9E53C0,"void", p0)


end


-- PC:0xDD564BDD0472C936 Old:0x9FE8FD5E


function HUD.PAUSE_MENU_ACTIVATE_CONTEXT(contextHash)


  Velora.invoke(0x9E53E0,"void", contextHash)


end


-- PC:0x444D8CF241EC25C5 Old:0x0029046E


function HUD.PAUSE_MENU_DEACTIVATE_CONTEXT(contextHash)


  Velora.invoke(0x9E5420,"void", contextHash)


end


-- PC:0x84698AB38D0C6636 Old:0xC51BC42F


function HUD.PAUSE_MENU_IS_CONTEXT_ACTIVE(contextHash)


  return Velora.invoke(0x9E55A0,"bool", contextHash)


end


-- PC:0x2A25ADC48F87841F Old:0x016D7AF9


function HUD.PAUSE_MENU_IS_CONTEXT_MENU_ACTIVE()


  return Velora.invoke(0x9E54B0,"bool")


end


function HUD.PAUSE_MENU_GET_HAIR_COLOUR_INDEX()


  return Velora.invoke(0x9E5530,"int")


end


function HUD.PAUSE_MENU_GET_MOUSE_HOVER_INDEX()


  return Velora.invoke(0x9E5550,"int")


end


function HUD.PAUSE_MENU_GET_MOUSE_HOVER_UNIQUE_ID()


  return Velora.invoke(0x9E5570,"int")


end


function HUD.PAUSE_MENU_GET_MOUSE_CLICK_EVENT(p0, p1, p2)


  return Velora.invoke(0x9E5590,"bool", p0, p1, p2)


end


-- PC:0x4895BDEA16E7C080 Old:0x15B24768


function HUD.PAUSE_MENU_REDRAW_INSTRUCTIONAL_BUTTONS(p0)


  Velora.invoke(0x9E55A0,"void", p0)


end


-- PC:0xC78E239AC5B2DDB9 Old:0x6C67131A


function HUD.PAUSE_MENU_SET_BUSY_SPINNER(p0, position, spinnerIndex)


  Velora.invoke(0x9E55B0,"void", p0, position, spinnerIndex)


end


-- PC:0xF06EBB91A81E09E3 Old:0x11D09737


function HUD.PAUSE_MENU_SET_WARN_ON_TAB_CHANGE(p0)


  Velora.invoke(0x9E55F0,"void", p0)


end


-- PC:0x3BAB9A4E4F2FF5C7 Old:0xD3BF3ABD


function HUD.IS_FRONTEND_READY_FOR_CONTROL()


  return Velora.invoke(0x9E5650,"bool")


end


-- PC:0xEC9264727EEC0F28 Old:0xC06B763D


function HUD.TAKE_CONTROL_OF_FRONTEND()


  Velora.invoke(0x9E5650,"void")


end


-- PC:0x14621BB1DF14E2B2 Old:0xB9392CE7


function HUD.RELEASE_CONTROL_OF_FRONTEND()


  Velora.invoke(0x9E5660,"void")


end


-- PC:0x66E7CB63C97B7D20 Old:0x92DAFA78


function HUD.CODE_WANTS_SCRIPT_TO_TAKE_CONTROL()


  return Velora.invoke(0x9E56E0,"bool")


end


-- PC:0x593FEAE1F73392D4 Old:0x22CA9F2A


function HUD.GET_SCREEN_CODE_WANTS_SCRIPT_TO_CONTROL()


  return Velora.invoke(0x9E5690,"int")


end


-- PC:0x4E3CD0EF8A489541 Old:0xDA7951A2


function HUD.IS_NAVIGATING_MENU_CONTENT()


  return Velora.invoke(0x9E56B0,"bool")


end


-- PC:0xF284AC67940C6812 Old:0x7D95AFFF


function HUD.HAS_MENU_TRIGGER_EVENT_OCCURRED()


  return Velora.invoke(0x9E56C0,"bool")


end


-- PC:0x2E22FEFA0100275E Old:0x96863460


function HUD.HAS_MENU_LAYOUT_CHANGED_EVENT_OCCURRED()


  return Velora.invoke(0x9E56D0,"bool")


end


function HUD.SET_SAVEGAME_LIST_UNIQUE_ID(p0)


  Velora.invoke(0x9E56E0,"void", p0)


end


-- PC:0x36C1451A88A09630 Old:0x8543AAC8


function HUD.GET_MENU_TRIGGER_EVENT_DETAILS()


  Velora.invoke(0x9E56F0,"void")


end


-- PC:0x7E17BE53E1AAABAF Old:0x6025AA2F


function HUD.GET_MENU_LAYOUT_CHANGED_EVENT_DETAILS()


  Velora.invoke(0x9E5720,"void")


end


-- PC:0xA238192F33110615 Old:0x46794EB2


function HUD.GET_PM_PLAYER_CREW_COLOR()


  return Velora.invoke(0x9E5A20,"bool")


end


-- PC:0xEF4CED81CEBEDC6D Old:0x4370999E


function HUD.GET_MENU_PED_INT_STAT(p0, p1)


  return Velora.invoke(0x9E57F0,"bool", p0, p1)


end


function HUD.GET_CHARACTER_MENU_PED_INT_STAT(p0, p1, p2)


  return Velora.invoke(0x9E5820,"bool", p0, p1, p2)


end


-- PC:0x90A6526CF0381030 Old:0xD6CC4766


function HUD.GET_MENU_PED_MASKED_INT_STAT(statHash, mask, p3)


  return Velora.invoke(0x9E5850,"bool", statHash, mask, p3)


end


function HUD.GET_CHARACTER_MENU_PED_MASKED_INT_STAT(statHash, outValue, p2, mask, p4)


  return Velora.invoke(0x9E58F0,"bool", statHash, outValue, p2, mask, p4)


end


-- PC:0x5FBD7095FE7AE57F Old:0x51972B04


function HUD.GET_MENU_PED_FLOAT_STAT(statHash)


  return Velora.invoke(0x9E5990,"bool", statHash)


end


function HUD.GET_CHARACTER_MENU_PED_FLOAT_STAT(statHash, p2)


  return Velora.invoke(0x9E59C0,"bool", statHash, p2)


end


-- PC:0x052991E59076E4E4 Old:0xD43BB56D


function HUD.GET_MENU_PED_BOOL_STAT(statHash)


  return Velora.invoke(0x9E59F0,"bool", statHash)


end


-- PC:0x5E62BE5DC58E9E06 Old:0x28058ACF


function HUD.CLEAR_PED_IN_PAUSE_MENU()


  Velora.invoke(0x9E5A20,"void")


end


-- PC:0xAC0BFBDC3BE00E14 Old:0x2AD2C9CE


function HUD.GIVE_PED_TO_PAUSE_MENU(ped, p1)


  Velora.invoke(0x9E5A60,"void", ped, p1)


end


-- PC:0x3CA6050692BC61B0 Old:0x127310EB


function HUD.SET_PAUSE_MENU_PED_LIGHTING(state)


  Velora.invoke(0x9E5A70,"void", state)


end


-- PC:0xECF128344E9FF9F1 Old:0x8F45D327


function HUD.SET_PAUSE_MENU_PED_SLEEP_STATE(state)


  Velora.invoke(0x9E5AD0,"void", state)


end


-- PC:0x805D7CBB36FD6C4C Old:0x19FCBBB2


function HUD.OPEN_ONLINE_POLICIES_MENU()


  Velora.invoke(0x9E5B20,"void")


end


-- PC:0xF13FE2A80C05C561 Old:0x850690FF


function HUD.ARE_ONLINE_POLICIES_UP_TO_DATE()


  return Velora.invoke(0x9E5BA0,"bool")


end


-- PC:0x6F72CD94F7B5B68C Old:0x9D4934F4


function HUD.IS_ONLINE_POLICIES_MENU_ACTIVE()


  return Velora.invoke(0x9E5B90,"bool")


end


-- PC:0x75D3691713C3B05A Old:0x57218529


function HUD.OPEN_SOCIAL_CLUB_MENU()


  Velora.invoke(0x9E5BA0,"void")


end


-- PC:0xD2B32BE3FC1626C6 Old:0x5F86AA39


function HUD.CLOSE_SOCIAL_CLUB_MENU()


  Velora.invoke(0x9E5BE0,"void")


end


-- PC:0x9E778248D6685FE0 Old:0x7AD67C95


function HUD.SET_SOCIAL_CLUB_TOUR(name)


  Velora.invoke(0x9E5C00,"void", name)


end


-- PC:0xC406BE343FC4B9AF Old:0xD4DA14EF


function HUD.IS_SOCIAL_CLUB_ACTIVE()


  return Velora.invoke(0x9E5C40,"bool")


end


function HUD.SET_TEXT_INPUT_BOX_ENABLED(p0)


  Velora.invoke(0x9E5C40,"void", p0)


end


function HUD.FORCE_CLOSE_TEXT_INPUT_BOX()


  Velora.invoke(0x9E5C50,"void")


end


function HUD.SET_ALLOW_COMMA_ON_TEXT_INPUT(p0)


  Velora.invoke(0x9E5C60,"void", p0)


end


function HUD.OVERRIDE_MP_TEXT_CHAT_TEAM_STRING(gxtEntryHash)


  Velora.invoke(0x9E5C70,"void", gxtEntryHash)


end


function HUD.IS_MP_TEXT_CHAT_TYPING()


  return Velora.invoke(0x9E5C90,"bool")


end


function HUD.CLOSE_MP_TEXT_CHAT()


  Velora.invoke(0x9E5C90,"void")


end


function HUD.MP_TEXT_CHAT_IS_TEAM_JOB(p0)


  Velora.invoke(0x9E5CA0,"void", p0)


end


function HUD.OVERRIDE_MP_TEXT_CHAT_COLOR(p0, hudColor)


  Velora.invoke(0x9E5CB0,"void", p0, hudColor)


end


function HUD.MP_TEXT_CHAT_DISABLE(toggle)


  Velora.invoke(0x9E5CC0,"void", toggle)


end


-- PC:0xCEF214315D276FD1 Old:0xFF06772A


function HUD.FLAG_PLAYER_CONTEXT_IN_TOURNAMENT(toggle)


  Velora.invoke(0x9E5CD0,"void", toggle)


end


-- PC:0xD30C50DF888D58B5 Old:0x96C4C4DD


function HUD.SET_PED_HAS_AI_BLIP(ped, hasCone)


  Velora.invoke(0x9E5CF0,"void", ped, hasCone)


end


function HUD.SET_PED_HAS_AI_BLIP_WITH_COLOUR(ped, hasCone, color)


  Velora.invoke(0x9E5D30,"void", ped, hasCone, color)


end


-- PC:0x15B8ECF844EE67ED Old:0x3BE1257F


function HUD.DOES_PED_HAVE_AI_BLIP(ped)


  return Velora.invoke(0x9E5DA0,"bool", ped)


end


-- PC:0xE52B8E7F85D39A08 Old:0xD8E31B1A


function HUD.SET_PED_AI_BLIP_GANG_ID(ped, gangId)


  Velora.invoke(0x9E5DA0,"void", ped, gangId)


end


-- PC:0x3EED80DFF7325CAA Old:0x872C2CFB


function HUD.SET_PED_AI_BLIP_HAS_CONE(ped, toggle)


  Velora.invoke(0x9E5DB0,"void", ped, toggle)


end


-- PC:0x0C4BBF625CA98C4E Old:0xFFDF46F0


function HUD.SET_PED_AI_BLIP_FORCED_ON(ped, toggle)


  Velora.invoke(0x9E5DD0,"void", ped, toggle)


end


-- PC:0x97C65887D4B37FA9 Old:0xF9DC2AF7


function HUD.SET_PED_AI_BLIP_NOTICE_RANGE(ped, range)


  Velora.invoke(0x9E5DF0,"void", ped, range)


end


function HUD.SET_PED_AI_BLIP_SPRITE(ped, spriteId)


  Velora.invoke(0x9E5E00,"void", ped, spriteId)


end


-- PC:0x7CD934010E115C2C Old:0x06349065


function HUD.GET_AI_PED_PED_BLIP_INDEX(ped)


  return Velora.invoke(0x9E5E60,"int", ped)


end


-- PC:0x56176892826A4FE8 Old:0xCA52CF43


function HUD.GET_AI_PED_VEHICLE_BLIP_INDEX(ped)


  return Velora.invoke(0x9E5E30,"int", ped)


end


function HUD.HAS_DIRECTOR_MODE_BEEN_LAUNCHED_BY_CODE()


  return Velora.invoke(0x9E5E50,"bool")


end


function HUD.SET_DIRECTOR_MODE_LAUNCHED_BY_SCRIPT()


  Velora.invoke(0x9E5E60,"void")


end


function HUD.SET_PLAYER_IS_IN_DIRECTOR_MODE(toggle)


  Velora.invoke(0x9E5E70,"void", toggle)


end


function HUD.SET_DIRECTOR_MODE_AVAILABLE(toggle)


  Velora.invoke(0x9E5E90,"void", toggle)


end


function HUD.HIDE_HUDMARKERS_THIS_FRAME()


  Velora.invoke(0x9E5EB0,"void")


end


