-- compat_STATS.lua — AUTO GENERATO


-- STATS


STATS=STATS or {}


-- PC:0xEB0A72181D4AA4AD Old:0x84BDD475


function STATS.STAT_CLEAR_SLOT_FOR_RELOAD(statSlot)


  return Velora.invoke(0xACF000,"bool", statSlot)


end


-- PC:0xA651443F437B1CE6 Old:0x9E5629F4


function STATS.STAT_LOAD(statSlot)


  return Velora.invoke(0xACF0B0,"bool", statSlot)


end


-- PC:0xE07BCA305B82D2FD Old:0xE10A7CA4


function STATS.STAT_SAVE(p0, p1, p2, p3)


  return Velora.invoke(0xACF0E0,"bool", p0, p1, p2, p3)


end


-- PC:0x5688585E6D563CD8 Old:0xC62406A6


function STATS.STAT_SET_OPEN_SAVETYPE_IN_JOB(p0)


  Velora.invoke(0xACF120,"void", p0)


end


-- PC:0xA1750FFAFA181661 Old:0x4E9AC983


function STATS.STAT_LOAD_PENDING(statSlot)


  return Velora.invoke(0xACF300,"bool", statSlot)


end


-- PC:0x7D3A583856F2C5AC Old:0xC3FD3822


function STATS.STAT_SAVE_PENDING()


  return Velora.invoke(0xACF180,"bool")


end


-- PC:0xBBB6AD006F1BBEA3 Old:0xA3407CA3


function STATS.STAT_SAVE_PENDING_OR_REQUESTED()


  return Velora.invoke(0xACF1A0,"bool")


end


-- PC:0x49A49BED12794D70 Old:0x2F171B94


function STATS.STAT_DELETE_SLOT(p0)


  return Velora.invoke(0xACF1E0,"bool", p0)


end


-- PC:0x0D0A9F0E7BD91E3C Old:0x7A299C13


function STATS.STAT_SLOT_IS_LOADED(statSlot)


  return Velora.invoke(0xACF250,"bool", statSlot)


end


-- PC:0x7F2C4CDF2E82DF4C Old:0x0BF0F4B2


function STATS.STAT_CLOUD_SLOT_LOAD_FAILED(p0)


  return Velora.invoke(0xACF280,"bool", p0)


end


-- PC:0xE496A53BA5F50A56 Old:0xCE6B62B5


function STATS.STAT_CLOUD_SLOT_LOAD_FAILED_CODE(p0)


  return Velora.invoke(0xACF2B0,"int", p0)


end


-- PC:0xF434A10BA01C37D0 Old:0xCE7A2411


function STATS.STAT_SET_BLOCK_SAVES(toggle)


  Velora.invoke(0xACF300,"void", toggle)


end


function STATS.STAT_GET_BLOCK_SAVES()


  return Velora.invoke(0xACF3C0,"bool")


end


-- PC:0x7E6946F68A38B74F Old:0x22804C20


function STATS.STAT_CLOUD_SLOT_SAVE_FAILED(p0)


  return Velora.invoke(0xACF340,"bool", p0)


end


-- PC:0xA8733668D1047B51 Old:0x395D18B1


function STATS.STAT_CLEAR_PENDING_SAVES(p0)


  Velora.invoke(0xACF3C0,"void", p0)


end


-- PC:0xECB41AC6AB754401 Old:0xED7000C8


function STATS.STAT_LOAD_DIRTY_READ_DETECTED()


  return Velora.invoke(0xACF430,"bool")


end


function STATS.STAT_CLEAR_DIRTY_READ_DETECTED()


  Velora.invoke(0xACF430,"void")


end


-- PC:0xC0E0D686DDFC6EAE Old:0x099FCC86


function STATS.STAT_GET_LOAD_SAFE_TO_PROGRESS_TO_MP_FROM_SP()


  return Velora.invoke(0xACFA50,"bool")


end


-- PC:0xB3271D7AB655B441 Old:0xC9CC1C5C


function STATS.STAT_SET_INT(statName, value, save)


  return Velora.invoke(0xACF4B0,"bool", statName, value, save)


end


-- PC:0x4851997F37FE9B3C Old:0x6CEA96F2


function STATS.STAT_SET_FLOAT(statName, value, save)


  return Velora.invoke(0xACF4E0,"bool", statName, value, save)


end


-- PC:0x4B33C4243DE0C432 Old:0x55D79DFB


function STATS.STAT_SET_BOOL(statName, value, save)


  return Velora.invoke(0xACF520,"bool", statName, value, save)


end


-- PC:0x17695002FD8B2AE0 Old:0xC1224AA7


function STATS.STAT_SET_GXT_LABEL(statName, value, save)


  return Velora.invoke(0xACF560,"bool", statName, value, save)


end


-- PC:0x2C29BFB64F4FCBE4 Old:0x36BE807B


function STATS.STAT_SET_DATE(statName, value, numFields, save)


  return Velora.invoke(0xACF5A0,"bool", statName, value, numFields, save)


end


-- PC:0xA87B2335D12531D7 Old:0xB1EF2E21


function STATS.STAT_SET_STRING(statName, value, save)


  return Velora.invoke(0xACF5E0,"bool", statName, value, save)


end


-- PC:0xDB283FDE680FE72E Old:0x1192C9A3


function STATS.STAT_SET_POS(statName, x, y, z, save)


  return Velora.invoke(0xACF620,"bool", statName, x, y, z, save)


end


-- PC:0x7BBB1B54583ED410 Old:0x2CBAA739


function STATS.STAT_SET_MASKED_INT(statName, p1, p2, p3, save)


  return Velora.invoke(0xACF660,"bool", statName, p1, p2, p3, save)


end


-- PC:0x8CDDF1E452BABE11 Old:0xDBE78ED7


function STATS.STAT_SET_USER_ID(statName, value, save)


  return Velora.invoke(0xACF6A0,"bool", statName, value, save)


end


-- PC:0xC2F84B7F9C4D0C61 Old:0xA286F015


function STATS.STAT_SET_CURRENT_POSIX_TIME(statName, p1)


  return Velora.invoke(0xACF6E0,"bool", statName, p1)


end


-- PC:0x767FBC2AC802EF3D Old:0x1C6FE43E


function STATS.STAT_GET_INT(statHash, p2)


  return Velora.invoke(0xACF710,"bool", statHash, p2)


end


-- PC:0xD7AE6C9C9C6AC54C Old:0xFCBDA612


function STATS.STAT_GET_FLOAT(statHash, p2)


  return Velora.invoke(0xACF7F0,"bool", statHash, p2)


end


-- PC:0x11B5E6D2AE73F48E Old:0x28A3DD2B


function STATS.STAT_GET_BOOL(statHash, p2)


  return Velora.invoke(0xACF820,"bool", statHash, p2)


end


-- PC:0x8B0FACEFC36C824B Old:0xD762D16C


function STATS.STAT_GET_DATE(statHash, outValue, numFields, p3)


  return Velora.invoke(0xACF850,"bool", statHash, outValue, numFields, p3)


end


-- PC:0x350F82CCB186AA1B Old:0xC846ECCE


function STATS.STAT_GET_POS(statName, p4)


  return Velora.invoke(0xACF8B0,"bool", statName, p4)


end


-- PC:0x655185A06D9EEAAB Old:0xE9D9B70F


function STATS.STAT_GET_MASKED_INT(statHash, p2, p3, p4)


  return Velora.invoke(0xACF8F0,"bool", statHash, p2, p3, p4)


end


-- PC:0x69FF13266D7296DA Old:0x3507D253


function STATS.STAT_SET_LICENSE_PLATE(statName, str)


  return Velora.invoke(0xACFA20,"bool", statName, str)


end


-- PC:0x9B5A68C6489E9909 Old:0xDFC5F71E


function STATS.STAT_INCREMENT(statName, value)


  Velora.invoke(0xACFA50,"void", statName, value)


end


-- PC:0x5A556B229A169402 Old:0x46F21343


function STATS.STAT_COMMUNITY_START_SYNCH()


  return Velora.invoke(0xACFB50,"bool")


end


-- PC:0xB1D2BB1E1631F5B1 Old:0x02F283CE


function STATS.STAT_COMMUNITY_SYNCH_IS_PENDING()


  return Velora.invoke(0xACFB00,"bool")


end


-- PC:0xBED9F5693F34ED17 Old:0xC4110917


function STATS.STAT_COMMUNITY_GET_HISTORY(statName, p1)


  return Velora.invoke(0xACFB10,"bool", statName, p1)


end


-- PC:0x26D7399B9587FE89 Old:0x343B27E2


function STATS.STAT_RESET_ALL_ONLINE_CHARACTER_STATS(p0)


  Velora.invoke(0xACFB50,"void", p0)


end


-- PC:0xA78B8FA58200DA56 Old:0xE3247582


function STATS.STAT_LOCAL_RESET_ALL_ONLINE_CHARACTER_STATS(p0)


  Velora.invoke(0xACFB60,"void", p0)


end


-- PC:0xE0E854F5280FB769 Old:0xFD66A429


function STATS.STAT_GET_NUMBER_OF_DAYS(statName)


  return Velora.invoke(0xACFC40,"int", statName)


end


-- PC:0xF2D4B2FE415AAFC3 Old:0x9B431236


function STATS.STAT_GET_NUMBER_OF_HOURS(statName)


  return Velora.invoke(0xACFBE0,"int", statName)


end


-- PC:0x7583B4BE4C5A41B5 Old:0x347B4436


function STATS.STAT_GET_NUMBER_OF_MINUTES(statName)


  return Velora.invoke(0xACFC00,"int", statName)


end


-- PC:0x2CE056FF3723F00B Old:0x2C1D6C31


function STATS.STAT_GET_NUMBER_OF_SECONDS(statName)


  return Velora.invoke(0xACFC20,"int", statName)


end


-- PC:0x68F01422BE1D838F Old:0x24DD4929


function STATS.STAT_SET_PROFILE_SETTING_VALUE(profileSetting, value)


  Velora.invoke(0xACFC40,"void", profileSetting, value)


end


function STATS.STATS_COMPLETED_CHARACTER_CREATION(p0)


  Velora.invoke(0xACFCB0,"void", p0)


end


-- PC:0x94F12ABF9C79E339 Old:0xCA160BCC


function STATS.PACKED_STAT_GET_INT_STAT_INDEX(p0)


  return Velora.invoke(0xAD00F0,"int", p0)


end


-- PC:0x61E111E323419E07 Old:0x1F938864


function STATS.GET_PACKED_INT_STAT_KEY(index, spStat, charStat, character)


  return Velora.invoke(0xACFCF0,"int", index, spStat, charStat, character)


end


-- PC:0xD16C2AD6B8E32854 Old:0xFB93C5A2


function STATS.GET_PACKED_TU_INT_STAT_KEY(index, spStat, charStat, character)


  return Velora.invoke(0xACFDD0,"int", index, spStat, charStat, character)


end


function STATS.GET_PACKED_NG_INT_STAT_KEY(index, spStat, charStat, character, section)


  return Velora.invoke(0xACFEB0,"int", index, spStat, charStat, character, section)


end


function STATS.GET_PACKED_STAT_BOOL_CODE(index, characterSlot)


  return Velora.invoke(0xACFF90,"bool", index, characterSlot)


end


function STATS.GET_PACKED_STAT_INT_CODE(index, characterSlot)


  return Velora.invoke(0xAD0040,"int", index, characterSlot)


end


function STATS.SET_PACKED_STAT_BOOL_CODE(index, value, characterSlot)


  Velora.invoke(0xAD00F0,"void", index, value, characterSlot)


end


function STATS.SET_PACKED_STAT_INT_CODE(index, value, characterSlot)


  Velora.invoke(0xAD0140,"void", index, value, characterSlot)


end


-- PC:0x5009DFD741329729 Old:0x61ECC465


function STATS.PLAYSTATS_BACKGROUND_SCRIPT_ACTION(action, value)


  Velora.invoke(0xAD0190,"void", action, value)


end


-- PC:0x93054C88E6AA7C44 Old:0x598C06F3


function STATS.PLAYSTATS_NPC_INVITE(p0)


  Velora.invoke(0xAD03A0,"void", p0)


end


-- PC:0x46F917F6B4128FE4 Old:0x8770017B


function STATS.PLAYSTATS_AWARD_XP(amount, type, category)


  Velora.invoke(0xAD03B0,"void", amount, type, category)


end


-- PC:0xC7F2DE41D102BFB4 Old:0x56AFB9F5


function STATS.PLAYSTATS_RANK_UP(rank)


  Velora.invoke(0xAD03D0,"void", rank)


end


-- PC:0x098760C7461724CD Old:0x896CDF8D


function STATS.PLAYSTATS_STARTED_SESSION_IN_OFFLINEMODE()


  Velora.invoke(0xAD03E0,"void")


end


-- PC:0xA071E0ED98F91286 Old:0x1A66945F


function STATS.PLAYSTATS_ACTIVITY_DONE(p0, activityId)


  Velora.invoke(0xAD0470,"void", p0, activityId)


end


-- PC:0xC5BE134EC7BA96A0 Old:0xC960E161


function STATS.PLAYSTATS_LEAVE_JOB_CHAIN(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD0510,"void", p0, p1, p2, p3, p4)


end


-- PC:0xC19A2925C34D2231 Old:0x3AAB699C


function STATS.PLAYSTATS_MISSION_STARTED(p0, p1, p2, p3)


  Velora.invoke(0xAD05D0,"void", p0, p1, p2, p3)


end


-- PC:0x7C4BB33A8CED7324 Old:0x5B90B5FF


function STATS.PLAYSTATS_MISSION_OVER(p0, p1, p2, p3, p4, p5)


  Velora.invoke(0xAD05F0,"void", p0, p1, p2, p3, p4, p5)


end


-- PC:0xC900596A63978C1D Old:0xCDC52280


function STATS.PLAYSTATS_MISSION_CHECKPOINT(p0, p1, p2, p3)


  Velora.invoke(0xAD06A0,"void", p0, p1, p2, p3)


end


-- PC:0x71862B1D855F32E1 Old:0xAC2C7C63


function STATS.PLAYSTATS_RANDOM_MISSION_DONE(name, p1, p2, p3)


  Velora.invoke(0xAD06D0,"void", name, p1, p2, p3)


end


-- PC:0x121FB4DDDC2D5291 Old:0x413539BC


function STATS.PLAYSTATS_ROS_BET(amount, act, player, cm)


  Velora.invoke(0xAD0700,"void", amount, act, player, cm)


end


-- PC:0x9C375C315099DDE4 Old:0x580D5508


function STATS.PLAYSTATS_RACE_CHECKPOINT(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD07B0,"void", p0, p1, p2, p3, p4)


end


-- PC:0x6DEE77AFF8C21BD1 Old:0x489E27E7


function STATS.PLAYSTATS_CREATE_MATCH_HISTORY_ID_2()


  return Velora.invoke(0xAD0810,"bool")


end


-- PC:0xBC80E22DED931E3D Old:0x2BDE85C1


function STATS.PLAYSTATS_MATCH_STARTED(p0, p1, p2)


  Velora.invoke(0xAD0810,"void", p0, p1, p2)


end


-- PC:0x176852ACAAC173D1 Old:0xA4746384


function STATS.PLAYSTATS_SHOP_ITEM(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD0830,"void", p0, p1, p2, p3, p4)


end


-- PC:0x1CAE5D2E3F9A07F0 Old:0x6602CED6


function STATS.PLAYSTATS_CRATE_DROP_MISSION_DONE(p0, p1, p2, p3, p4, p5, p6, p7)


  Velora.invoke(0xAD0860,"void", p0, p1, p2, p3, p4, p5, p6, p7)


end


-- PC:0xAFC7E5E075A96F46 Old:0xD003E648


function STATS.PLAYSTATS_CRATE_CREATED(p0, p1, p2)


  Velora.invoke(0xAD0910,"void", p0, p1, p2)


end


-- PC:0xCB00196B31C39EB1 Old:0x759E0EC9


function STATS.PLAYSTATS_HOLD_UP_MISSION_DONE(p0, p1, p2, p3)


  Velora.invoke(0xAD0940,"void", p0, p1, p2, p3)


end


-- PC:0x2B69F5074C894811 Old:0x62073DF7


function STATS.PLAYSTATS_IMPORT_EXPORT_MISSION_DONE(p0, p1, p2, p3)


  Velora.invoke(0xAD0970,"void", p0, p1, p2, p3)


end


-- PC:0xADDD1C754E2E2914 Old:0x06CE3692


function STATS.PLAYSTATS_RACE_TO_POINT_MISSION_DONE(p0, p1, p2, p3)


  Velora.invoke(0xAD09F0,"void", p0, p1, p2, p3)


end


-- PC:0x79AB33F0FBFAC40C Old:0x8D5C7B37


function STATS.PLAYSTATS_ACQUIRED_HIDDEN_PACKAGE(p0)


  Velora.invoke(0xAD0AB0,"void", p0)


end


-- PC:0xDDF24D535060F811 Old:0x37D152BB


function STATS.PLAYSTATS_WEBSITE_VISITED(scaleformHash, p1)


  Velora.invoke(0xAD0AC0,"void", scaleformHash, p1)


end


-- PC:0x0F71DE29AB2258F1 Old:0xD1FA1BDB


function STATS.PLAYSTATS_FRIEND_ACTIVITY(p0, p1)


  Velora.invoke(0xAD0AD0,"void", p0, p1)


end


-- PC:0x69DEA3E9DB727B4C Old:0xFE14A8EA


function STATS.PLAYSTATS_ODDJOB_DONE(totalTimeMs, p1, p2)


  Velora.invoke(0xAD0AE0,"void", totalTimeMs, p1, p2)


end


-- PC:0xBA739D6D5A05D6E7 Old:0x25740A1D


function STATS.PLAYSTATS_PROP_CHANGE(p0, p1, p2, p3)


  Velora.invoke(0xAD0AF0,"void", p0, p1, p2, p3)


end


-- PC:0x34B973047A2268B9 Old:0x3AFF9E58


function STATS.PLAYSTATS_CLOTH_CHANGE(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD0B80,"void", p0, p1, p2, p3, p4)


end


-- PC:0xE95C8A1875A02CA4 Old:0x79716890


function STATS.PLAYSTATS_WEAPON_MODE_CHANGE(weaponHash, componentHashTo, componentHashFrom)


  Velora.invoke(0xAD0C00,"void", weaponHash, componentHashTo, componentHashFrom)


end


-- PC:0x6058665D72302D3F Old:0x345166F3


function STATS.PLAYSTATS_CHEAT_APPLIED(cheat)


  Velora.invoke(0xAD0CC0,"void", cheat)


end


-- PC:0xF8C54A461C3E11DC Old:0x04181752


function STATS.PLAYSTATS_JOB_ACTIVITY_END(p0, p1, p2, p3)


  Velora.invoke(0xAD0CE0,"void", p0, p1, p2, p3)


end


-- PC:0xF5BB8DAC426A52C0 Old:0x40520E70


function STATS.PLAYSTATS_JOB_BEND(p0, p1, p2, p3)


  Velora.invoke(0xAD0D00,"void", p0, p1, p2, p3)


end


-- PC:0xA736CF7FB7C5BFF4 Old:0x31002201


function STATS.PLAYSTATS_JOB_LTS_END(p0, p1, p2, p3)


  Velora.invoke(0xAD0D20,"void", p0, p1, p2, p3)


end


-- PC:0x14E0B2D1AD1044E0 Old:0xDDD1F1F3


function STATS.PLAYSTATS_JOB_LTS_ROUND_END(p0, p1, p2, p3)


  Velora.invoke(0xAD0D40,"void", p0, p1, p2, p3)


end


-- PC:0x90D0622866E80445 Old:0x66FEB701


function STATS.PLAYSTATS_QUICKFIX_TOOL(element, item)


  Velora.invoke(0xAD0D60,"void", element, item)


end


-- PC:0x5DA3A8DE8CB6226F Old:0x9E2B9522


function STATS.PLAYSTATS_IDLE_KICK(msStoodIdle)


  Velora.invoke(0xAD0E10,"void", msStoodIdle)


end


-- PC:0xD1032E482629049E Old:0x1AC97138


function STATS.PLAYSTATS_SET_JOIN_TYPE(joinType)


  Velora.invoke(0xAD0E90,"void", joinType)


end


-- PC:0xF4FF020A08BC8863 Old:0xB731DF54


function STATS.PLAYSTATS_HEIST_SAVE_CHEAT(hash, p1)


  Velora.invoke(0xAD0EA0,"void", hash, p1)


end


function STATS.PLAYSTATS_APPEND_DIRECTOR_METRIC(p0)


  Velora.invoke(0xAD0EB0,"void", p0)


end


function STATS.PLAYSTATS_AWARD_BAD_SPORT(id)


  Velora.invoke(0xAD0F30,"void", id)


end


function STATS.PLAYSTATS_PEGASUS_AS_PERSONAL_AIRCRAFT(modelHash)


  Velora.invoke(0xAD0FA0,"void", modelHash)


end


function STATS.PLAYSTATS_FM_EVENT_CHALLENGES(p0)


  Velora.invoke(0xAD10C0,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_VEHICLETARGET(p0)


  Velora.invoke(0xAD10D0,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_URBANWARFARE(p0)


  Velora.invoke(0xAD10E0,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_CHECKPOINTCOLLECTION(p0)


  Velora.invoke(0xAD10F0,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_ATOB(p0)


  Velora.invoke(0xAD1100,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_PENNEDIN(p0)


  Velora.invoke(0xAD1110,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_PASSTHEPARCEL(p0)


  Velora.invoke(0xAD1120,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_HOTPROPERTY(p0)


  Velora.invoke(0xAD1130,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_DEADDROP(p0)


  Velora.invoke(0xAD1140,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_KINGOFTHECASTLE(p0)


  Velora.invoke(0xAD1150,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_CRIMINALDAMAGE(p0)


  Velora.invoke(0xAD1160,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_COMPETITIVEURBANWARFARE(p0)


  Velora.invoke(0xAD1170,"void", p0)


end


function STATS.PLAYSTATS_FM_EVENT_HUNTBEAST(p0)


  Velora.invoke(0xAD1180,"void", p0)


end


function STATS.PLAYSTATS_PIMENU_HIDE_OPTIONS(data)


  Velora.invoke(0xAD1190,"void", data)


end


-- PC:0x117B45156D7EFF2E Old:0x0A56EE34


function STATS.LEADERBOARDS_GET_NUMBER_OF_COLUMNS(p0, p1)


  return Velora.invoke(0xAD16F0,"int", p0, p1)


end


-- PC:0xC4B5467A1886EA7E Old:0x3821A334


function STATS.LEADERBOARDS_GET_COLUMN_ID(p0, p1, p2)


  return Velora.invoke(0xAD12C0,"int", p0, p1, p2)


end


-- PC:0xBF4FEF46DB7894D3 Old:0x6F2820F4


function STATS.LEADERBOARDS_GET_COLUMN_TYPE(p0, p1, p2)


  return Velora.invoke(0xAD1310,"int", p0, p1, p2)


end


-- PC:0xA34CB6E6F0DF4A0B Old:0x233E058A


function STATS.LEADERBOARDS_READ_CLEAR_ALL()


  return Velora.invoke(0xAD1380,"int")


end


-- PC:0x7CCE5C737A665701 Old:0x7090012F


function STATS.LEADERBOARDS_READ_CLEAR(p0, p1, p2)


  return Velora.invoke(0xAD13C0,"int", p0, p1, p2)


end


-- PC:0xAC392C8483342AC2 Old:0xEEB8BF5C


function STATS.LEADERBOARDS_READ_PENDING(p0, p1, p2)


  return Velora.invoke(0xAD1430,"bool", p0, p1, p2)


end


-- PC:0xA31FD15197B192BD Old:0x1789437B


function STATS.LEADERBOARDS_READ_ANY_PENDING()


  return Velora.invoke(0xAD1460,"bool")


end


-- PC:0x2FB19228983E832C Old:0x3AC5B2F1


function STATS.LEADERBOARDS_READ_SUCCESSFUL(p0, p1, p2)


  return Velora.invoke(0xAD14B0,"bool", p0, p1, p2)


end


-- PC:0x918B101666F9CB83 Old:0xBD91B136


function STATS.LEADERBOARDS2_READ_FRIENDS_BY_ROW(p0, p1, p2, p3, p4, p5)


  return Velora.invoke(0xAD1530,"bool", p0, p1, p2, p3, p4, p5)


end


-- PC:0xC30713A383BFBF0E Old:0x6B553408


function STATS.LEADERBOARDS2_READ_BY_HANDLE(p0, p1)


  return Velora.invoke(0xAD1570,"bool", p0, p1)


end


-- PC:0xA9CDB1E3F0A49883 Old:0xCA931F34


function STATS.LEADERBOARDS2_READ_BY_ROW(p0, p1, p2, p3, p4, p5, p6)


  return Velora.invoke(0xDEADBEEF,"bool", p0, p1, p2, p3, p4, p5, p6)


end


-- PC:0xBA2C7DB0C129449A Old:0x1B03F59F


function STATS.LEADERBOARDS2_READ_BY_RANK(p0, p1, p2)


  return Velora.invoke(0xAD15A0,"bool", p0, p1, p2)


end


-- PC:0x5CE587FB5A42C8C4 Old:0xC5B7E685


function STATS.LEADERBOARDS2_READ_BY_RADIUS(p0, p1, p2)


  return Velora.invoke(0xAD15D0,"bool", p0, p1, p2)


end


-- PC:0x7EEC7E4F6984A16A Old:0xAC020C18


function STATS.LEADERBOARDS2_READ_BY_SCORE_INT(p0, p1, p2)


  return Velora.invoke(0xAD1600,"bool", p0, p1, p2)


end


-- PC:0xE662C8B759D08F3C Old:0xC678B29F


function STATS.LEADERBOARDS2_READ_BY_SCORE_FLOAT(p0, p1, p2)


  return Velora.invoke(0xAD1630,"bool", p0, p1, p2)


end


-- PC:0xC38DC1E90D22547C Old:0x9BEC3401


function STATS.LEADERBOARDS2_READ_RANK_PREDICTION(p0, p1, p2)


  return Velora.invoke(0xAD1660,"bool", p0, p1, p2)


end


function STATS.LEADERBOARDS2_READ_BY_PLAFORM(p0, gamerHandleCsv, platformName)


  return Velora.invoke(0xAD1690,"bool", p0, gamerHandleCsv, platformName)


end


-- PC:0xA0F93D5465B3094D Old:0xC977D6E2


function STATS.LEADERBOARDS2_READ_GET_ROW_DATA_START(p0)


  return Velora.invoke(0xAD16C0,"bool", p0)


end


-- PC:0x71B008056E5692D6 Old:0xF2DB6A82


function STATS.LEADERBOARDS2_READ_GET_ROW_DATA_END()


  Velora.invoke(0xAD16F0,"void")


end


-- PC:0x34770B9CE0E03B91 Old:0x766A74FE


function STATS.LEADERBOARDS2_READ_GET_ROW_DATA_INFO(p0, p1)


  return Velora.invoke(0xAD18F0,"bool", p0, p1)


end


-- PC:0x88578F6EC36B4A3A Old:0x6B90E730


function STATS.LEADERBOARDS2_READ_GET_ROW_DATA_INT(p0, p1)


  return Velora.invoke(0xAD1860,"int", p0, p1)


end


-- PC:0x38491439B6BA7F7D Old:0x509A286F


function STATS.LEADERBOARDS2_READ_GET_ROW_DATA_FLOAT(p0, p1)


  return Velora.invoke(0xAD1890,"float", p0, p1)


end


-- PC:0xAE2206545888AE49 Old:0x5F9DF634


function STATS.LEADERBOARDS2_WRITE_DATA(p0)


  return Velora.invoke(0xAD18C0,"bool", p0)


end


-- PC:0x0BCA1D2C47B0D269 Old:0x7524E27B


function STATS.LEADERBOARDS_WRITE_ADD_COLUMN(p0, p1, p2)


  Velora.invoke(0xAD18F0,"void", p0, p1, p2)


end


-- PC:0x2E65248609523599 Old:0x1C5CCC3A


function STATS.LEADERBOARDS_WRITE_ADD_COLUMN_LONG(p0, p1, p2)


  Velora.invoke(0xAD1910,"void", p0, p1, p2)


end


-- PC:0xB9BB18E2C40142ED Old:0x44F7D82B


function STATS.LEADERBOARDS_CACHE_DATA_ROW(p0)


  return Velora.invoke(0xAD1960,"bool", p0)


end


-- PC:0xD4B02A6B476E1FDC Old:0x87F498C1


function STATS.LEADERBOARDS_CLEAR_CACHE_DATA()


  Velora.invoke(0xAD1960,"void")


end


-- PC:0x8EC74CEB042E7CFF Old:0x88AE9667


function STATS.LEADERBOARDS_CLEAR_CACHE_DATA_ID(p0)


  Velora.invoke(0xAD1980,"void", p0)


end


-- PC:0x9C51349BE6CDFE2C Old:0xFC8A71F3


function STATS.LEADERBOARDS_GET_CACHE_EXISTS(p0)


  return Velora.invoke(0xAD1AD0,"bool", p0)


end


-- PC:0xF04C1C27DA35F6C8 Old:0xEDF02302


function STATS.LEADERBOARDS_GET_CACHE_TIME(p0)


  return Velora.invoke(0xAD1A00,"int", p0)


end


-- PC:0x58A651CD201D89AD Old:0xCE7CB520


function STATS.LEADERBOARDS_GET_CACHE_NUMBER_OF_ROWS(p0)


  return Velora.invoke(0xAD1A60,"int", p0)


end


-- PC:0x9120E8DBA3D69273 Old:0xA11289EC


function STATS.LEADERBOARDS_GET_CACHE_DATA_ROW(p0, p1, p2)


  return Velora.invoke(0xAD1AA0,"bool", p0, p1, p2)


end


-- PC:0x11FF1C80276097ED Old:0x4AC39C6C


function STATS.PRESENCE_EVENT_UPDATESTAT_INT(statHash, value, p2)


  Velora.invoke(0xAD1AD0,"void", statHash, value, p2)


end


-- PC:0x30A6614C1F7799B8 Old:0x3E69E7C3


function STATS.PRESENCE_EVENT_UPDATESTAT_FLOAT(statHash, value, p2)


  Velora.invoke(0xAD1AF0,"void", statHash, value, p2)


end


-- PC:0x6483C25849031C4F Old:0x2FFD2FA5


function STATS.PRESENCE_EVENT_UPDATESTAT_INT_WITH_STRING(statHash, value, p2, string)


  Velora.invoke(0xAD1B10,"void", statHash, value, p2, string)


end


-- PC:0x5EAD2BF6484852E4 Old:0x23D70C39


function STATS.GET_PLAYER_HAS_DRIVEN_ALL_VEHICLES()


  return Velora.invoke(0xAD1B80,"bool")


end


-- PC:0xC141B8917E0017EC Old:0x0AD43306


function STATS.SET_HAS_POSTED_ALL_VEHICLES_DRIVEN()


  Velora.invoke(0xAD1B80,"void")


end


-- PC:0xB475F27C6A994D65 Old:0xC7DE5C30


function STATS.SET_PROFILE_SETTING_PROLOGUE_COMPLETE()


  Velora.invoke(0xAD1BD0,"void")


end


function STATS.SET_PROFILE_SETTING_SP_CHOP_MISSION_COMPLETE()


  Velora.invoke(0xAD1C20,"void")


end


-- PC:0xF1A1803D3476F215 Old:0xA3DAC790


function STATS.SET_PROFILE_SETTING_CREATOR_RACES_DONE(value)


  Velora.invoke(0xAD1C70,"void", value)


end


-- PC:0x38BAAA5DD4C9D19F Old:0x726FAE66


function STATS.SET_PROFILE_SETTING_CREATOR_DM_DONE(value)


  Velora.invoke(0xAD1CD0,"void", value)


end


-- PC:0x55384438FC55AD8E Old:0xF03895A4


function STATS.SET_PROFILE_SETTING_CREATOR_CTF_DONE(value)


  Velora.invoke(0xAD1D30,"void", value)


end


-- PC:0x723C1CE13FBFDB67 Old:0x4C39CF10


function STATS.SET_JOB_ACTIVITY_ID_STARTED(p0, characterSlot)


  Velora.invoke(0xAD1D90,"void", p0, characterSlot)


end


-- PC:0x0D01D20616FC73FB Old:0x2180AE13


function STATS.SET_FREEMODE_PROLOGUE_DONE(p0, characterSlot)


  Velora.invoke(0xAD1DA0,"void", p0, characterSlot)


end


function STATS.SET_FREEMODE_STRAND_PROGRESSION_STATUS(profileSetting, settingValue)


  Velora.invoke(0xAD1DB0,"void", profileSetting, settingValue)


end


-- PC:0x428EAF89E24F6C36 Old:0xEE292B91


function STATS.STAT_NETWORK_INCREMENT_ON_SUICIDE(p0, p1)


  Velora.invoke(0xAD1E00,"void", p0, p1)


end


-- PC:0x047CBED6F6F8B63C Old:0xA063CABD


function STATS.STAT_SET_CHEAT_IS_ACTIVE()


  Velora.invoke(0xAD1E80,"void")


end


-- PC:0xC980E62E33DF1D5C Old:0x62C19A3D


function STATS.LEADERBOARDS2_WRITE_DATA_FOR_EVENT_TYPE(p0, p1)


  return Velora.invoke(0xAD1ED0,"bool", p0, p1)


end


-- PC:0x6F361B8889A792A3 Old:0x3B4EF322


function STATS.FORCE_CLOUD_MP_STATS_DOWNLOAD_AND_OVERWRITE_LOCAL_SAVE()


  Velora.invoke(0xAD1ED0,"void")


end


function STATS.STAT_MIGRATE_CLEAR_FOR_RESTART()


  Velora.invoke(0xAD1F20,"void")


end


function STATS.STAT_MIGRATE_SAVEGAME_START(platformName)


  return Velora.invoke(0xAD1FE0,"bool", platformName)


end


function STATS.STAT_MIGRATE_SAVEGAME_GET_STATUS()


  return Velora.invoke(0xAD1F40,"int")


end


function STATS.STAT_MIGRATE_CHECK_ALREADY_DONE()


  return Velora.invoke(0xAD1F50,"bool")


end


function STATS.STAT_MIGRATE_CHECK_START()


  return Velora.invoke(0xAD1F60,"bool")


end


function STATS.STAT_MIGRATE_CHECK_GET_IS_PLATFORM_AVAILABLE(p0)


  return Velora.invoke(0xAD1F70,"int", p0)


end


function STATS.STAT_MIGRATE_CHECK_GET_PLATFORM_STATUS(p0, p1)


  return Velora.invoke(0xAD1F80,"int", p0, p1)


end


-- PC:0x886913BBEACA68C1 Old:0xE3F0D62D


function STATS.STAT_GET_SAVE_MIGRATION_STATUS(data)


  return Velora.invoke(0xAD1F90,"int", data)


end


function STATS.STAT_SAVE_MIGRATION_CANCEL_PENDING_OPERATION()


  return Velora.invoke(0xAD1FA0,"bool")


end


function STATS.STAT_GET_CANCEL_SAVE_MIGRATION_STATUS()


  return Velora.invoke(0xAD1FB0,"int")


end


function STATS.STAT_SAVE_MIGRATION_CONSUME_CONTENT(contentId, srcPlatform, srcGamerHandle)


  return Velora.invoke(0xAD1FC0,"bool", contentId, srcPlatform, srcGamerHandle)


end


function STATS.STAT_GET_SAVE_MIGRATION_CONSUME_CONTENT_STATUS()


  return Velora.invoke(0xAD1FD0,"int")


end


function STATS.STAT_ENABLE_STATS_TRACKING()


  Velora.invoke(0xAD1FE0,"void")


end


function STATS.STAT_DISABLE_STATS_TRACKING()


  Velora.invoke(0xAD1FF0,"void")


end


function STATS.STAT_IS_STATS_TRACKING_ENABLED()


  return Velora.invoke(0xAD22A0,"bool")


end


function STATS.STAT_START_RECORD_STAT(statType, valueType)


  return Velora.invoke(0xAD2020,"bool", statType, valueType)


end


function STATS.STAT_STOP_RECORD_STAT()


  return Velora.invoke(0xAD2070,"bool")


end


function STATS.STAT_GET_RECORDED_VALUE()


  return Velora.invoke(0xAD20A0,"bool")


end


function STATS.STAT_IS_RECORDING_STAT()


  return Velora.invoke(0xAD20D0,"bool")


end


function STATS.STAT_GET_CURRENT_NEAR_MISS_NOCRASH_PRECISE()


  return Velora.invoke(0xAD20F0,"int")


end


function STATS.STAT_GET_CURRENT_REAR_WHEEL_DISTANCE()


  return Velora.invoke(0xAD2100,"float")


end


function STATS.STAT_GET_CURRENT_FRONT_WHEEL_DISTANCE()


  return Velora.invoke(0xAD2130,"float")


end


function STATS.STAT_GET_CURRENT_JUMP_DISTANCE()


  return Velora.invoke(0xAD2160,"float")


end


function STATS.STAT_GET_CURRENT_DRIVE_NOCRASH_DISTANCE()


  return Velora.invoke(0xAD2180,"float")


end


function STATS.STAT_GET_CURRENT_SPEED()


  return Velora.invoke(0xAD21A0,"float")


end


function STATS.STAT_GET_CURRENT_DRIVING_REVERSE_DISTANCE()


  return Velora.invoke(0xAD21C0,"float")


end


function STATS.STAT_GET_CURRENT_SKYDIVING_DISTANCE()


  return Velora.invoke(0xAD21E0,"float")


end


function STATS.STAT_GET_CHALLENGE_FLYING_DIST()


  return Velora.invoke(0xAD2200,"float")


end


function STATS.STAT_GET_FLYING_ALTITUDE()


  return Velora.invoke(0xAD2220,"bool")


end


function STATS.STAT_IS_PLAYER_VEHICLE_ABOVE_OCEAN()


  return Velora.invoke(0xAD2250,"bool")


end


function STATS.STAT_GET_VEHICLE_BAIL_DISTANCE()


  return Velora.invoke(0xAD2270,"float")


end


function STATS.STAT_ROLLBACK_SAVE_MIGRATION()


  return Velora.invoke(0xAD2290,"bool")


end


function STATS.SET_HAS_SPECIALEDITION_CONTENT(value)


  Velora.invoke(0xAD22A0,"void", value)


end


function STATS.SET_SAVE_MIGRATION_TRANSACTION_ID_WARNING(transactionId)


  Velora.invoke(0xAD22E0,"void", transactionId)


end


function STATS.GET_BOSS_GOON_UUID(characterSlot, p1, p2)


  Velora.invoke(0xAD2320,"void", characterSlot, p1, p2)


end


function STATS.PLAYSTATS_BW_BOSSONBOSSDEATHMATCH(p0)


  Velora.invoke(0xAD2390,"void", p0)


end


function STATS.PLAYSTATS_BW_YATCHATTACK(p0)


  Velora.invoke(0xAD23A0,"void", p0)


end


function STATS.PLAYSTATS_BW_HUNT_THE_BOSS(p0)


  Velora.invoke(0xAD23B0,"void", p0)


end


function STATS.PLAYSTATS_BW_SIGHTSEER(p0)


  Velora.invoke(0xAD23C0,"void", p0)


end


function STATS.PLAYSTATS_BW_ASSAULT(p0)


  Velora.invoke(0xAD23D0,"void", p0)


end


function STATS.PLAYSTATS_BW_BELLY_OF_THE_BEAST(p0)


  Velora.invoke(0xAD23E0,"void", p0)


end


function STATS.PLAYSTATS_BW_HEAD_HUNTER(p0)


  Velora.invoke(0xAD23F0,"void", p0)


end


function STATS.PLAYSTATS_BW_FRAGILE_GOODS(p0)


  Velora.invoke(0xAD2400,"void", p0)


end


function STATS.PLAYSTATS_BW_AIR_FREIGHT(p0)


  Velora.invoke(0xAD2410,"void", p0)


end


function STATS.PLAYSTATS_BC_CAR_JACKING(p0)


  Velora.invoke(0xAD2420,"void", p0)


end


function STATS.PLAYSTATS_BC_SMASH_AND_GRAB(p0)


  Velora.invoke(0xAD2430,"void", p0)


end


function STATS.PLAYSTATS_BC_PROTECTION_RACKET(p0)


  Velora.invoke(0xAD2440,"void", p0)


end


function STATS.PLAYSTATS_BC_MOST_WANTED(p0)


  Velora.invoke(0xAD2450,"void", p0)


end


function STATS.PLAYSTATS_BC_FINDERS_KEEPERS(p0)


  Velora.invoke(0xAD2460,"void", p0)


end


function STATS.PLAYSTATS_BC_POINT_TO_POINT(p0)


  Velora.invoke(0xAD2470,"void", p0)


end


function STATS.PLAYSTATS_BC_CASHING(p0)


  Velora.invoke(0xAD2480,"void", p0)


end


function STATS.PLAYSTATS_BC_SALVAGE(p0)


  Velora.invoke(0xAD2490,"void", p0)


end


function STATS.PLAYSTATS_SPENT_PI_CUSTOM_LOADOUT(amount)


  Velora.invoke(0xAD24A0,"void", amount)


end


function STATS.PLAYSTATS_BUY_CONTRABAND_MISSION(data)


  Velora.invoke(0xAD2570,"void", data)


end


function STATS.PLAYSTATS_SELL_CONTRABAND_MISSION(data)


  Velora.invoke(0xAD2580,"void", data)


end


function STATS.PLAYSTATS_DEFEND_CONTRABAND_MISSION(data)


  Velora.invoke(0xAD2590,"void", data)


end


function STATS.PLAYSTATS_RECOVER_CONTRABAND_MISSION(data)


  Velora.invoke(0xAD25A0,"void", data)


end


function STATS.PLAYSTATS_HIT_CONTRABAND_DESTROY_LIMIT(p0)


  Velora.invoke(0xAD25B0,"void", p0)


end


function STATS.START_BEING_BOSS(p0)


  Velora.invoke(0xAD2640,"void", p0)


end


function STATS.START_BEING_GOON(p0, p1, p2)


  Velora.invoke(0xAD2660,"void", p0, p1, p2)


end


function STATS.END_BEING_BOSS(p0, p1)


  Velora.invoke(0xAD26F0,"void", p0, p1)


end


function STATS.END_BEING_GOON(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD2710,"void", p0, p1, p2, p3, p4)


end


function STATS.HIRED_LIMO(p0, p1)


  Velora.invoke(0xAD2730,"void", p0, p1)


end


function STATS.ORDER_BOSS_VEHICLE(p0, p1, vehicleHash)


  Velora.invoke(0xAD27B0,"void", p0, p1, vehicleHash)


end


function STATS.CHANGE_UNIFORM(p0, p1, p2)


  Velora.invoke(0xAD2860,"void", p0, p1, p2)


end


function STATS.CHANGE_GOON_LOOKING_FOR_WORK(p0)


  Velora.invoke(0xAD28F0,"void", p0)


end


function STATS.SEND_METRIC_GHOSTING_TO_PLAYER(p0)


  Velora.invoke(0xAD2910,"void", p0)


end


function STATS.SEND_METRIC_VIP_POACH(p0, p1, p2)


  Velora.invoke(0xAD2920,"void", p0, p1, p2)


end


function STATS.SEND_METRIC_PUNISH_BODYGUARD(p0)


  Velora.invoke(0xAD29F0,"void", p0)


end


function STATS.PLAYSTATS_START_TRACKING_STUNTS()


  Velora.invoke(0xAD2AA0,"void")


end


function STATS.PLAYSTATS_STOP_TRACKING_STUNTS()


  Velora.invoke(0xAD2AB0,"void")


end


function STATS.PLAYSTATS_MISSION_ENDED(p0)


  Velora.invoke(0xAD2AC0,"void", p0)


end


function STATS.PLAYSTATS_IMPEXP_MISSION_ENDED(p0)


  Velora.invoke(0xAD2AD0,"void", p0)


end


function STATS.PLAYSTATS_CHANGE_MC_ROLE(p0, p1, p2, p3, role, p5, p6)


  Velora.invoke(0xAD2AE0,"void", p0, p1, p2, p3, role, p5, p6)


end


function STATS.PLAYSTATS_CHANGE_MC_OUTFIT(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD2B10,"void", p0, p1, p2, p3, p4)


end


function STATS.PLAYSTATS_SWITCH_MC_EMBLEM(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD2B30,"void", p0, p1, p2, p3, p4)


end


function STATS.PLAYSTATS_MC_REQUEST_BIKE(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD2B50,"void", p0, p1, p2, p3, p4)


end


function STATS.PLAYSTATS_MC_KILLED_RIVAL_MC_MEMBER(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD2B70,"void", p0, p1, p2, p3, p4)


end


function STATS.PLAYSTATS_ABANDONED_MC(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD2B90,"void", p0, p1, p2, p3, p4)


end


function STATS.PLAYSTATS_EARNED_MC_POINTS(p0, p1, p2, p3, p4, p5)


  Velora.invoke(0xAD2BB0,"void", p0, p1, p2, p3, p4, p5)


end


function STATS.PLAYSTATS_MC_FORMATION_ENDS(p0, p1, p2, p3, p4, p5, p6)


  Velora.invoke(0xAD2BD0,"void", p0, p1, p2, p3, p4, p5, p6)


end


function STATS.PLAYSTATS_MC_CLUBHOUSE_ACTIVITY(p0, p1, p2, p3, p4, p5, p6, p7)


  Velora.invoke(0xAD2C00,"void", p0, p1, p2, p3, p4, p5, p6, p7)


end


function STATS.PLAYSTATS_RIVAL_BEHAVIOR(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)


  Velora.invoke(0xAD2C40,"void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)


end


function STATS.PLAYSTATS_COPY_RANK_INTO_NEW_SLOT(p0, p1, p2, p3, p4, p5, p6)


  Velora.invoke(0xAD2D70,"void", p0, p1, p2, p3, p4, p5, p6)


end


function STATS.PLAYSTATS_DUPE_DETECTED(data)


  Velora.invoke(0xAD2E30,"void", data)


end


function STATS.PLAYSTATS_BAN_ALERT(p0)


  Velora.invoke(0xAD2EF0,"void", p0)


end


function STATS.PLAYSTATS_GUNRUNNING_MISSION_ENDED(data)


  Velora.invoke(0xAD2F60,"void", data)


end


function STATS.PLAYSTATS_GUNRUNNING_RND(p0)


  Velora.invoke(0xAD2F70,"void", p0)


end


function STATS.PLAYSTATS_BUSINESS_BATTLE_ENDED(p0)


  Velora.invoke(0xAD3040,"void", p0)


end


function STATS.PLAYSTATS_WAREHOUSE_MISSION_ENDED(p0)


  Velora.invoke(0xAD3050,"void", p0)


end


function STATS.PLAYSTATS_NIGHTCLUB_MISSION_ENDED(p0)


  Velora.invoke(0xAD3060,"void", p0)


end


function STATS.PLAYSTATS_DJ_USAGE(p0, p1)


  Velora.invoke(0xAD3070,"void", p0, p1)


end


function STATS.PLAYSTATS_MINIGAME_USAGE(p0, p1, p2)


  Velora.invoke(0xAD3100,"void", p0, p1, p2)


end


function STATS.PLAYSTATS_STONE_HATCHET_ENDED(data)


  Velora.invoke(0xAD31A0,"void", data)


end


function STATS.PLAYSTATS_SMUGGLER_MISSION_ENDED(data)


  Velora.invoke(0xAD31B0,"void", data)


end


function STATS.PLAYSTATS_FM_HEIST_PREP_ENDED(data)


  Velora.invoke(0xAD31C0,"void", data)


end


function STATS.PLAYSTATS_INSTANCED_HEIST_ENDED(data, p1, p2, p3)


  Velora.invoke(0xAD31D0,"void", data, p1, p2, p3)


end


function STATS.PLAYSTATS_DAR_CHECKPOINT(data)


  Velora.invoke(0xAD31F0,"void", data)


end


function STATS.PLAYSTATS_ENTER_SESSION_PACK(data)


  Velora.invoke(0xAD3200,"void", data)


end


function STATS.PLAYSTATS_DRONE_USAGE(p0, p1, p2)


  Velora.invoke(0xAD3210,"void", p0, p1, p2)


end


function STATS.PLAYSTATS_SPIN_WHEEL(p0, p1, p2, p3)


  Velora.invoke(0xAD32B0,"void", p0, p1, p2, p3)


end


function STATS.PLAYSTATS_ARENA_WARS_SPECTATOR(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD3370,"void", p0, p1, p2, p3, p4)


end


function STATS.PLAYSTATS_ARENA_WARS_ENDED(data)


  Velora.invoke(0xAD3430,"void", data)


end


function STATS.PLAYSTATS_SWITCH_PASSIVE_MODE(p0, p1, p2, p3)


  Velora.invoke(0xAD3440,"void", p0, p1, p2, p3)


end


function STATS.PLAYSTATS_COLLECTIBLE_PICKED_UP(p0, objectHash, p2, p3, moneyAmount, rpAmount, chipsAmount, p7, p8, p9, p10)


  Velora.invoke(0xAD34E0,"void", p0, objectHash, p2, p3, moneyAmount, rpAmount, chipsAmount, p7, p8, p9, p10)


end


function STATS.PLAYSTATS_CASINO_STORY_MISSION_ENDED(p0, p1)


  Velora.invoke(0xAD3600,"void", p0, p1)


end


function STATS.PLAYSTATS_CASINO_CHIP(p0)


  Velora.invoke(0xAD3670,"void", p0)


end


function STATS.PLAYSTATS_CASINO_ROULETTE(p0)


  Velora.invoke(0xAD3730,"void", p0)


end


function STATS.PLAYSTATS_CASINO_BLACKJACK(p0)


  Velora.invoke(0xAD3740,"void", p0)


end


function STATS.PLAYSTATS_CASINO_THREE_CARD_POKER(p0)


  Velora.invoke(0xAD3750,"void", p0)


end


function STATS.PLAYSTATS_CASINO_SLOT_MACHINE(p0)


  Velora.invoke(0xAD38A0,"void", p0)


end


function STATS.PLAYSTATS_CASINO_INSIDE_TRACK(p0)


  Velora.invoke(0xAD39E0,"void", p0)


end


function STATS.PLAYSTATS_CASINO_LUCKY_SEVEN(p0)


  Velora.invoke(0xAD3B20,"void", p0)


end


function STATS.PLAYSTATS_CASINO_ROULETTE_LIGHT(p0)


  Velora.invoke(0xAD3C70,"void", p0)


end


function STATS.PLAYSTATS_CASINO_BLACKJACK_LIGHT(p0)


  Velora.invoke(0xAD3D50,"void", p0)


end


function STATS.PLAYSTATS_CASINO_THREE_CARD_POKER_LIGHT(p0)


  Velora.invoke(0xAD3E70,"void", p0)


end


function STATS.PLAYSTATS_CASINO_SLOT_MACHINE_LIGHT(p0)


  Velora.invoke(0xAD3F50,"void", p0)


end


function STATS.PLAYSTATS_CASINO_INSIDE_TRACK_LIGHT(p0)


  Velora.invoke(0xAD4040,"void", p0)


end


function STATS.PLAYSTATS_ARCADE_GAME(p0, p1, p2, p3, p4, p5, p6)


  Velora.invoke(0xAD4130,"void", p0, p1, p2, p3, p4, p5, p6)


end


function STATS.PLAYSTATS_ARCADE_LOVE_MATCH(p0, p1)


  Velora.invoke(0xAD41F0,"void", p0, p1)


end


function STATS.PLAYSTATS_FREEMODE_CASINO_MISSION_ENDED(data)


  Velora.invoke(0xAD4290,"void", data)


end


function STATS.PLAYSTATS_HEIST3_DRONE(p0)


  Velora.invoke(0xAD42A0,"void", p0)


end


function STATS.PLAYSTATS_HEIST3_HACK(p0, p1, p2, p3, p4, p5)


  Velora.invoke(0xAD4340,"void", p0, p1, p2, p3, p4, p5)


end


function STATS.PLAYSTATS_NPC_PHONE(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)


  Velora.invoke(0xAD43F0,"void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)


end


function STATS.PLAYSTATS_ARCADE_CABINET(p0)


  Velora.invoke(0xAD4400,"void", p0)


end


function STATS.PLAYSTATS_HEIST3_FINALE(p0)


  Velora.invoke(0xAD44B0,"void", p0)


end


function STATS.PLAYSTATS_HEIST3_PREP(p0)


  Velora.invoke(0xAD4510,"void", p0)


end


function STATS.PLAYSTATS_MASTER_CONTROL(p0, p1, p2, p3)


  Velora.invoke(0xAD4570,"void", p0, p1, p2, p3)


end


function STATS.PLAYSTATS_QUIT_MODE(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD4610,"void", p0, p1, p2, p3, p4)


end


function STATS.PLAYSTATS_MISSION_VOTE(p0)


  Velora.invoke(0xAD4700,"void", p0)


end


function STATS.PLAYSTATS_NJVS_VOTE(p0)


  Velora.invoke(0xAD4710,"void", p0)


end


function STATS.PLAYSTATS_KILL_YOURSELF()


  Velora.invoke(0xDEADBEEF,"void")


end


function STATS.PLAYSTATS_FM_MISSION_END(p0, p1, p2)


  Velora.invoke(0xAD4830,"void", p0, p1, p2)


end


function STATS.PLAYSTATS_HEIST4_PREP(p0)


  Velora.invoke(0xAD4850,"void", p0)


end


function STATS.PLAYSTATS_HEIST4_FINALE(p0)


  Velora.invoke(0xAD48B0,"void", p0)


end


function STATS.PLAYSTATS_HEIST4_HACK(p0, p1, p2, p3, p4)


  Velora.invoke(0xAD4910,"void", p0, p1, p2, p3, p4)


end


function STATS.PLAYSTATS_SUB_WEAP(p0, p1, p2, p3)


  Velora.invoke(0xAD49C0,"void", p0, p1, p2, p3)


end


function STATS.PLAYSTATS_FAST_TRVL(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)


  Velora.invoke(0xAD4A60,"void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)


end


function STATS.PLAYSTATS_HUB_ENTRY(p0)


  Velora.invoke(0xAD4BA0,"void", p0)


end


function STATS.PLAYSTATS_DJ_MISSION_ENDED(p0)


  Velora.invoke(0xAD4C70,"void", p0)


end


function STATS.PLAYSTATS_ROBBERY_PREP(p0)


  Velora.invoke(0xAD4C80,"void", p0)


end


function STATS.PLAYSTATS_ROBBERY_FINALE(p0)


  Velora.invoke(0xAD4CE0,"void", p0)


end


function STATS.PLAYSTATS_EXTRA_EVENT(p0)


  Velora.invoke(0xAD4D40,"void", p0)


end


function STATS.PLAYSTATS_CARCLUB_POINTS(p0)


  Velora.invoke(0xAD4DE0,"void", p0)


end


function STATS.PLAYSTATS_CARCLUB_CHALLENGE(p0, p1, p2, p3)


  Velora.invoke(0xAD4ED0,"void", p0, p1, p2, p3)


end


function STATS.PLAYSTATS_CARCLUB_PRIZE(p0, vehicleModel)


  Velora.invoke(0xAD4F70,"void", p0, vehicleModel)


end


function STATS.PLAYSTATS_AWARD_NAV(p0, p1, p2, p3)


  Velora.invoke(0xAD4FF0,"void", p0, p1, p2, p3)


end


function STATS.PLAYSTATS_INST_MISSION_END(p0)


  Velora.invoke(0xAD5120,"void", p0)


end


function STATS.PLAYSTATS_HUB_EXIT(p0)


  Velora.invoke(0xAD5180,"void", p0)


end


function STATS.PLAYSTATS_INVENTORY(p0)


  Velora.invoke(0xAD5320,"void", p0)


end


