-- compat_GRAPHICS.lua — AUTO GENERATO


-- GRAPHICS


GRAPHICS=GRAPHICS or {}


-- PC:0x175B6BFC15CDD0C5 Old:0x1418CA37


function GRAPHICS.SET_DEBUG_LINES_AND_SPHERES_DRAWING_ACTIVE(enabled)


  Velora.invoke(0x9CB750,"void", enabled)


end


-- PC:0x7FDFADE676AA3CB0 Old:0xABF783AB


function GRAPHICS.DRAW_DEBUG_LINE(x1, y1, z1, x2, y2, z2, r, g, b, alpha)


  Velora.invoke(0x9CB760,"void", x1, y1, z1, x2, y2, z2, r, g, b, alpha)


end


-- PC:0xD8B9A8AC5608FF94 Old:0xE8BFF632


function GRAPHICS.DRAW_DEBUG_LINE_WITH_TWO_COLOURS(x1, y1, z1, x2, y2, z2, r1, g1, b1, r2, g2, b2, alpha1, alpha2)


  Velora.invoke(0x9CB770,"void", x1, y1, z1, x2, y2, z2, r1, g1, b1, r2, g2, b2, alpha1, alpha2)


end


-- PC:0xAAD68E1AB39DA632 Old:0x304D0EEF


function GRAPHICS.DRAW_DEBUG_SPHERE(x, y, z, radius, red, green, blue, alpha)


  Velora.invoke(0x9CB780,"void", x, y, z, radius, red, green, blue, alpha)


end


-- PC:0x083A2CA4F2E573BD Old:0x8524A848


function GRAPHICS.DRAW_DEBUG_BOX(x1, y1, z1, x2, y2, z2, r, g, b, alpha)


  Velora.invoke(0x9CB790,"void", x1, y1, z1, x2, y2, z2, r, g, b, alpha)


end


-- PC:0x73B1189623049839 Old:0xB6DF3709


function GRAPHICS.DRAW_DEBUG_CROSS(x, y, z, size, red, green, blue, alpha)


  Velora.invoke(0x9CB7A0,"void", x, y, z, size, red, green, blue, alpha)


end


-- PC:0x3903E216620488E8 Old:0x269B006F


function GRAPHICS.DRAW_DEBUG_TEXT(text, x, y, z, red, green, blue, alpha)


  Velora.invoke(0x9CB7B0,"void", text, x, y, z, red, green, blue, alpha)


end


-- PC:0xA3BB2E9555C05A8F Old:0x528B973B


function GRAPHICS.DRAW_DEBUG_TEXT_2D(text, x, y, z, red, green, blue, alpha)


  Velora.invoke(0x9CB7C0,"void", text, x, y, z, red, green, blue, alpha)


end


-- PC:0x6B7256074AE34680 Old:0xB3426BCC


function GRAPHICS.DRAW_LINE(x1, y1, z1, x2, y2, z2, red, green, blue, alpha)


  Velora.invoke(0x9CB7D0,"void", x1, y1, z1, x2, y2, z2, red, green, blue, alpha)


end


-- PC:0xAC26716048436851 Old:0xABD19253


function GRAPHICS.DRAW_POLY(x1, y1, z1, x2, y2, z2, x3, y3, z3, red, green, blue, alpha)


  Velora.invoke(0x9CB8A0,"void", x1, y1, z1, x2, y2, z2, x3, y3, z3, red, green, blue, alpha)


end


function GRAPHICS.DRAW_TEXTURED_POLY(x1, y1, z1, x2, y2, z2, x3, y3, z3, red, green, blue, alpha, textureDict, textureName, u1, v1, w1, u2, v2, w2, u3, v3, w3)


  Velora.invoke(0x9CB980,"void", x1, y1, z1, x2, y2, z2, x3, y3, z3, red, green, blue, alpha, textureDict, textureName, u1, v1, w1, u2, v2, w2, u3, v3, w3)


end


function GRAPHICS.DRAW_TEXTURED_POLY_WITH_THREE_COLOURS(x1, y1, z1, x2, y2, z2, x3, y3, z3, red1, green1, blue1, alpha1, red2, green2, blue2, alpha2, red3, green3, blue3, alpha3, textureDict, textureName, u1, v1, w1, u2, v2, w2, u3, v3, w3)


  Velora.invoke(0x9CB9F0,"void", x1, y1, z1, x2, y2, z2, x3, y3, z3, red1, green1, blue1, alpha1, red2, green2, blue2, alpha2, red3, green3, blue3, alpha3, textureDict, textureName, u1, v1, w1, u2, v2, w2, u3, v3, w3)


end


-- PC:0xD3A9971CADAC7252 Old:0xCD4D9DD5


function GRAPHICS.DRAW_BOX(x1, y1, z1, x2, y2, z2, red, green, blue, alpha)


  Velora.invoke(0x9CBA80,"void", x1, y1, z1, x2, y2, z2, red, green, blue, alpha)


end


-- PC:0x23BA6B0C2AD7B0D3 Old:0xC44C2F44


function GRAPHICS.SET_BACKFACECULLING(toggle)


  Velora.invoke(0x9CBB50,"void", toggle)


end


function GRAPHICS.SET_DEPTHWRITING(toggle)


  Velora.invoke(0x9CBB70,"void", toggle)


end


-- PC:0x1DD2139A9A20DCE8 Old:0xBA9AD458


function GRAPHICS.BEGIN_TAKE_MISSION_CREATOR_PHOTO()


  return Velora.invoke(0x9CBBF0,"bool")


end


-- PC:0x90A78ECAA4E78453 Old:0xADBBA287


function GRAPHICS.GET_STATUS_OF_TAKE_MISSION_CREATOR_PHOTO()


  return Velora.invoke(0x9CBBD0,"int")


end


-- PC:0x0A46AF8A78DC5E0A Old:0x9E553002


function GRAPHICS.FREE_MEMORY_FOR_MISSION_CREATOR_PHOTO()


  Velora.invoke(0x9CBBF0,"void")


end


-- PC:0x4862437A486F91B0 Old:0x56C1E488


function GRAPHICS.LOAD_MISSION_CREATOR_PHOTO(p0, p1, p2, p3)


  return Velora.invoke(0x9CBCF0,"bool", p0, p1, p2, p3)


end


-- PC:0x1670F8D05056F257 Old:0x226B08EA


function GRAPHICS.GET_STATUS_OF_LOAD_MISSION_CREATOR_PHOTO(p0)


  return Velora.invoke(0x9CBC60,"int", p0)


end


-- PC:0x7FA5D82B8F58EC06 Old:0x1F3CADB0


function GRAPHICS.BEGIN_CREATE_MISSION_CREATOR_PHOTO_PREVIEW()


  return Velora.invoke(0x9CBC90,"bool")


end


-- PC:0x5B0316762AFD4A64 Old:0xA9DC8558


function GRAPHICS.GET_STATUS_OF_CREATE_MISSION_CREATOR_PHOTO_PREVIEW()


  return Velora.invoke(0x9CBCC0,"int")


end


-- PC:0x346EF3ECAAAB149E Old:0x88EAF398


function GRAPHICS.FREE_MEMORY_FOR_MISSION_CREATOR_PHOTO_PREVIEW()


  Velora.invoke(0x9CBCF0,"void")


end


-- PC:0xA67C35C56EB1BD9D Old:0x47B0C137


function GRAPHICS.BEGIN_TAKE_HIGH_QUALITY_PHOTO()


  return Velora.invoke(0x9CBD40,"bool")


end


-- PC:0x0D6CA79EEEBD8CA3 Old:0x65376C9B


function GRAPHICS.GET_STATUS_OF_TAKE_HIGH_QUALITY_PHOTO()


  return Velora.invoke(0x9CBD20,"int")


end


-- PC:0xD801CC02177FA3F1 Old:0x9CBA682A


function GRAPHICS.FREE_MEMORY_FOR_HIGH_QUALITY_PHOTO()


  Velora.invoke(0x9CBD40,"void")


end


function GRAPHICS.SET_TAKEN_PHOTO_IS_MUGSHOT(toggle)


  Velora.invoke(0x9CBD50,"void", toggle)


end


function GRAPHICS.SET_ARENA_THEME_AND_VARIATION_FOR_TAKEN_PHOTO(p0, p1)


  Velora.invoke(0x9CBD70,"void", p0, p1)


end


function GRAPHICS.SET_ON_ISLAND_X_FOR_TAKEN_PHOTO(p0)


  Velora.invoke(0x9CBD80,"void", p0)


end


-- PC:0x3DEC726C25A11BAC Old:0x3B15D33C


function GRAPHICS.SAVE_HIGH_QUALITY_PHOTO(unused)


  return Velora.invoke(0x9CBE30,"bool", unused)


end


-- PC:0x0C0C4E81E1AC60A0 Old:0xEC5D0317


function GRAPHICS.GET_STATUS_OF_SAVE_HIGH_QUALITY_PHOTO()


  return Velora.invoke(0x9CBDC0,"int")


end


-- PC:0x759650634F07B6B4 Old:0x25D569EB


function GRAPHICS.BEGIN_CREATE_LOW_QUALITY_COPY_OF_PHOTO(p0)


  return Velora.invoke(0x9CBDE0,"bool", p0)


end


-- PC:0xCB82A0BF0E3E3265 Old:0xCFCDC518


function GRAPHICS.GET_STATUS_OF_CREATE_LOW_QUALITY_COPY_OF_PHOTO(p0)


  return Velora.invoke(0x9CBE10,"int", p0)


end


-- PC:0x6A12D88881435DCA Old:0x108F36CC


function GRAPHICS.FREE_MEMORY_FOR_LOW_QUALITY_PHOTO()


  Velora.invoke(0x9CBE30,"void")


end


-- PC:0x1072F115DAB0717E Old:0xE9F2B68F


function GRAPHICS.DRAW_LOW_QUALITY_PHOTO_TO_PHONE(p0, p1)


  Velora.invoke(0x9CBE40,"void", p0, p1)


end


-- PC:0x34D23450F028B0BF Old:0x727AA63F


function GRAPHICS.GET_MAXIMUM_NUMBER_OF_PHOTOS()


  return Velora.invoke(0x9CBF00,"int")


end


-- PC:0xDC54A7AF8B3A14EF Old:0x239272BD


function GRAPHICS.GET_MAXIMUM_NUMBER_OF_CLOUD_PHOTOS()


  return Velora.invoke(0x9CBE70,"int")


end


-- PC:0x473151EBC762C6DA Old:0x21DBF0C9


function GRAPHICS.GET_CURRENT_NUMBER_OF_CLOUD_PHOTOS()


  return Velora.invoke(0x9CBE80,"int")


end


-- PC:0x2A893980E96B659A Old:0x199FABF0


function GRAPHICS.QUEUE_OPERATION_TO_CREATE_SORTED_LIST_OF_PHOTOS(p0)


  return Velora.invoke(0x9CBEA0,"bool", p0)


end


-- PC:0xF5BED327CEA362B1 Old:0x596B900D


function GRAPHICS.GET_STATUS_OF_SORTED_LIST_OPERATION(p0)


  return Velora.invoke(0x9CBED0,"int", p0)


end


-- PC:0x4AF92ACD3141D96C Old:0xC9EF81ED


function GRAPHICS.CLEAR_STATUS_OF_SORTED_LIST_OPERATION()


  Velora.invoke(0x9CBF00,"void")


end


-- PC:0xE791DF1F73ED2C8B Old:0x9D84554C


function GRAPHICS.DOES_THIS_PHOTO_SLOT_CONTAIN_A_VALID_PHOTO(p0)


  return Velora.invoke(0x9CBF40,"bool", p0)


end


-- PC:0xEC72C258667BE5EA Old:0x9C106AD9


function GRAPHICS.LOAD_HIGH_QUALITY_PHOTO(p0)


  return Velora.invoke(0x9CBF20,"bool", p0)


end


-- PC:0x40AFB081F8ADD4EE Old:0x762E5C5F


function GRAPHICS.GET_LOAD_HIGH_QUALITY_PHOTO_STATUS(p0)


  return Velora.invoke(0x9CBF30,"int", p0)


end


function GRAPHICS.DRAW_LIGHT_WITH_RANGEEX(x, y, z, r, g, b, range, intensity, shadow)


  Velora.invoke(0x9CBF40,"void", x, y, z, r, g, b, range, intensity, shadow)


end


-- PC:0xF2A1B2771A01DBD4 Old:0x6A396E9A


function GRAPHICS.DRAW_LIGHT_WITH_RANGE(posX, posY, posZ, colorR, colorG, colorB, range, intensity)


  Velora.invoke(0x9CBF70,"void", posX, posY, posZ, colorR, colorG, colorB, range, intensity)


end


-- PC:0xD0F64B265C8C8B33 Old:0xBDBC410C


function GRAPHICS.DRAW_SPOT_LIGHT(posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, hardness, radius, falloff)


  Velora.invoke(0x9CBFA0,"void", posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, hardness, radius, falloff)


end


-- PC:0x5BCA583A583194DB Old:0x32BF9598


function GRAPHICS.DRAW_SHADOWED_SPOT_LIGHT(posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, roundness, radius, falloff, shadowId)


  Velora.invoke(0x9CBFD0,"void", posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, roundness, radius, falloff, shadowId)


end


-- PC:0xC9B18B4619F48F7B Old:0x93628786


function GRAPHICS.FADE_UP_PED_LIGHT(p0)


  Velora.invoke(0x9CC040,"void", p0)


end


-- PC:0xDEADC0DEDEADC0DE Old:0xC12AC47A


function GRAPHICS.UPDATE_LIGHTS_ON_ENTITY(entity)


  Velora.invoke(0x9CC050,"void", entity)


end


function GRAPHICS.SET_LIGHT_OVERRIDE_MAX_INTENSITY_SCALE(p0)


  Velora.invoke(0x9CC0F0,"void", p0)


end


function GRAPHICS.GET_LIGHT_OVERRIDE_MAX_INTENSITY_SCALE()


  return Velora.invoke(0x9CC120,"float")


end


-- PC:0x28477EC23D892089 Old:0x48D84A02


function GRAPHICS.DRAW_MARKER(type, posX, posY, posZ, dirX, dirY, dirZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, red, green, blue, alpha, bobUpAndDown, faceCamera, p19, rotate, textureDict, textureName, drawOnEnts)


  Velora.invoke(0x9CC120,"void", type, posX, posY, posZ, dirX, dirY, dirZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, red, green, blue, alpha, bobUpAndDown, faceCamera, p19, rotate, textureDict, textureName, drawOnEnts)


end


function GRAPHICS.DRAW_MARKER_EX(type, posX, posY, posZ, dirX, dirY, dirZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, red, green, blue, alpha, bobUpAndDown, faceCamera, p19, rotate, textureDict, textureName, drawOnEnts, p24, p25)


  Velora.invoke(0x9CC200,"void", type, posX, posY, posZ, dirX, dirY, dirZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, red, green, blue, alpha, bobUpAndDown, faceCamera, p19, rotate, textureDict, textureName, drawOnEnts, p24, p25)


end


function GRAPHICS.DRAW_MARKER_SPHERE(x, y, z, radius, red, green, blue, alpha)


  Velora.invoke(0x9CC300,"void", x, y, z, radius, red, green, blue, alpha)


end


-- PC:0x0134F0835AB6BFCB Old:0xF541B690


function GRAPHICS.CREATE_CHECKPOINT(type, posX1, posY1, posZ1, posX2, posY2, posZ2, diameter, red, green, blue, alpha, reserved)


  return Velora.invoke(0x9CC540,"int", type, posX1, posY1, posZ1, posX2, posY2, posZ2, diameter, red, green, blue, alpha, reserved)


end


-- PC:0x4B5B4DA5D79F1943 Old:0x80151CCF


function GRAPHICS.SET_CHECKPOINT_INSIDE_CYLINDER_HEIGHT_SCALE(checkpoint, scale)


  Velora.invoke(0x9CC540,"void", checkpoint, scale)


end


function GRAPHICS.SET_CHECKPOINT_INSIDE_CYLINDER_SCALE(checkpoint, scale)


  Velora.invoke(0x9CC590,"void", checkpoint, scale)


end


-- PC:0x2707AAE9D9297D89 Old:0xFF0F9B22


function GRAPHICS.SET_CHECKPOINT_CYLINDER_HEIGHT(checkpoint, nearHeight, farHeight, radius)


  Velora.invoke(0x9CC5E0,"void", checkpoint, nearHeight, farHeight, radius)


end


-- PC:0x7167371E8AD747F7 Old:0xEF9C8CB3


function GRAPHICS.SET_CHECKPOINT_RGBA(checkpoint, red, green, blue, alpha)


  Velora.invoke(0x9CC650,"void", checkpoint, red, green, blue, alpha)


end


-- PC:0xB9EA40907C680580 Old:0xA5456DBB


function GRAPHICS.SET_CHECKPOINT_RGBA2(checkpoint, red, green, blue, alpha)


  Velora.invoke(0x9CC6D0,"void", checkpoint, red, green, blue, alpha)


end


-- PC:0xF51D36185993515D Old:0x20EABD0F


function GRAPHICS.SET_CHECKPOINT_CLIPPLANE_WITH_POS_NORM(checkpoint, posX, posY, posZ, unkX, unkY, unkZ)


  Velora.invoke(0x9CC750,"void", checkpoint, posX, posY, posZ, unkX, unkY, unkZ)


end


function GRAPHICS.SET_CHECKPOINT_FORCE_OLD_ARROW_POINTING(checkpoint)


  Velora.invoke(0x9CC7D0,"void", checkpoint)


end


-- PC:0x615D3925E87A3B26 Old:0x1E3A3126


function GRAPHICS.SET_CHECKPOINT_DECAL_ROT_ALIGNED_TO_CAMERA_ROT(checkpoint)


  Velora.invoke(0x9CC810,"void", checkpoint)


end


function GRAPHICS.SET_CHECKPOINT_FORCE_DIRECTION(checkpoint)


  Velora.invoke(0x9CC850,"void", checkpoint)


end


function GRAPHICS.SET_CHECKPOINT_DIRECTION(checkpoint, posX, posY, posZ)


  Velora.invoke(0x9CC890,"void", checkpoint, posX, posY, posZ)


end


-- PC:0xF5ED37F54CD4D52E Old:0xB66CF3CA


function GRAPHICS.DELETE_CHECKPOINT(checkpoint)


  Velora.invoke(0x9CC8F0,"void", checkpoint)


end


-- PC:0x22A249A53034450A Old:0x932FDB81


function GRAPHICS.DONT_RENDER_IN_GAME_UI(p0)


  Velora.invoke(0x9CC930,"void", p0)


end


-- PC:0xDC459CFA0CCE245B Old:0x7E946E87


function GRAPHICS.FORCE_RENDER_IN_GAME_UI(toggle)


  Velora.invoke(0x9CC950,"void", toggle)


end


-- PC:0xDFA2EF8E04127DD5 Old:0x4C9B035F


function GRAPHICS.REQUEST_STREAMED_TEXTURE_DICT(textureDict, p1)


  Velora.invoke(0x9CC970,"void", textureDict, p1)


end


-- PC:0x0145F696AAAAD2E4 Old:0x3F436EEF


function GRAPHICS.HAS_STREAMED_TEXTURE_DICT_LOADED(textureDict)


  return Velora.invoke(0x9CCA60,"bool", textureDict)


end


-- PC:0xBE2CACCF5A8AA805 Old:0xF07DDA38


function GRAPHICS.SET_STREAMED_TEXTURE_DICT_AS_NO_LONGER_NEEDED(textureDict)


  Velora.invoke(0x9CCA60,"void", textureDict)


end


-- PC:0x3A618A217E5154F0 Old:0xDD2BFC77


function GRAPHICS.DRAW_RECT(x, y, width, height, r, g, b, a)


  Velora.invoke(0x9CCAC0,"void", x, y, width, height, r, g, b, a)


end


-- PC:0xC6372ECD45D73BCD Old:0xF8FBCC25


function GRAPHICS.SET_SCRIPT_GFX_DRAW_BEHIND_PAUSEMENU(toggle)


  Velora.invoke(0x9CCB00,"void", toggle)


end


-- PC:0x61BB1D9B3A95D802 Old:0xADF81D24


function GRAPHICS.SET_SCRIPT_GFX_DRAW_ORDER(drawOrder)


  Velora.invoke(0x9CCB20,"void", drawOrder)


end


-- PC:0xB8A850F20A067EB6 Old:0x228A2598


function GRAPHICS.SET_SCRIPT_GFX_ALIGN(horizontalAlign, verticalAlign)


  Velora.invoke(0x9CCBB0,"void", horizontalAlign, verticalAlign)


end


-- PC:0xE3A3DB414A373DAB Old:0x3FE33BD6


function GRAPHICS.RESET_SCRIPT_GFX_ALIGN()


  Velora.invoke(0x9CCBD0,"void")


end


-- PC:0xF5A2C681787E579D Old:0x76C641E4


function GRAPHICS.SET_SCRIPT_GFX_ALIGN_PARAMS(x, y, w, h)


  Velora.invoke(0x9CCBF0,"void", x, y, w, h)


end


function GRAPHICS.GET_SCRIPT_GFX_ALIGN_POSITION(x, y)


  Velora.invoke(0x9CCC30,"void", x, y)


end


-- PC:0xBAF107B6BB2C97F0 Old:0x3F0D1A6F


function GRAPHICS.GET_SAFE_ZONE_SIZE()


  return Velora.invoke(0x9CCCD0,"float")


end


-- PC:0xE7FFAE5EBF23D890 Old:0x1FEC16B0


function GRAPHICS.DRAW_SPRITE(textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha)


  Velora.invoke(0x9CCCD0,"void", textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha)


end


function GRAPHICS.DRAW_SPRITE_ARX(textureDict, textureName, x, y, width, height, p6, red, green, blue, alpha, p11, p12)


  Velora.invoke(0x9CCE30,"void", textureDict, textureName, x, y, width, height, p6, red, green, blue, alpha, p11, p12)


end


function GRAPHICS.DRAW_SPRITE_NAMED_RENDERTARGET(textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha, p11)


  Velora.invoke(0x9CCF90,"void", textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha, p11)


end


function GRAPHICS.DRAW_SPRITE_ARX_WITH_UV(textureDict, textureName, x, y, width, height, u1, v1, u2, v2, heading, red, green, blue, alpha, p15)


  Velora.invoke(0x9CD0E0,"void", textureDict, textureName, x, y, width, height, u1, v1, u2, v2, heading, red, green, blue, alpha, p15)


end


-- PC:0x9CD43EEE12BF4DD0 Old:0xF3027D21


function GRAPHICS.ADD_ENTITY_ICON(entity, icon)


  return Velora.invoke(0x9CD3C0,"int", entity, icon)


end


-- PC:0xE0E8BEECCA96BA31 Old:0xD1D2FD52


function GRAPHICS.SET_ENTITY_ICON_VISIBILITY(entity, toggle)


  Velora.invoke(0x9CD3C0,"void", entity, toggle)


end


-- PC:0x1D5F595CCAE2E238 Old:0x6EE1E946


function GRAPHICS.SET_ENTITY_ICON_COLOR(entity, red, green, blue, alpha)


  Velora.invoke(0x9CD420,"void", entity, red, green, blue, alpha)


end


-- PC:0xAA0008F3BBB8F416 Old:0xE10198D5


function GRAPHICS.SET_DRAW_ORIGIN(x, y, z, p3)


  Velora.invoke(0x9CD4C0,"void", x, y, z, p3)


end


-- PC:0xFF0B610F6BE0D7AF Old:0xDD76B263


function GRAPHICS.CLEAR_DRAW_ORIGIN()


  Velora.invoke(0x9CD580,"void")


end


function GRAPHICS.SET_BINK_MOVIE(name)


  return Velora.invoke(0x9CD620,"int", name)


end


function GRAPHICS.PLAY_BINK_MOVIE(binkMovie)


  Velora.invoke(0x9CD620,"void", binkMovie)


end


function GRAPHICS.STOP_BINK_MOVIE(binkMovie)


  Velora.invoke(0x9CD660,"void", binkMovie)


end


function GRAPHICS.RELEASE_BINK_MOVIE(binkMovie)


  Velora.invoke(0x9CD6A0,"void", binkMovie)


end


function GRAPHICS.DRAW_BINK_MOVIE(binkMovie, p1, p2, p3, p4, p5, r, g, b, a)


  Velora.invoke(0x9CD6F0,"void", binkMovie, p1, p2, p3, p4, p5, r, g, b, a)


end


function GRAPHICS.SET_BINK_MOVIE_TIME(binkMovie, progress)


  Velora.invoke(0x9CD820,"void", binkMovie, progress)


end


function GRAPHICS.GET_BINK_MOVIE_TIME(binkMovie)


  return Velora.invoke(0x9CD8E0,"float", binkMovie)


end


function GRAPHICS.SET_BINK_MOVIE_VOLUME(binkMovie, value)


  Velora.invoke(0x9CD8E0,"void", binkMovie, value)


end


-- PC:0x845BAD77CC770633 Old:0x784944DB


function GRAPHICS.ATTACH_TV_AUDIO_TO_ENTITY(entity)


  Velora.invoke(0x9CD920,"void", entity)


end


function GRAPHICS.SET_BINK_MOVIE_AUDIO_FRONTEND(binkMovie, p1)


  Velora.invoke(0x9CD990,"void", binkMovie, p1)


end


-- PC:0x113D2C5DC57E1774 Old:0x2E0DFA35


function GRAPHICS.SET_TV_AUDIO_FRONTEND(toggle)


  Velora.invoke(0x9CD9D0,"void", toggle)


end


function GRAPHICS.SET_BINK_SHOULD_SKIP(binkMovie, bShouldSkip)


  Velora.invoke(0x9CD9F0,"void", binkMovie, bShouldSkip)


end


-- PC:0xB66064452270E8F1 Old:0x9627905C


function GRAPHICS.LOAD_MOVIE_MESH_SET(movieMeshSetName)


  return Velora.invoke(0x9CDAB0,"int", movieMeshSetName)


end


-- PC:0xEB119AA014E89183 Old:0x4FA5501D


function GRAPHICS.RELEASE_MOVIE_MESH_SET(movieMeshSet)


  Velora.invoke(0x9CDAB0,"void", movieMeshSet)


end


-- PC:0x9B6E70C5CEEF4EEB Old:0x9D5D9B38


function GRAPHICS.QUERY_MOVIE_MESH_SET_STATE(p0)


  return Velora.invoke(0x9CDB30,"int", p0)


end


-- PC:0x888D57E407E63624 Old:0x29F3572F


function GRAPHICS.GET_SCREEN_RESOLUTION()


  Velora.invoke(0x9CDB30,"void")


end


function GRAPHICS.GET_ACTUAL_SCREEN_RESOLUTION()


  Velora.invoke(0x9CDB50,"void")


end


function GRAPHICS.GET_ASPECT_RATIO(b)


  return Velora.invoke(0x9CDC20,"float", b)


end


function GRAPHICS.GET_SCREEN_ASPECT_RATIO()


  return Velora.invoke(0x9CDBB0,"float")


end


-- PC:0x30CF4BDA4FCB1905 Old:0xEC717AEF


function GRAPHICS.GET_IS_WIDESCREEN()


  return Velora.invoke(0x9CDBE0,"bool")


end


-- PC:0x84ED31191CC5D2C9 Old:0x1C340359


function GRAPHICS.GET_IS_HIDEF()


  return Velora.invoke(0x9CDC00,"bool")


end


function GRAPHICS.ADJUST_NEXT_POS_SIZE_AS_NORMALIZED_16_9()


  Velora.invoke(0x9CDC20,"void")


end


-- PC:0x18F621F7A5B1F85D Old:0xD1E5565F


function GRAPHICS.SET_NIGHTVISION(toggle)


  Velora.invoke(0x9CDC30,"void", toggle)


end


-- PC:0x35FB78DC42B7BD21 Old:0xF3A6309E


function GRAPHICS.GET_REQUESTINGNIGHTVISION()


  return Velora.invoke(0x9CDCB0,"bool")


end


-- PC:0x2202A3F42C8E5F79 Old:0x62619061


function GRAPHICS.GET_USINGNIGHTVISION()


  return Velora.invoke(0x9CDC60,"bool")


end


function GRAPHICS.SET_EXPOSURETWEAK(toggle)


  Velora.invoke(0x9CDCB0,"void", toggle)


end


function GRAPHICS.FORCE_EXPOSURE_READBACK(toggle)


  Velora.invoke(0x9CDCD0,"void", toggle)


end


function GRAPHICS.OVERRIDE_NIGHTVISION_LIGHT_RANGE(p0)


  Velora.invoke(0x9CDCF0,"void", p0)


end


-- PC:0xE787BF1C5CF823C9 Old:0xD576F5DD


function GRAPHICS.SET_NOISEOVERIDE(toggle)


  Velora.invoke(0x9CDD00,"void", toggle)


end


-- PC:0xCB6A7C3BB17A0C67 Old:0x046B62D9


function GRAPHICS.SET_NOISINESSOVERIDE(value)


  Velora.invoke(0x9CDD20,"void", value)


end


-- PC:0x34E82F05DF2974F5 Old:0x1F950E4B


function GRAPHICS.GET_SCREEN_COORD_FROM_WORLD_COORD(worldX, worldY, worldZ)


  return Velora.invoke(0x9CDE50,"bool", worldX, worldY, worldZ)


end


-- PC:0x35736EE65BD00C11 Old:0x096DAA4D


function GRAPHICS.GET_TEXTURE_RESOLUTION(textureDict, textureName)


  local x,y,z=Velora.invoke(0x9CDDB0,"vector3", textureDict, textureName)


  return {x=x,y=y,z=z}


end


function GRAPHICS.OVERRIDE_PED_CREW_LOGO_TEXTURE(ped, txd, txn)


  return Velora.invoke(0x9CDE20,"bool", ped, txd, txn)


end


-- PC:0xE2892E7E55D7073A Old:0x455F1084


function GRAPHICS.SET_DISTANCE_BLUR_STRENGTH_OVERRIDE(p0)


  Velora.invoke(0x9CDE50,"void", p0)


end


-- PC:0x0AB84296FED9CFC6 Old:0x7E55A1EE


function GRAPHICS.SET_FLASH(p0, p1, fadeIn, duration, fadeOut)


  Velora.invoke(0x9CDE70,"void", p0, p1, fadeIn, duration, fadeOut)


end


-- PC:0x3669F1B198DCAA4F Old:0x0DCC0B8B


function GRAPHICS.DISABLE_OCCLUSION_THIS_FRAME()


  Velora.invoke(0x9CDEA0,"void")


end


-- PC:0x1268615ACE24D504 Old:0xAA2A0EAF


function GRAPHICS.SET_ARTIFICIAL_LIGHTS_STATE(state)


  Velora.invoke(0x9CDEB0,"void", state)


end


function GRAPHICS.SET_ARTIFICIAL_VEHICLE_LIGHTS_STATE(toggle)


  Velora.invoke(0x9CDED0,"void", toggle)


end


function GRAPHICS.DISABLE_HDTEX_THIS_FRAME()


  Velora.invoke(0x9CDEF0,"void")


end


-- PC:0xE2C9439ED45DEA60 Old:0x3129C31A


function GRAPHICS.CREATE_TRACKED_POINT()


  return Velora.invoke(0x9CDF20,"int")


end


-- PC:0x164ECBB3CF750CB0 Old:0x28689AA4


function GRAPHICS.SET_TRACKED_POINT_INFO(point, x, y, z, radius)


  Velora.invoke(0x9CDF20,"void", point, x, y, z, radius)


end


-- PC:0xC45CCDAAC9221CA8 Old:0x0BFC4F64


function GRAPHICS.IS_TRACKED_POINT_VISIBLE(point)


  return Velora.invoke(0x9CE000,"bool", point)


end


-- PC:0xB25DC90BAD56CA42 Old:0x14AC675F


function GRAPHICS.DESTROY_TRACKED_POINT(point)


  Velora.invoke(0x9CE000,"void", point)


end


function GRAPHICS.SET_GRASS_CULL_SPHERE(p0, p1, p2, p3)


  return Velora.invoke(0x9CE020,"int", p0, p1, p2, p3)


end


function GRAPHICS.REMOVE_GRASS_CULL_SPHERE(handle)


  Velora.invoke(0x9CE020,"void", handle)


end


function GRAPHICS.PROCGRASS_ENABLE_CULLSPHERE(handle, x, y, z, scale)


  Velora.invoke(0x9CE030,"void", handle, x, y, z, scale)


end


function GRAPHICS.PROCGRASS_DISABLE_CULLSPHERE(handle)


  Velora.invoke(0x9CE090,"void", handle)


end


function GRAPHICS.PROCGRASS_IS_CULLSPHERE_ENABLED(handle)


  return Velora.invoke(0x9CE0E0,"bool", handle)


end


function GRAPHICS.PROCGRASS_ENABLE_AMBSCALESCAN()


  Velora.invoke(0x9CE0E0,"void")


end


function GRAPHICS.PROCGRASS_DISABLE_AMBSCALESCAN()


  Velora.invoke(0x9CE0F0,"void")


end


function GRAPHICS.DISABLE_PROCOBJ_CREATION()


  Velora.invoke(0x9CE100,"void")


end


function GRAPHICS.ENABLE_PROCOBJ_CREATION()


  Velora.invoke(0x9CE110,"void")


end


function GRAPHICS.GRASSBATCH_ENABLE_FLATTENING_EXT_IN_SPHERE(x, y, z, p3, p4, p5, p6, scale)


  Velora.invoke(0x9CE120,"void", x, y, z, p3, p4, p5, p6, scale)


end


function GRAPHICS.GRASSBATCH_ENABLE_FLATTENING_IN_SPHERE(x, y, z, radius, p4, p5, p6)


  Velora.invoke(0x9CE1B0,"void", x, y, z, radius, p4, p5, p6)


end


function GRAPHICS.GRASSBATCH_DISABLE_FLATTENING()


  Velora.invoke(0x9CE240,"void")


end


-- PC:0x03FC694AE06C5A20 Old:0x48F16186


function GRAPHICS.CASCADE_SHADOWS_INIT_SESSION()


  Velora.invoke(0x9CE250,"void")


end


-- PC:0xD2936CAB8B58FCBD Old:0x84F05943


function GRAPHICS.CASCADE_SHADOWS_SET_CASCADE_BOUNDS(p0, p1, p2, p3, p4, p5, p6, p7)


  Velora.invoke(0x9CE270,"void", p0, p1, p2, p3, p4, p5, p6, p7)


end


-- PC:0x5F0F3F56635809EF Old:0x13D4ABC0


function GRAPHICS.CASCADE_SHADOWS_SET_CASCADE_BOUNDS_SCALE(p0)


  Velora.invoke(0x9CE2B0,"void", p0)


end


-- PC:0x5E9DAF5A20F15908 Old:0xD2157428


function GRAPHICS.CASCADE_SHADOWS_SET_ENTITY_TRACKER_SCALE(p0)


  Velora.invoke(0x9CE2C0,"void", p0)


end


-- PC:0x36F6626459D91457 Old:0xC07C64C9


function GRAPHICS.CASCADE_SHADOWS_SET_SPLIT_Z_EXP_WEIGHT(p0)


  Velora.invoke(0x9CE2D0,"void", p0)


end


function GRAPHICS.CASCADE_SHADOWS_SET_BOUND_POSITION(p0)


  Velora.invoke(0x9CE2E0,"void", p0)


end


-- PC:0x80ECBC0C856D3B0B Old:0xFE903D0F


function GRAPHICS.CASCADE_SHADOWS_ENABLE_ENTITY_TRACKER(toggle)


  Velora.invoke(0x9CE2F0,"void", toggle)


end


function GRAPHICS.CASCADE_SHADOWS_SET_SCREEN_SIZE_CHECK_ENABLED(p0)


  Velora.invoke(0x9CE310,"void", p0)


end


-- PC:0xB11D94BC55F41932 Old:0xDE10BA1F


function GRAPHICS.CASCADE_SHADOWS_SET_SHADOW_SAMPLE_TYPE(type)


  Velora.invoke(0x9CE330,"void", type)


end


function GRAPHICS.CASCADE_SHADOWS_CLEAR_SHADOW_SAMPLE_TYPE()


  Velora.invoke(0x9CE340,"void")


end


-- PC:0x6DDBF9DFFC4AC080 Old:0x9F470BE3


function GRAPHICS.CASCADE_SHADOWS_SET_AIRCRAFT_MODE(p0)


  Velora.invoke(0x9CE350,"void", p0)


end


-- PC:0xD39D13C9FEBF0511 Old:0x4A124267


function GRAPHICS.CASCADE_SHADOWS_SET_DYNAMIC_DEPTH_MODE(p0)


  Velora.invoke(0x9CE370,"void", p0)


end


-- PC:0x02AC28F3A01FA04A Old:0xB19B2764


function GRAPHICS.CASCADE_SHADOWS_SET_DYNAMIC_DEPTH_VALUE(p0)


  Velora.invoke(0x9CE390,"void", p0)


end


-- PC:0x0AE73D8DF3A762B2 Old:0x342FA2B4


function GRAPHICS.CASCADE_SHADOWS_ENABLE_FREEZER(p0)


  Velora.invoke(0x9CE3A0,"void", p0)


end


function GRAPHICS.WATER_REFLECTION_SET_SCRIPT_OBJECT_VISIBILITY(p0)


  Velora.invoke(0x9CE3C0,"void", p0)


end


-- PC:0xA51C4B86B71652AE Old:0x5D3BFFC9


function GRAPHICS.GOLF_TRAIL_SET_ENABLED(toggle)


  Velora.invoke(0x9CE3E0,"void", toggle)


end


-- PC:0x312342E1A4874F3F Old:0xD9653728


function GRAPHICS.GOLF_TRAIL_SET_PATH(p0, p1, p2, p3, p4, p5, p6, p7, p8)


  Velora.invoke(0x9CE400,"void", p0, p1, p2, p3, p4, p5, p6, p7, p8)


end


-- PC:0x2485D34E50A22E84 Old:0x72BA8A14


function GRAPHICS.GOLF_TRAIL_SET_RADIUS(p0, p1, p2)


  Velora.invoke(0x9CE450,"void", p0, p1, p2)


end


-- PC:0x12995F2E53FFA601 Old:0x804F444C


function GRAPHICS.GOLF_TRAIL_SET_COLOUR(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)


  Velora.invoke(0x9CE470,"void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)


end


-- PC:0xDBAA5EC848BA2D46 Old:0xBB1A1294


function GRAPHICS.GOLF_TRAIL_SET_TESSELLATION(p0, p1)


  Velora.invoke(0x9CE4E0,"void", p0, p1)


end


-- PC:0xC0416B061F2B7E5E Old:0x1A1A72EF


function GRAPHICS.GOLF_TRAIL_SET_FIXED_CONTROL_POINT_ENABLE(p0)


  Velora.invoke(0x9CE4F0,"void", p0)


end


-- PC:0xB1BB03742917A5D6 Old:0x3BB12B75


function GRAPHICS.GOLF_TRAIL_SET_FIXED_CONTROL_POINT(type, xPos, yPos, zPos, p4, red, green, blue, alpha)


  Velora.invoke(0x9CE510,"void", type, xPos, yPos, zPos, p4, red, green, blue, alpha)


end


-- PC:0x9CFDD90B2B844BF7 Old:0x4EA70FB4


function GRAPHICS.GOLF_TRAIL_SET_SHADER_PARAMS(p0, p1, p2, p3, p4)


  Velora.invoke(0x9CE5D0,"void", p0, p1, p2, p3, p4)


end


-- PC:0x06F761EA47C1D3ED Old:0x0D830DC7


function GRAPHICS.GOLF_TRAIL_SET_FACING(p0)


  Velora.invoke(0x9CE600,"void", p0)


end


-- PC:0xA4819F5E23E2FFAD Old:0xA08B46AD


function GRAPHICS.GOLF_TRAIL_GET_MAX_HEIGHT()


  return Velora.invoke(0x9CE690,"float")


end


-- PC:0xA4664972A9B8F8BA Old:0xECD470F0


function GRAPHICS.GOLF_TRAIL_GET_VISUAL_CONTROL_POINT(p0)


  local x,y,z=Velora.invoke(0x9CE640,"vector3", p0)


  return {x=x,y=y,z=z}


end


-- PC:0x7E08924259E08CE0 Old:0x74D4995C


function GRAPHICS.SET_SEETHROUGH(toggle)


  Velora.invoke(0x9CE690,"void", toggle)


end


-- PC:0x44B80ABAB9D80BD3 Old:0x1FE547F2


function GRAPHICS.GET_USINGSEETHROUGH()


  return Velora.invoke(0x9CE6E0,"bool")


end


-- PC:0x70A64C0234EF522C Old:0x310E9B67


function GRAPHICS.SEETHROUGH_RESET()


  Velora.invoke(0x9CE6E0,"void")


end


function GRAPHICS.SEETHROUGH_SET_FADE_STARTDISTANCE(distance)


  Velora.invoke(0x9CE6F0,"void", distance)


end


function GRAPHICS.SEETHROUGH_SET_FADE_ENDDISTANCE(distance)


  Velora.invoke(0x9CE710,"void", distance)


end


function GRAPHICS.SEETHROUGH_GET_MAX_THICKNESS()


  return Velora.invoke(0x9CE750,"float")


end


function GRAPHICS.SEETHROUGH_SET_MAX_THICKNESS(thickness)


  Velora.invoke(0x9CE750,"void", thickness)


end


function GRAPHICS.SEETHROUGH_SET_NOISE_MIN(amount)


  Velora.invoke(0x9CE780,"void", amount)


end


function GRAPHICS.SEETHROUGH_SET_NOISE_MAX(amount)


  Velora.invoke(0x9CE7A0,"void", amount)


end


function GRAPHICS.SEETHROUGH_SET_HILIGHT_INTENSITY(intensity)


  Velora.invoke(0x9CE7C0,"void", intensity)


end


function GRAPHICS.SEETHROUGH_SET_HIGHLIGHT_NOISE(noise)


  Velora.invoke(0x9CE7E0,"void", noise)


end


-- PC:0xD7D0B00177485411 Old:0x654F0287


function GRAPHICS.SEETHROUGH_SET_HEATSCALE(index, heatScale)


  Velora.invoke(0x9CE800,"void", index, heatScale)


end


-- PC:0x1086127B3A63505E Old:0x5B2A67A8


function GRAPHICS.SEETHROUGH_SET_COLOR_NEAR(red, green, blue)


  Velora.invoke(0x9CE840,"void", red, green, blue)


end


-- PC:0xB3C641F3630BF6DA Old:0xF6B837F0


function GRAPHICS.SET_MOTIONBLUR_MAX_VEL_SCALER(p0)


  Velora.invoke(0x9CE8C0,"void", p0)


end


-- PC:0xE59343E9E96529E7 Old:0xD906A3A9


function GRAPHICS.GET_MOTIONBLUR_MAX_VEL_SCALER()


  return Velora.invoke(0x9CE900,"float")


end


function GRAPHICS.SET_FORCE_MOTIONBLUR(toggle)


  Velora.invoke(0x9CE900,"void", toggle)


end


-- PC:0xE63D7C6EECECB66B Old:0xD34A6CBA


function GRAPHICS.TOGGLE_PLAYER_DAMAGE_OVERLAY(toggle)


  Velora.invoke(0x9CE920,"void", toggle)


end


-- PC:0xE3E2C1B4C59DBC77 Old:0xD8CC7221


function GRAPHICS.RESET_ADAPTATION(p0)


  Velora.invoke(0x9CE950,"void", p0)


end


-- PC:0xA328A24AAA6B7FDC Old:0x5604B890


function GRAPHICS.TRIGGER_SCREENBLUR_FADE_IN(transitionTime)


  return Velora.invoke(0x9CEA10,"bool", transitionTime)


end


-- PC:0xEFACC8AEF94430D5 Old:0x46617502


function GRAPHICS.TRIGGER_SCREENBLUR_FADE_OUT(transitionTime)


  return Velora.invoke(0x9CE9B0,"bool", transitionTime)


end


-- PC:0xDE81239437E8C5A8 Old:0xDB7AECDA


function GRAPHICS.DISABLE_SCREENBLUR_FADE()


  Velora.invoke(0x9CEA10,"void")


end


-- PC:0x5CCABFFCA31DDE33 Old:0xEA432A94


function GRAPHICS.GET_SCREENBLUR_FADE_CURRENT_TIME()


  return Velora.invoke(0x9CEA80,"float")


end


-- PC:0x7B226C785A52A0A9 Old:0x926B8734


function GRAPHICS.IS_SCREENBLUR_FADE_RUNNING()


  return Velora.invoke(0x9CEA40,"bool")


end


-- PC:0xDFC252D8A3E15AB7 Old:0x30ADE541


function GRAPHICS.TOGGLE_PAUSED_RENDERPHASES(toggle)


  Velora.invoke(0x9CEA80,"void", toggle)


end


-- PC:0xEB3DAC2C86001E5E Old:0xD4F5D07D


function GRAPHICS.GET_TOGGLE_PAUSED_RENDERPHASES_STATUS()


  return Velora.invoke(0x9CEAC0,"bool")


end


-- PC:0xE1C8709406F2C41C Old:0x0113EAE4


function GRAPHICS.RESET_PAUSED_RENDERPHASES()


  Velora.invoke(0x9CEAC0,"void")


end


-- PC:0x851CD923176EBA7C Old:0xDCBA251B


function GRAPHICS.GRAB_PAUSEMENU_OWNERSHIP()


  Velora.invoke(0x9CEAD0,"void")


end


-- PC:0xBA3D65906822BED5 Old:0x513D444B


function GRAPHICS.SET_HIDOF_OVERRIDE(p0, p1, nearplaneOut, nearplaneIn, farplaneOut, farplaneIn)


  Velora.invoke(0x9CEAF0,"void", p0, p1, nearplaneOut, nearplaneIn, farplaneOut, farplaneIn)


end


function GRAPHICS.SET_LOCK_ADAPTIVE_DOF_DISTANCE(p0)


  Velora.invoke(0x9CEB40,"void", p0)


end


-- PC:0x7AC24EAB6D74118D Old:0xB2410EAB


function GRAPHICS.PHONEPHOTOEDITOR_TOGGLE(p0)


  return Velora.invoke(0x9CF0A0,"bool", p0)


end


-- PC:0xBCEDB009461DA156 Old:0x5AB94128


function GRAPHICS.PHONEPHOTOEDITOR_IS_ACTIVE()


  return Velora.invoke(0x9CEBC0,"bool")


end


-- PC:0x27FEB5254759CDE3 Old:0xD63FCB3E


function GRAPHICS.PHONEPHOTOEDITOR_SET_FRAME_TXD(textureDict, p1)


  return Velora.invoke(0x9CEBE0,"bool", textureDict, p1)


end


-- PC:0x25129531F77B9ED3 Old:0xDD79D679


function GRAPHICS.START_PARTICLE_FX_NON_LOOPED_AT_COORD(effectName, xPos, yPos, zPos, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis)


  return Velora.invoke(0x9CEC10,"bool", effectName, xPos, yPos, zPos, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis)


end


-- PC:0xF56B8137DF10135D Old:0x633F8C48


function GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD(effectName, xPos, yPos, zPos, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, p11)


  return Velora.invoke(0x9CECF0,"bool", effectName, xPos, yPos, zPos, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, p11)


end


-- PC:0x0E7E72961BA18619 Old:0x53DAEF4E


function GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE(effectName, ped, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, axisZ)


  return Velora.invoke(0x9CEDE0,"bool", effectName, ped, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, axisZ)


end


-- PC:0xA41B6A43642AC2CF Old:0x161780C1


function GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE(effectName, ped, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, axisZ)


  return Velora.invoke(0x9CEE70,"bool", effectName, ped, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, axisZ)


end


-- PC:0x0D53A3B8DA0809D2 Old:0x9604DAD4


function GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_ENTITY(effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, axisZ)


  return Velora.invoke(0x9CEF00,"bool", effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, axisZ)


end


-- PC:0xC95EB1DB6E92113D Old:0x469A2B4A


function GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_ENTITY(effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, axisZ)


  return Velora.invoke(0x9CEF90,"bool", effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, axisZ)


end


function GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_BONE(effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, axisZ)


  return Velora.invoke(0x9CF020,"bool", effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, axisZ)


end


-- PC:0x26143A59EF48B262 Old:0x7B689E20


function GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_COLOUR(r, g, b)


  Velora.invoke(0x9CF0A0,"void", r, g, b)


end


-- PC:0x77168D722C58B2FC Old:0x497EAFF2


function GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_ALPHA(alpha)


  Velora.invoke(0x9CF0C0,"void", alpha)


end


function GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_SCALE(scale)


  Velora.invoke(0x9CF0F0,"void", scale)


end


function GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_EMITTER_SIZE(p0, p1, scale)


  Velora.invoke(0x9CF100,"void", p0, p1, scale)


end


function GRAPHICS.SET_PARTICLE_FX_FORCE_VEHICLE_INTERIOR(toggle)


  Velora.invoke(0x9CF120,"void", toggle)


end


-- PC:0xE184F4F0DC5910E7 Old:0xD348E3E6


function GRAPHICS.START_PARTICLE_FX_LOOPED_AT_COORD(effectName, x, y, z, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, p11)


  return Velora.invoke(0x9CF440,"int", effectName, x, y, z, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, p11)


end


-- PC:0xF28DA9F38CD1787C Old:0xF8FC196F


function GRAPHICS.START_PARTICLE_FX_LOOPED_ON_PED_BONE(effectName, ped, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis)


  return Velora.invoke(0x9CF1A0,"int", effectName, ped, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis)


end


-- PC:0x1AE42C1660FD6517 Old:0x0D06FF62


function GRAPHICS.START_PARTICLE_FX_LOOPED_ON_ENTITY(effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis)


  return Velora.invoke(0x9CF200,"int", effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis)


end


-- PC:0xC6EB449E33977F0B Old:0x23BF0F9B


function GRAPHICS.START_PARTICLE_FX_LOOPED_ON_ENTITY_BONE(effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis)


  return Velora.invoke(0x9CF290,"int", effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis)


end


-- PC:0x6F60E89A7B64EE1D Old:0x110752B2


function GRAPHICS.START_NETWORKED_PARTICLE_FX_LOOPED_ON_ENTITY(effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, r, g, b, a)


  return Velora.invoke(0x9CF320,"int", effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, r, g, b, a)


end


-- PC:0xDDE23F30CC5A0F03 Old:0xF478EFCF


function GRAPHICS.START_NETWORKED_PARTICLE_FX_LOOPED_ON_ENTITY_BONE(effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis, r, g, b, a)


  return Velora.invoke(0x9CF3B0,"int", effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis, r, g, b, a)


end


-- PC:0x8F75998877616996 Old:0xD245455B


function GRAPHICS.STOP_PARTICLE_FX_LOOPED(ptfxHandle, p1)


  Velora.invoke(0x9CF440,"void", ptfxHandle, p1)


end


-- PC:0xC401503DFE8D53CF Old:0x6BA48C7E


function GRAPHICS.REMOVE_PARTICLE_FX(ptfxHandle, p1)


  Velora.invoke(0x9CF460,"void", ptfxHandle, p1)


end


-- PC:0xB8FEAEEBCC127425 Old:0xCEDE52E9


function GRAPHICS.REMOVE_PARTICLE_FX_FROM_ENTITY(entity)


  Velora.invoke(0x9CF480,"void", entity)


end


-- PC:0xDD19FA1C6D657305 Old:0x7EB8F275


function GRAPHICS.REMOVE_PARTICLE_FX_IN_RANGE(X, Y, Z, radius)


  Velora.invoke(0x9CF4D0,"void", X, Y, Z, radius)


end


function GRAPHICS.FORCE_PARTICLE_FX_IN_VEHICLE_INTERIOR(p0, p1)


  Velora.invoke(0x9CF500,"void", p0, p1)


end


-- PC:0x74AFEF0D2E1E409B Old:0xCBF91D2A


function GRAPHICS.DOES_PARTICLE_FX_LOOPED_EXIST(ptfxHandle)


  return Velora.invoke(0x9CF550,"bool", ptfxHandle)


end


-- PC:0xF7DDEBEC43483C43 Old:0x641F7790


function GRAPHICS.SET_PARTICLE_FX_LOOPED_OFFSETS(ptfxHandle, x, y, z, rotX, rotY, rotZ)


  Velora.invoke(0x9CF550,"void", ptfxHandle, x, y, z, rotX, rotY, rotZ)


end


-- PC:0x5F0C4B5B1C393BE2 Old:0x1CBC1373


function GRAPHICS.SET_PARTICLE_FX_LOOPED_EVOLUTION(ptfxHandle, propertyName, amount, noNetwork)


  Velora.invoke(0x9CF5A0,"void", ptfxHandle, propertyName, amount, noNetwork)


end


-- PC:0x7F8F65877F88783B Old:0x5219D530


function GRAPHICS.SET_PARTICLE_FX_LOOPED_COLOUR(ptfxHandle, r, g, b, p4)


  Velora.invoke(0x9CF5C0,"void", ptfxHandle, r, g, b, p4)


end


-- PC:0x726845132380142E Old:0x5ED49BE1


function GRAPHICS.SET_PARTICLE_FX_LOOPED_ALPHA(ptfxHandle, alpha)


  Velora.invoke(0x9CF5F0,"void", ptfxHandle, alpha)


end


-- PC:0xB44250AAA456492D Old:0x099B8B49


function GRAPHICS.SET_PARTICLE_FX_LOOPED_SCALE(ptfxHandle, scale)


  Velora.invoke(0x9CF600,"void", ptfxHandle, scale)


end


-- PC:0xDCB194B85EF7B541 Old:0x233DE879


function GRAPHICS.SET_PARTICLE_FX_LOOPED_FAR_CLIP_DIST(ptfxHandle, range)


  Velora.invoke(0x9CF610,"void", ptfxHandle, range)


end


-- PC:0xEEC4047028426510 Old:0x19EC0001


function GRAPHICS.SET_PARTICLE_FX_CAM_INSIDE_VEHICLE(p0)


  Velora.invoke(0x9CF630,"void", p0)


end


-- PC:0xACEE6F360FC1F6B6 Old:0x6B125A02


function GRAPHICS.SET_PARTICLE_FX_CAM_INSIDE_NONPLAYER_VEHICLE(vehicle, p1)


  Velora.invoke(0x9CF650,"void", vehicle, p1)


end


-- PC:0x96EF97DAEB89BEF5 Old:0xD938DEE0


function GRAPHICS.SET_PARTICLE_FX_SHOOTOUT_BOAT(p0)


  Velora.invoke(0x9CF6D0,"void", p0)


end


function GRAPHICS.CLEAR_PARTICLE_FX_SHOOTOUT_BOAT()


  Velora.invoke(0x9CF740,"void")


end


function GRAPHICS.SET_PARTICLE_FX_BLOOD_SCALE(p0)


  Velora.invoke(0x9CF770,"void", p0)


end


function GRAPHICS.DISABLE_IN_WATER_PTFX(toggle)


  Velora.invoke(0x9CF7B0,"void", toggle)


end


function GRAPHICS.DISABLE_DOWNWASH_PTFX(toggle)


  Velora.invoke(0x9CF7E0,"void", toggle)


end


function GRAPHICS.SET_PARTICLE_FX_SLIPSTREAM_LODRANGE_SCALE(scale)


  Velora.invoke(0x9CF810,"void", scale)


end


-- PC:0xD821490579791273 Old:0xC61C75E9


function GRAPHICS.ENABLE_CLOWN_BLOOD_VFX(toggle)


  Velora.invoke(0x9CF850,"void", toggle)


end


-- PC:0x9DCE1F0F78260875 Old:0xCE8B8748


function GRAPHICS.ENABLE_ALIEN_BLOOD_VFX(toggle)


  Velora.invoke(0x9CF890,"void", toggle)


end


-- PC:0x27E32866E9A5C416 Old:0xC1AD5DDF


function GRAPHICS.SET_PARTICLE_FX_BULLET_IMPACT_SCALE(scale)


  Velora.invoke(0x9CF8D0,"void", scale)


end


-- PC:0xBB90E12CAC1DAB25 Old:0x3968E915


function GRAPHICS.SET_PARTICLE_FX_BULLET_IMPACT_LODRANGE_SCALE(p0)


  Velora.invoke(0x9CF910,"void", p0)


end


-- PC:0xCA4AE345A153D573 Old:0x64BA4648


function GRAPHICS.SET_PARTICLE_FX_BULLET_TRACE_NO_ANGLE_REJECT(p0)


  Velora.invoke(0x9CF950,"void", p0)


end


-- PC:0x54E22EA2C1956A8D Old:0x8BE3D47F


function GRAPHICS.SET_PARTICLE_FX_BANG_SCRAPE_LODRANGE_SCALE(p0)


  Velora.invoke(0x9CF980,"void", p0)


end


-- PC:0x949F397A288B28B3 Old:0xE3880F5A


function GRAPHICS.SET_PARTICLE_FX_FOOT_LODRANGE_SCALE(p0)


  Velora.invoke(0x9CF9C0,"void", p0)


end


function GRAPHICS.SET_PARTICLE_FX_FOOT_OVERRIDE_NAME(p0)


  Velora.invoke(0x9CFA00,"void", p0)


end


function GRAPHICS.SET_SKIDMARK_RANGE_SCALE(scale)


  Velora.invoke(0x9CFA80,"void", scale)


end


function GRAPHICS.SET_PTFX_FORCE_VEHICLE_INTERIOR_FLAG(p0)


  Velora.invoke(0x9CFAC0,"void", p0)


end


function GRAPHICS.REGISTER_POSTFX_BULLET_IMPACT(weaponWorldPosX, weaponWorldPosY, weaponWorldPosZ, intensity)


  Velora.invoke(0x9CFAF0,"void", weaponWorldPosX, weaponWorldPosY, weaponWorldPosZ, intensity)


end


function GRAPHICS.FORCE_POSTFX_BULLET_IMPACTS_AFTER_HUD(p0)


  Velora.invoke(0x9CFB60,"void", p0)


end


-- PC:0x6C38AF3693A69A91 Old:0x9C720B61


function GRAPHICS.USE_PARTICLE_FX_ASSET(name)


  Velora.invoke(0x9CFB80,"void", name)


end


-- PC:0xEA1E2D93F6F75ED9 Old:0xC92719A7


function GRAPHICS.SET_PARTICLE_FX_OVERRIDE(oldAsset, newAsset)


  Velora.invoke(0x9CFBA0,"void", oldAsset, newAsset)


end


-- PC:0x89C8553DD3274AAE Old:0x9E8D8B72


function GRAPHICS.RESET_PARTICLE_FX_OVERRIDE(name)


  Velora.invoke(0x9CFBD0,"void", name)


end


function GRAPHICS.SET_WEATHER_PTFX_USE_OVERRIDE_SETTINGS(p0)


  Velora.invoke(0x9CFC50,"void", p0)


end


function GRAPHICS.SET_WEATHER_PTFX_OVERRIDE_CURR_LEVEL(p0)


  Velora.invoke(0x9CFC70,"void", p0)


end


-- PC:0x9C30613D50A6ADEF Old:0xDEECBC57


function GRAPHICS.WASH_DECALS_IN_RANGE(x, y, z, range, p4)


  Velora.invoke(0x9CFC90,"void", x, y, z, range, p4)


end


-- PC:0x5B712761429DBC14 Old:0x2929F11A


function GRAPHICS.WASH_DECALS_FROM_VEHICLE(vehicle, p1)


  Velora.invoke(0x9CFCD0,"void", vehicle, p1)


end


-- PC:0xD77EDADB0420E6E0 Old:0xF81E884A


function GRAPHICS.FADE_DECALS_IN_RANGE(x, y, z, p3, p4)


  Velora.invoke(0x9CFD30,"void", x, y, z, p3, p4)


end


-- PC:0x5D6B2D4830A67C62 Old:0x06A619A0


function GRAPHICS.REMOVE_DECALS_IN_RANGE(x, y, z, range)


  Velora.invoke(0x9CFD70,"void", x, y, z, range)


end


-- PC:0xCCF71CBDDF5B6CB9 Old:0x8B67DCA7


function GRAPHICS.REMOVE_DECALS_FROM_OBJECT(obj)


  Velora.invoke(0x9CFDB0,"void", obj)


end


-- PC:0xA6F6F70FDC6D144C Old:0xF4999A55


function GRAPHICS.REMOVE_DECALS_FROM_OBJECT_FACING(obj, x, y, z)


  Velora.invoke(0x9CFE10,"void", obj, x, y, z)


end


-- PC:0xE91F1B65F2B48D57 Old:0x831D06CA


function GRAPHICS.REMOVE_DECALS_FROM_VEHICLE(vehicle)


  Velora.invoke(0x9CFE80,"void", vehicle)


end


-- PC:0xB302244A1839BDAD Old:0xEAD0C412


function GRAPHICS.ADD_DECAL(decalType, posX, posY, posZ, p4, p5, p6, p7, p8, p9, width, height, rCoef, gCoef, bCoef, opacity, timeout, p17, p18, p19)


  return Velora.invoke(0x9D0070,"int", decalType, posX, posY, posZ, p4, p5, p6, p7, p8, p9, width, height, rCoef, gCoef, bCoef, opacity, timeout, p17, p18, p19)


end


-- PC:0x4F5212C7AD880DF8 Old:0x1259DF42


function GRAPHICS.ADD_PETROL_DECAL(x, y, z, groundLvl, width, transparency)


  return Velora.invoke(0x9CFF70,"int", x, y, z, groundLvl, width, transparency)


end


function GRAPHICS.ADD_OIL_DECAL(x, y, z, groundLvl, width, transparency)


  return Velora.invoke(0x9CFFF0,"int", x, y, z, groundLvl, width, transparency)


end


-- PC:0x99AC7F0D8B9C893D Old:0xE3938B0B


function GRAPHICS.START_PETROL_TRAIL_DECALS(p0)


  Velora.invoke(0x9D0070,"void", p0)


end


-- PC:0x967278682CB6967A Old:0xBAEC6ADD


function GRAPHICS.ADD_PETROL_TRAIL_DECAL_INFO(x, y, z, p3)


  Velora.invoke(0x9D00D0,"void", x, y, z, p3)


end


-- PC:0x0A123435A26C36CD Old:0xCCCA6855


function GRAPHICS.END_PETROL_TRAIL_DECALS()


  Velora.invoke(0x9D0100,"void")


end


-- PC:0xED3F346429CCD659 Old:0xA4363188


function GRAPHICS.REMOVE_DECAL(decal)


  Velora.invoke(0x9D0110,"void", decal)


end


-- PC:0xC694D74949CAFD0C Old:0xCDD4A61A


function GRAPHICS.IS_DECAL_ALIVE(decal)


  return Velora.invoke(0x9D0190,"bool", decal)


end


-- PC:0x323F647679A09103 Old:0x054448EF


function GRAPHICS.GET_DECAL_WASH_LEVEL(decal)


  return Velora.invoke(0x9D0160,"float", decal)


end


-- PC:0xD9454B5752C857DC Old:0xEAB6417C


function GRAPHICS.SET_DISABLE_PETROL_DECALS_IGNITING_THIS_FRAME()


  Velora.invoke(0x9D0190,"void")


end


-- PC:0x27CFB1B1E078CB2D Old:0xC2703B88


function GRAPHICS.SET_DISABLE_PETROL_DECALS_RECYCLING_THIS_FRAME()


  Velora.invoke(0x9D01A0,"void")


end


-- PC:0x4B5CFC83122DF602 Old:0xA706E84D


function GRAPHICS.SET_DISABLE_DECAL_RENDERING_THIS_FRAME()


  Velora.invoke(0x9D01B0,"void")


end


-- PC:0x2F09F7976C512404 Old:0x242C6A04


function GRAPHICS.GET_IS_PETROL_DECAL_IN_RANGE(xCoord, yCoord, zCoord, radius)


  return Velora.invoke(0x9D0270,"bool", xCoord, yCoord, zCoord, radius)


end


-- PC:0x8A35C742130C6080 Old:0x335695CF


function GRAPHICS.PATCH_DECAL_DIFFUSE_MAP(decalType, textureDict, textureName)


  Velora.invoke(0x9D0270,"void", decalType, textureDict, textureName)


end


-- PC:0xB7ED70C49521A61D Old:0x7B786555


function GRAPHICS.UNPATCH_DECAL_DIFFUSE_MAP(decalType)


  Velora.invoke(0x9D02B0,"void", decalType)


end


-- PC:0x84C8D7C2D30D3280 Old:0xCE9E6CF2


function GRAPHICS.MOVE_VEHICLE_DECALS(p0, p1)


  Velora.invoke(0x9D02D0,"void", p0, p1)


end


-- PC:0x428BDCB9DA58DA53 Old:0x12077738


function GRAPHICS.ADD_VEHICLE_CREW_EMBLEM(vehicle, ped, boneIndex, x1, x2, x3, y1, y2, y3, z1, z2, z3, scale, p13, alpha)


  return Velora.invoke(0x9D0400,"bool", vehicle, ped, boneIndex, x1, x2, x3, y1, y2, y3, z1, z2, z3, scale, p13, alpha)


end


function GRAPHICS.ABORT_VEHICLE_CREW_EMBLEM_REQUEST()


  return Velora.invoke(0x9D03B0,"bool")


end


-- PC:0xD2300034310557E4 Old:0x667046A8


function GRAPHICS.REMOVE_VEHICLE_CREW_EMBLEM(vehicle, p1)


  Velora.invoke(0x9D0400,"void", vehicle, p1)


end


-- PC:0xFE26117A5841B2FF Old:0x4F4D76E8


function GRAPHICS.GET_VEHICLE_CREW_EMBLEM_REQUEST_STATE(vehicle, p1)


  return Velora.invoke(0x9D0530,"int", vehicle, p1)


end


-- PC:0x060D935D3981A275 Old:0x6D58F73B


function GRAPHICS.DOES_VEHICLE_HAVE_CREW_EMBLEM(vehicle, p1)


  return Velora.invoke(0x9D04C0,"bool", vehicle, p1)


end


-- PC:0x0E4299C549F0D1F1 Old:0x9BABCBA4


function GRAPHICS.DISABLE_COMPOSITE_SHOTGUN_DECALS(toggle)


  Velora.invoke(0x9D0530,"void", toggle)


end


-- PC:0x02369D5C8A51FDCF Old:0xFDF6D8DA


function GRAPHICS.DISABLE_SCUFF_DECALS(toggle)


  Velora.invoke(0x9D0560,"void", toggle)


end


-- PC:0x46D1A61A21F566FC Old:0x2056A015


function GRAPHICS.SET_DECAL_BULLET_IMPACT_RANGE_SCALE(p0)


  Velora.invoke(0x9D0590,"void", p0)


end


-- PC:0x2A2A52824DB96700 Old:0x0F486429


function GRAPHICS.OVERRIDE_INTERIOR_SMOKE_NAME(name)


  Velora.invoke(0x9D05D0,"void", name)


end


-- PC:0x1600FD8CF72EBC12 Old:0xD87CC710


function GRAPHICS.OVERRIDE_INTERIOR_SMOKE_LEVEL(level)


  Velora.invoke(0x9D0600,"void", level)


end


-- PC:0xEFB55E7C25D3B3BE Old:0xE29EE145


function GRAPHICS.OVERRIDE_INTERIOR_SMOKE_END()


  Velora.invoke(0x9D0620,"void")


end


function GRAPHICS.REGISTER_NOIR_LENS_EFFECT()


  Velora.invoke(0x9D0630,"void")


end


-- PC:0xC9F98AC1884E73A2 Old:0x7CFAE36F


function GRAPHICS.DISABLE_VEHICLE_DISTANTLIGHTS(toggle)


  Velora.invoke(0x9D0660,"void", toggle)


end


-- PC:0x03300B57FCAC6DDB Old:0x60F72371


function GRAPHICS.RENDER_SHADOWED_LIGHTS_WITH_NO_SHADOWS(p0)


  Velora.invoke(0x9D0680,"void", p0)


end


function GRAPHICS.REQUEST_EARLY_LIGHT_CHECK()


  Velora.invoke(0x9D06A0,"void")


end


-- PC:0xAEEDAD1420C65CC0 Old:0xC53576CA


function GRAPHICS.USE_SNOW_FOOT_VFX_WHEN_UNSHELTERED(toggle)


  Velora.invoke(0x9D06B0,"void", toggle)


end


-- PC:0x4CC7F0FEA5283FE0 Old:0x7158B1EA


function GRAPHICS.USE_SNOW_WHEEL_VFX_WHEN_UNSHELTERED(toggle)


  Velora.invoke(0x9D06F0,"void", toggle)


end


function GRAPHICS.DISABLE_REGION_VFX(p0)


  Velora.invoke(0x9D0710,"void", p0)


end


-- PC:0xD7021272EB0A451E Old:0x137E3E24


function GRAPHICS.PRESET_INTERIOR_AMBIENT_CACHE(timecycleModifierName)


  Velora.invoke(0x9D0760,"void", timecycleModifierName)


end


-- PC:0x2C933ABF17A1DF41 Old:0xA81F3638


function GRAPHICS.SET_TIMECYCLE_MODIFIER(modifierName)


  Velora.invoke(0x9D07B0,"void", modifierName)


end


-- PC:0x82E7FFCD5B2326B3 Old:0x458F4F45


function GRAPHICS.SET_TIMECYCLE_MODIFIER_STRENGTH(strength)


  Velora.invoke(0x9D0830,"void", strength)


end


-- PC:0x3BCF567485E1971C Old:0xBB2BA72A


function GRAPHICS.SET_TRANSITION_TIMECYCLE_MODIFIER(modifierName, transition)


  Velora.invoke(0x9D0850,"void", modifierName, transition)


end


-- PC:0x1CBA05AE7BD7EE05 Old:0x56345F6B


function GRAPHICS.SET_TRANSITION_OUT_OF_TIMECYCLE_MODIFIER(strength)


  Velora.invoke(0x9D08B0,"void", strength)


end


-- PC:0x0F07E7745A236711 Old:0x8D8DF8EE


function GRAPHICS.CLEAR_TIMECYCLE_MODIFIER()


  Velora.invoke(0x9D08D0,"void")


end


-- PC:0xFDF3D97C674AFB66 Old:0x594FEEC4


function GRAPHICS.GET_TIMECYCLE_MODIFIER_INDEX()


  return Velora.invoke(0x9D0970,"int")


end


-- PC:0x459FD2C8D0AB78BC Old:0x03C44E4B


function GRAPHICS.GET_TIMECYCLE_TRANSITION_MODIFIER_INDEX()


  return Velora.invoke(0x9D0930,"int")


end


function GRAPHICS.GET_IS_TIMECYCLE_TRANSITIONING_OUT()


  return Velora.invoke(0x9D0950,"bool")


end


-- PC:0x58F735290861E6B4 Old:0x7E082045


function GRAPHICS.PUSH_TIMECYCLE_MODIFIER()


  Velora.invoke(0x9D0970,"void")


end


-- PC:0x3C8938D7D872211E Old:0x79D7D235


function GRAPHICS.POP_TIMECYCLE_MODIFIER()


  Velora.invoke(0x9D0980,"void")


end


-- PC:0xBBF327DED94E4DEB Old:0x85BA15A4


function GRAPHICS.SET_CURRENT_PLAYER_TCMODIFIER(modifierName)


  Velora.invoke(0x9D0990,"void", modifierName)


end


-- PC:0xBDEB86F4D5809204 Old:0x9559BB38


function GRAPHICS.SET_PLAYER_TCMODIFIER_TRANSITION(value)


  Velora.invoke(0x9D0A60,"void", value)


end


-- PC:0xBF59707B3E5ED531 Old:0x554BA16E


function GRAPHICS.SET_NEXT_PLAYER_TCMODIFIER(modifierName)


  Velora.invoke(0x9D0A80,"void", modifierName)


end


-- PC:0x1A8E2C8B9CF4549C Old:0xE8F538B5


function GRAPHICS.ADD_TCMODIFIER_OVERRIDE(modifierName1, modifierName2)


  Velora.invoke(0x9D0B30,"void", modifierName1, modifierName2)


end


function GRAPHICS.CLEAR_ALL_TCMODIFIER_OVERRIDES(p0)


  Velora.invoke(0x9D0BA0,"void", p0)


end


function GRAPHICS.SET_EXTRA_TCMODIFIER(modifierName)


  Velora.invoke(0x9D0BB0,"void", modifierName)


end


function GRAPHICS.CLEAR_EXTRA_TCMODIFIER()


  Velora.invoke(0x9D0C30,"void")


end


function GRAPHICS.GET_EXTRA_TCMODIFIER()


  return Velora.invoke(0x9D0C70,"int")


end


function GRAPHICS.ENABLE_MOON_CYCLE_OVERRIDE(strength)


  Velora.invoke(0x9D0C70,"void", strength)


end


function GRAPHICS.DISABLE_MOON_CYCLE_OVERRIDE()


  Velora.invoke(0x9D0CA0,"void")


end


-- PC:0x11FE353CF9733E6F Old:0xC67E3DCB


function GRAPHICS.REQUEST_SCALEFORM_MOVIE(scaleformName)


  return Velora.invoke(0x9D1020,"int", scaleformName)


end


function GRAPHICS.REQUEST_SCALEFORM_MOVIE_WITH_IGNORE_SUPER_WIDESCREEN(scaleformName)


  return Velora.invoke(0x9D0CF0,"int", scaleformName)


end


-- PC:0xC514489CFB8AF806 Old:0x7CC8057D


function GRAPHICS.REQUEST_SCALEFORM_MOVIE_INSTANCE(scaleformName)


  return Velora.invoke(0x9D0D20,"int", scaleformName)


end


function GRAPHICS.REQUEST_SCALEFORM_MOVIE_SKIP_RENDER_WHILE_PAUSED(scaleformName)


  return Velora.invoke(0x9D0D50,"int", scaleformName)


end


-- PC:0x85F01B8D5B90570E Old:0xDDFB6448


function GRAPHICS.HAS_SCALEFORM_MOVIE_LOADED(scaleformHandle)


  return Velora.invoke(0x9D0D80,"bool", scaleformHandle)


end


function GRAPHICS.IS_ACTIVE_SCALEFORM_MOVIE_DELETING(val)


  return Velora.invoke(0x9D0E90,"bool", val)


end


function GRAPHICS.IS_SCALEFORM_MOVIE_DELETING(val)


  return Velora.invoke(0x9D0F10,"bool", val)


end


-- PC:0x0C1C5D756FB5F337 Old:0x494A9E50


function GRAPHICS.HAS_SCALEFORM_MOVIE_FILENAME_LOADED(scaleformName)


  return Velora.invoke(0x9D0F50,"bool", scaleformName)


end


-- PC:0x8217150E1217EBFD Old:0x1DFE8D8A


function GRAPHICS.HAS_SCALEFORM_CONTAINER_MOVIE_LOADED_INTO_PARENT(scaleformHandle)


  return Velora.invoke(0x9D0FF0,"bool", scaleformHandle)


end


-- PC:0x1D132D614DD86811 Old:0x5FED3BA1


function GRAPHICS.SET_SCALEFORM_MOVIE_AS_NO_LONGER_NEEDED()


  Velora.invoke(0x9D1020,"void")


end


-- PC:0x6D8EB211944DCE08 Old:0x18C9DE8D


function GRAPHICS.SET_SCALEFORM_MOVIE_TO_USE_SYSTEM_TIME(scaleform, toggle)


  Velora.invoke(0x9D10A0,"void", scaleform, toggle)


end


function GRAPHICS.SET_SCALEFORM_MOVIE_TO_USE_LARGE_RT(scaleformHandle, toggle)


  Velora.invoke(0x9D1100,"void", scaleformHandle, toggle)


end


function GRAPHICS.SET_SCALEFORM_MOVIE_TO_USE_SUPER_LARGE_RT(scaleformHandle, toggle)


  Velora.invoke(0x9D1150,"void", scaleformHandle, toggle)


end


-- PC:0x54972ADAF0294A93 Old:0x48DA6A58


function GRAPHICS.DRAW_SCALEFORM_MOVIE(scaleformHandle, x, y, width, height, red, green, blue, alpha, p9)


  Velora.invoke(0x9D11A0,"void", scaleformHandle, x, y, width, height, red, green, blue, alpha, p9)


end


-- PC:0x0DF606929C105BE1 Old:0x7B48E696


function GRAPHICS.DRAW_SCALEFORM_MOVIE_FULLSCREEN(scaleform, red, green, blue, alpha, p5)


  Velora.invoke(0x9D11F0,"void", scaleform, red, green, blue, alpha, p5)


end


-- PC:0xCF537FDE4FBD4CE5 Old:0x9C59FC06


function GRAPHICS.DRAW_SCALEFORM_MOVIE_FULLSCREEN_MASKED(scaleform1, scaleform2, red, green, blue, alpha)


  Velora.invoke(0x9D12C0,"void", scaleform1, scaleform2, red, green, blue, alpha)


end


-- PC:0x87D51D72255D4E78 Old:0xC4F63A89


function GRAPHICS.DRAW_SCALEFORM_MOVIE_3D(scaleform, posX, posY, posZ, rotX, rotY, rotZ, p7, p8, p9, scaleX, scaleY, scaleZ, rotationOrder)


  Velora.invoke(0x9D12E0,"void", scaleform, posX, posY, posZ, rotX, rotY, rotZ, p7, p8, p9, scaleX, scaleY, scaleZ, rotationOrder)


end


-- PC:0x1CE592FDC749D6F5 Old:0x899933C8


function GRAPHICS.DRAW_SCALEFORM_MOVIE_3D_SOLID(scaleform, posX, posY, posZ, rotX, rotY, rotZ, p7, p8, p9, scaleX, scaleY, scaleZ, rotationOrder)


  Velora.invoke(0x9D1300,"void", scaleform, posX, posY, posZ, rotX, rotY, rotZ, p7, p8, p9, scaleX, scaleY, scaleZ, rotationOrder)


end


-- PC:0xFBD96D87AC96D533 Old:0x7AB77B57


function GRAPHICS.CALL_SCALEFORM_MOVIE_METHOD(scaleform, method)


  Velora.invoke(0x9D1320,"void", scaleform, method)


end


-- PC:0xD0837058AE2E4BEE Old:0x557EDA1D


function GRAPHICS.CALL_SCALEFORM_MOVIE_METHOD_WITH_NUMBER(scaleform, methodName, param1, param2, param3, param4, param5)


  Velora.invoke(0x9D13F0,"void", scaleform, methodName, param1, param2, param3, param4, param5)


end


-- PC:0x51BC1ED3CC44E8F7 Old:0x91A7FCEB


function GRAPHICS.CALL_SCALEFORM_MOVIE_METHOD_WITH_STRING(scaleform, methodName, param1, param2, param3, param4, param5)


  Velora.invoke(0x9D14C0,"void", scaleform, methodName, param1, param2, param3, param4, param5)


end


-- PC:0xEF662D8D57E290B1 Old:0x6EAF56DE


function GRAPHICS.CALL_SCALEFORM_MOVIE_METHOD_WITH_NUMBER_AND_STRING(scaleform, methodName, floatParam1, floatParam2, floatParam3, floatParam4, floatParam5, stringParam1, stringParam2, stringParam3, stringParam4, stringParam5)


  Velora.invoke(0x9D15A0,"void", scaleform, methodName, floatParam1, floatParam2, floatParam3, floatParam4, floatParam5, stringParam1, stringParam2, stringParam3, stringParam4, stringParam5)


end


-- PC:0x98C494FD5BDFBFD5 Old:0x5D66CE1E


function GRAPHICS.BEGIN_SCALEFORM_SCRIPT_HUD_MOVIE_METHOD(hudComponent, methodName)


  return Velora.invoke(0x9D1870,"bool", hudComponent, methodName)


end


-- PC:0xF6E48914C7A8694E Old:0x215ABBE8


function GRAPHICS.BEGIN_SCALEFORM_MOVIE_METHOD(scaleform, methodName)


  return Velora.invoke(0x9D16D0,"bool", scaleform, methodName)


end


-- PC:0xAB58C27C2E6123C6 Old:0xF6015178


function GRAPHICS.BEGIN_SCALEFORM_MOVIE_METHOD_ON_FRONTEND(methodName)


  return Velora.invoke(0x9D17B0,"bool", methodName)


end


-- PC:0xB9449845F73F5E9C Old:0x5E219B67


function GRAPHICS.BEGIN_SCALEFORM_MOVIE_METHOD_ON_FRONTEND_HEADER(methodName)


  return Velora.invoke(0x9D1810,"bool", methodName)


end


-- PC:0xC6796A8FFA375E53 Old:0x02DBF2D7


function GRAPHICS.END_SCALEFORM_MOVIE_METHOD()


  Velora.invoke(0x9D1870,"void")


end


-- PC:0xC50AA39A577AF886 Old:0x2F38B526


function GRAPHICS.END_SCALEFORM_MOVIE_METHOD_RETURN_VALUE()


  return Velora.invoke(0x9D1990,"int")


end


-- PC:0x768FF8961BA904D6 Old:0x5CD7C3C0


function GRAPHICS.IS_SCALEFORM_MOVIE_METHOD_RETURN_VALUE_READY(methodReturn)


  return Velora.invoke(0x9D18A0,"bool", methodReturn)


end


-- PC:0x2DE7EFA66B906036 Old:0x2CFB0E6D


function GRAPHICS.GET_SCALEFORM_MOVIE_METHOD_RETURN_VALUE_INT(methodReturn)


  return Velora.invoke(0x9D18D0,"int", methodReturn)


end


function GRAPHICS.GET_SCALEFORM_MOVIE_METHOD_RETURN_VALUE_BOOL(methodReturn)


  return Velora.invoke(0x9D18F0,"bool", methodReturn)


end


-- PC:0xC3D0841A0CC546A6 Old:0x716777CB


function GRAPHICS.SCALEFORM_MOVIE_METHOD_ADD_PARAM_INT(value)


  Velora.invoke(0x9D1990,"void", value)


end


-- PC:0xD69736AAE04DB51A Old:0x9A01FFDA


function GRAPHICS.SCALEFORM_MOVIE_METHOD_ADD_PARAM_FLOAT(value)


  Velora.invoke(0x9D19A0,"void", value)


end


-- PC:0xC58424BA936EB458 Old:0x0D4AE8CB


function GRAPHICS.SCALEFORM_MOVIE_METHOD_ADD_PARAM_BOOL(value)


  Velora.invoke(0x9D19C0,"void", value)


end


-- PC:0x80338406F3475E55 Old:0x3AC9CB55


function GRAPHICS.BEGIN_TEXT_COMMAND_SCALEFORM_STRING(componentType)


  Velora.invoke(0x9D19E0,"void", componentType)


end


-- PC:0x362E2D3FE93A9959 Old:0x386CE0B8


function GRAPHICS.END_TEXT_COMMAND_SCALEFORM_STRING()


  Velora.invoke(0x9D19F0,"void")


end


-- PC:0xAE4E8157D9ECF087 Old:0x2E80DB52


function GRAPHICS.END_TEXT_COMMAND_UNPARSED_SCALEFORM_STRING()


  Velora.invoke(0x9D1A00,"void")


end


function GRAPHICS.SCALEFORM_MOVIE_METHOD_ADD_PARAM_LITERAL_STRING(string)


  Velora.invoke(0x9D1A10,"void", string)


end


-- PC:0xBA7148484BD90365 Old:0x4DAAD55B


function GRAPHICS.SCALEFORM_MOVIE_METHOD_ADD_PARAM_TEXTURE_NAME_STRING(string)


  Velora.invoke(0x9D1A30,"void", string)


end


-- PC:0xE83A3E3557A56640 Old:0xCCBF0334


function GRAPHICS.SCALEFORM_MOVIE_METHOD_ADD_PARAM_PLAYER_NAME_STRING(string)


  Velora.invoke(0x9D1A50,"void", string)


end


-- PC:0x5E657EF1099EDD65 Old:0x91A081A1


function GRAPHICS.DOES_LATEST_BRIEF_STRING_EXIST(p0)


  return Velora.invoke(0x9D1AA0,"bool", p0)


end


-- PC:0xEC52C631A1831C03 Old:0x83A9811D


function GRAPHICS.SCALEFORM_MOVIE_METHOD_ADD_PARAM_LATEST_BRIEF_STRING(value)


  Velora.invoke(0x9D1AA0,"void", value)


end


-- PC:0x9304881D6F6537EA Old:0x7AF85862


function GRAPHICS.REQUEST_SCALEFORM_SCRIPT_HUD_MOVIE(hudComponent)


  Velora.invoke(0x9D1B10,"void", hudComponent)


end


-- PC:0xDF6E5987D2B4D140 Old:0x79B43255


function GRAPHICS.HAS_SCALEFORM_SCRIPT_HUD_MOVIE_LOADED(hudComponent)


  return Velora.invoke(0x9D1B60,"bool", hudComponent)


end


-- PC:0xF44A5456AC3F4F97 Old:0x03D87600


function GRAPHICS.REMOVE_SCALEFORM_SCRIPT_HUD_MOVIE(hudComponent)


  Velora.invoke(0x9D1B60,"void", hudComponent)


end


-- PC:0xD1C7CB175E012964 Old:0xE9183D3A


function GRAPHICS.PASS_KEYBOARD_INPUT_TO_SCALEFORM(scaleformHandle)


  return Velora.invoke(0x9D1BA0,"bool", scaleformHandle)


end


-- PC:0xBAABBB23EB6E484E Old:0x41A8A627


function GRAPHICS.SET_TV_CHANNEL(channel)


  Velora.invoke(0x9D1BA0,"void", channel)


end


-- PC:0xFC1E275A90D39995 Old:0x6B96145A


function GRAPHICS.GET_TV_CHANNEL()


  return Velora.invoke(0x9D1BD0,"int")


end


-- PC:0x2982BF73F66E9DDC Old:0xF3504F4D


function GRAPHICS.SET_TV_VOLUME(volume)


  Velora.invoke(0x9D1BD0,"void", volume)


end


-- PC:0x2170813D3DD8661B Old:0x39555CF0


function GRAPHICS.GET_TV_VOLUME()


  return Velora.invoke(0x9D1C00,"float")


end


-- PC:0xFDDC2B4ED3C69DF0 Old:0x8129EF89


function GRAPHICS.DRAW_TV_CHANNEL(xPos, yPos, xScale, yScale, rotation, red, green, blue, alpha)


  Velora.invoke(0x9D1C00,"void", xPos, yPos, xScale, yScale, rotation, red, green, blue, alpha)


end


-- PC:0xF7B38B8305F1FE8B Old:0xB262DE67


function GRAPHICS.SET_TV_CHANNEL_PLAYLIST(tvChannel, playlistName, restart)


  Velora.invoke(0x9D1D20,"void", tvChannel, playlistName, restart)


end


-- PC:0x2201C576FACAEBE8 Old:0x78C4DCBE


function GRAPHICS.SET_TV_CHANNEL_PLAYLIST_AT_HOUR(tvChannel, playlistName, hour)


  Velora.invoke(0x9D1D40,"void", tvChannel, playlistName, hour)


end


-- PC:0xBEB3D46BB7F043C0 Old:0xCBE7068F


function GRAPHICS.CLEAR_TV_CHANNEL_PLAYLIST(tvChannel)


  Velora.invoke(0x9D1D80,"void", tvChannel)


end


function GRAPHICS.IS_PLAYLIST_ON_CHANNEL(tvChannel, p1)


  return Velora.invoke(0x9D1E00,"bool", tvChannel, p1)


end


-- PC:0x0AD973CA1E077B60 Old:0x4D1EB0FB


function GRAPHICS.IS_TVSHOW_CURRENTLY_PLAYING(videoCliphash)


  return Velora.invoke(0x9D1DD0,"bool", videoCliphash)


end


-- PC:0x74C180030FDE4B69 Old:0x796DE696


function GRAPHICS.ENABLE_MOVIE_KEYFRAME_WAIT(toggle)


  Velora.invoke(0x9D1E00,"void", toggle)


end


-- PC:0xD1C55B110E4DF534 Old:0xD99EC000


function GRAPHICS.SET_TV_PLAYER_WATCHING_THIS_FRAME(p0)


  Velora.invoke(0x9D1E20,"void", p0)


end


function GRAPHICS.GET_CURRENT_TV_CLIP_NAMEHASH()


  return Velora.invoke(0x9D1E90,"int")


end


-- PC:0x873FA65C778AD970 Old:0xC2DEBA3D


function GRAPHICS.ENABLE_MOVIE_SUBTITLES(toggle)


  Velora.invoke(0x9D1E90,"void", toggle)


end


-- PC:0xD3A10FC7FD8D98CD Old:0xE40A0F1A


function GRAPHICS.UI3DSCENE_IS_AVAILABLE()


  return Velora.invoke(0x9D2040,"bool")


end


-- PC:0xF1CEA8A4198D8E9A Old:0x2E7D9B98


function GRAPHICS.UI3DSCENE_PUSH_PRESET(presetName)


  return Velora.invoke(0x9D1ED0,"bool", presetName)


end


-- PC:0x98C4FE6EC34154CA Old:0x9A0E3BFE


function GRAPHICS.UI3DSCENE_ASSIGN_PED_TO_SLOT(presetName, ped, slot, posX, posY, posZ)


  return Velora.invoke(0x9D1F40,"bool", presetName, ped, slot, posX, posY, posZ)


end


-- PC:0x7A42B2E236E71415 Old:0x431AA036


function GRAPHICS.UI3DSCENE_CLEAR_PATCHED_DATA()


  Velora.invoke(0x9D2040,"void")


end


-- PC:0x108BE26959A9D9BB Old:0x24A7A7F6


function GRAPHICS.UI3DSCENE_MAKE_PUSHED_PRESET_PERSISTENT(toggle)


  Velora.invoke(0x9D2060,"void", toggle)


end


-- PC:0xA356990E161C9E65 Old:0xA1CB6C94


function GRAPHICS.TERRAINGRID_ACTIVATE(toggle)


  Velora.invoke(0x9D2080,"void", toggle)


end


-- PC:0x1C4FC5752BCD8E48 Old:0x3B637AA7


function GRAPHICS.TERRAINGRID_SET_PARAMS(x, y, z, forwardX, forwardY, forwardZ, sizeX, sizeY, sizeZ, gridScale, glowIntensity, normalHeight, heightDiff)


  Velora.invoke(0x9D20A0,"void", x, y, z, forwardX, forwardY, forwardZ, sizeX, sizeY, sizeZ, gridScale, glowIntensity, normalHeight, heightDiff)


end


-- PC:0x5CE62918F8D703C7 Old:0xDF552973


function GRAPHICS.TERRAINGRID_SET_COLOURS(lowR, lowG, lowB, lowAlpha, r, g, b, alpha, highR, highG, highB, highAlpha)


  Velora.invoke(0x9D2180,"void", lowR, lowG, lowB, lowAlpha, r, g, b, alpha, highR, highG, highB, highAlpha)


end


-- PC:0x2206BF9A37B7F724 Old:0x1D980479


function GRAPHICS.ANIMPOSTFX_PLAY(effectName, duration, looped)


  Velora.invoke(0x9D21F0,"void", effectName, duration, looped)


end


-- PC:0x068E835A1D0DC0E3 Old:0x06BB5CDA


function GRAPHICS.ANIMPOSTFX_STOP(effectName)


  Velora.invoke(0x9D2280,"void", effectName)


end


function GRAPHICS.ANIMPOSTFX_GET_CURRENT_TIME(effectName)


  return Velora.invoke(0x9D23C0,"float", effectName)


end


-- PC:0x36AD3E690DA5ACEB Old:0x089D5921


function GRAPHICS.ANIMPOSTFX_IS_RUNNING(effectName)


  return Velora.invoke(0x9D2350,"bool", effectName)


end


-- PC:0xB4EDDC19532BFB85 Old:0x4E6D875B


function GRAPHICS.ANIMPOSTFX_STOP_ALL()


  Velora.invoke(0x9D23C0,"void")


end


function GRAPHICS.ANIMPOSTFX_STOP_AND_FLUSH_REQUESTS(effectName)


  Velora.invoke(0x9D23E0,"void", effectName)


end


