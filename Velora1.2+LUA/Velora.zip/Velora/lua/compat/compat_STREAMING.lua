-- compat_STREAMING.lua — AUTO GENERATO
-- STREAMING
STREAMING=STREAMING or {}
-- PC:0xBD6E84632DD4CB3F Old:0xC9DBDA90
function STREAMING.LOAD_ALL_OBJECTS_NOW()
  Velora.invoke(0xAD4210,"void")
end
-- PC:0x4448EB75B4904BDB Old:0xB72403F5
function STREAMING.LOAD_SCENE(x, y, z)
  Velora.invoke(0xAD4230,"void", x, y, z)
end
-- PC:0xC4582015556D1C46 Old:0xC76E023C
function STREAMING.NETWORK_UPDATE_LOAD_SCENE()
  return Velora.invoke(0xAD42B0,"bool")
end
-- PC:0x41CA5A33160EA4AB Old:0x6DCFC021
function STREAMING.IS_NETWORK_LOADING_SCENE()
  return Velora.invoke(0xAD42E0,"bool")
end
-- PC:0xE37B76C387BE28ED Old:0xE1013910
function STREAMING.SET_INTERIOR_ACTIVE(interiorID, toggle)
  Velora.invoke(0xAD4300,"void", interiorID, toggle)
end
-- PC:0x963D27A58DF860AC Old:0xFFF1B500
function STREAMING.REQUEST_MODEL(model)
  Velora.invoke(0xAD4320,"void", model)
end
-- PC:0xA0261AEF7ACFC51E Old:0x48CEB6B4
function STREAMING.REQUEST_MENU_PED_MODEL(model)
  Velora.invoke(0xAD4330,"void", model)
end
-- PC:0x98A4EB5D89A0C952 Old:0x62BFDB37
function STREAMING.HAS_MODEL_LOADED(model)
  return Velora.invoke(0xAD4350,"bool", model)
end
-- PC:0x8A7A40100EDFEC58 Old:0x939243FB
function STREAMING.REQUEST_MODELS_IN_ROOM(interior, roomName)
  Velora.invoke(0xAD4410,"void", interior, roomName)
end
-- PC:0xE532F5D78798DAAB Old:0xAE0F069E
function STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(model)
  Velora.invoke(0xAD4480,"void", model)
end
-- PC:0x35B9E0803292B641 Old:0x1094782F
function STREAMING.IS_MODEL_IN_CDIMAGE(model)
  return Velora.invoke(0xAD4500,"bool", model)
end
-- PC:0xC0296A2EDF545E92 Old:0xAF8F8E9D
function STREAMING.IS_MODEL_VALID(model)
  return Velora.invoke(0xAD4570,"bool", model)
end
function STREAMING.IS_MODEL_A_PED(model)
  return Velora.invoke(0xAD45E0,"bool", model)
end
-- PC:0x19AAC8F07BFEC53E Old:0xFFFC85D4
function STREAMING.IS_MODEL_A_VEHICLE(model)
  return Velora.invoke(0xAD4650,"bool", model)
end
-- PC:0x07503F7948F491A7 Old:0xCD9805E7
function STREAMING.REQUEST_COLLISION_AT_COORD(x, y, z)
  Velora.invoke(0xAD46C0,"void", x, y, z)
end
-- PC:0x923CB32A3B874FCB Old:0x3930C042
function STREAMING.REQUEST_COLLISION_FOR_MODEL(model)
  Velora.invoke(0xAD4700,"void", model)
end
-- PC:0x22CCA434E368F03A Old:0x41A094F8
function STREAMING.HAS_COLLISION_FOR_MODEL_LOADED(model)
  return Velora.invoke(0xAD4710,"bool", model)
end
-- PC:0xC9156DC11411A9EA Old:0xC2CC1DF2
function STREAMING.REQUEST_ADDITIONAL_COLLISION_AT_COORD(x, y, z)
  Velora.invoke(0xAD47B0,"void", x, y, z)
end
-- PC:0x2DA49C3B79856961 Old:0xCD31C872
function STREAMING.DOES_ANIM_DICT_EXIST(animDict)
  return Velora.invoke(0xAD47F0,"bool", animDict)
end
-- PC:0xD3BD40951412FEF6 Old:0xDCA96950
function STREAMING.REQUEST_ANIM_DICT(animDict)
  Velora.invoke(0xAD4850,"void", animDict)
end
-- PC:0xD031A9162D01088C Old:0x05E6763C
function STREAMING.HAS_ANIM_DICT_LOADED(animDict)
  return Velora.invoke(0xAD4860,"bool", animDict)
end
-- PC:0xF66A602F829E2A06 Old:0x0AE050B5
function STREAMING.REMOVE_ANIM_DICT(animDict)
  Velora.invoke(0xAD48E0,"void", animDict)
end
-- PC:0x6EA47DAE7FAD0EED Old:0x2988B3FC
function STREAMING.REQUEST_ANIM_SET(animSet)
  Velora.invoke(0xAD4960,"void", animSet)
end
-- PC:0xC4EA073D86FB29B0 Old:0x4FFF397D
function STREAMING.HAS_ANIM_SET_LOADED(animSet)
  return Velora.invoke(0xAD4970,"bool", animSet)
end
-- PC:0x16350528F93024B3 Old:0xD04A817A
function STREAMING.REMOVE_ANIM_SET(animSet)
  Velora.invoke(0xAD4A00,"void", animSet)
end
-- PC:0xD2A71E1A77418A49 Old:0x546C627A
function STREAMING.REQUEST_CLIP_SET(clipSet)
  Velora.invoke(0xAD4A90,"void", clipSet)
end
-- PC:0x318234F4F3738AF3 Old:0x230D5455
function STREAMING.HAS_CLIP_SET_LOADED(clipSet)
  return Velora.invoke(0xAD4AA0,"bool", clipSet)
end
-- PC:0x01F73A131C18CD94 Old:0x1E21F7AA
function STREAMING.REMOVE_CLIP_SET(clipSet)
  Velora.invoke(0xAD4B30,"void", clipSet)
end
-- PC:0x41B4893843BBDB74 Old:0x3B70D1DB
function STREAMING.REQUEST_IPL(iplName)
  Velora.invoke(0xAD4BC0,"void", iplName)
end
-- PC:0xEE6C5AD3ECE0A82D Old:0xDF7CBD36
function STREAMING.REMOVE_IPL(iplName)
  Velora.invoke(0xAD4C40,"void", iplName)
end
-- PC:0x88A741E44A2B3495 Old:0xB2C33714
function STREAMING.IS_IPL_ACTIVE(iplName)
  return Velora.invoke(0xAD4C50,"bool", iplName)
end
-- PC:0x6E0C692677008888 Old:0x27EF6CB2
function STREAMING.SET_STREAMING(toggle)
  Velora.invoke(0xAD4CA0,"void", toggle)
end
function STREAMING.LOAD_GLOBAL_WATER_FILE(waterType)
  Velora.invoke(0xAD4CC0,"void", waterType)
end
function STREAMING.GET_GLOBAL_WATER_FILE()
  return Velora.invoke(0xAD4CD0,"int")
end
-- PC:0x717CD6E6FAEBBEDC Old:0x9211A28A
function STREAMING.SET_GAME_PAUSES_FOR_STREAMING(toggle)
  Velora.invoke(0xAD4CF0,"void", toggle)
end
-- PC:0x77B5F9A36BF96710 Old:0xAFCB2B86
function STREAMING.SET_REDUCE_PED_MODEL_BUDGET(toggle)
  Velora.invoke(0xAD4D10,"void", toggle)
end
-- PC:0x80C527893080CCF3 Old:0xCDB4FB7E
function STREAMING.SET_REDUCE_VEHICLE_MODEL_BUDGET(toggle)
  Velora.invoke(0xAD4D30,"void", toggle)
end
-- PC:0x42CBE54462D92634 Old:0x3EA7FCE4
function STREAMING.SET_DITCH_POLICE_MODELS(toggle)
  Velora.invoke(0xAD4D50,"void", toggle)
end
-- PC:0x4060057271CEBC89 Old:0xC2EE9A02
function STREAMING.GET_NUMBER_OF_STREAMING_REQUESTS()
  return Velora.invoke(0xAD4D60,"int")
end
-- PC:0x944955FB2A3935C8 Old:0x2C649263
function STREAMING.REQUEST_PTFX_ASSET()
  Velora.invoke(0xAD4D80,"void")
end
-- PC:0xCA7D9B86ECA7481B Old:0x3EFF96BE
function STREAMING.HAS_PTFX_ASSET_LOADED()
  return Velora.invoke(0xAD4D90,"bool")
end
-- PC:0x88C6814073DD4A73 Old:0xC10F178C
function STREAMING.REMOVE_PTFX_ASSET()
  Velora.invoke(0xAD4DB0,"void")
end
-- PC:0xB80D8756B4668AB6 Old:0xCFEA19A9
function STREAMING.REQUEST_NAMED_PTFX_ASSET(fxName)
  Velora.invoke(0xAD4DC0,"void", fxName)
end
-- PC:0x8702416E512EC454 Old:0x9ACC6446
function STREAMING.HAS_NAMED_PTFX_ASSET_LOADED(fxName)
  return Velora.invoke(0xAD4DD0,"bool", fxName)
end
-- PC:0x5F61EBBE1A00F96D Old:0xC44762A1
function STREAMING.REMOVE_NAMED_PTFX_ASSET(fxName)
  Velora.invoke(0xAD4E00,"void", fxName)
end
-- PC:0xCB9E1EB3BE2AF4E9 Old:0x1D56993C
function STREAMING.SET_VEHICLE_POPULATION_BUDGET(p0)
  Velora.invoke(0xAD4E10,"void", p0)
end
-- PC:0x8C95333CFC3340F3 Old:0xD2D026CD
function STREAMING.SET_PED_POPULATION_BUDGET(p0)
  Velora.invoke(0xAD4E30,"void", p0)
end
-- PC:0x31B73D1EA9F01DA2 Old:0x34D91E7A
function STREAMING.CLEAR_FOCUS()
  Velora.invoke(0xAD4E50,"void")
end
-- PC:0xBB7454BAFF08FE25 Old:0x14680A60
function STREAMING.SET_FOCUS_POS_AND_VEL(x, y, z, offsetX, offsetY, offsetZ)
  Velora.invoke(0xAD4E60,"void", x, y, z, offsetX, offsetY, offsetZ)
end
-- PC:0x198F77705FA0931D Old:0x18DB04AC
function STREAMING.SET_FOCUS_ENTITY(entity)
  Velora.invoke(0xAD4ED0,"void", entity)
end
-- PC:0x2DDFF3FB9075D747 Old:0xB456D707
function STREAMING.IS_ENTITY_FOCUS(entity)
  return Velora.invoke(0xAD4F50,"bool", entity)
end
function STREAMING.SET_RESTORE_FOCUS_ENTITY(p0)
  Velora.invoke(0xAD4FB0,"void", p0)
end
-- PC:0xAF12610C644A35C9 Old:0x403CD434
function STREAMING.SET_MAPDATACULLBOX_ENABLED(name, toggle)
  Velora.invoke(0xAD5030,"void", name, toggle)
end
-- PC:0x4E52E752C76E7E7A Old:0xA07BAEB9
function STREAMING.SET_ALL_MAPDATA_CULLED(p0)
  Velora.invoke(0xAD5050,"void", p0)
end
-- PC:0x219C7B8D53E429FD Old:0x10B6AB36
function STREAMING.STREAMVOL_CREATE_SPHERE(x, y, z, rad, p4, p5)
  return Velora.invoke(0xAD5060,"int", x, y, z, rad, p4, p5)
end
-- PC:0x1F3F018BC3AFA77C Old:0x72344191
function STREAMING.STREAMVOL_CREATE_FRUSTUM(p0, p1, p2, p3, p4, p5, p6, p7, p8)
  return Velora.invoke(0xAD5160,"int", p0, p1, p2, p3, p4, p5, p6, p7, p8)
end
-- PC:0x0AD9710CEE2F590F Old:0xC0157255
function STREAMING.STREAMVOL_CREATE_LINE(p0, p1, p2, p3, p4, p5, p6)
  return Velora.invoke(0xAD5240,"int", p0, p1, p2, p3, p4, p5, p6)
end
-- PC:0x1EE7D8DF4425F053 Old:0xE80F8ABE
function STREAMING.STREAMVOL_DELETE(unused)
  Velora.invoke(0xAD52F0,"void", unused)
end
-- PC:0x7D41E9D2D17C5B2D Old:0x1B3521F4
function STREAMING.STREAMVOL_HAS_LOADED(unused)
  return Velora.invoke(0xAD5310,"bool", unused)
end
-- PC:0x07C313F94746702C Old:0x42CFE9C0
function STREAMING.STREAMVOL_IS_VALID(unused)
  return Velora.invoke(0xAD5340,"bool", unused)
end
-- PC:0xBC9823AB80A3DCAC Old:0x56253356
function STREAMING.IS_STREAMVOL_ACTIVE()
  return Velora.invoke(0xAD5350,"bool")
end
-- PC:0x212A8D0D2BABFAC2 Old:0xDF9C38B6
function STREAMING.NEW_LOAD_SCENE_START(posX, posY, posZ, offsetX, offsetY, offsetZ, radius, p7)
  return Velora.invoke(0xAD5360,"bool", posX, posY, posZ, offsetX, offsetY, offsetZ, radius, p7)
end
-- PC:0xACCFB4ACF53551B0 Old:0xFA037FEB
function STREAMING.NEW_LOAD_SCENE_START_SPHERE(x, y, z, radius, p4)
  return Velora.invoke(0xAD5410,"bool", x, y, z, radius, p4)
end
-- PC:0xC197616D221FF4A4 Old:0x7C05B1F6
function STREAMING.NEW_LOAD_SCENE_STOP()
  Velora.invoke(0xAD54A0,"void")
end
-- PC:0xA41A05B6CB741B85 Old:0xAD234B7F
function STREAMING.IS_NEW_LOAD_SCENE_ACTIVE()
  return Velora.invoke(0xAD54B0,"bool")
end
-- PC:0x01B8247A7A8B9AD1 Old:0x3ECD839F
function STREAMING.IS_NEW_LOAD_SCENE_LOADED()
  return Velora.invoke(0xAD54D0,"bool")
end
-- PC:0x71E7B2E657449AAD Old:0xEAA51103
function STREAMING.IS_SAFE_TO_START_PLAYER_SWITCH()
  return Velora.invoke(0xAD5500,"bool")
end
-- PC:0xFAA23F2CBA159D67 Old:0x0829E975
function STREAMING.START_PLAYER_SWITCH(from, to, flags, switchType)
  Velora.invoke(0xAD5550,"void", from, to, flags, switchType)
end
-- PC:0x95C0A5BBDC189AA1 Old:0x2832C010
function STREAMING.STOP_PLAYER_SWITCH()
  Velora.invoke(0xAD5610,"void")
end
-- PC:0xD9D2CFFF49FAB35F Old:0x56135ACC
function STREAMING.IS_PLAYER_SWITCH_IN_PROGRESS()
  return Velora.invoke(0xAD5640,"bool")
end
-- PC:0xB3C94A90D9FC9E62 Old:0x280DC015
function STREAMING.GET_PLAYER_SWITCH_TYPE()
  return Velora.invoke(0xAD5670,"int")
end
-- PC:0xB5D7B26B45720E05 Old:0xD5A450F1
function STREAMING.GET_IDEAL_PLAYER_SWITCH_TYPE(x1, y1, z1, x2, y2, z2)
  return Velora.invoke(0xAD5680,"int", x1, y1, z1, x2, y2, z2)
end
-- PC:0x470555300D10B2A5 Old:0x39A0E1F2
function STREAMING.GET_PLAYER_SWITCH_STATE()
  return Velora.invoke(0xAD56E0,"int")
end
-- PC:0x20F898A5D9782800 Old:0x9B7BA38F
function STREAMING.GET_PLAYER_SHORT_SWITCH_STATE()
  return Velora.invoke(0xAD5700,"int")
end
-- PC:0x5F2013F8BC24EE69 Old:0xF0BD420D
function STREAMING.SET_PLAYER_SHORT_SWITCH_STYLE(p0)
  Velora.invoke(0xAD5720,"void", p0)
end
-- PC:0x78C0D93253149435 Old:0x02BA7AC2
function STREAMING.GET_PLAYER_SWITCH_JUMP_CUT_INDEX()
  return Velora.invoke(0xAD5740,"int")
end
-- PC:0xC208B673CE446B61 Old:0x47352E14
function STREAMING.SET_PLAYER_SWITCH_OUTRO(cameraCoordX, cameraCoordY, cameraCoordZ, camRotationX, camRotationY, camRotationZ, camFov, camFarClip, rotationOrder)
  Velora.invoke(0xAD5760,"void", cameraCoordX, cameraCoordY, cameraCoordZ, camRotationX, camRotationY, camRotationZ, camFov, camFarClip, rotationOrder)
end
-- PC:0x0FDE9DBFC0A6BC65 Old:0x279077B0
function STREAMING.SET_PLAYER_SWITCH_ESTABLISHING_SHOT(name)
  Velora.invoke(0xAD5850,"void", name)
end
-- PC:0x43D1680C6D19A8E9 Old:0x55CB21F9
function STREAMING.ALLOW_PLAYER_SWITCH_PAN()
  Velora.invoke(0xAD58B0,"void")
end
-- PC:0x74DE2E8739086740 Old:0x1084F2F4
function STREAMING.ALLOW_PLAYER_SWITCH_OUTRO()
  Velora.invoke(0xAD58F0,"void")
end
-- PC:0x8E2A065ABDAE6994 Old:0x5B1E995D
function STREAMING.ALLOW_PLAYER_SWITCH_ASCENT()
  Velora.invoke(0xAD5930,"void")
end
-- PC:0xAD5FDF34B81BFE79 Old:0x4B4B9A13
function STREAMING.ALLOW_PLAYER_SWITCH_DESCENT()
  Velora.invoke(0xAD5970,"void")
end
-- PC:0xDFA80CB25D0A19B3 Old:0x408F7148
function STREAMING.IS_SWITCH_READY_FOR_DESCENT()
  return Velora.invoke(0xAD59B0,"bool")
end
-- PC:0xD4793DFF3AF2ABCD Old:0x4062FF73
function STREAMING.ENABLE_SWITCH_PAUSE_BEFORE_DESCENT()
  Velora.invoke(0xAD59F0,"void")
end
-- PC:0xBD605B8E0E18B3BB Old:0x59CC312D
function STREAMING.DISABLE_SWITCH_OUTRO_FX()
  Velora.invoke(0xAD5A30,"void")
end
-- PC:0xAAB3200ED59016BC Old:0xFB4D062D
function STREAMING.SWITCH_TO_MULTI_FIRSTPART(ped, flags, switchType)
  Velora.invoke(0xAD5A80,"void", ped, flags, switchType)
end
-- PC:0xD8295AF639FD9CB8 Old:0x2349373B
function STREAMING.SWITCH_TO_MULTI_SECONDPART(ped)
  Velora.invoke(0xAD5B00,"void", ped)
end
-- PC:0x933BBEEB8C61B5F4 Old:0x74C16879
function STREAMING.IS_SWITCH_TO_MULTI_FIRSTPART_FINISHED()
  return Velora.invoke(0xAD5B60,"bool")
end
-- PC:0x08C2D6C52A3104BB Old:0x569847E3
function STREAMING.GET_PLAYER_SWITCH_INTERP_OUT_DURATION()
  return Velora.invoke(0xAD5B80,"int")
end
-- PC:0x5B48A06DD0E792A5 Old:0xC7A3D279
function STREAMING.GET_PLAYER_SWITCH_INTERP_OUT_CURRENT_TIME()
  return Velora.invoke(0xAD5BA0,"int")
end
-- PC:0x5B74EA8CFD5E3E7E Old:0x90F64284
function STREAMING.IS_SWITCH_SKIPPING_DESCENT()
  return Velora.invoke(0xAD5BE0,"bool")
end
function STREAMING.SET_SCENE_STREAMING_TRACKS_CAM_POS_THIS_FRAME()
  Velora.invoke(0xAD5C20,"void")
end
-- PC:0x0C15B0E443B2349D Old:0x7154B6FD
function STREAMING.GET_LODSCALE()
  return Velora.invoke(0xAD5C30,"float")
end
-- PC:0xA76359FC80B2438E Old:0xE5612C1A
function STREAMING.OVERRIDE_LODSCALE_THIS_FRAME(scaling)
  Velora.invoke(0xAD5C50,"void", scaling)
end
-- PC:0xBED8CA5FF5E04113 Old:0x9CD6A451
function STREAMING.REMAP_LODSCALE_RANGE_THIS_FRAME(p0, p1, p2, p3)
  Velora.invoke(0xAD5C70,"void", p0, p1, p2, p3)
end
-- PC:0x472397322E92A856 Old:0x4267DA87
function STREAMING.SUPPRESS_HD_MAP_STREAMING_THIS_FRAME()
  Velora.invoke(0xAD5CA0,"void")
end
-- PC:0x40AEFD1A244741F2 Old:0x9FA4AF99
function STREAMING.SET_RENDER_HD_ONLY(toggle)
  Velora.invoke(0xAD5CB0,"void", toggle)
end
function STREAMING.FORCE_ALLOW_TIME_BASED_FADING_THIS_FRAME()
  Velora.invoke(0xAD5CF0,"void")
end
-- PC:0x95A7DABDDBB78AE7 Old:0x9EF0A9CF
function STREAMING.IPL_GROUP_SWAP_START(iplName1, iplName2)
  Velora.invoke(0xAD5D00,"void", iplName1, iplName2)
end
-- PC:0x63EB2B972A218CAC Old:0xF2CDD6A8
function STREAMING.IPL_GROUP_SWAP_CANCEL()
  Velora.invoke(0xAD5D10,"void")
end
-- PC:0xFB199266061F820A Old:0x17B0A1CD
function STREAMING.IPL_GROUP_SWAP_IS_READY()
  return Velora.invoke(0xAD5D30,"bool")
end
-- PC:0xF4A0DADB70F57FA6 Old:0x3DA7AA5D
function STREAMING.IPL_GROUP_SWAP_FINISH()
  Velora.invoke(0xAD5D60,"void")
end
-- PC:0x5068F488DDB54DD8 Old:0xDAB4BAC0
function STREAMING.IPL_GROUP_SWAP_IS_ACTIVE()
  return Velora.invoke(0xAD5D80,"bool")
end
-- PC:0x3D245789CE12982C Old:0x37BE2FBB
function STREAMING.PREFETCH_SRL(srl)
  Velora.invoke(0xAD5DA0,"void", srl)
end
-- PC:0xD0263801A4C5B0BB Old:0x670FA2A6
function STREAMING.IS_SRL_LOADED()
  return Velora.invoke(0xAD5DC0,"bool")
end
-- PC:0x9BADDC94EF83B823 Old:0x24F49427
function STREAMING.BEGIN_SRL()
  Velora.invoke(0xAD5DF0,"void")
end
-- PC:0x0A41540E63C9EE17 Old:0x1977C56A
function STREAMING.END_SRL()
  Velora.invoke(0xAD5E00,"void")
end
-- PC:0xA74A541C6884E7B8 Old:0x30F8A487
function STREAMING.SET_SRL_TIME(p0)
  Velora.invoke(0xAD5E10,"void", p0)
end
-- PC:0xEF39EE20C537E98C Old:0x814D0752
function STREAMING.SET_SRL_POST_CUTSCENE_CAMERA(p0, p1, p2, p3, p4, p5)
  Velora.invoke(0xAD5E30,"void", p0, p1, p2, p3, p4, p5)
end
-- PC:0xBEB2D9A1D9A8F55A Old:0x62F02485
function STREAMING.SET_SRL_READAHEAD_TIMES(p0, p1, p2, p3)
  Velora.invoke(0xAD5E80,"void", p0, p1, p2, p3)
end
-- PC:0x20C6C7E4EB082A7F Old:0xA6459CAA
function STREAMING.SET_SRL_LONG_JUMP_MODE(p0)
  Velora.invoke(0xAD5EA0,"void", p0)
end
-- PC:0xF8155A7F03DDFC8E Old:0xF8F515E4
function STREAMING.SET_SRL_FORCE_PRESTREAM(p0)
  Velora.invoke(0xAD5EC0,"void", p0)
end
-- PC:0xB85F26619073E775 Old:0x80BAA035
function STREAMING.SET_HD_AREA(x, y, z, radius)
  Velora.invoke(0xAD5EE0,"void", x, y, z, radius)
end
-- PC:0xCE58B1CFB9290813 Old:0x7CAC6FA0
function STREAMING.CLEAR_HD_AREA()
  Velora.invoke(0xAD5F30,"void")
end
-- PC:0xB5A4DB34FE89B88A Old:0xE243B2AF
function STREAMING.INIT_CREATOR_BUDGET()
  Velora.invoke(0xAD5F40,"void")
end
-- PC:0xCCE26000E9A6FAD7 Old:0x897A510F
function STREAMING.SHUTDOWN_CREATOR_BUDGET()
  Velora.invoke(0xAD5F50,"void")
end
-- PC:0x0BC3144DEB678666 Old:0xC0E83320
function STREAMING.ADD_MODEL_TO_CREATOR_BUDGET(modelHash)
  return Velora.invoke(0xAD5F60,"bool", modelHash)
end
-- PC:0xF086AD9354FAC3A3 Old:0x1C576388
function STREAMING.REMOVE_MODEL_FROM_CREATOR_BUDGET(modelHash)
  Velora.invoke(0xAD6010,"void", modelHash)
end
-- PC:0x3D3D8B3BE5A83D35 Old:0x3E9C4CBE
function STREAMING.GET_USED_CREATOR_BUDGET()
  return Velora.invoke(0xAD60B0,"float")
end
function STREAMING.SET_ISLAND_ENABLED(name, toggle)
  Velora.invoke(0xAD6230,"void", name, toggle)
end
