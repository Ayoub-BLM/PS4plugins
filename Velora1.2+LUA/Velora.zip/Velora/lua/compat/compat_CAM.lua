-- compat_CAM.lua — AUTO GENERATO
-- CAM
CAM=CAM or {}
-- PC:0x07E5B515DB0636FC Old:0x74337969
function CAM.RENDER_SCRIPT_CAMS(render, ease, easeTime, p3, p4, p5)
  Velora.invoke(0x98ED60,"void", render, ease, easeTime, p3, p4, p5)
end
-- PC:0xC819F3CBB62BF692 Old:0xD3C08183
function CAM.STOP_RENDERING_SCRIPT_CAMS_USING_CATCH_UP(render, p1, p2, p3)
  Velora.invoke(0x98EE10,"void", render, p1, p2, p3)
end
-- PC:0xC3981DCE61D9E13F Old:0xE9BF2A7D
function CAM.CREATE_CAM(camName, p1)
  return Velora.invoke(0x98EE90,"int", camName, p1)
end
-- PC:0xB51194800B257161 Old:0x23B02F15
function CAM.CREATE_CAM_WITH_PARAMS(camName, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, p9)
  return Velora.invoke(0x98EF10,"int", camName, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, p9)
end
-- PC:0x5E3CF89C6BCCA67D Old:0x5D6739AE
function CAM.CREATE_CAMERA(camHash, p1)
  return Velora.invoke(0x98F080,"int", camHash, p1)
end
-- PC:0x6ABFA3E16460F22D Old:0x0688BE9A
function CAM.CREATE_CAMERA_WITH_PARAMS(camHash, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, p9)
  return Velora.invoke(0x98F100,"int", camHash, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, p9)
end
-- PC:0x865908C81A2C22E9 Old:0xC39302BD
function CAM.DESTROY_CAM(cam, bScriptHostCam)
  Velora.invoke(0x98F270,"void", cam, bScriptHostCam)
end
-- PC:0x8E5FB15663F79120 Old:0x10C151CE
function CAM.DESTROY_ALL_CAMS(bScriptHostCam)
  Velora.invoke(0x98F2D0,"void", bScriptHostCam)
end
-- PC:0xA7A932170592B50E Old:0x1EF89DC0
function CAM.DOES_CAM_EXIST(cam)
  return Velora.invoke(0x98F310,"bool", cam)
end
-- PC:0x026FB97D0A425F84 Old:0x064659C2
function CAM.SET_CAM_ACTIVE(cam, active)
  Velora.invoke(0x98F350,"void", cam, active)
end
-- PC:0xDFB2B516207D3534 Old:0x4B58F177
function CAM.IS_CAM_ACTIVE(cam)
  return Velora.invoke(0x98F3C0,"bool", cam)
end
-- PC:0x02EC0AF5C5A49B7A Old:0x6EC6B5B2
function CAM.IS_CAM_RENDERING(cam)
  return Velora.invoke(0x98F410,"bool", cam)
end
-- PC:0x5234F9F10919EABA Old:0x0FCF4DF1
function CAM.GET_RENDERING_CAM()
  return Velora.invoke(0x98F480,"int")
end
-- PC:0xBAC038F7459AE5AE Old:0x7C40F09C
function CAM.GET_CAM_COORD(cam)
  local x,y,z=Velora.invoke(0x98F4D0,"vector3", cam)
  return {x=x,y=y,z=z}
end
-- PC:0x7D304C1C955E3E12 Old:0xDAC84C9F
function CAM.GET_CAM_ROT(cam, rotationOrder)
  local x,y,z=Velora.invoke(0x98F570,"vector3", cam, rotationOrder)
  return {x=x,y=y,z=z}
end
-- PC:0xC3330A45CCCDB26A Old:0xD6E9FCF5
function CAM.GET_CAM_FOV(cam)
  return Velora.invoke(0x98F650,"float", cam)
end
-- PC:0xC520A34DAFBF24B1 Old:0xCFCD35EE
function CAM.GET_CAM_NEAR_CLIP(cam)
  return Velora.invoke(0x98F6B0,"float", cam)
end
-- PC:0xB60A9CFEB21CA6AA Old:0x09F119B8
function CAM.GET_CAM_FAR_CLIP(cam)
  return Velora.invoke(0x98F710,"float", cam)
end
function CAM.GET_CAM_NEAR_DOF(cam)
  return Velora.invoke(0x98F770,"float", cam)
end
-- PC:0x255F8DAFD540D397 Old:0x98C5CCE9
function CAM.GET_CAM_FAR_DOF(cam)
  return Velora.invoke(0x98F7D0,"float", cam)
end
function CAM.GET_CAM_DOF_STRENGTH(cam)
  return Velora.invoke(0x98F830,"float", cam)
end
-- PC:0xBFD8727AEA3CCEBA Old:0x2167CEBF
function CAM.SET_CAM_PARAMS(cam, posX, posY, posZ, rotX, rotY, rotZ, fieldOfView, p8, p9, p10, p11)
  Velora.invoke(0x98F890,"void", cam, posX, posY, posZ, rotX, rotY, rotZ, fieldOfView, p8, p9, p10, p11)
end
-- PC:0x4D41783FB745E42E Old:0x7A8053AF
function CAM.SET_CAM_COORD(cam, posX, posY, posZ)
  Velora.invoke(0x98F8D0,"void", cam, posX, posY, posZ)
end
-- PC:0x85973643155D0B07 Old:0xEE38B3C1
function CAM.SET_CAM_ROT(cam, rotX, rotY, rotZ, rotationOrder)
  Velora.invoke(0x98F970,"void", cam, rotX, rotY, rotZ, rotationOrder)
end
-- PC:0xB13C14F66A00D047 Old:0xD3D5D74F
function CAM.SET_CAM_FOV(cam, fieldOfView)
  Velora.invoke(0x98F990,"void", cam, fieldOfView)
end
-- PC:0xC7848EFCCC545182 Old:0x46DB13B1
function CAM.SET_CAM_NEAR_CLIP(cam, nearClip)
  Velora.invoke(0x98FA40,"void", cam, nearClip)
end
-- PC:0xAE306F2A904BF86E Old:0x0D23E381
function CAM.SET_CAM_FAR_CLIP(cam, farClip)
  Velora.invoke(0x98FAB0,"void", cam, farClip)
end
function CAM.FORCE_CAM_FAR_CLIP(cam, p1)
  Velora.invoke(0x98FB30,"void", cam, p1)
end
-- PC:0x6F0F77FBA9A8F2E6 Old:0xFD6E0D67
function CAM.SET_CAM_MOTION_BLUR_STRENGTH(cam, strength)
  Velora.invoke(0x98FBD0,"void", cam, strength)
end
-- PC:0x3FA4BF0A7AB7DE2C Old:0xF28254DF
function CAM.SET_CAM_NEAR_DOF(cam, nearDOF)
  Velora.invoke(0x98FC50,"void", cam, nearDOF)
end
-- PC:0xEDD91296CD01AEE0 Old:0x58515E8E
function CAM.SET_CAM_FAR_DOF(cam, farDOF)
  Velora.invoke(0x98FCC0,"void", cam, farDOF)
end
-- PC:0x5EE29B4D7D5DF897 Old:0x3CC4EB3F
function CAM.SET_CAM_DOF_STRENGTH(cam, dofStrength)
  Velora.invoke(0x98FD30,"void", cam, dofStrength)
end
-- PC:0x3CF48F6F96E749DC Old:0xAD6C2B8F
function CAM.SET_CAM_DOF_PLANES(cam, p1, p2, p3, p4)
  Velora.invoke(0x98FDB0,"void", cam, p1, p2, p3, p4)
end
-- PC:0x16A96863A17552BB Old:0x8306C256
function CAM.SET_CAM_USE_SHALLOW_DOF_MODE(cam, toggle)
  Velora.invoke(0x98FE60,"void", cam, toggle)
end
-- PC:0xA13B0222F3D94A94 Old:0x8BBF2950
function CAM.SET_USE_HI_DOF()
  Velora.invoke(0x98FED0,"void")
end
function CAM.SET_USE_HI_DOF_ON_SYNCED_SCENE_THIS_UPDATE()
  Velora.invoke(0x98FEF0,"void")
end
function CAM.SET_CAM_DOF_OVERRIDDEN_FOCUS_DISTANCE(camera, p1)
  Velora.invoke(0x98FF10,"void", camera, p1)
end
function CAM.SET_CAM_DOF_OVERRIDDEN_FOCUS_DISTANCE_BLEND_LEVEL(p0, p1)
  Velora.invoke(0x98FFD0,"void", p0, p1)
end
function CAM.SET_CAM_DOF_FNUMBER_OF_LENS(camera, p1)
  Velora.invoke(0x990090,"void", camera, p1)
end
function CAM.SET_CAM_DOF_FOCAL_LENGTH_MULTIPLIER(camera, multiplier)
  Velora.invoke(0x990150,"void", camera, multiplier)
end
function CAM.SET_CAM_DOF_FOCUS_DISTANCE_BIAS(camera, p1)
  Velora.invoke(0x990210,"void", camera, p1)
end
function CAM.SET_CAM_DOF_MAX_NEAR_IN_FOCUS_DISTANCE(camera, p1)
  Velora.invoke(0x9902D0,"void", camera, p1)
end
function CAM.SET_CAM_DOF_MAX_NEAR_IN_FOCUS_DISTANCE_BLEND_LEVEL(camera, p1)
  Velora.invoke(0x990380,"void", camera, p1)
end
-- PC:0xFEDB7D269E8C60E3 Old:0xAD7C45F6
function CAM.ATTACH_CAM_TO_ENTITY(cam, entity, xOffset, yOffset, zOffset, isRelative)
  Velora.invoke(0x9904C0,"void", cam, entity, xOffset, yOffset, zOffset, isRelative)
end
-- PC:0x61A3DBA14AB7F411 Old:0x506BB35C
function CAM.ATTACH_CAM_TO_PED_BONE(cam, ped, boneIndex, x, y, z, heading)
  Velora.invoke(0x9904E0,"void", cam, ped, boneIndex, x, y, z, heading)
end
function CAM.HARD_ATTACH_CAM_TO_PED_BONE(cam, ped, boneIndex, p3, p4, p5, p6, p7, p8, p9)
  Velora.invoke(0x990500,"void", cam, ped, boneIndex, p3, p4, p5, p6, p7, p8, p9)
end
function CAM.HARD_ATTACH_CAM_TO_ENTITY(cam, entity, xRot, yRot, zRot, xOffset, yOffset, zOffset, isRelative)
  Velora.invoke(0x990530,"void", cam, entity, xRot, yRot, zRot, xOffset, yOffset, zOffset, isRelative)
end
function CAM.ATTACH_CAM_TO_VEHICLE_BONE(cam, vehicle, boneIndex, relativeRotation, rotX, rotY, rotZ, offsetX, offsetY, offsetZ, fixedDirection)
  Velora.invoke(0x990560,"void", cam, vehicle, boneIndex, relativeRotation, rotX, rotY, rotZ, offsetX, offsetY, offsetZ, fixedDirection)
end
-- PC:0xA2FABBE87F4BAD82 Old:0xF4FBF14A
function CAM.DETACH_CAM(cam)
  Velora.invoke(0x9905B0,"void", cam)
end
-- PC:0x45F1DE9C34B93AE6 Old:0xE4BD5342
function CAM.SET_CAM_INHERIT_ROLL_VEHICLE(cam, p1)
  Velora.invoke(0x990620,"void", cam, p1)
end
-- PC:0xF75497BB865F0803 Old:0x914BC21A
function CAM.POINT_CAM_AT_COORD(cam, x, y, z)
  Velora.invoke(0x990630,"void", cam, x, y, z)
end
-- PC:0x5640BFF86B16E8DC Old:0x7597A0F7
function CAM.POINT_CAM_AT_ENTITY(cam, entity, p2, p3, p4, p5)
  Velora.invoke(0x9906E0,"void", cam, entity, p2, p3, p4, p5)
end
-- PC:0x68B2B5F33BA63C41 Old:0x09F47049
function CAM.POINT_CAM_AT_PED_BONE(cam, ped, boneIndex, x, y, z, p6)
  Velora.invoke(0x990700,"void", cam, ped, boneIndex, x, y, z, p6)
end
-- PC:0xF33AB75780BA57DE Old:0x5435F6A5
function CAM.STOP_CAM_POINTING(cam)
  Velora.invoke(0x990720,"void", cam)
end
-- PC:0x8C1DC7770C51DC8D Old:0x0C74F9AF
function CAM.SET_CAM_AFFECTS_AIMING(cam, toggle)
  Velora.invoke(0x990790,"void", cam, toggle)
end
-- PC:0x661B5C8654ADD825 Old:0xE1A0B2F1
function CAM.SET_CAM_CONTROLS_MINI_MAP_HEADING(cam, toggle)
  Velora.invoke(0x990810,"void", cam, toggle)
end
function CAM.SET_CAM_IS_INSIDE_VEHICLE(cam, toggle)
  Velora.invoke(0x9908B0,"void", cam, toggle)
end
-- PC:0x271017B9BA825366 Old:0x43220969
function CAM.ALLOW_MOTION_BLUR_DECAY(p0, p1)
  Velora.invoke(0x990930,"void", p0, p1)
end
-- PC:0x1B93E0107865DD40 Old:0x9B00DF3F
function CAM.SET_CAM_DEBUG_NAME(camera, name)
  Velora.invoke(0x9909B0,"void", camera, name)
end
function CAM.GET_DEBUG_CAM()
  return Velora.invoke(0x9909C0,"int")
end
-- PC:0x8609C75EC438FB3B Old:0xAD3C7EAA
function CAM.ADD_CAM_SPLINE_NODE(camera, x, y, z, xRot, yRot, zRot, length, smoothingStyle, rotationOrder)
  Velora.invoke(0x9909E0,"void", camera, x, y, z, xRot, yRot, zRot, length, smoothingStyle, rotationOrder)
end
-- PC:0x0A9F2A468B328E74 Old:0x30510511
function CAM.ADD_CAM_SPLINE_NODE_USING_CAMERA_FRAME(cam, cam2, length, p3)
  Velora.invoke(0x990A00,"void", cam, cam2, length, p3)
end
-- PC:0x0FB82563989CF4FB Old:0xBA6C085B
function CAM.ADD_CAM_SPLINE_NODE_USING_CAMERA(cam, cam2, length, p3)
  Velora.invoke(0x990A20,"void", cam, cam2, length, p3)
end
-- PC:0x609278246A29CA34 Old:0xB4737F03
function CAM.ADD_CAM_SPLINE_NODE_USING_GAMEPLAY_FRAME(cam, length, p2)
  Velora.invoke(0x990A40,"void", cam, length, p2)
end
-- PC:0x242B5874F0A4E052 Old:0xF0AED233
function CAM.SET_CAM_SPLINE_PHASE(cam, p1)
  Velora.invoke(0x990AD0,"void", cam, p1)
end
-- PC:0xB5349E36C546509A Old:0x39784DD9
function CAM.GET_CAM_SPLINE_PHASE(cam)
  return Velora.invoke(0x990B60,"float", cam)
end
-- PC:0xD9D0E694C8282C96 Old:0x7B9522F6
function CAM.GET_CAM_SPLINE_NODE_PHASE(cam)
  return Velora.invoke(0x990BF0,"float", cam)
end
-- PC:0x1381539FEE034CDA Old:0x3E91FC8A
function CAM.SET_CAM_SPLINE_DURATION(cam, timeDuration)
  Velora.invoke(0x990C80,"void", cam, timeDuration)
end
-- PC:0xD1B0F412F109EA5D Old:0x15E141CE
function CAM.SET_CAM_SPLINE_SMOOTHING_STYLE(cam, smoothingStyle)
  Velora.invoke(0x990CF0,"void", cam, smoothingStyle)
end
-- PC:0xB22B17DF858716A6 Old:0xF8AEB6BD
function CAM.GET_CAM_SPLINE_NODE_INDEX(cam)
  return Velora.invoke(0x990D60,"int", cam)
end
-- PC:0x83B8201ED82A9A2D Old:0x21D275DA
function CAM.SET_CAM_SPLINE_NODE_EASE(cam, easingFunction, p2, p3)
  Velora.invoke(0x990DE0,"void", cam, easingFunction, p2, p3)
end
-- PC:0xA6385DEB180F319F Old:0xA3BD9E94
function CAM.SET_CAM_SPLINE_NODE_VELOCITY_SCALE(cam, p1, scale)
  Velora.invoke(0x990E90,"void", cam, p1, scale)
end
-- PC:0x40B62FA033EB0346 Old:0x326A17E2
function CAM.OVERRIDE_CAM_SPLINE_VELOCITY(cam, p1, p2, p3)
  Velora.invoke(0x990F50,"void", cam, p1, p2, p3)
end
-- PC:0x7DCF7C708D292D55 Old:0x633179E6
function CAM.OVERRIDE_CAM_SPLINE_MOTION_BLUR(cam, p1, p2, p3)
  Velora.invoke(0x991010,"void", cam, p1, p2, p3)
end
-- PC:0x7BF1A54AE67AC070 Old:0xC90B2DDC
function CAM.SET_CAM_SPLINE_NODE_EXTRA_FLAGS(cam, p1, flags)
  Velora.invoke(0x9910D0,"void", cam, p1, flags)
end
-- PC:0x0290F35C0AD97864 Old:0x60B34FF5
function CAM.IS_CAM_SPLINE_PAUSED(cam)
  return Velora.invoke(0x9910F0,"bool", cam)
end
-- PC:0x9FBDA379383A52A4 Old:0x7983E7F0
function CAM.SET_CAM_ACTIVE_WITH_INTERP(camTo, camFrom, duration, easeLocation, easeRotation)
  Velora.invoke(0x9911D0,"void", camTo, camFrom, duration, easeLocation, easeRotation)
end
-- PC:0x036F97C908C2B52C Old:0x7159CB5D
function CAM.IS_CAM_INTERPOLATING(cam)
  return Velora.invoke(0x9911F0,"bool", cam)
end
-- PC:0x6A25241C340D3822 Old:0x1D4211B0
function CAM.SHAKE_CAM(cam, type, amplitude)
  Velora.invoke(0x991280,"void", cam, type, amplitude)
end
-- PC:0xA2746EEAE3E577CD Old:0xE1168767
function CAM.ANIMATED_SHAKE_CAM(cam, p1, p2, p3, amplitude)
  Velora.invoke(0x991310,"void", cam, p1, p2, p3, amplitude)
end
-- PC:0x6B24BFE83A2BE47B Old:0x0961FD9B
function CAM.IS_CAM_SHAKING(cam)
  return Velora.invoke(0x9913B0,"bool", cam)
end
-- PC:0xD93DB43B82BC0D00 Old:0x60FF6382
function CAM.SET_CAM_SHAKE_AMPLITUDE(cam, amplitude)
  Velora.invoke(0x991420,"void", cam, amplitude)
end
-- PC:0xBDECF64367884AC3 Old:0x40D0EB87
function CAM.STOP_CAM_SHAKING(cam, p1)
  Velora.invoke(0x991490,"void", cam, p1)
end
-- PC:0xF4C8CF9E353AFECA Old:0x2B0F05CD
function CAM.SHAKE_SCRIPT_GLOBAL(p0, p1)
  Velora.invoke(0x991500,"void", p0, p1)
end
-- PC:0xC2EAE3FB8CDBED31 Old:0xCB75BD9C
function CAM.ANIMATED_SHAKE_SCRIPT_GLOBAL(p0, p1, p2, p3)
  Velora.invoke(0x991540,"void", p0, p1, p2, p3)
end
-- PC:0xC912AF078AF19212 Old:0x6AEFE6A5
function CAM.IS_SCRIPT_GLOBAL_SHAKING()
  return Velora.invoke(0x991590,"bool")
end
-- PC:0x1C9D7949FA533490 Old:0x26FCFB96
function CAM.STOP_SCRIPT_GLOBAL_SHAKING(p0)
  Velora.invoke(0x9915C0,"void", p0)
end
function CAM.TRIGGER_VEHICLE_PART_BROKEN_CAMERA_SHAKE(vehicle, p1, p2)
  Velora.invoke(0x9915F0,"void", vehicle, p1, p2)
end
-- PC:0x9A2D0FB2E7852392 Old:0xBCEFB87E
function CAM.PLAY_CAM_ANIM(cam, animName, animDictionary, x, y, z, xRot, yRot, zRot, p9, p10)
  return Velora.invoke(0x991680,"bool", cam, animName, animDictionary, x, y, z, xRot, yRot, zRot, p9, p10)
end
-- PC:0xC90621D8A0CEECF2 Old:0xB998CB49
function CAM.IS_CAM_PLAYING_ANIM(cam, animName, animDictionary)
  return Velora.invoke(0x9916C0,"bool", cam, animName, animDictionary)
end
-- PC:0x4145A4C44FF3B5A6 Old:0x3CB1D17F
function CAM.SET_CAM_ANIM_CURRENT_PHASE(cam, phase)
  Velora.invoke(0x991770,"void", cam, phase)
end
-- PC:0xA10B2DB49E92A6B0 Old:0x345F72D0
function CAM.GET_CAM_ANIM_CURRENT_PHASE(cam)
  return Velora.invoke(0x9917E0,"float", cam)
end
-- PC:0xE32EFE9AB4A9AA0C Old:0x9458459E
function CAM.PLAY_SYNCHRONIZED_CAM_ANIM(p0, p1, animName, animDictionary)
  return Velora.invoke(0x991830,"bool", p0, p1, animName, animDictionary)
end
-- PC:0x503F5920162365B2 Old:0x56F9ED27
function CAM.SET_FLY_CAM_HORIZONTAL_RESPONSE(cam, p1, p2, p3)
  Velora.invoke(0x991860,"void", cam, p1, p2, p3)
end
function CAM.SET_FLY_CAM_VERTICAL_RESPONSE(cam, p1, p2, p3)
  Velora.invoke(0x991910,"void", cam, p1, p2, p3)
end
-- PC:0xF9D02130ECDD1D77 Old:0x71570DBA
function CAM.SET_FLY_CAM_MAX_HEIGHT(cam, height)
  Velora.invoke(0x9919C0,"void", cam, height)
end
-- PC:0xC91C6C55199308CA Old:0x60B345DE
function CAM.SET_FLY_CAM_COORD_AND_CONSTRAIN(cam, x, y, z)
  Velora.invoke(0x991A40,"void", cam, x, y, z)
end
-- PC:0xC8B5C4A79CC18B94 Old:0x44473EFC
function CAM.SET_FLY_CAM_VERTICAL_CONTROLS_THIS_UPDATE(cam)
  Velora.invoke(0x991AE0,"void", cam)
end
-- PC:0x5C48A1D6E3B33179 Old:0xDA931D65
function CAM.WAS_FLY_CAM_CONSTRAINED_ON_PREVIOUS_UDPATE(cam)
  return Velora.invoke(0x991B50,"bool", cam)
end
-- PC:0xB16FCE9DDC7BA182 Old:0x9CAA05FA
function CAM.IS_SCREEN_FADED_OUT()
  return Velora.invoke(0x991BD0,"bool")
end
-- PC:0x5A859503B0C08678 Old:0x4F37276D
function CAM.IS_SCREEN_FADED_IN()
  return Velora.invoke(0x991BF0,"bool")
end
-- PC:0x797AC7CB535BA28F Old:0x79275A57
function CAM.IS_SCREEN_FADING_OUT()
  return Velora.invoke(0x991C10,"bool")
end
-- PC:0x5C544BC6C57AC575 Old:0xC7C82800
function CAM.IS_SCREEN_FADING_IN()
  return Velora.invoke(0x991C30,"bool")
end
-- PC:0xD4E8E24955024033 Old:0x66C1BDEE
function CAM.DO_SCREEN_FADE_IN(duration)
  Velora.invoke(0x991C50,"void", duration)
end
-- PC:0x891B5B39AC6302AF Old:0x89D01805
function CAM.DO_SCREEN_FADE_OUT(duration)
  Velora.invoke(0x991C60,"void", duration)
end
-- PC:0xDCD4EA924F42D01A Old:0x1A75DC9A
function CAM.SET_WIDESCREEN_BORDERS(p0, p1)
  Velora.invoke(0x991C70,"void", p0, p1)
end
function CAM.ARE_WIDESCREEN_BORDERS_ACTIVE()
  return Velora.invoke(0x991C90,"bool")
end
-- PC:0x14D6F5678D8F1B37 Old:0x9388CF79
function CAM.GET_GAMEPLAY_CAM_COORD()
  local x,y,z=Velora.invoke(0x991CB0,"vector3")
  return {x=x,y=y,z=z}
end
-- PC:0x837765A25378F0BB Old:0x13A010B5
function CAM.GET_GAMEPLAY_CAM_ROT(rotationOrder)
  local x,y,z=Velora.invoke(0x991CF0,"vector3", rotationOrder)
  return {x=x,y=y,z=z}
end
-- PC:0x65019750A0324133 Old:0x4D6B3BFA
function CAM.GET_GAMEPLAY_CAM_FOV()
  return Velora.invoke(0x991D90,"float")
end
-- PC:0x487A82C650EB7799 Old:0xA6E73135
function CAM.SET_GAMEPLAY_CAM_MOTION_BLUR_SCALING_THIS_UPDATE(p0)
  Velora.invoke(0x991DC0,"void", p0)
end
-- PC:0x0225778816FDC28C Old:0x1126E37C
function CAM.SET_GAMEPLAY_CAM_MAX_MOTION_BLUR_STRENGTH_THIS_UPDATE(p0)
  Velora.invoke(0x991E00,"void", p0)
end
-- PC:0x743607648ADD4587 Old:0xCAF839C2
function CAM.GET_GAMEPLAY_CAM_RELATIVE_HEADING()
  return Velora.invoke(0x991E50,"float")
end
-- PC:0xB4EC2312F4E5B1F1 Old:0x20C6217C
function CAM.SET_GAMEPLAY_CAM_RELATIVE_HEADING(heading)
  Velora.invoke(0x991E80,"void", heading)
end
-- PC:0x3A6867B4845BEDA2 Old:0xFC5A4946
function CAM.GET_GAMEPLAY_CAM_RELATIVE_PITCH()
  return Velora.invoke(0x991E90,"float")
end
-- PC:0x6D0858B8EDFD2B7D Old:0x6381B963
function CAM.SET_GAMEPLAY_CAM_RELATIVE_PITCH(angle, scalingFactor)
  Velora.invoke(0x991EC0,"void", angle, scalingFactor)
end
function CAM.RESET_GAMEPLAY_CAM_FULL_ATTACH_PARENT_TRANSFORM_TIMER()
  Velora.invoke(0x991F30,"void")
end
function CAM.FORCE_CAMERA_RELATIVE_HEADING_AND_PITCH(roll, pitch, yaw)
  Velora.invoke(0x991F60,"void", roll, pitch, yaw)
end
function CAM.FORCE_BONNET_CAMERA_RELATIVE_HEADING_AND_PITCH(p0, p1)
  Velora.invoke(0x991F80,"void", p0, p1)
end
function CAM.SET_FIRST_PERSON_SHOOTER_CAMERA_HEADING(yaw)
  Velora.invoke(0x9920A0,"void", yaw)
end
function CAM.SET_FIRST_PERSON_SHOOTER_CAMERA_PITCH(pitch)
  Velora.invoke(0x9920E0,"void", pitch)
end
function CAM.SET_SCRIPTED_CAMERA_IS_FIRST_PERSON_THIS_FRAME(p0)
  Velora.invoke(0x992140,"void", p0)
end
-- PC:0xFD55E49555E017CF Old:0xF2EFE660
function CAM.SHAKE_GAMEPLAY_CAM(shakeName, intensity)
  Velora.invoke(0x992160,"void", shakeName, intensity)
end
-- PC:0x016C090630DF1F89 Old:0x3457D681
function CAM.IS_GAMEPLAY_CAM_SHAKING()
  return Velora.invoke(0x9921A0,"bool")
end
-- PC:0xA87E00932DB4D85D Old:0x9219D44A
function CAM.SET_GAMEPLAY_CAM_SHAKE_AMPLITUDE(amplitude)
  Velora.invoke(0x9921D0,"void", amplitude)
end
-- PC:0x0EF93E9F3D08C178 Old:0xFD569E4E
function CAM.STOP_GAMEPLAY_CAM_SHAKING(p0)
  Velora.invoke(0x992200,"void", p0)
end
-- PC:0x8BBACBF51DA047A8 Old:0x7D3007A2
function CAM.SET_GAMEPLAY_CAM_FOLLOW_PED_THIS_UPDATE(ped)
  Velora.invoke(0x992230,"void", ped)
end
-- PC:0x39B5D1B10383F0C8 Old:0x0EF276DA
function CAM.IS_GAMEPLAY_CAM_RENDERING()
  return Velora.invoke(0x9922A0,"bool")
end
-- PC:0x3044240D2E0FA842 Old:0xC0B00C20
function CAM.IS_INTERPOLATING_FROM_SCRIPT_CAMS()
  return Velora.invoke(0x9922D0,"bool")
end
-- PC:0x705A276EBFF3133D Old:0x60C23785
function CAM.IS_INTERPOLATING_TO_SCRIPT_CAMS()
  return Velora.invoke(0x992310,"bool")
end
-- PC:0xDB90C6CCA48940F1 Old:0x20BFF6E5
function CAM.SET_GAMEPLAY_CAM_ALTITUDE_FOV_SCALING_STATE(p0)
  Velora.invoke(0x992350,"void", p0)
end
-- PC:0xEA7F0AD7E9BA676F Old:0xA61FF9AC
function CAM.DISABLE_GAMEPLAY_CAM_ALTITUDE_FOV_SCALING_THIS_UPDATE()
  Velora.invoke(0x992380,"void")
end
-- PC:0x70FDA869F3317EA9 Old:0x33C83F17
function CAM.IS_GAMEPLAY_CAM_LOOKING_BEHIND()
  return Velora.invoke(0x9923A0,"bool")
end
-- PC:0x2AED6301F67007D5 Old:0x2701A9AD
function CAM.SET_GAMEPLAY_CAM_IGNORE_ENTITY_COLLISION_THIS_UPDATE(entity)
  Velora.invoke(0x9923D0,"void", entity)
end
-- PC:0x49482F9FCD825AAA Old:0xC4736ED3
function CAM.DISABLE_CAM_COLLISION_FOR_OBJECT(entity)
  Velora.invoke(0x992440,"void", entity)
end
function CAM.BYPASS_CAMERA_COLLISION_BUOYANCY_TEST_THIS_UPDATE()
  Velora.invoke(0x9924A0,"void")
end
function CAM.SET_GAMEPLAY_CAM_ENTITY_TO_LIMIT_FOCUS_OVER_BOUNDING_SPHERE_THIS_UPDATE(entity)
  Velora.invoke(0x9924D0,"void", entity)
end
function CAM.DISABLE_FIRST_PERSON_CAMERA_WATER_CLIPPING_TEST_THIS_UPDATE()
  Velora.invoke(0x992540,"void")
end
-- PC:0xDD79DF9F4D26E1C9 Old:0x6B0E9D57
function CAM.SET_FOLLOW_CAM_IGNORE_ATTACH_PARENT_MOVEMENT_THIS_UPDATE()
  Velora.invoke(0x992560,"void")
end
-- PC:0xE33D59DA70B58FDF Old:0xDD1329E2
function CAM.IS_SPHERE_VISIBLE(x, y, z, radius)
  return Velora.invoke(0x992580,"bool", x, y, z, radius)
end
-- PC:0xC6D3D26810C8E0F9 Old:0x9F9E856C
function CAM.IS_FOLLOW_PED_CAM_ACTIVE()
  return Velora.invoke(0x9925F0,"bool")
end
-- PC:0x44A113DD6FFC48D1 Old:0x1425F6AC
function CAM.SET_FOLLOW_PED_CAM_THIS_UPDATE(camName, p1)
  return Velora.invoke(0x992620,"bool", camName, p1)
end
-- PC:0x271401846BD26E92 Old:0x8DC53629
function CAM.USE_SCRIPT_CAM_FOR_AMBIENT_POPULATION_ORIGIN_THIS_FRAME(p0, p1)
  Velora.invoke(0x9926B0,"void", p0, p1)
end
-- PC:0xC8391C309684595A Old:0x1F9DE6E4
function CAM.SET_FOLLOW_PED_CAM_LADDER_ALIGN_THIS_UPDATE()
  Velora.invoke(0x992700,"void")
end
-- PC:0x8F993D26E0CA5E8E Old:0x749909AC
function CAM.SET_THIRD_PERSON_CAM_RELATIVE_HEADING_LIMITS_THIS_UPDATE(minimum, maximum)
  Velora.invoke(0x992730,"void", minimum, maximum)
end
-- PC:0xA516C198B7DCA1E1 Old:0xFA3A16E7
function CAM.SET_THIRD_PERSON_CAM_RELATIVE_PITCH_LIMITS_THIS_UPDATE(minimum, maximum)
  Velora.invoke(0x9927D0,"void", minimum, maximum)
end
-- PC:0xDF2E1F7742402E81 Old:0x77340650
function CAM.SET_THIRD_PERSON_CAM_ORBIT_DISTANCE_LIMITS_THIS_UPDATE(p0, distance)
  Velora.invoke(0x992870,"void", p0, distance)
end
-- PC:0xE9EA16D6E54CDCA4 Old:0x4B22C5CB
function CAM.SET_IN_VEHICLE_CAM_STATE_THIS_UPDATE(p0, p1)
  Velora.invoke(0x992920,"void", p0, p1)
end
function CAM.DISABLE_ON_FOOT_FIRST_PERSON_VIEW_THIS_UPDATE()
  Velora.invoke(0x992990,"void")
end
function CAM.DISABLE_FIRST_PERSON_FLASH_EFFECT_THIS_UPDATE()
  Velora.invoke(0x9929B0,"void")
end
function CAM.BLOCK_FIRST_PERSON_ORIENTATION_RESET_THIS_UPDATE()
  Velora.invoke(0x9929C0,"void")
end
-- PC:0x33E6C8EFD0CD93E9 Old:0x57583DF1
function CAM.GET_FOLLOW_PED_CAM_ZOOM_LEVEL()
  return Velora.invoke(0x9929F0,"int")
end
-- PC:0x8D4D46230B2C353A Old:0xA65FF946
function CAM.GET_FOLLOW_PED_CAM_VIEW_MODE()
  return Velora.invoke(0x992A10,"int")
end
-- PC:0x5A4F9EDF1673F704 Old:0x495DBE8D
function CAM.SET_FOLLOW_PED_CAM_VIEW_MODE(viewMode)
  Velora.invoke(0x992A30,"void", viewMode)
end
-- PC:0xCBBDE6D335D6D496 Old:0x8DD49B77
function CAM.IS_FOLLOW_VEHICLE_CAM_ACTIVE()
  return Velora.invoke(0x992A40,"bool")
end
-- PC:0x91EF6EE6419E5B97 Old:0x9DB5D391
function CAM.SET_FOLLOW_VEHICLE_CAM_HIGH_ANGLE_MODE_THIS_UPDATE(p0)
  Velora.invoke(0x992A70,"void", p0)
end
-- PC:0x9DFE13ECDC1EC196 Old:0x92302899
function CAM.SET_FOLLOW_VEHICLE_CAM_HIGH_ANGLE_MODE_EVERY_UPDATE(p0, p1)
  Velora.invoke(0x992AA0,"void", p0, p1)
end
function CAM.SET_TABLE_GAMES_CAMERA_THIS_UPDATE(hash)
  return Velora.invoke(0x992AD0,"bool", hash)
end
-- PC:0xEE82280AB767B690 Old:0x8CD67DE3
function CAM.GET_FOLLOW_VEHICLE_CAM_ZOOM_LEVEL()
  return Velora.invoke(0x992B50,"int")
end
-- PC:0x19464CB6E4078C8A Old:0x8F55EBBE
function CAM.SET_FOLLOW_VEHICLE_CAM_ZOOM_LEVEL(zoomLevel)
  Velora.invoke(0x992B70,"void", zoomLevel)
end
-- PC:0xA4FF579AC0E3AAAE Old:0xA4B4DB03
function CAM.GET_FOLLOW_VEHICLE_CAM_VIEW_MODE()
  return Velora.invoke(0x992B80,"int")
end
-- PC:0xAC253D7842768F48 Old:0xC4FBBBD3
function CAM.SET_FOLLOW_VEHICLE_CAM_VIEW_MODE(viewMode)
  Velora.invoke(0x992BA0,"void", viewMode)
end
-- PC:0xEE778F8C7E1142E2 Old:0xF3B148A6
function CAM.GET_CAM_VIEW_MODE_FOR_CONTEXT(context)
  return Velora.invoke(0x992BB0,"int", context)
end
-- PC:0x2A2173E46DAECD12 Old:0x1DEBCB45
function CAM.SET_CAM_VIEW_MODE_FOR_CONTEXT(context, viewMode)
  Velora.invoke(0x992BD0,"void", context, viewMode)
end
function CAM.GET_CAM_ACTIVE_VIEW_MODE_CONTEXT()
  return Velora.invoke(0x992BE0,"int")
end
function CAM.USE_VEHICLE_CAM_STUNT_SETTINGS_THIS_UPDATE()
  Velora.invoke(0x992C10,"void")
end
function CAM.USE_DEDICATED_STUNT_CAMERA_THIS_UPDATE(camName)
  Velora.invoke(0x992C30,"void", camName)
end
function CAM.FORCE_VEHICLE_CAM_STUNT_SETTINGS_THIS_UPDATE()
  Velora.invoke(0x992C60,"void")
end
function CAM.SET_FOLLOW_VEHICLE_CAM_SEAT_THIS_UPDATE(seatIndex)
  Velora.invoke(0x992C80,"void", seatIndex)
end
-- PC:0x68EDDA28A5976D07 Old:0xC24B4F6F
function CAM.IS_AIM_CAM_ACTIVE()
  return Velora.invoke(0x992CA0,"bool")
end
-- PC:0x74BD83EA840F6BC9 Old:0x8F320DE4
function CAM.IS_AIM_CAM_ACTIVE_IN_ACCURATE_MODE()
  return Velora.invoke(0x992D00,"bool")
end
-- PC:0x5E346D934122613F Old:0xD6280468
function CAM.IS_FIRST_PERSON_AIM_CAM_ACTIVE()
  return Velora.invoke(0x992D40,"bool")
end
-- PC:0x1A31FE0049E542F6 Old:0x1BAA7182
function CAM.DISABLE_AIM_CAM_THIS_UPDATE()
  Velora.invoke(0x992D70,"void")
end
-- PC:0x7EC52CC40597D170 Old:0x33951005
function CAM.GET_FIRST_PERSON_AIM_CAM_ZOOM_FACTOR()
  return Velora.invoke(0x992DB0,"float")
end
-- PC:0x70894BD0915C5BCA Old:0x9F4AF763
function CAM.SET_FIRST_PERSON_AIM_CAM_ZOOM_FACTOR(zoomFactor)
  Velora.invoke(0x992DD0,"void", zoomFactor)
end
-- PC:0xCED08CBE8EBB97C7 Old:0x68BA0730
function CAM.SET_FIRST_PERSON_AIM_CAM_ZOOM_FACTOR_LIMITS_THIS_UPDATE(p0, p1)
  Velora.invoke(0x992DF0,"void", p0, p1)
end
-- PC:0x2F7F2B26DD3F18EE Old:0x2F29F0D5
function CAM.SET_FIRST_PERSON_AIM_CAM_RELATIVE_HEADING_LIMITS_THIS_UPDATE(p0, p1)
  Velora.invoke(0x992E10,"void", p0, p1)
end
-- PC:0xBCFC632DB7673BF0 Old:0x76DAC96C
function CAM.SET_FIRST_PERSON_AIM_CAM_RELATIVE_PITCH_LIMITS_THIS_UPDATE(p0, p1)
  Velora.invoke(0x992F80,"void", p0, p1)
end
-- PC:0x0AF7B437918103B3 Old:0x0E21069D
function CAM.SET_FIRST_PERSON_AIM_CAM_NEAR_CLIP_THIS_UPDATE(p0)
  Velora.invoke(0x993020,"void", p0)
end
-- PC:0x42156508606DE65E Old:0x71E9C63E
function CAM.SET_THIRD_PERSON_AIM_CAM_NEAR_CLIP_THIS_UPDATE(p0)
  Velora.invoke(0x993060,"void", p0)
end
-- PC:0x4008EDF7D6E48175 Old:0xD1EEBC45
function CAM.SET_ALLOW_CUSTOM_VEHICLE_DRIVE_BY_CAM_THIS_UPDATE(p0)
  Velora.invoke(0x9930A0,"void", p0)
end
function CAM.FORCE_TIGHTSPACE_CUSTOM_FRAMING_THIS_UPDATE()
  Velora.invoke(0x9930D0,"void")
end
-- PC:0xA200EB1EE790F448 Old:0x9C84BDA0
function CAM.GET_FINAL_RENDERED_CAM_COORD()
  local x,y,z=Velora.invoke(0x9930F0,"vector3")
  return {x=x,y=y,z=z}
end
-- PC:0x5B4E4C817FCC2DFB Old:0x1FFBEFC5
function CAM.GET_FINAL_RENDERED_CAM_ROT(rotationOrder)
  local x,y,z=Velora.invoke(0x993130,"vector3", rotationOrder)
  return {x=x,y=y,z=z}
end
-- PC:0x26903D9CD1175F2C Old:0xACADF916
function CAM.GET_FINAL_RENDERED_REMOTE_PLAYER_CAM_ROT(player, rotationOrder)
  local x,y,z=Velora.invoke(0x9931C0,"vector3", player, rotationOrder)
  return {x=x,y=y,z=z}
end
-- PC:0x80EC114669DAEFF4 Old:0x721B763B
function CAM.GET_FINAL_RENDERED_CAM_FOV()
  return Velora.invoke(0x9932C0,"float")
end
-- PC:0x5F35F6732C3FBBA0 Old:0x23E3F106
function CAM.GET_FINAL_RENDERED_REMOTE_PLAYER_CAM_FOV(player)
  return Velora.invoke(0x9932E0,"float", player)
end
-- PC:0xD0082607100D7193 Old:0x457AE195
function CAM.GET_FINAL_RENDERED_CAM_NEAR_CLIP()
  return Velora.invoke(0x993330,"float")
end
-- PC:0xDFC8CBC606FDB0FC Old:0x46CB3A49
function CAM.GET_FINAL_RENDERED_CAM_FAR_CLIP()
  return Velora.invoke(0x993350,"float")
end
-- PC:0xA03502FC581F7D9B Old:0x19297A7A
function CAM.GET_FINAL_RENDERED_CAM_NEAR_DOF()
  return Velora.invoke(0x993370,"float")
end
-- PC:0x9780F32BCAF72431 Old:0xF24777CA
function CAM.GET_FINAL_RENDERED_CAM_FAR_DOF()
  return Velora.invoke(0x993390,"float")
end
-- PC:0x162F9D995753DC19 Old:0x38992E83
function CAM.GET_FINAL_RENDERED_CAM_MOTION_BLUR_STRENGTH()
  return Velora.invoke(0x9933B0,"float")
end
-- PC:0xD51ADCD2D8BC0FB3 Old:0xF27483C9
function CAM.SET_GAMEPLAY_COORD_HINT(x, y, z, duration, blendOutDuration, blendInDuration, p6)
  Velora.invoke(0x9933D0,"void", x, y, z, duration, blendOutDuration, blendInDuration, p6)
end
-- PC:0x2B486269ACD548D3 Old:0x7C27343E
function CAM.SET_GAMEPLAY_PED_HINT(ped, x1, y1, z1, p4, duration, blendOutDuration, blendInDuration)
  Velora.invoke(0x993460,"void", ped, x1, y1, z1, p4, duration, blendOutDuration, blendInDuration)
end
-- PC:0xA2297E18F3E71C2E Old:0x2C9A11D8
function CAM.SET_GAMEPLAY_VEHICLE_HINT(vehicle, offsetX, offsetY, offsetZ, p4, time, easeInTime, easeOutTime)
  Velora.invoke(0x993530,"void", vehicle, offsetX, offsetY, offsetZ, p4, time, easeInTime, easeOutTime)
end
-- PC:0x83E87508A2CA2AC6 Old:0x2ED5E2F8
function CAM.SET_GAMEPLAY_OBJECT_HINT(object, xOffset, yOffset, zOffset, p4, time, easeInTime, easeOutTime)
  Velora.invoke(0x993600,"void", object, xOffset, yOffset, zOffset, p4, time, easeInTime, easeOutTime)
end
-- PC:0x189E955A8313E298 Old:0x66C32306
function CAM.SET_GAMEPLAY_ENTITY_HINT(entity, xOffset, yOffset, zOffset, p4, time, easeInTime, easeOutTime, p8)
  Velora.invoke(0x9936D0,"void", entity, xOffset, yOffset, zOffset, p4, time, easeInTime, easeOutTime, p8)
end
-- PC:0xE520FF1AD2785B40 Old:0xAD8DA205
function CAM.IS_GAMEPLAY_HINT_ACTIVE()
  return Velora.invoke(0x9937A0,"bool")
end
-- PC:0xF46C581C61718916 Old:0x1BC28B7B
function CAM.STOP_GAMEPLAY_HINT(p0)
  Velora.invoke(0x9937E0,"void", p0)
end
-- PC:0xCCD078C2665D2973 Old:0xCAFEE798
function CAM.STOP_GAMEPLAY_HINT_BEING_CANCELLED_THIS_UPDATE(p0)
  Velora.invoke(0x993820,"void", p0)
end
function CAM.STOP_CODE_GAMEPLAY_HINT(p0)
  Velora.invoke(0x993830,"void", p0)
end
function CAM.IS_CODE_GAMEPLAY_HINT_ACTIVE()
  return Velora.invoke(0x993870,"bool")
end
-- PC:0x513403FB9C56211F Old:0x96FD173B
function CAM.SET_GAMEPLAY_HINT_FOV(FOV)
  Velora.invoke(0x9938A0,"void", FOV)
end
-- PC:0xF8BDBF3D573049A1 Old:0x72E8CD3A
function CAM.SET_GAMEPLAY_HINT_FOLLOW_DISTANCE_SCALAR(value)
  Velora.invoke(0x9938F0,"void", value)
end
-- PC:0xD1F8363DFAD03848 Old:0x79472AE3
function CAM.SET_GAMEPLAY_HINT_BASE_ORBIT_PITCH_OFFSET(value)
  Velora.invoke(0x993930,"void", value)
end
-- PC:0x5D7B620DAE436138 Old:0xFC7464A0
function CAM.SET_GAMEPLAY_HINT_CAMERA_RELATIVE_SIDE_OFFSET(xOffset)
  Velora.invoke(0x993970,"void", xOffset)
end
-- PC:0xC92717EF615B6704 Old:0x3554AA0E
function CAM.SET_GAMEPLAY_HINT_CAMERA_RELATIVE_VERTICAL_OFFSET(yOffset)
  Velora.invoke(0x9939B0,"void", yOffset)
end
-- PC:0xE3433EADAAF7EE40 Old:0x2F0CE859
function CAM.SET_GAMEPLAY_HINT_CAMERA_BLEND_TO_FOLLOW_PED_MEDIUM_VIEW_MODE(toggle)
  Velora.invoke(0x9939F0,"void", toggle)
end
-- PC:0x51669F7D1FB53D9F Old:0x3FBC5D00
function CAM.SET_CINEMATIC_BUTTON_ACTIVE(p0)
  Velora.invoke(0x993A20,"void", p0)
end
-- PC:0xB15162CB5826E9E8 Old:0x80471AD9
function CAM.IS_CINEMATIC_CAM_RENDERING()
  return Velora.invoke(0x993A80,"bool")
end
-- PC:0xDCE214D9ED58F3CF Old:0x61815F31
function CAM.SHAKE_CINEMATIC_CAM(shakeType, amount)
  Velora.invoke(0x993AB0,"void", shakeType, amount)
end
-- PC:0xBBC08F6B4CB8FF0A Old:0x8376D939
function CAM.IS_CINEMATIC_CAM_SHAKING()
  return Velora.invoke(0x993AF0,"bool")
end
-- PC:0xC724C701C30B2FE7 Old:0x67510C4B
function CAM.SET_CINEMATIC_CAM_SHAKE_AMPLITUDE(p0)
  Velora.invoke(0x993B20,"void", p0)
end
-- PC:0x2238E588E588A6D7 Old:0x71C12904
function CAM.STOP_CINEMATIC_CAM_SHAKING(p0)
  Velora.invoke(0x993B50,"void", p0)
end
-- PC:0xADFF1B2A555F5FBA Old:0x5AC6DAC9
function CAM.DISABLE_CINEMATIC_BONNET_CAMERA_THIS_UPDATE()
  Velora.invoke(0x993B80,"void")
end
-- PC:0x62ECFCFDEE7885D6 Old:0x837F8581
function CAM.DISABLE_CINEMATIC_VEHICLE_IDLE_MODE_THIS_UPDATE()
  Velora.invoke(0x993BA0,"void")
end
-- PC:0x9E4CFFF989258472 Old:0x65DDE8AF
function CAM.INVALIDATE_CINEMATIC_VEHICLE_IDLE_MODE()
  Velora.invoke(0x993BC0,"void")
end
-- PC:0xF4F2C0D4EE209E20 Old:0xD75CDD75
function CAM.INVALIDATE_IDLE_CAM()
  Velora.invoke(0x993BE0,"void")
end
-- PC:0xCA9D2AA3E326D720 Old:0x96A07066
function CAM.IS_CINEMATIC_IDLE_CAM_RENDERING()
  return Velora.invoke(0x993C00,"bool")
end
function CAM.IS_CINEMATIC_FIRST_PERSON_VEHICLE_INTERIOR_CAM_RENDERING()
  return Velora.invoke(0x993C30,"bool")
end
-- PC:0x741B0129D4560F31 Old:0xAC494E35
function CAM.CREATE_CINEMATIC_SHOT(p0, time, p2, entity)
  Velora.invoke(0x993C60,"void", p0, time, p2, entity)
end
-- PC:0xCC9F3371A7C28BC9 Old:0xA4049042
function CAM.IS_CINEMATIC_SHOT_ACTIVE(p0)
  return Velora.invoke(0x993C80,"bool", p0)
end
-- PC:0x7660C6E75D3A078E Old:0xD78358C5
function CAM.STOP_CINEMATIC_SHOT(p0)
  Velora.invoke(0x993CF0,"void", p0)
end
-- PC:0xA41BCD7213805AAC Old:0xFBB85E02
function CAM.FORCE_CINEMATIC_RENDERING_THIS_UPDATE(toggle)
  Velora.invoke(0x993D50,"void", toggle)
end
-- PC:0xDC9DA9E8789F5246 Old:0x4938C82F
function CAM.SET_CINEMATIC_NEWS_CHANNEL_ACTIVE_THIS_UPDATE()
  Velora.invoke(0x993DB0,"void")
end
-- PC:0xDCF0754AC3D6FD4E Old:0x2009E747
function CAM.SET_CINEMATIC_MODE_ACTIVE(toggle)
  Velora.invoke(0x993DD0,"void", toggle)
end
-- PC:0x1F2300CB7FA7B7F6 Old:0x6739AD55
function CAM.IS_IN_VEHICLE_MOBILE_PHONE_CAMERA_RENDERING()
  return Velora.invoke(0x993E30,"bool")
end
function CAM.DISABLE_CINEMATIC_SLOW_MO_THIS_UPDATE()
  return Velora.invoke(0x993E50,"bool")
end
-- PC:0xD7360051C885628B Old:0x1DD55F13
function CAM.IS_BONNET_CINEMATIC_CAM_RENDERING()
  return Velora.invoke(0x993E70,"bool")
end
-- PC:0xF5F1E89A970B7796 Old:0x1A900C84
function CAM.IS_CINEMATIC_CAM_INPUT_ACTIVE()
  return Velora.invoke(0x993EA0,"bool")
end
function CAM.IGNORE_MENU_PREFERENCE_FOR_BONNET_CAMERA_THIS_UPDATE()
  Velora.invoke(0x993EF0,"void")
end
function CAM.BYPASS_CUTSCENE_CAM_RENDERING_THIS_UPDATE()
  Velora.invoke(0x993F10,"void")
end
function CAM.STOP_CUTSCENE_CAM_SHAKING(p0)
  Velora.invoke(0x993F30,"void", p0)
end
-- PC:0x12DED8CA53D47EA5 Old:0x067BA6F5
function CAM.SET_CUTSCENE_CAM_FAR_CLIP_THIS_UPDATE(p0)
  Velora.invoke(0x993F60,"void", p0)
end
-- PC:0x89215EC747DF244A Old:0xFD99BE2B
function CAM.GET_FOCUS_PED_ON_SCREEN(p0, p1, p2, p3, p4, p5, p6, p7, p8)
  return Velora.invoke(0x993FA0,"int", p0, p1, p2, p3, p4, p5, p6, p7, p8)
end
-- PC:0x5A43C76F7FC7BA5F Old:0xE206C450
function CAM.DISABLE_NEAR_CLIP_SCAN_THIS_UPDATE()
  Velora.invoke(0x994000,"void")
end
-- PC:0x80C8B1846639BB19 Old:0xB06CCD38
function CAM.SET_CAM_DEATH_FAIL_EFFECT_STATE(p0)
  Velora.invoke(0x994010,"void", p0)
end
function CAM.SET_FIRST_PERSON_FLASH_EFFECT_TYPE(p0)
  Velora.invoke(0x994020,"void", p0)
end
function CAM.SET_FIRST_PERSON_FLASH_EFFECT_VEHICLE_MODEL_NAME(vehicleName)
  Velora.invoke(0x994050,"void", vehicleName)
end
function CAM.SET_FIRST_PERSON_FLASH_EFFECT_VEHICLE_MODEL_HASH(vehicleModel)
  Velora.invoke(0x994080,"void", vehicleModel)
end
function CAM.IS_ALLOWED_INDEPENDENT_CAMERA_MODES()
  return Velora.invoke(0x9940B0,"bool")
end
function CAM.CAMERA_PREVENT_COLLISION_SETTINGS_FOR_TRIPLEHEAD_IN_INTERIORS_THIS_UPDATE()
  Velora.invoke(0x9940D0,"void")
end
function CAM.REPLAY_GET_MAX_DISTANCE_ALLOWED_FROM_PLAYER()
  return Velora.invoke(0x9940F0,"float")
end
