-- compat_PLAYER.lua — AUTO GENERATO
-- PLAYER
PLAYER=PLAYER or {}
-- PC:0x43A66C31C68491C0 Old:0x6E31E993
function PLAYER.GET_PLAYER_PED(player)
  return Velora.invoke(0xAA4720,"int", player)
end
-- PC:0x50FAC3A3E030A6E1 Old:0x6AC64990
function PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player)
  return Velora.invoke(0xAA4770,"int", player)
end
-- PC:0x00A1CADD00108836 Old:0x774A4C54
function PLAYER.SET_PLAYER_MODEL(player, model)
  Velora.invoke(0xAA47B0,"void", player, model)
end
-- PC:0x048189FAC643DEEE Old:0xBE515485
function PLAYER.CHANGE_PLAYER_PED(player, ped, p2, resetDamage)
  Velora.invoke(0xAA47C0,"void", player, ped, p2, resetDamage)
end
-- PC:0xE902EF951DCE178F Old:0x6EF43BBB
function PLAYER.GET_PLAYER_RGB_COLOUR(player)
  Velora.invoke(0xAA47F0,"void", player)
end
-- PC:0x407C7F91DDB46C16 Old:0x4C1B8867
function PLAYER.GET_NUMBER_OF_PLAYERS()
  return Velora.invoke(0xAA4850,"int")
end
-- PC:0x37039302F4E0A008 Old:0x9873E404
function PLAYER.GET_PLAYER_TEAM(player)
  return Velora.invoke(0xAA4880,"int", player)
end
-- PC:0x0299FA38396A4940 Old:0x725ADCF2
function PLAYER.SET_PLAYER_TEAM(player, team)
  Velora.invoke(0xAA48C0,"void", player, team)
end
function PLAYER.GET_NUMBER_OF_PLAYERS_IN_TEAM(team)
  return Velora.invoke(0xAA4930,"int", team)
end
-- PC:0x085DEB493BE80812 Old:0x1CF7D7DA
function PLAYER.GET_WANTED_LEVEL_RADIUS(player)
  return Velora.invoke(0xAA4A40,"float", player)
end
-- PC:0x0C92BA89F1AF26F8 Old:0x821F2D2C
function PLAYER.GET_PLAYER_WANTED_CENTRE_POSITION(player)
  local x,y,z=Velora.invoke(0xAA4A70,"vector3", player)
  return {x=x,y=y,z=z}
end
-- PC:0x520E541A97A13354 Old:0xF261633A
function PLAYER.SET_PLAYER_WANTED_CENTRE_POSITION(player, p2, p3)
  Velora.invoke(0xAA4B10,"void", player, p2, p3)
end
-- PC:0xFDD179EAF45B556C Old:0xD9783F6B
function PLAYER.GET_WANTED_LEVEL_THRESHOLD(wantedLevel)
  return Velora.invoke(0xAA4B90,"int", wantedLevel)
end
-- PC:0x39FF19C64EF7DA5B Old:0xB7A0914B
function PLAYER.SET_PLAYER_WANTED_LEVEL(player, wantedLevel, disableNoMission)
  Velora.invoke(0xAA4BB0,"void", player, wantedLevel, disableNoMission)
end
-- PC:0x340E61DE7F471565 Old:0xED6F44F5
function PLAYER.SET_PLAYER_WANTED_LEVEL_NO_DROP(player, wantedLevel, p2)
  Velora.invoke(0xAA4BD0,"void", player, wantedLevel, p2)
end
-- PC:0xE0A7D1E497FFCD6F Old:0xAF3AFD83
function PLAYER.SET_PLAYER_WANTED_LEVEL_NOW(player, p1)
  Velora.invoke(0xAA4C90,"void", player, p1)
end
-- PC:0xAFAF86043E5874E9 Old:0xE13A71C7
function PLAYER.ARE_PLAYER_FLASHING_STARS_ABOUT_TO_DROP(player)
  return Velora.invoke(0xAA4D50,"bool", player)
end
-- PC:0x0A6EB355EE14A2DB Old:0x5E72AB72
function PLAYER.ARE_PLAYER_STARS_GREYED_OUT(player)
  return Velora.invoke(0xAA4DC0,"bool", player)
end
function PLAYER.IS_WANTED_AND_HAS_BEEN_SEEN_BY_COPS(player)
  return Velora.invoke(0xAA4E20,"bool", player)
end
-- PC:0xDB172424876553F4 Old:0x48A18913
function PLAYER.SET_DISPATCH_COPS_FOR_PLAYER(player, toggle)
  Velora.invoke(0xAA4E90,"void", player, toggle)
end
-- PC:0x238DB2A2C23EE9EF Old:0x589A2661
function PLAYER.IS_PLAYER_WANTED_LEVEL_GREATER(player, wantedLevel)
  return Velora.invoke(0xAA4F00,"bool", player, wantedLevel)
end
-- PC:0xB302540597885499 Old:0x54EA5BCC
function PLAYER.CLEAR_PLAYER_WANTED_LEVEL(player)
  Velora.invoke(0xAA4F50,"void", player)
end
-- PC:0x424D4687FA1E5652 Old:0x140CA5A8
function PLAYER.IS_PLAYER_DEAD(player)
  return Velora.invoke(0xAA4FF0,"bool", player)
end
-- PC:0xFA1E2BF8B10598F9 Old:0xED1D1662
function PLAYER.IS_PLAYER_PRESSING_HORN(player)
  return Velora.invoke(0xAA5030,"bool", player)
end
-- PC:0x8D32347D6D4C40A2 Old:0xD17AFCD8
function PLAYER.SET_PLAYER_CONTROL(player, bHasControl, flags)
  Velora.invoke(0xAA5070,"void", player, bHasControl, flags)
end
-- PC:0xE28E54788CE8F12D Old:0xBDCDD163
function PLAYER.GET_PLAYER_WANTED_LEVEL(player)
  return Velora.invoke(0xAA5090,"int", player)
end
-- PC:0xAA5F02DB48D704B9 Old:0x665A06F5
function PLAYER.SET_MAX_WANTED_LEVEL(maxWantedLevel)
  Velora.invoke(0xAA50E0,"void", maxWantedLevel)
end
-- PC:0x43286D561B72B8BF Old:0x8E114B10
function PLAYER.SET_POLICE_RADAR_BLIPS(toggle)
  Velora.invoke(0xAA5100,"void", toggle)
end
-- PC:0x32C62AA929C2DA6A Old:0xE6DE71B7
function PLAYER.SET_POLICE_IGNORE_PLAYER(player, toggle)
  Velora.invoke(0xAA5120,"void", player, toggle)
end
-- PC:0x5E9564D8246B909A Old:0xE15D777F
function PLAYER.IS_PLAYER_PLAYING(player)
  return Velora.invoke(0xAA5190,"bool", player)
end
-- PC:0x8EEDA153AD141BA4 Old:0xC915285E
function PLAYER.SET_EVERYONE_IGNORE_PLAYER(player, toggle)
  Velora.invoke(0xAA51D0,"void", player, toggle)
end
-- PC:0x056E0FE8534C2949 Old:0x49EAE968
function PLAYER.SET_ALL_RANDOM_PEDS_FLEE(player, toggle)
  Velora.invoke(0xAA5240,"void", player, toggle)
end
-- PC:0x471D2FF42A94B4F2 Old:0xBF974891
function PLAYER.SET_ALL_RANDOM_PEDS_FLEE_THIS_FRAME(player)
  Velora.invoke(0xAA5290,"void", player)
end
-- PC:0xDE45D1A1EF45EE61 Old:0x274631FE
function PLAYER.SET_ALL_NEUTRAL_RANDOM_PEDS_FLEE(player, toggle)
  Velora.invoke(0xAA52C0,"void", player, toggle)
end
-- PC:0xC3376F42B1FACCC6 Old:0x02DF7AF4
function PLAYER.SET_ALL_NEUTRAL_RANDOM_PEDS_FLEE_THIS_FRAME(player)
  Velora.invoke(0xAA5320,"void", player)
end
function PLAYER.SET_LAW_PEDS_CAN_ATTACK_NON_WANTED_PLAYER_THIS_FRAME(player)
  Velora.invoke(0xAA5350,"void", player)
end
-- PC:0x596976B02B6B5700 Old:0xA3D675ED
function PLAYER.SET_IGNORE_LOW_PRIORITY_SHOCKING_EVENTS(player, toggle)
  Velora.invoke(0xAA5380,"void", player, toggle)
end
-- PC:0x020E5F00CDA207BA Old:0x1359292F
function PLAYER.SET_WANTED_LEVEL_MULTIPLIER(multiplier)
  Velora.invoke(0xAA53D0,"void", multiplier)
end
-- PC:0x9B0BB33B04405E7A Old:0xB552626C
function PLAYER.SET_WANTED_LEVEL_DIFFICULTY(player, difficulty)
  Velora.invoke(0xAA5410,"void", player, difficulty)
end
-- PC:0xB9D0DD990DC141DD Old:0xA64C378D
function PLAYER.RESET_WANTED_LEVEL_DIFFICULTY(player)
  Velora.invoke(0xAA5460,"void", player)
end
function PLAYER.GET_WANTED_LEVEL_TIME_TO_ESCAPE()
  return Velora.invoke(0xAA54A0,"int")
end
function PLAYER.SET_WANTED_LEVEL_HIDDEN_ESCAPE_TIME(player, wantedLevel, lossTime)
  Velora.invoke(0xAA54C0,"void", player, wantedLevel, lossTime)
end
function PLAYER.RESET_WANTED_LEVEL_HIDDEN_ESCAPE_TIME(player)
  Velora.invoke(0xAA5510,"void", player)
end
-- PC:0xBF9BD71691857E48 Old:0x5F8A22A6
function PLAYER.START_FIRING_AMNESTY(duration)
  Velora.invoke(0xAA5550,"void", duration)
end
-- PC:0xE9B09589827545E7 Old:0xD8EB3A44
function PLAYER.REPORT_CRIME(player, crimeType, wantedLvlThresh)
  Velora.invoke(0xAA55B0,"void", player, crimeType, wantedLvlThresh)
end
-- PC:0x9A987297ED8BD838 Old:0x59B5C2A2
function PLAYER.SUPPRESS_CRIME_THIS_FRAME(player, crimeType)
  Velora.invoke(0xAA5670,"void", player, crimeType)
end
-- PC:0xBC9490CA15AEA8FB Old:0x6B34A160
function PLAYER.UPDATE_WANTED_POSITION_THIS_FRAME(player)
  Velora.invoke(0xAA56C0,"void", player)
end
-- PC:0x4669B3ED80F24B4E Old:0xB9FB142F
function PLAYER.SUPPRESS_LOSING_WANTED_LEVEL_IF_HIDDEN_THIS_FRAME(player)
  Velora.invoke(0xAA56F0,"void", player)
end
function PLAYER.ALLOW_EVASION_HUD_IF_DISABLING_HIDDEN_EVASION_THIS_FRAME(player, p1)
  Velora.invoke(0xAA5720,"void", player, p1)
end
-- PC:0xAD73CE5A09E42D12 Old:0x85725848
function PLAYER.FORCE_START_HIDDEN_EVASION(player)
  Velora.invoke(0xAA5790,"void", player)
end
-- PC:0x36F1B38855F2A8DF Old:0x3A7E5FB6
function PLAYER.SUPPRESS_WITNESSES_CALLING_POLICE_THIS_FRAME(player)
  Velora.invoke(0xAA57D0,"void", player)
end
-- PC:0xDC64D2C53493ED12 Old:0xD15C4B1C
function PLAYER.REPORT_POLICE_SPOTTED_PLAYER(player)
  Velora.invoke(0xAA5800,"void", player)
end
-- PC:0xB45EFF719D8427A6 Old:0xBF6993C7
function PLAYER.SET_LAW_RESPONSE_DELAY_OVERRIDE(p0)
  Velora.invoke(0xAA5890,"void", p0)
end
-- PC:0x0032A6DBA562C518 Old:0x47CAB814
function PLAYER.RESET_LAW_RESPONSE_DELAY_OVERRIDE()
  Velora.invoke(0xAA58B0,"void")
end
-- PC:0xDE7465A27D403C06 Old:0x39E3CB3F
function PLAYER.CAN_PLAYER_START_MISSION(player)
  return Velora.invoke(0xAA58C0,"bool", player)
end
-- PC:0x908CBECC2CAA3690 Old:0xBB77E9CD
function PLAYER.IS_PLAYER_READY_FOR_CUTSCENE(player)
  return Velora.invoke(0xAA5900,"bool", player)
end
-- PC:0x7912F7FC4F6264B6 Old:0xF3240B77
function PLAYER.IS_PLAYER_TARGETTING_ENTITY(player, entity)
  return Velora.invoke(0xAA5930,"bool", player, entity)
end
-- PC:0x13EDE1A5DBF797C9 Old:0xF6AAA2D7
function PLAYER.GET_PLAYER_TARGET_ENTITY(player)
  return Velora.invoke(0xAA59D0,"bool", player)
end
-- PC:0x2E397FD2ECD37C87 Old:0x1DEC67B7
function PLAYER.IS_PLAYER_FREE_AIMING(player)
  return Velora.invoke(0xAA5A30,"bool", player)
end
-- PC:0x3C06B5C839B38F7B Old:0x7D80EEAA
function PLAYER.IS_PLAYER_FREE_AIMING_AT_ENTITY(player, entity)
  return Velora.invoke(0xAA5A80,"bool", player, entity)
end
-- PC:0x2975C866E6713290 Old:0x8866D9D0
function PLAYER.GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(player)
  return Velora.invoke(0xAA5B30,"bool", player)
end
-- PC:0x29961D490E5814FD Old:0x74D42C03
function PLAYER.SET_PLAYER_LOCKON_RANGE_OVERRIDE(player, range)
  Velora.invoke(0xAA5BA0,"void", player, range)
end
-- PC:0x6E8834B52EC20C77 Old:0xF4D99685
function PLAYER.SET_PLAYER_CAN_DO_DRIVE_BY(player, toggle)
  Velora.invoke(0xAA5BF0,"void", player, toggle)
end
-- PC:0xD5E460AD7020A246 Old:0x71B305BB
function PLAYER.SET_PLAYER_CAN_BE_HASSLED_BY_GANGS(player, toggle)
  Velora.invoke(0xAA5C40,"void", player, toggle)
end
-- PC:0xD465A8599DFF6814 Old:0x13CAFAFA
function PLAYER.SET_PLAYER_CAN_USE_COVER(player, toggle)
  Velora.invoke(0xAA5C90,"void", player, toggle)
end
-- PC:0x462E0DB9B137DC5F Old:0x457F1E44
function PLAYER.GET_MAX_WANTED_LEVEL()
  return Velora.invoke(0xAA5CE0,"int")
end
-- PC:0x78CFE51896B6B8A4 Old:0x456DB50D
function PLAYER.IS_PLAYER_TARGETTING_ANYTHING(player)
  return Velora.invoke(0xAA5CF0,"bool", player)
end
-- PC:0xA01B8075D8B92DF4 Old:0x7DD7900C
function PLAYER.SET_PLAYER_SPRINT(player, toggle)
  Velora.invoke(0xAA5D40,"void", player, toggle)
end
-- PC:0xA6F312FCCE9C1DFE Old:0xC0445A9C
function PLAYER.RESET_PLAYER_STAMINA(player)
  Velora.invoke(0xAA5D90,"void", player)
end
-- PC:0xA352C1B864CAFD33 Old:0x62A93608
function PLAYER.RESTORE_PLAYER_STAMINA(player, p1)
  Velora.invoke(0xAA5DC0,"void", player, p1)
end
-- PC:0x3F9F16F8E65A7ED7 Old:0x47017C90
function PLAYER.GET_PLAYER_SPRINT_STAMINA_REMAINING(player)
  return Velora.invoke(0xAA5E20,"float", player)
end
-- PC:0x1885BC9B108B4C99 Old:0x40E80543
function PLAYER.GET_PLAYER_SPRINT_TIME_REMAINING(player)
  return Velora.invoke(0xAA5E70,"float", player)
end
-- PC:0xA1FCF8E6AF40B731 Old:0x1317125A
function PLAYER.GET_PLAYER_UNDERWATER_TIME_REMAINING(player)
  return Velora.invoke(0xAA5EE0,"float", player)
end
function PLAYER.SET_PLAYER_UNDERWATER_BREATH_PERCENT_REMAINING(player, time)
  return Velora.invoke(0xAA5F40,"float", player, time)
end
-- PC:0x0D127585F77030AF Old:0xA5EDCDE8
function PLAYER.GET_PLAYER_GROUP(player)
  return Velora.invoke(0xAA5FB0,"int", player)
end
-- PC:0x92659B4CE1863CB3 Old:0x02A50657
function PLAYER.GET_PLAYER_MAX_ARMOUR(player)
  return Velora.invoke(0xAA5FD0,"int", player)
end
-- PC:0x49C32D60007AFA47 Old:0x618857F2
function PLAYER.IS_PLAYER_CONTROL_ON(player)
  return Velora.invoke(0xAA6010,"bool", player)
end
function PLAYER.GET_ARE_CAMERA_CONTROLS_DISABLED()
  return Velora.invoke(0xAA6070,"bool")
end
-- PC:0x8A876A65283DD7D7 Old:0x61B00A84
function PLAYER.IS_PLAYER_SCRIPT_CONTROL_ON(player)
  return Velora.invoke(0xAA60B0,"bool", player)
end
-- PC:0x95E8F73DC65EFB9C Old:0x4A9E9AE0
function PLAYER.IS_PLAYER_CLIMBING(player)
  return Velora.invoke(0xAA6100,"bool", player)
end
-- PC:0x388A47C51ABDAC8E Old:0x7F6A60D3
function PLAYER.IS_PLAYER_BEING_ARRESTED(player, atArresting)
  return Velora.invoke(0xAA6140,"bool", player, atArresting)
end
-- PC:0x2D03E13C460760D6 Old:0x453C7CAB
function PLAYER.RESET_PLAYER_ARREST_STATE(player)
  Velora.invoke(0xAA61D0,"void", player)
end
-- PC:0xB6997A7EB3F5C8C0 Old:0xE2757AC1
function PLAYER.GET_PLAYERS_LAST_VEHICLE()
  return Velora.invoke(0xAA6200,"int")
end
-- PC:0xA5EDC40EF369B48D Old:0x309BBDC1
function PLAYER.GET_PLAYER_INDEX()
  return Velora.invoke(0xAA6230,"int")
end
-- PC:0x41BD2A6B006AF756 Old:0x98DD98F1
function PLAYER.INT_TO_PLAYERINDEX(value)
  return Velora.invoke(0xAA6270,"int", value)
end
-- PC:0x9EC6603812C24710 Old:0x98F3B274
function PLAYER.INT_TO_PARTICIPANTINDEX(value)
  return Velora.invoke(0xAA6280,"int", value)
end
-- PC:0x5D35ECF3A81A0EE0 Old:0x6E9B8B9E
function PLAYER.GET_TIME_SINCE_PLAYER_HIT_VEHICLE(player)
  return Velora.invoke(0xAA6290,"int", player)
end
-- PC:0xE36A25322DC35F42 Old:0xB6209195
function PLAYER.GET_TIME_SINCE_PLAYER_HIT_PED(player)
  return Velora.invoke(0xAA62D0,"int", player)
end
-- PC:0xD559D2BE9E37853B Old:0x8836E732
function PLAYER.GET_TIME_SINCE_PLAYER_DROVE_ON_PAVEMENT(player)
  return Velora.invoke(0xAA6310,"int", player)
end
-- PC:0xDB89591E290D9182 Old:0x9F27D00E
function PLAYER.GET_TIME_SINCE_PLAYER_DROVE_AGAINST_TRAFFIC(player)
  return Velora.invoke(0xAA6350,"int", player)
end
-- PC:0xDCCFD3F106C36AB4 Old:0x85C7E232
function PLAYER.IS_PLAYER_FREE_FOR_AMBIENT_TASK(player)
  return Velora.invoke(0xAA6390,"bool", player)
end
-- PC:0x4F8644AF03D0E0D6 Old:0x8AEA886C
function PLAYER.PLAYER_ID()
  return Velora.invoke(0xAA63C0,"int")
end
-- PC:0xD80958FC74E988A6 Old:0xFA92E226
function PLAYER.PLAYER_PED_ID()
  return Velora.invoke(0xAA6400,"int")
end
-- PC:0xEE68096F9F37341E Old:0x8DD5B838
function PLAYER.NETWORK_PLAYER_ID_TO_INT()
  return Velora.invoke(0xAA6440,"int")
end
-- PC:0xC968670BFACE42D9 Old:0x4B37333C
function PLAYER.HAS_FORCE_CLEANUP_OCCURRED(cleanupFlags)
  return Velora.invoke(0xAA6480,"bool", cleanupFlags)
end
-- PC:0xBC8983F38F78ED51 Old:0xFDAAEA2B
function PLAYER.FORCE_CLEANUP(cleanupFlags)
  Velora.invoke(0xAA64C0,"void", cleanupFlags)
end
-- PC:0x4C68DDDDF0097317 Old:0x04256C73
function PLAYER.FORCE_CLEANUP_FOR_ALL_THREADS_WITH_THIS_NAME(name, cleanupFlags)
  Velora.invoke(0xAA6500,"void", name, cleanupFlags)
end
-- PC:0xF745B37630DF176B Old:0x882D3EB3
function PLAYER.FORCE_CLEANUP_FOR_THREAD_WITH_THIS_ID(id, cleanupFlags)
  Velora.invoke(0xAA6530,"void", id, cleanupFlags)
end
-- PC:0x9A41CF4674A12272 Old:0x39AA9FC8
function PLAYER.GET_CAUSE_OF_MOST_RECENT_FORCE_CLEANUP()
  return Velora.invoke(0xAA6570,"int")
end
-- PC:0x8026FF78F208978A Old:0xA454DD29
function PLAYER.SET_PLAYER_MAY_ONLY_ENTER_THIS_VEHICLE(player, vehicle)
  Velora.invoke(0xAA65A0,"void", player, vehicle)
end
-- PC:0x1DE37BBF9E9CC14A Old:0xAF7AFCC4
function PLAYER.SET_PLAYER_MAY_NOT_ENTER_ANY_VEHICLE(player)
  Velora.invoke(0xAA65B0,"void", player)
end
-- PC:0xBEC7076D64130195 Old:0x822BC992
function PLAYER.GIVE_ACHIEVEMENT_TO_PLAYER(achievementId)
  return Velora.invoke(0xAA65F0,"bool", achievementId)
end
function PLAYER.SET_ACHIEVEMENT_PROGRESS(achievementId, progress)
  return Velora.invoke(0xAA6620,"bool", achievementId, progress)
end
function PLAYER.GET_ACHIEVEMENT_PROGRESS(achievementId)
  return Velora.invoke(0xAA6650,"int", achievementId)
end
-- PC:0x867365E111A3B6EB Old:0x136A5BE9
function PLAYER.HAS_ACHIEVEMENT_BEEN_PASSED(achievementId)
  return Velora.invoke(0xAA6680,"bool", achievementId)
end
-- PC:0xF25D331DC2627BBC Old:0x9FAB6729
function PLAYER.IS_PLAYER_ONLINE()
  return Velora.invoke(0xAA66B0,"bool")
end
-- PC:0x74556E1420867ECA Old:0x8F72FAD0
function PLAYER.IS_PLAYER_LOGGING_IN_NP()
  return Velora.invoke(0xAA66E0,"bool")
end
-- PC:0x94DD7888C10A979E Old:0x4264CED2
function PLAYER.DISPLAY_SYSTEM_SIGNIN_UI(p0)
  Velora.invoke(0xAA66F0,"void", p0)
end
-- PC:0x5D511E3867C87139 Old:0xE495B6DA
function PLAYER.IS_SYSTEM_UI_BEING_DISPLAYED()
  return Velora.invoke(0xAA6700,"bool")
end
-- PC:0x239528EACDC3E7DE Old:0xDFB9A2A2
function PLAYER.SET_PLAYER_INVINCIBLE(player, toggle)
  Velora.invoke(0xAA6720,"void", player, toggle)
end
-- PC:0xB721981B2B939E07 Old:0x680C90EE
function PLAYER.GET_PLAYER_INVINCIBLE(player)
  return Velora.invoke(0xAA67A0,"bool", player)
end
function PLAYER.GET_PLAYER_DEBUG_INVINCIBLE(player)
  return Velora.invoke(0xAA67E0,"bool", player)
end
function PLAYER.SET_PLAYER_INVINCIBLE_BUT_HAS_REACTIONS(player, toggle)
  Velora.invoke(0xAA67F0,"void", player, toggle)
end
-- PC:0xCAC57395B151135F Old:0x00563E0D
function PLAYER.SET_PLAYER_CAN_COLLECT_DROPPED_MONEY(player, p1)
  Velora.invoke(0xAA6860,"void", player, p1)
end
-- PC:0xF3AC26D3CC576528 Old:0x6255F3B4
function PLAYER.REMOVE_PLAYER_HELMET(player, p2)
  Velora.invoke(0xAA68B0,"void", player, p2)
end
-- PC:0x3C49C870E66F0A28 Old:0xC7B4D7AC
function PLAYER.GIVE_PLAYER_RAGDOLL_CONTROL(player, toggle)
  Velora.invoke(0xAA6900,"void", player, toggle)
end
-- PC:0x5C8B2F450EE4328E Old:0x0B270E0F
function PLAYER.SET_PLAYER_LOCKON(player, toggle)
  Velora.invoke(0xAA6960,"void", player, toggle)
end
-- PC:0xB1906895227793F3 Old:0x61CAE253
function PLAYER.SET_PLAYER_TARGETING_MODE(targetMode)
  Velora.invoke(0xAA69A0,"void", targetMode)
end
-- PC:0x5702B917B99DB1CD Old:0x772DA539
function PLAYER.SET_PLAYER_TARGET_LEVEL(targetLevel)
  Velora.invoke(0xAA6A10,"void", targetLevel)
end
function PLAYER.GET_IS_USING_FPS_THIRD_PERSON_COVER()
  return Velora.invoke(0xAA6A20,"bool")
end
function PLAYER.GET_IS_USING_HOOD_CAMERA()
  return Velora.invoke(0xDEADBEEF,"bool")
end
-- PC:0xF0B67A4DE6AB5F98 Old:0x1D31CBBD
function PLAYER.CLEAR_PLAYER_HAS_DAMAGED_AT_LEAST_ONE_PED(player)
  Velora.invoke(0xAA6A40,"void", player)
end
-- PC:0x20CE80B0C2BF4ACC Old:0x14F52453
function PLAYER.HAS_PLAYER_DAMAGED_AT_LEAST_ONE_PED(player)
  return Velora.invoke(0xAA6A70,"bool", player)
end
-- PC:0x4AACB96203D11A31 Old:0x7E3BFBC5
function PLAYER.CLEAR_PLAYER_HAS_DAMAGED_AT_LEAST_ONE_NON_ANIMAL_PED(player)
  Velora.invoke(0xAA6AC0,"void", player)
end
-- PC:0xE4B90F367BD81752 Old:0xA3707DFC
function PLAYER.HAS_PLAYER_DAMAGED_AT_LEAST_ONE_NON_ANIMAL_PED(player)
  return Velora.invoke(0xAA6AF0,"bool", player)
end
-- PC:0xCA7DC8329F0A1E9E Old:0xF20F72E5
function PLAYER.SET_AIR_DRAG_MULTIPLIER_FOR_PLAYERS_VEHICLE(player, multiplier)
  Velora.invoke(0xAA6B40,"void", player, multiplier)
end
-- PC:0xA91C6F0FF7D16A13 Old:0xB986FF47
function PLAYER.SET_SWIM_MULTIPLIER_FOR_PLAYER(player, multiplier)
  Velora.invoke(0xAA6BA0,"void", player, multiplier)
end
-- PC:0x6DB47AA77FD94E09 Old:0x825423C2
function PLAYER.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(player, multiplier)
  Velora.invoke(0xAA6C00,"void", player, multiplier)
end
-- PC:0x5063F92F07C2A316 Old:0x62824EF4
function PLAYER.GET_TIME_SINCE_LAST_ARREST()
  return Velora.invoke(0xAA6C60,"int")
end
-- PC:0xC7034807558DDFCA Old:0x24BC5AC0
function PLAYER.GET_TIME_SINCE_LAST_DEATH()
  return Velora.invoke(0xAA6C90,"int")
end
-- PC:0xAEBF081FFC0A0E5E Old:0xF23277F3
function PLAYER.ASSISTED_MOVEMENT_CLOSE_ROUTE()
  Velora.invoke(0xAA6CC0,"void")
end
-- PC:0x8621390F0CDCFE1F Old:0xD04568B9
function PLAYER.ASSISTED_MOVEMENT_FLUSH_ROUTE()
  Velora.invoke(0xAA6D10,"void")
end
-- PC:0x0FEE4F80AC44A726 Old:0x94E42E2E
function PLAYER.SET_PLAYER_FORCED_AIM(player, toggle)
  Velora.invoke(0xAA6D40,"void", player, toggle)
end
-- PC:0x75E7D505F2B15902 Old:0xB0C576CB
function PLAYER.SET_PLAYER_FORCED_ZOOM(player, toggle)
  Velora.invoke(0xAA6D80,"void", player, toggle)
end
-- PC:0x7651BC64AE59E128 Old:0x374F42F0
function PLAYER.SET_PLAYER_FORCE_SKIP_AIM_INTRO(player, toggle)
  Velora.invoke(0xAA6DD0,"void", player, toggle)
end
-- PC:0x5E6CC07646BBEAB8 Old:0x30CB28CB
function PLAYER.DISABLE_PLAYER_FIRING(player, toggle)
  Velora.invoke(0xAA6E20,"void", player, toggle)
end
function PLAYER.DISABLE_PLAYER_THROW_GRENADE_WHILE_USING_GUN()
  Velora.invoke(0xAA6EB0,"void")
end
-- PC:0x2E8AABFA40A84F8C Old:0xCCD937E7
function PLAYER.SET_DISABLE_AMBIENT_MELEE_MOVE(player, toggle)
  Velora.invoke(0xAA6ED0,"void", player, toggle)
end
-- PC:0x77DFCCF5948B8C71 Old:0xC6C3C53B
function PLAYER.SET_PLAYER_MAX_ARMOUR(player, value)
  Velora.invoke(0xAA6F20,"void", player, value)
end
function PLAYER.SPECIAL_ABILITY_ACTIVATE(player, p1)
  Velora.invoke(0xAA6F60,"void", player, p1)
end
function PLAYER.SET_SPECIAL_ABILITY_MP(player, p1, p2)
  Velora.invoke(0xAA6FC0,"void", player, p1, p2)
end
function PLAYER.SPECIAL_ABILITY_DEACTIVATE_MP(player, p1)
  Velora.invoke(0xAA7030,"void", player, p1)
end
-- PC:0xD6A953C6D1492057 Old:0x80C2AB09
function PLAYER.SPECIAL_ABILITY_DEACTIVATE(player, p1)
  Velora.invoke(0xAA7040,"void", player, p1)
end
-- PC:0x9CB5CE07A3968D5A Old:0x0751908A
function PLAYER.SPECIAL_ABILITY_DEACTIVATE_FAST(player, p1)
  Velora.invoke(0xAA70A0,"void", player, p1)
end
-- PC:0x375F0E738F861A94 Old:0xA7D8BCD3
function PLAYER.SPECIAL_ABILITY_RESET(player, p1)
  Velora.invoke(0xAA7110,"void", player, p1)
end
-- PC:0xC9A763D8FE87436A Old:0x4136829A
function PLAYER.SPECIAL_ABILITY_CHARGE_ON_MISSION_FAILED(player, p1)
  Velora.invoke(0xAA7170,"void", player, p1)
end
-- PC:0x2E7B9B683481687D Old:0x6F463F56
function PLAYER.SPECIAL_ABILITY_CHARGE_SMALL(player, p1, p2, p3)
  Velora.invoke(0xAA71D0,"void", player, p1, p2, p3)
end
-- PC:0xF113E3AA9BC54613 Old:0xAB55D8F3
function PLAYER.SPECIAL_ABILITY_CHARGE_MEDIUM(player, p1, p2, p3)
  Velora.invoke(0xAA7200,"void", player, p1, p2, p3)
end
-- PC:0xF733F45FA4497D93 Old:0xF440C04D
function PLAYER.SPECIAL_ABILITY_CHARGE_LARGE(player, p1, p2, p3)
  Velora.invoke(0xAA7230,"void", player, p1, p2, p3)
end
-- PC:0xED481732DFF7E997 Old:0x5FEE98A2
function PLAYER.SPECIAL_ABILITY_CHARGE_CONTINUOUS(player, p1, p2)
  Velora.invoke(0xAA7260,"void", player, p1, p2)
end
-- PC:0xB7B0870EB531D08D Old:0x72429998
function PLAYER.SPECIAL_ABILITY_CHARGE_ABSOLUTE(player, p1, p2, p3)
  Velora.invoke(0xAA72E0,"void", player, p1, p2, p3)
end
-- PC:0xA0696A65F009EE18 Old:0x8C7E68C1
function PLAYER.SPECIAL_ABILITY_CHARGE_NORMALIZED(player, normalizedValue, p2, p3)
  Velora.invoke(0xAA7360,"void", player, normalizedValue, p2, p3)
end
-- PC:0x3DACA8DDC6FD4980 Old:0xB71589DA
function PLAYER.SPECIAL_ABILITY_FILL_METER(player, p1, p2)
  Velora.invoke(0xAA73F0,"void", player, p1, p2)
end
-- PC:0x1D506DBBBC51E64B Old:0x9F80F6DF
function PLAYER.SPECIAL_ABILITY_DEPLETE_METER(player, p1, p2)
  Velora.invoke(0xAA7470,"void", player, p1, p2)
end
-- PC:0x6A09D0D590A47D13 Old:0x1B7BB388
function PLAYER.SPECIAL_ABILITY_LOCK(playerModel, p1)
  Velora.invoke(0xAA74F0,"void", playerModel, p1)
end
-- PC:0xF145F3BE2EFA9A3B Old:0x1FDB2919
function PLAYER.SPECIAL_ABILITY_UNLOCK(playerModel, p1)
  Velora.invoke(0xAA7510,"void", playerModel, p1)
end
-- PC:0xC6017F6A6CDFA694 Old:0xC9C75E82
function PLAYER.IS_SPECIAL_ABILITY_UNLOCKED(playerModel)
  return Velora.invoke(0xAA7530,"bool", playerModel)
end
-- PC:0x3E5F7FC85D854E15 Old:0x1B17E334
function PLAYER.IS_SPECIAL_ABILITY_ACTIVE(player, p1)
  return Velora.invoke(0xAA7560,"bool", player, p1)
end
-- PC:0x05A1FE504B7F2587 Old:0x2E19D7F6
function PLAYER.IS_SPECIAL_ABILITY_METER_FULL(player, p1)
  return Velora.invoke(0xAA75D0,"bool", player, p1)
end
-- PC:0x181EC197DAEFE121 Old:0xC86C1B4E
function PLAYER.ENABLE_SPECIAL_ABILITY(player, toggle, p2)
  Velora.invoke(0xAA7640,"void", player, toggle, p2)
end
-- PC:0xB1D200FE26AEF3CB Old:0xC01238CC
function PLAYER.IS_SPECIAL_ABILITY_ENABLED(player, p1)
  return Velora.invoke(0xAA76B0,"bool", player, p1)
end
-- PC:0xA49C426ED0CA4AB7 Old:0xFF1BC556
function PLAYER.SET_SPECIAL_ABILITY_MULTIPLIER(multiplier)
  Velora.invoke(0xAA7720,"void", multiplier)
end
-- PC:0xFFEE8FA29AB9A18E Old:0x5D0FE25B
function PLAYER.UPDATE_SPECIAL_ABILITY_FROM_STAT(player, p1)
  Velora.invoke(0xAA7740,"void", player, p1)
end
-- PC:0x5FC472C501CCADB3 Old:0x46E7E31D
function PLAYER.GET_IS_PLAYER_DRIVING_ON_HIGHWAY(player)
  return Velora.invoke(0xAA77A0,"bool", player)
end
-- PC:0xF10B44FD479D69F3 Old:0x1E359CC8
function PLAYER.GET_IS_PLAYER_DRIVING_WRECKLESS(player, p1)
  return Velora.invoke(0xAA7820,"bool", player, p1)
end
-- PC:0xDD2620B7B9D16FF1 Old:0x8CB53C9F
function PLAYER.GET_IS_MOPPING_AREA_FREE_IN_FRONT_OF_PLAYER(player, p1)
  return Velora.invoke(0xAA78C0,"bool", player, p1)
end
-- PC:0xAD15F075A4DA0FDE Old:0xC552E06C
function PLAYER.START_PLAYER_TELEPORT(player, x, y, z, heading, p5, findCollisionLand, p7)
  Velora.invoke(0xAA78F0,"void", player, x, y, z, heading, p5, findCollisionLand, p7)
end
function PLAYER.UPDATE_PLAYER_TELEPORT(player)
  return Velora.invoke(0xAA7930,"bool", player)
end
-- PC:0xC449EDED9D73009C Old:0x86AB8DBB
function PLAYER.STOP_PLAYER_TELEPORT()
  Velora.invoke(0xAA7980,"void")
end
-- PC:0x02B15662D7F8886F Old:0x3A11D118
function PLAYER.IS_PLAYER_TELEPORT_ACTIVE()
  return Velora.invoke(0xAA7990,"bool")
end
-- PC:0x2F395D61F3A1F877 Old:0xC3B02362
function PLAYER.GET_PLAYER_CURRENT_STEALTH_NOISE(player)
  return Velora.invoke(0xAA79B0,"float", player)
end
-- PC:0x5DB660B38DD98A31 Old:0x45514731
function PLAYER.SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER(player, regenRate)
  Velora.invoke(0xAA7A00,"void", player, regenRate)
end
function PLAYER.GET_PLAYER_HEALTH_RECHARGE_MAX_PERCENT(player)
  return Velora.invoke(0xAA7A50,"float", player)
end
function PLAYER.SET_PLAYER_HEALTH_RECHARGE_MAX_PERCENT(player, limit)
  Velora.invoke(0xAA7AA0,"void", player, limit)
end
function PLAYER.DISABLE_PLAYER_HEALTH_RECHARGE(player)
  Velora.invoke(0xAA7B00,"void", player)
end
function PLAYER.SET_PLAYER_FALL_DISTANCE_TO_TRIGGER_RAGDOLL_OVERRIDE(player, p1)
  Velora.invoke(0xAA7B30,"void", player, p1)
end
-- PC:0xCE07B9F7817AADA3 Old:0xB02C2F39
function PLAYER.SET_PLAYER_WEAPON_DAMAGE_MODIFIER(player, modifier)
  Velora.invoke(0xAA7B80,"void", player, modifier)
end
-- PC:0x2D83BC011CA14A3C Old:0xAE446344
function PLAYER.SET_PLAYER_WEAPON_DEFENSE_MODIFIER(player, modifier)
  Velora.invoke(0xAA7BD0,"void", player, modifier)
end
function PLAYER.SET_PLAYER_WEAPON_MINIGUN_DEFENSE_MODIFIER(player, modifier)
  Velora.invoke(0xAA7C20,"void", player, modifier)
end
-- PC:0x4A3DC7ECCC321032 Old:0x362E69AD
function PLAYER.SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(player, modifier, p2)
  Velora.invoke(0xAA7C70,"void", player, modifier, p2)
end
-- PC:0xAE540335B4ABC4E2 Old:0x9F3D577F
function PLAYER.SET_PLAYER_MELEE_WEAPON_DEFENSE_MODIFIER(player, modifier)
  Velora.invoke(0xAA7CD0,"void", player, modifier)
end
-- PC:0xA50E117CDDF82F0C Old:0x823ECA63
function PLAYER.SET_PLAYER_VEHICLE_DAMAGE_MODIFIER(player, modifier)
  Velora.invoke(0xAA7D20,"void", player, modifier)
end
-- PC:0x4C60E6EFDAFF2462 Old:0xA16626C7
function PLAYER.SET_PLAYER_VEHICLE_DEFENSE_MODIFIER(player, modifier)
  Velora.invoke(0xAA7D70,"void", player, modifier)
end
function PLAYER.SET_PLAYER_MAX_EXPLOSIVE_DAMAGE(player, p1)
  Velora.invoke(0xAA7DC0,"void", player, p1)
end
function PLAYER.SET_PLAYER_EXPLOSIVE_DAMAGE_MODIFIER(player, p1)
  Velora.invoke(0xAA7E10,"void", player, p1)
end
function PLAYER.SET_PLAYER_WEAPON_TAKEDOWN_DEFENSE_MODIFIER(player, p1)
  Velora.invoke(0xAA7E60,"void", player, p1)
end
-- PC:0xA3D0E54541D9A5E5 Old:0x8EA12EDB
function PLAYER.SET_PLAYER_PARACHUTE_TINT_INDEX(player, tintIndex)
  Velora.invoke(0xAA7EB0,"void", player, tintIndex)
end
-- PC:0x75D3F7A1B0D9B145 Old:0x432B0509
function PLAYER.GET_PLAYER_PARACHUTE_TINT_INDEX(player)
  Velora.invoke(0xAA7EF0,"void", player)
end
-- PC:0xAF04C87F5DC1DF38 Old:0x70689638
function PLAYER.SET_PLAYER_RESERVE_PARACHUTE_TINT_INDEX(player, index)
  Velora.invoke(0xAA7F30,"void", player, index)
end
-- PC:0xD5A016BC3C09CF40 Old:0x77B8EF01
function PLAYER.GET_PLAYER_RESERVE_PARACHUTE_TINT_INDEX(player)
  Velora.invoke(0xAA7F70,"void", player)
end
-- PC:0x93B0FB27C9A04060 Old:0xD79D5D1B
function PLAYER.SET_PLAYER_PARACHUTE_PACK_TINT_INDEX(player, tintIndex)
  Velora.invoke(0xAA7FB0,"void", player, tintIndex)
end
-- PC:0x6E9C742F340CE5A2 Old:0x4E418E13
function PLAYER.GET_PLAYER_PARACHUTE_PACK_TINT_INDEX(player)
  Velora.invoke(0xAA7FF0,"void", player)
end
-- PC:0x7DDAB28D31FAC363 Old:0xA3E4798E
function PLAYER.SET_PLAYER_HAS_RESERVE_PARACHUTE(player)
  Velora.invoke(0xAA8030,"void", player)
end
-- PC:0x5DDFE2FF727F3CA3 Old:0x30DA1DA1
function PLAYER.GET_PLAYER_HAS_RESERVE_PARACHUTE(player)
  return Velora.invoke(0xAA8060,"bool", player)
end
-- PC:0xF401B182DBA8AF53 Old:0x832DEB7A
function PLAYER.SET_PLAYER_CAN_LEAVE_PARACHUTE_SMOKE_TRAIL(player, enabled)
  Velora.invoke(0xAA80A0,"void", player, enabled)
end
-- PC:0x8217FD371A4625CF Old:0x14FE9264
function PLAYER.SET_PLAYER_PARACHUTE_SMOKE_TRAIL_COLOR(player, r, g, b)
  Velora.invoke(0xAA80F0,"void", player, r, g, b)
end
-- PC:0xEF56DBABD3CD4887 Old:0xF66E5CDD
function PLAYER.GET_PLAYER_PARACHUTE_SMOKE_TRAIL_COLOR(player)
  Velora.invoke(0xAA81A0,"void", player)
end
function PLAYER.SET_PLAYER_PHONE_PALETTE_IDX(player, flags)
  Velora.invoke(0xAA8210,"void", player, flags)
end
-- PC:0xDB89EF50FF25FCE9 Old:0x15786DD1
function PLAYER.SET_PLAYER_NOISE_MULTIPLIER(player, multiplier)
  Velora.invoke(0xAA8240,"void", player, multiplier)
end
-- PC:0xB2C1A29588A9F47C Old:0x8D2D89C4
function PLAYER.SET_PLAYER_SNEAKING_NOISE_MULTIPLIER(player, multiplier)
  Velora.invoke(0xAA8290,"void", player, multiplier)
end
-- PC:0xF297383AA91DCA29 Old:0x1C70B2EB
function PLAYER.CAN_PED_HEAR_PLAYER(player, ped)
  return Velora.invoke(0xAA82E0,"bool", player, ped)
end
-- PC:0x477D5D63E63ECA5D Old:0x0D77CC34
function PLAYER.SIMULATE_PLAYER_INPUT_GAIT(player, amount, gaitType, speed, p4, p5)
  Velora.invoke(0xAA8390,"void", player, amount, gaitType, speed, p4, p5)
end
-- PC:0x19531C47A2ABD691 Old:0x4A701EE1
function PLAYER.RESET_PLAYER_INPUT_GAIT(player)
  Velora.invoke(0xAA8440,"void", player)
end
-- PC:0x9F343285A00B4BB6 Old:0xA97C2059
function PLAYER.SET_AUTO_GIVE_PARACHUTE_WHEN_ENTER_PLANE(player, toggle)
  Velora.invoke(0xAA8480,"void", player, toggle)
end
-- PC:0xD2B315B6689D537D Old:0xA25D767E
function PLAYER.SET_AUTO_GIVE_SCUBA_GEAR_WHEN_EXIT_VEHICLE(player, toggle)
  Velora.invoke(0xAA84D0,"void", player, toggle)
end
-- PC:0x4E9021C1FCDD507A Old:0x3D26105F
function PLAYER.SET_PLAYER_STEALTH_PERCEPTION_MODIFIER(player, value)
  Velora.invoke(0xAA8520,"void", player, value)
end
-- PC:0x690A61A6D13583F6 Old:0x1D371529
function PLAYER.IS_REMOTE_PLAYER_IN_NON_CLONED_VEHICLE(player)
  return Velora.invoke(0xAA8580,"bool", player)
end
-- PC:0x9EDD76E87D5D51BA Old:0xE30A64DC
function PLAYER.INCREASE_PLAYER_JUMP_SUPPRESSION_RANGE(player)
  Velora.invoke(0xAA85C0,"void", player)
end
-- PC:0xC54C95DA968EC5B5 Old:0xF1E0CAFC
function PLAYER.SET_PLAYER_SIMULATE_AIMING(player, toggle)
  Velora.invoke(0xAA85F0,"void", player, toggle)
end
-- PC:0x749FADDF97DFE930 Old:0xF7A0F00F
function PLAYER.SET_PLAYER_CLOTH_PIN_FRAMES(player, p1)
  Velora.invoke(0xAA8630,"void", player, p1)
end
-- PC:0x9F7BBA2EA6372500 Old:0xB8209F16
function PLAYER.SET_PLAYER_CLOTH_PACKAGE_INDEX(index)
  Velora.invoke(0xAA8670,"void", index)
end
-- PC:0x14D913B777DFF5DA Old:0x8D9FD4D1
function PLAYER.SET_PLAYER_CLOTH_LOCK_COUNTER(value)
  Velora.invoke(0xAA86A0,"void", value)
end
-- PC:0xED51733DC73AED51 Old:0xECD12E60
function PLAYER.PLAYER_ATTACH_VIRTUAL_BOUND(p0, p1, p2, p3, p4, p5, p6, p7)
  Velora.invoke(0xAA86D0,"void", p0, p1, p2, p3, p4, p5, p6, p7)
end
-- PC:0x1DD5897E2FA6E7C9 Old:0x96100EA4
function PLAYER.PLAYER_DETACH_VIRTUAL_BOUND()
  Velora.invoke(0xAA86F0,"void")
end
-- PC:0xD705740BB0A1CF4C Old:0x4A01B76A
function PLAYER.HAS_PLAYER_BEEN_SPOTTED_IN_STOLEN_VEHICLE(player)
  return Velora.invoke(0xAA8750,"bool", player)
end
-- PC:0x38D28DA81E4E9BF9 Old:0x013B4F72
function PLAYER.IS_PLAYER_BATTLE_AWARE(player)
  return Velora.invoke(0xAA87A0,"bool", player)
end
-- PC:0xBC0753C9CA14B506 Old:0x9DF75B2A
function PLAYER.GET_PLAYER_RECEIVED_BATTLE_EVENT_RECENTLY(player, p1, p2)
  return Velora.invoke(0xAA8820,"bool", player, p1, p2)
end
-- PC:0x5006D96C995A5827 Old:0x64DDB07D
function PLAYER.EXTEND_WORLD_BOUNDARY_FOR_PLAYER(x, y, z)
  Velora.invoke(0xAA8890,"void", x, y, z)
end
-- PC:0xDA1DF03D5A315F4E Old:0xA97C2F6C
function PLAYER.RESET_WORLD_BOUNDARY_FOR_PLAYER()
  Velora.invoke(0xAA88F0,"void")
end
-- PC:0x4EC12697209F2196 Old:0x9765E71D
function PLAYER.IS_PLAYER_RIDING_TRAIN(player)
  return Velora.invoke(0xAA8950,"bool", player)
end
-- PC:0xD55DDFB47991A294 Old:0xFEA40B6C
function PLAYER.HAS_PLAYER_LEFT_THE_WORLD(player)
  return Velora.invoke(0xAA89B0,"bool", player)
end
-- PC:0xFF300C7649724A0B Old:0xAD8383FA
function PLAYER.SET_PLAYER_LEAVE_PED_BEHIND(player, toggle)
  Velora.invoke(0xAA8A00,"void", player, toggle)
end
-- PC:0xD9284A8C0D48352C Old:0x9254249D
function PLAYER.SET_PLAYER_PARACHUTE_VARIATION_OVERRIDE(player, p1, p2, p3, p4)
  Velora.invoke(0xAA8A50,"void", player, p1, p2, p3, p4)
end
-- PC:0x0F4CC924CF8C7B21 Old:0xFD60F5AB
function PLAYER.CLEAR_PLAYER_PARACHUTE_VARIATION_OVERRIDE(player)
  Velora.invoke(0xAA8AC0,"void", player)
end
-- PC:0x977DB4641F6FC3DB Old:0x5D382498
function PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(player, model)
  Velora.invoke(0xAA8AF0,"void", player, model)
end
function PLAYER.SET_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player, model)
  Velora.invoke(0xAA8B30,"void", player, model)
end
function PLAYER.GET_PLAYER_PARACHUTE_MODEL_OVERRIDE(player)
  return Velora.invoke(0xAA8B70,"int", player)
end
function PLAYER.GET_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player)
  return Velora.invoke(0xAA8BB0,"int", player)
end
-- PC:0x8753997EB5F6EE3F Old:0x6FF034BB
function PLAYER.CLEAR_PLAYER_PARACHUTE_MODEL_OVERRIDE(player)
  Velora.invoke(0xAA8BF0,"void", player)
end
function PLAYER.CLEAR_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player)
  Velora.invoke(0xAA8C30,"void", player)
end
-- PC:0xDC80A4C2F18A2B64 Old:0xA877FF5E
function PLAYER.SET_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(player, model)
  Velora.invoke(0xAA8C70,"void", player, model)
end
-- PC:0x10C54E4389C12B42 Old:0xBB62AAC5
function PLAYER.CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(player)
  Velora.invoke(0xAA8CB0,"void", player)
end
-- PC:0xC142BE3BB9CE125F Old:0x8C6E611D
function PLAYER.DISABLE_PLAYER_VEHICLE_REWARDS(player)
  Velora.invoke(0xAA8CF0,"void", player)
end
-- PC:0x2F7CEB6520288061 Old:0x2849D4B2
function PLAYER.SET_PLAYER_SPECTATED_VEHICLE_RADIO_OVERRIDE(p0)
  Velora.invoke(0xAA8D20,"void", p0)
end
-- PC:0x5DC40A8869C22141 Old:0x7A6B0EF8
function PLAYER.SET_PLAYER_BLUETOOTH_STATE(player, state)
  Velora.invoke(0xAA8D60,"void", player, state)
end
-- PC:0x65FAEE425DE637B0 Old:0xEA01BD4A
function PLAYER.IS_PLAYER_BLUETOOTH_ENABLE(player)
  return Velora.invoke(0xAA8DB0,"bool", player)
end
function PLAYER.DISABLE_CAMERA_VIEW_MODE_CYCLE(player)
  Velora.invoke(0xAA8E00,"void", player)
end
-- PC:0x56105E599CAB0EFA Old:0x0098D244
function PLAYER.GET_PLAYER_FAKE_WANTED_LEVEL(player)
  return Velora.invoke(0xAA8E30,"int", player)
end
function PLAYER.SET_PLAYER_CAN_DAMAGE_PLAYER(player1, player2, toggle)
  Velora.invoke(0xAA8E90,"void", player1, player2, toggle)
end
function PLAYER.SET_APPLY_WAYPOINT_OF_PLAYER(player, hudColor)
  Velora.invoke(0xAA8F10,"void", player, hudColor)
end
function PLAYER.IS_PLAYER_VEHICLE_WEAPON_TOGGLED_TO_NON_HOMING(p0)
  return Velora.invoke(0xAA8F20,"bool", p0)
end
function PLAYER.SET_PLAYER_VEHICLE_WEAPON_TO_NON_HOMING(p0)
  Velora.invoke(0xAA8F90,"void", p0)
end
function PLAYER.SET_PLAYER_HOMING_DISABLED_FOR_ALL_VEHICLE_WEAPONS(p0, p1)
  Velora.invoke(0xAA8FF0,"void", p0, p1)
end
function PLAYER.ADD_PLAYER_TARGETABLE_ENTITY(player, entity)
  Velora.invoke(0xAA9070,"void", player, entity)
end
function PLAYER.REMOVE_PLAYER_TARGETABLE_ENTITY(player, entity)
  Velora.invoke(0xAA90E0,"void", player, entity)
end
function PLAYER.SET_PLAYER_PREVIOUS_VARIATION_DATA(player, p1, p2, p3, p4, p5)
  Velora.invoke(0xAA9150,"void", player, p1, p2, p3, p4, p5)
end
function PLAYER.REMOVE_SCRIPT_FIRE_POSITION()
  Velora.invoke(0xAA91D0,"void")
end
function PLAYER.SET_SCRIPT_FIRE_POSITION(coordX, coordY, coordZ)
  Velora.invoke(0xAA9210,"void", coordX, coordY, coordZ)
end
