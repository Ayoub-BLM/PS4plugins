-- compat_pc.lua
-- Compatibilità automatica PC → Velora PS4
-- Da caricare DOPO compat_loader.lua, PRIMA degli script utente.
-- Non modifica i namespace esistenti: aggiunge solo gli alias mancanti.

-- ─────────────────────────────────────────────────────────────
--  1. JOAAT / GAMEPLAY.GET_HASH_KEY
-- ─────────────────────────────────────────────────────────────


Libs = Libs or {}


local function joaat(s)
    s = s:lower()
    local h = 0
    for i = 1, #s do
        h = (h + s:byte(i)) & 0xFFFFFFFF
        h = (h + ((h << 10) & 0xFFFFFFFF)) & 0xFFFFFFFF
        h = (h ~  (h >>  6)) & 0xFFFFFFFF
    end
    h = (h + ((h <<  3) & 0xFFFFFFFF)) & 0xFFFFFFFF
    h = (h ~  (h >> 11)) & 0xFFFFFFFF
    h = (h + ((h << 15) & 0xFFFFFFFF)) & 0xFFFFFFFF
    if h >= 0x80000000 then h = h - 0x100000000 end
    return h
end

GAMEPLAY = GAMEPLAY or {}
function GAMEPLAY.GET_HASH_KEY(k)
    return joaat(k)
end

-- ─────────────────────────────────────────────────────────────
--  2. GAMEPLAY.GET_GAME_TIMER  (usato da GUIProjectile)
-- ─────────────────────────────────────────────────────────────
if not GAMEPLAY.GET_GAME_TIMER then
    function GAMEPLAY.GET_GAME_TIMER()
        -- GET_GAME_TIMER → hash PC 0x4F3FE921 / PS4 old 0xA7E94B00
        -- Usa GET_FRAME_COUNT come fallback affidabile (ms approssimati a 30fps)
        return math.floor(Velora.GetFrameCount() * 33.33)
    end
end

-- ─────────────────────────────────────────────────────────────
--  3. OBJECT.CREATE_OBJECT  →  CREATE_OBJECT_NO_OFFSET
-- ─────────────────────────────────────────────────────────────
OBJECT = OBJECT or {}
if not OBJECT.CREATE_OBJECT then
    function OBJECT.CREATE_OBJECT(modelHash, x, y, z, isNetwork, bScriptHostObj, dynamic)
        return OBJECT.CREATE_OBJECT_NO_OFFSET(modelHash, x, y, z, isNetwork, bScriptHostObj, dynamic)
    end
end

-- ─────────────────────────────────────────────────────────────
--  4. OBJECT.DELETE_OBJECT  →  versione con handle (invoke_ptr)
-- ─────────────────────────────────────────────────────────────
-- Il compat generato non passa l'argomento; lo sostituiamo.
function OBJECT.DELETE_OBJECT(handle)
    if handle and handle ~= 0 then
        ENTITY.SET_ENTITY_AS_MISSION_ENTITY(handle, true, true)
        Velora.invoke_ptr(0xA5F4F0, 0, handle)
    end
end

-- ─────────────────────────────────────────────────────────────
--  5. ENTITY.DELETE_ENTITY  →  versione con handle
-- ─────────────────────────────────────────────────────────────
function ENTITY.DELETE_ENTITY(handle)
    if handle and handle ~= 0 then
        ENTITY.SET_ENTITY_AS_MISSION_ENTITY(handle, true, true)
        Velora.invoke_ptr(0x9B29B0, 0, handle)
    end
end

-- ─────────────────────────────────────────────────────────────
--  6. ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED  →  con handle
-- ─────────────────────────────────────────────────────────────
function ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(handle)
    if handle and handle ~= 0 then
        Velora.invoke_ptr(0x9B2E70, 0, handle)
    end
end

-- ─────────────────────────────────────────────────────────────
--  7. NETWORK.SET_ENTITY_LOCALLY_INVISIBLE  →  alias corretto
-- ─────────────────────────────────────────────────────────────
NETWORK = NETWORK or {}
if not NETWORK.SET_ENTITY_LOCALLY_INVISIBLE then
    function NETWORK.SET_ENTITY_LOCALLY_INVISIBLE(entity)
        NETWORK.SET_ENTITY_LOCALLY_INVISIBLE(entity)  -- esiste già nel compat_NETWORK
    end
end
-- La funzione corretta è in NETWORK (compat_NETWORK.lua la definisce)
-- ma alcuni script la chiamano come NETWORK.SET_ENTITY_LOCALLY_INVISIBLE
-- Già presente, nessun alias necessario.

-- ─────────────────────────────────────────────────────────────
--  8. PED.GET_PED_NEARBY_VEHICLES / GET_PED_NEARBY_PEDS
--     Velora li espone come Velora.GetNearbyVehicles / GetNearbyPeds
--     e restituiscono (table, count) invece di (table_with_count_at_0).
--     Qui creiamo wrapper compatibili col formato PC.
-- ─────────────────────────────────────────────────────────────
PED = PED or {}

local _orig_nearby_peds = PED.GET_PED_NEARBY_PEDS
function PED.GET_PED_NEARBY_PEDS(ped, p1, ignore)
    -- Velora.GetNearbyPeds restituisce (table, count)
    local t, count = Velora.GetNearbyPeds(ped, ignore)
    return t, count
end

local _orig_nearby_vehs = PED.GET_PED_NEARBY_VEHICLES
function PED.GET_PED_NEARBY_VEHICLES(ped, p1)
    local t, count = Velora.GetNearbyVehicles(ped)
    return t, count
end

-- ─────────────────────────────────────────────────────────────
--  9. UI.*  →  alias verso HUD.*  (usato da GUIProjectile)
-- ─────────────────────────────────────────────────────────────
UI = UI or {}

UI.SET_TEXT_FONT            = HUD.SET_TEXT_FONT
UI.SET_TEXT_SCALE           = HUD.SET_TEXT_SCALE
UI.SET_TEXT_COLOUR          = HUD.SET_TEXT_COLOUR
UI.SET_TEXT_CENTRE          = HUD.SET_TEXT_CENTRE
UI.SET_TEXT_DROPSHADOW      = HUD.SET_TEXT_DROPSHADOW
UI.SET_TEXT_EDGE            = HUD.SET_TEXT_EDGE

-- _SET_TEXT_ENTRY  →  BEGIN_TEXT_COMMAND_DISPLAY_TEXT
function UI._SET_TEXT_ENTRY(entry)
    HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT(entry)
end

-- _ADD_TEXT_COMPONENT_STRING  →  ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME
function UI._ADD_TEXT_COMPONENT_STRING(text)
    HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text)
end

-- _DRAW_TEXT  →  END_TEXT_COMMAND_DISPLAY_TEXT
function UI._DRAW_TEXT(x, y)
    HUD.END_TEXT_COMMAND_DISPLAY_TEXT(x, y)
end

-- _SET_NOTIFICATION_TEXT_ENTRY
function UI._SET_NOTIFICATION_TEXT_ENTRY(entry)
    HUD.BEGIN_TEXT_COMMAND_THEFEED_POST(entry)
end

-- _DRAW_NOTIFICATION  →  END_TEXT_COMMAND_THEFEED_POST_TICKER
function UI._DRAW_NOTIFICATION(blink, p1)
    return HUD.END_TEXT_COMMAND_THEFEED_POST_TICKER(blink or false, p1 or true)
end

-- _REMOVE_NOTIFICATION  →  THEFEED_REMOVE_ITEM
function UI._REMOVE_NOTIFICATION(id)
    HUD.THEFEED_REMOVE_ITEM(id)
end

-- ─────────────────────────────────────────────────────────────
-- 10. GRAPHICS.GET_SCREEN_RESOLUTION  →  wrapper che ritorna valori
--     (il compat generato chiama void senza output)
-- ─────────────────────────────────────────────────────────────
-- Su PS4 GTA V la risoluzione è sempre 1920×1080; restituiamo costanti.
function GRAPHICS.GET_SCREEN_RESOLUTION(p0, p1)
    return 1920, 1080
end

-- ─────────────────────────────────────────────────────────────
-- 11. get_key_pressed / Keys  →  stub per script PC legacy
--     Restituisce sempre false; gli script Velora devono usare
--     Native.IsControlJustPressed. Evita crash su script non
--     ancora convertiti.
-- ─────────────────────────────────────────────────────────────
Keys = Keys or {}
setmetatable(Keys, {
    __index = function(_, k) return k end  -- Keys.F7 → "F7" (stringa)
})

if not get_key_pressed then
    function get_key_pressed(key)
        return false  -- stub: non funziona su PS4
    end
end

-- ─────────────────────────────────────────────────────────────
-- 12. wait()  →  alias di Velora wait (se esiste) o no-op
--     Su Velora il wait nei tick blocca il frame; lo stub
--     evita crash ma non aspetta davvero.
-- ─────────────────────────────────────────────────────────────
if not wait then
    function wait(ms) end  -- no-op: usare state machine
end

-- ─────────────────────────────────────────────────────────────
-- 13. Native.IsControlJustPressed  →  alias breve per comodità
-- ─────────────────────────────────────────────────────────────
-- (già disponibile come Native.IsControlJustPressed nel bridge)

-- ─────────────────────────────────────────────────────────────
-- 14. AUDIO.PLAY_SOUND_FRONTEND  →  già in compat_AUDIO, OK
-- ─────────────────────────────────────────────────────────────

Velora.Log("[compat_pc] caricato OK")