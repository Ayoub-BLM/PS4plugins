-- compat_loader.lua — AUTO GENERATO
-- Carica tutti i namespace split.
local BASE="/data/Velora/lua/compat/"

dofile(BASE.."compat_AUDIO.lua")
dofile(BASE.."compat_CAM.lua")
dofile(BASE.."compat_DECORATOR.lua")
dofile(BASE.."compat_ENTITY.lua")
dofile(BASE.."compat_GRAPHICS.lua")
dofile(BASE.."compat_HUD.lua")
dofile(BASE.."compat_INTERIOR.lua")
dofile(BASE.."compat_NETWORK.lua")
dofile(BASE.."compat_OBJECT.lua")
dofile(BASE.."compat_PAD.lua")
dofile(BASE.."compat_PED.lua")
dofile(BASE.."compat_PLAYER.lua")
dofile(BASE.."compat_SCRIPT.lua")
dofile(BASE.."compat_STATS.lua")
dofile(BASE.."compat_STREAMING.lua")
dofile(BASE.."compat_TASK.lua")
dofile(BASE.."compat_VEHICLE.lua")
dofile(BASE.."compat_WEAPON.lua")
dofile(BASE.."compat_pc.lua")