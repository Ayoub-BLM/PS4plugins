-- compat_PAD.lua — AUTO GENERATO
-- PAD
PAD=PAD or {}
-- PC:0x1CEA6BFDF248E5D9 Old:0x9174AF84
function PAD.IS_CONTROL_ENABLED(control, action)
  return Velora.invoke(0xA65D70,"bool", control, action)
end
-- PC:0xF3A21BCD95725A4A Old:0x517A4384
function PAD.IS_CONTROL_PRESSED(control, action)
  return Velora.invoke(0xA65DD0,"bool", control, action)
end
-- PC:0x648EE3E7F38877DD Old:0x1F91A06E
function PAD.IS_CONTROL_RELEASED(control, action)
  return Velora.invoke(0xA65E40,"bool", control, action)
end
-- PC:0x580417101DDB492F Old:0x4487F579
function PAD.IS_CONTROL_JUST_PRESSED(control, action)
  return Velora.invoke(0xA65EB0,"bool", control, action)
end
-- PC:0x50F940259D3841E6 Old:0x2314444B
function PAD.IS_CONTROL_JUST_RELEASED(control, action)
  return Velora.invoke(0xA65F20,"bool", control, action)
end
-- PC:0xD95E79E8686D2C27 Old:0xC526F3C6
function PAD.GET_CONTROL_VALUE(control, action)
  return Velora.invoke(0xA66020,"int", control, action)
end
-- PC:0xEC3C9B8D5327B563 Old:0x5DE226A5
function PAD.GET_CONTROL_NORMAL(control, action)
  return Velora.invoke(0xA660A0,"float", control, action)
end
function PAD.SET_USE_ADJUSTED_MOUSE_COORDS(toggle)
  Velora.invoke(0xA66100,"void", toggle)
end
-- PC:0x5B84D09CEC5209C5 Old:0xC49343BB
function PAD.GET_CONTROL_UNBOUND_NORMAL(control, action)
  return Velora.invoke(0xA66120,"float", control, action)
end
function PAD.SET_CONTROL_VALUE_NEXT_FRAME(control, action, value)
  return Velora.invoke(0xA66180,"bool", control, action, value)
end
-- PC:0xE2587F8CBBD87B1D Old:0x32A93544
function PAD.IS_DISABLED_CONTROL_PRESSED(control, action)
  return Velora.invoke(0xA66200,"bool", control, action)
end
function PAD.IS_DISABLED_CONTROL_RELEASED(control, action)
  return Velora.invoke(0xA662A0,"bool", control, action)
end
-- PC:0x91AEF906BCA88877 Old:0xEE6ABD32
function PAD.IS_DISABLED_CONTROL_JUST_PRESSED(control, action)
  return Velora.invoke(0xA66340,"bool", control, action)
end
-- PC:0x305C8DCD79DA8B0F Old:0xD6A679E1
function PAD.IS_DISABLED_CONTROL_JUST_RELEASED(control, action)
  return Velora.invoke(0xA663E0,"bool", control, action)
end
-- PC:0x11E65974A982637C Old:0x66FF4FAA
function PAD.GET_DISABLED_CONTROL_NORMAL(control, action)
  return Velora.invoke(0xA66480,"float", control, action)
end
-- PC:0x4F8A26A890FD62FB Old:0xF2A65A4C
function PAD.GET_DISABLED_CONTROL_UNBOUND_NORMAL(control, action)
  return Velora.invoke(0xA66520,"float", control, action)
end
-- PC:0xD7D22F5592AED8BA Old:0x0E8EF929
function PAD.GET_CONTROL_HOW_LONG_AGO(control)
  return Velora.invoke(0xA665C0,"int", control)
end
function PAD.IS_USING_KEYBOARD_AND_MOUSE(control)
  return Velora.invoke(0xA66610,"bool", control)
end
function PAD.IS_USING_CURSOR(control)
  return Velora.invoke(0xA66620,"bool", control)
end
function PAD.SET_CURSOR_POSITION(x, y)
  return Velora.invoke(0xA66670,"bool", x, y)
end
function PAD.IS_USING_REMOTE_PLAY(control)
  return Velora.invoke(0xA66680,"bool", control)
end
function PAD.HAVE_CONTROLS_CHANGED(control)
  return Velora.invoke(0xA666D0,"bool", control)
end
function PAD.SET_CONTROL_LIGHT_EFFECT_COLOR(control, red, green, blue)
  Velora.invoke(0xA66860,"void", control, red, green, blue)
end
function PAD.CLEAR_CONTROL_LIGHT_EFFECT(control)
  Velora.invoke(0xA66900,"void", control)
end
function PAD.SET_CONTROL_SHAKE(control, duration, frequency)
  Velora.invoke(0xA66940,"void", control, duration, frequency)
end
function PAD.SET_CONTROL_TRIGGER_SHAKE(control, leftDuration, leftFrequency, rightDuration, rightFrequency)
  Velora.invoke(0xA669B0,"void", control, leftDuration, leftFrequency, rightDuration, rightFrequency)
end
function PAD.STOP_CONTROL_SHAKE(control)
  Velora.invoke(0xA669C0,"void", control)
end
function PAD.SET_CONTROL_SHAKE_SUPPRESSED_ID(control, uniqueId)
  Velora.invoke(0xA66A00,"void", control, uniqueId)
end
function PAD.CLEAR_CONTROL_SHAKE_SUPPRESSED_ID(control)
  Velora.invoke(0xA66A40,"void", control)
end
-- PC:0x77B612531280010D Old:0x313434B2
function PAD.IS_LOOK_INVERTED()
  return Velora.invoke(0xA66A80,"bool")
end
function PAD.IS_MOUSE_LOOK_INVERTED()
  return Velora.invoke(0xA66AA0,"bool")
end
-- PC:0xBB41AFBBBC0A0287 Old:0x81802053
function PAD.GET_LOCAL_PLAYER_AIM_STATE()
  return Velora.invoke(0xA66AB0,"int")
end
function PAD.GET_LOCAL_PLAYER_GAMEPAD_AIM_STATE()
  return Velora.invoke(0xA66AC0,"int")
end
function PAD.GET_IS_USING_ALTERNATE_HANDBRAKE()
  return Velora.invoke(0xA66AD0,"bool")
end
-- PC:0x0F70731BACCFBB96 Old:0xC1AFABD5
function PAD.GET_IS_USING_ALTERNATE_DRIVEBY()
  return Velora.invoke(0xA66AF0,"bool")
end
-- PC:0xFC859E2374407556 Old:0xC0823820
function PAD.GET_ALLOW_MOVEMENT_WHILE_ZOOMED()
  return Velora.invoke(0xA66B10,"bool")
end
-- PC:0x798FDEB5B1575088 Old:0xA86BD91F
function PAD.SET_PLAYERPAD_SHAKES_WHEN_CONTROLLER_DISABLED(toggle)
  Velora.invoke(0xA66B30,"void", toggle)
end
-- PC:0xEDE476E5EE29EDB1 Old:0x4E8E29E6
function PAD.SET_INPUT_EXCLUSIVE(control, action)
  Velora.invoke(0xA66B50,"void", control, action)
end
-- PC:0xFE99B66D079CF6BC Old:0x3800C0DC
function PAD.DISABLE_CONTROL_ACTION(control, action, disableRelatedActions)
  Velora.invoke(0xA66BA0,"void", control, action, disableRelatedActions)
end
-- PC:0x351220255D64C155 Old:0xD2753551
function PAD.ENABLE_CONTROL_ACTION(control, action, enableRelatedActions)
  Velora.invoke(0xA66C30,"void", control, action, enableRelatedActions)
end
-- PC:0x5F4B6931816E599B Old:0x16753CF4
function PAD.DISABLE_ALL_CONTROL_ACTIONS(control)
  Velora.invoke(0xA66CC0,"void", control)
end
-- PC:0xA5FFE9B05F199DE7 Old:0xFC2F119F
function PAD.ENABLE_ALL_CONTROL_ACTIONS(control)
  Velora.invoke(0xA66D10,"void", control)
end
-- PC:0x3D42B92563939375 Old:0xD2C80B2E
function PAD.INIT_PC_SCRIPTED_CONTROLS(schemeName)
  return Velora.invoke(0xA66D40,"bool", schemeName)
end
-- PC:0x4683149ED1DDE7A1 Old:0xBBFC9050
function PAD.SWITCH_PC_SCRIPTED_CONTROLS(schemeName)
  return Velora.invoke(0xA66D50,"bool", schemeName)
end
-- PC:0x643ED62D5EA3BEBD Old:0x42140FF9
function PAD.SHUTDOWN_PC_SCRIPTED_CONTROLS()
  Velora.invoke(0xA66D60,"void")
end
-- PC:0x7F4724035FDCA1DD Old:0x2CEDE6C5
function PAD.ALLOW_ALTERNATIVE_SCRIPT_CONTROLS_LAYOUT(control)
  Velora.invoke(0xA66D70,"void", control)
end
