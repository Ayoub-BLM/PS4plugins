-- compat_VEHICLE.lua — AUTO GENERATO
-- VEHICLE
VEHICLE=VEHICLE or {}
-- PC:0xAF35D0D2583051B0 Old:0xDD75460A
function VEHICLE.CREATE_VEHICLE(modelHash, x, y, z, heading, isNetwork, bScriptHostVeh, p7)
  return Velora.invoke(0xB15D00,"int", modelHash, x, y, z, heading, isNetwork, bScriptHostVeh, p7)
end
-- PC:0xEA386986E786A54F Old:0x9803AF60
function VEHICLE.DELETE_VEHICLE()
  Velora.invoke(0xB15D50,"void")
end
-- PC:0x7D6F9A3EF26136A0 Old:0xBB54ECCA
function VEHICLE.SET_VEHICLE_ALLOW_HOMING_MISSLE_LOCKON(vehicle, toggle, p2)
  Velora.invoke(0xB15D60,"void", vehicle, toggle, p2)
end
function VEHICLE.SET_VEHICLE_ALLOW_HOMING_MISSLE_LOCKON_SYNCED(vehicle, canBeLockedOn, p2)
  Velora.invoke(0xB15E80,"void", vehicle, canBeLockedOn, p2)
end
-- PC:0x5D14D4154BFE7B2C Old:0x8BAAC437
function VEHICLE.SET_VEHICLE_ALLOW_NO_PASSENGERS_LOCKON(veh, toggle)
  Velora.invoke(0xB15EE0,"void", veh, toggle)
end
-- PC:0xE6B0E8CFC3633BF0 Old:0xFBDE9FD8
function VEHICLE.GET_VEHICLE_HOMING_LOCKON_STATE(vehicle)
  return Velora.invoke(0xB15F80,"int", vehicle)
end
function VEHICLE.GET_VEHICLE_HOMING_LOCKEDONTO_STATE(p0)
  return Velora.invoke(0xB15FD0,"int", p0)
end
function VEHICLE.SET_VEHICLE_HOMING_LOCKEDONTO_STATE(p0, p1)
  Velora.invoke(0xB16020,"void", p0, p1)
end
-- PC:0x423E8DE37D934D89 Old:0x013B10B6
function VEHICLE.IS_VEHICLE_MODEL(vehicle, model)
  return Velora.invoke(0xB16080,"bool", vehicle, model)
end
-- PC:0xF6086BC836400876 Old:0xF6BDDA30
function VEHICLE.DOES_SCRIPT_VEHICLE_GENERATOR_EXIST(vehicleGenerator)
  return Velora.invoke(0xB16140,"bool", vehicleGenerator)
end
-- PC:0x9DEF883114668116 Old:0x25A9A261
function VEHICLE.CREATE_SCRIPT_VEHICLE_GENERATOR(x, y, z, heading, p4, p5, modelHash, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16)
  return Velora.invoke(0xB161A0,"int", x, y, z, heading, p4, p5, modelHash, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16)
end
-- PC:0x22102C9ABFCF125D Old:0xE4328E3F
function VEHICLE.DELETE_SCRIPT_VEHICLE_GENERATOR(vehicleGenerator)
  Velora.invoke(0xB16370,"void", vehicleGenerator)
end
-- PC:0xD9D620E0AC6DC4B0 Old:0x40D73747
function VEHICLE.SET_SCRIPT_VEHICLE_GENERATOR(vehicleGenerator, enabled)
  Velora.invoke(0xB163F0,"void", vehicleGenerator, enabled)
end
-- PC:0xC12321827687FE4D Old:0xB4E0E69A
function VEHICLE.SET_ALL_VEHICLE_GENERATORS_ACTIVE_IN_AREA(x1, y1, z1, x2, y2, z2, toggle, p7)
  Velora.invoke(0xB16480,"void", x1, y1, z1, x2, y2, z2, toggle, p7)
end
-- PC:0x34AD89078831A4BC Old:0xAB1FDD76
function VEHICLE.SET_ALL_VEHICLE_GENERATORS_ACTIVE()
  Velora.invoke(0xB164B0,"void")
end
-- PC:0x608207E7A8FB787C Old:0x87F767F2
function VEHICLE.SET_ALL_LOW_PRIORITY_VEHICLE_GENERATORS_ACTIVE(active)
  Velora.invoke(0xB164C0,"void", active)
end
-- PC:0x9A75585FB2E54FAD Old:0x935A95DA
function VEHICLE.SET_VEHICLE_GENERATOR_AREA_OF_INTEREST(x, y, z, radius)
  Velora.invoke(0xB164E0,"void", x, y, z, radius)
end
-- PC:0x0A436B8643716D14 Old:0x6C73E45A
function VEHICLE.CLEAR_VEHICLE_GENERATOR_AREA_OF_INTEREST()
  Velora.invoke(0xB16520,"void")
end
-- PC:0x49733E92263139D1 Old:0xE14FDBA6
function VEHICLE.SET_VEHICLE_ON_GROUND_PROPERLY(vehicle, p1)
  return Velora.invoke(0xB16530,"bool", vehicle, p1)
end
-- PC:0xE023E8AC4EF7C117 Old:0xA0909ADB
function VEHICLE.SET_VEHICLE_USE_CUTSCENE_WHEEL_COMPRESSION(p0, p1, p2, p3)
  return Velora.invoke(0xB165E0,"bool", p0, p1, p2, p3)
end
-- PC:0xB497F06B288DCFDF Old:0x18D07C6C
function VEHICLE.IS_VEHICLE_STUCK_ON_ROOF(vehicle)
  return Velora.invoke(0xB16720,"bool", vehicle)
end
-- PC:0xB72E26D81006005B Old:0x3A13D384
function VEHICLE.ADD_VEHICLE_UPSIDEDOWN_CHECK(vehicle)
  Velora.invoke(0xB16780,"void", vehicle)
end
-- PC:0xC53EB42A499A7E90 Old:0xF390BA1B
function VEHICLE.REMOVE_VEHICLE_UPSIDEDOWN_CHECK(vehicle)
  Velora.invoke(0xB167D0,"void", vehicle)
end
-- PC:0x5721B434AD84D57A Old:0x655F072C
function VEHICLE.IS_VEHICLE_STOPPED(vehicle)
  return Velora.invoke(0xB167F0,"bool", vehicle)
end
-- PC:0x24CB2137731FFE89 Old:0x1EF20849
function VEHICLE.GET_VEHICLE_NUMBER_OF_PASSENGERS(vehicle, includeDriver, includeDeadOccupants)
  return Velora.invoke(0xB16850,"int", vehicle, includeDriver, includeDeadOccupants)
end
-- PC:0xA7C4F2C6E744A550 Old:0x0A2FC08C
function VEHICLE.GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS(vehicle)
  return Velora.invoke(0xB168E0,"int", vehicle)
end
-- PC:0x2AD93716F184EDA4 Old:0x838F7BF7
function VEHICLE.GET_VEHICLE_MODEL_NUMBER_OF_SEATS(modelHash)
  return Velora.invoke(0xB16940,"int", modelHash)
end
-- PC:0xF7F203E31F96F6A1 Old:0x769E5CF2
function VEHICLE.IS_SEAT_WARP_ONLY(vehicle, seatIndex)
  return Velora.invoke(0xB169E0,"bool", vehicle, seatIndex)
end
-- PC:0xE33FFA906CE74880 Old:0x7C43D32A
function VEHICLE.IS_TURRET_SEAT(vehicle, seatIndex)
  return Velora.invoke(0xB16A80,"bool", vehicle, seatIndex)
end
function VEHICLE.DOES_VEHICLE_ALLOW_RAPPEL(vehicle)
  return Velora.invoke(0xB16B00,"bool", vehicle)
end
-- PC:0x245A6883D966D537 Old:0xF4187E51
function VEHICLE.SET_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME(multiplier)
  Velora.invoke(0xB16B60,"void", multiplier)
end
-- PC:0xB3B3359379FE77D3 Old:0x543F712B
function VEHICLE.SET_RANDOM_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME(multiplier)
  Velora.invoke(0xB16B90,"void", multiplier)
end
-- PC:0xEAE6DCC7EEE3DB1D Old:0xDD46CEBE
function VEHICLE.SET_PARKED_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME(multiplier)
  Velora.invoke(0xB16BB0,"void", multiplier)
end
-- PC:0xD4B8E3D1917BC86B Old:0x09462665
function VEHICLE.SET_DISABLE_RANDOM_TRAINS_THIS_FRAME(toggle)
  Velora.invoke(0xB16BD0,"void", toggle)
end
-- PC:0x90B6DA738A9A25DA Old:0xDAE2A2BE
function VEHICLE.SET_AMBIENT_VEHICLE_RANGE_MULTIPLIER_THIS_FRAME(value)
  Velora.invoke(0xB16BF0,"void", value)
end
-- PC:0x26324F33423F3CC3 Old:0x9F019C49
function VEHICLE.SET_FAR_DRAW_VEHICLES(toggle)
  Velora.invoke(0xB16C30,"void", toggle)
end
-- PC:0xCAA15F13EBD417FF Old:0x206A58E8
function VEHICLE.SET_NUMBER_OF_PARKED_VEHICLES(value)
  Velora.invoke(0xB16C50,"void", value)
end
-- PC:0xB664292EAECF7FA6 Old:0x4CDD35D0
function VEHICLE.SET_VEHICLE_DOORS_LOCKED(vehicle, doorLockStatus)
  Velora.invoke(0xB16C60,"void", vehicle, doorLockStatus)
end
-- PC:0xBE70724027F85BCD Old:0xD61D182D
function VEHICLE.SET_VEHICLE_INDIVIDUAL_DOORS_LOCKED(vehicle, doorId, doorLockStatus)
  Velora.invoke(0xB16CB0,"void", vehicle, doorId, doorLockStatus)
end
-- PC:0xD8050E0EB60CF274 Old:0xC54156A9
function VEHICLE.SET_VEHICLE_HAS_MUTED_SIRENS(vehicle, toggle)
  Velora.invoke(0xB16D30,"void", vehicle, toggle)
end
-- PC:0x517AAF684BB50CD1 Old:0x49829236
function VEHICLE.SET_VEHICLE_DOORS_LOCKED_FOR_PLAYER(vehicle, player, toggle)
  Velora.invoke(0xB16DD0,"void", vehicle, player, toggle)
end
-- PC:0xF6AF6CB341349015 Old:0x1DC50247
function VEHICLE.GET_VEHICLE_DOORS_LOCKED_FOR_PLAYER(vehicle, player)
  return Velora.invoke(0xB16DF0,"bool", vehicle, player)
end
-- PC:0xA2F80B8D040727CC Old:0x891BA8A4
function VEHICLE.SET_VEHICLE_DOORS_LOCKED_FOR_ALL_PLAYERS(vehicle, toggle)
  Velora.invoke(0xB16E60,"void", vehicle, toggle)
end
-- PC:0x9737A37136F07E75 Old:0xE4EF6514
function VEHICLE.SET_VEHICLE_DOORS_LOCKED_FOR_NON_SCRIPT_PLAYERS(vehicle, toggle)
  Velora.invoke(0xB16F10,"void", vehicle, toggle)
end
-- PC:0xB81F6D4A8F5EEBA8 Old:0x4F85E783
function VEHICLE.SET_VEHICLE_DOORS_LOCKED_FOR_TEAM(vehicle, team, toggle)
  Velora.invoke(0xB16F70,"void", vehicle, team, toggle)
end
function VEHICLE.SET_VEHICLE_DOORS_LOCKED_FOR_ALL_TEAMS(vehicle, toggle)
  Velora.invoke(0xB16FF0,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_DONT_TERMINATE_TASK_WHEN_ACHIEVED(vehicle)
  Velora.invoke(0xB17050,"void", vehicle)
end
-- PC:0xBA71116ADF5B514C Old:0xBEDEACEB
function VEHICLE.EXPLODE_VEHICLE(vehicle, isAudible, isInvisible)
  Velora.invoke(0xB17130,"void", vehicle, isAudible, isInvisible)
end
-- PC:0xF19D095E42D430CC Old:0x3764D734
function VEHICLE.SET_VEHICLE_OUT_OF_CONTROL(vehicle, killDriver, explodeOnImpact)
  Velora.invoke(0xB171E0,"void", vehicle, killDriver, explodeOnImpact)
end
-- PC:0x2E0A74E1002380B1 Old:0xDB8CB8E2
function VEHICLE.SET_VEHICLE_TIMED_EXPLOSION(vehicle, ped, toggle)
  Velora.invoke(0xB172C0,"void", vehicle, ped, toggle)
end
-- PC:0x99AD4CCCB128CBC9 Old:0x811373DE
function VEHICLE.ADD_VEHICLE_PHONE_EXPLOSIVE_DEVICE(vehicle)
  Velora.invoke(0xB172E0,"void", vehicle)
end
function VEHICLE.CLEAR_VEHICLE_PHONE_EXPLOSIVE_DEVICE()
  Velora.invoke(0xB17360,"void")
end
-- PC:0x6ADAABD3068C5235 Old:0xA4E69134
function VEHICLE.HAS_VEHICLE_PHONE_EXPLOSIVE_DEVICE()
  return Velora.invoke(0xB17390,"bool")
end
-- PC:0xEF49CF0270307CBE Old:0x65255524
function VEHICLE.DETONATE_VEHICLE_PHONE_EXPLOSIVE_DEVICE()
  Velora.invoke(0xB17410,"void")
end
-- PC:0x598803E85E8448D9 Old:0x68639D85
function VEHICLE.SET_TAXI_LIGHTS(vehicle, state)
  Velora.invoke(0xB17480,"void", vehicle, state)
end
-- PC:0x7504C0F113AB50FC Old:0x6FC4924A
function VEHICLE.IS_TAXI_LIGHT_ON(vehicle)
  return Velora.invoke(0xB17510,"bool", vehicle)
end
-- PC:0xCEE4490CD57BB3C2 Old:0xA90EC257
function VEHICLE.IS_VEHICLE_IN_GARAGE_AREA(garageName, vehicle)
  return Velora.invoke(0xB17580,"bool", garageName, vehicle)
end
-- PC:0x4F1D4BE3A7F24601 Old:0x57F24253
function VEHICLE.SET_VEHICLE_COLOURS(vehicle, colorPrimary, colorSecondary)
  Velora.invoke(0xB175F0,"void", vehicle, colorPrimary, colorSecondary)
end
-- PC:0x8B7FD87F0DDB421E Old:0x9C49CC15
function VEHICLE.SET_VEHICLE_FULLBEAM(vehicle, toggle)
  Velora.invoke(0xB17690,"void", vehicle, toggle)
end
-- PC:0x07116E24E9D1929D Old:0xA59E3DCD
function VEHICLE.SET_VEHICLE_IS_RACING(vehicle, toggle)
  Velora.invoke(0xB17730,"void", vehicle, toggle)
end
-- PC:0x7141766F91D15BEA Old:0x8DF9F9BC
function VEHICLE.SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle, r, g, b)
  Velora.invoke(0xB177E0,"void", vehicle, r, g, b)
end
-- PC:0xB64CF2CCA9D95F52 Old:0x1C2B9FEF
function VEHICLE.GET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle)
  Velora.invoke(0xB178B0,"void", vehicle)
end
-- PC:0x55E1D2758F34E437 Old:0x51E1E33D
function VEHICLE.CLEAR_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle)
  Velora.invoke(0xB17930,"void", vehicle)
end
-- PC:0xF095C0405307B21B Old:0xD7EC8760
function VEHICLE.GET_IS_VEHICLE_PRIMARY_COLOUR_CUSTOM(vehicle)
  return Velora.invoke(0xB17980,"bool", vehicle)
end
-- PC:0x36CED73BFED89754 Old:0x9D77259E
function VEHICLE.SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle, r, g, b)
  Velora.invoke(0xB179E0,"void", vehicle, r, g, b)
end
-- PC:0x8389CD56CA8072DC Old:0x3FF247A2
function VEHICLE.GET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle)
  Velora.invoke(0xB17AB0,"void", vehicle)
end
-- PC:0x5FFBDEEC3E8E2009 Old:0x7CE00B29
function VEHICLE.CLEAR_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle)
  Velora.invoke(0xB17B30,"void", vehicle)
end
-- PC:0x910A32E7AAD2656C Old:0x288AD228
function VEHICLE.GET_IS_VEHICLE_SECONDARY_COLOUR_CUSTOM(vehicle)
  return Velora.invoke(0xB17B80,"bool", vehicle)
end
-- PC:0x3AFDC536C3D01674 Old:0x8332730C
function VEHICLE.SET_VEHICLE_ENVEFF_SCALE(vehicle, fade)
  Velora.invoke(0xB17BE0,"void", vehicle, fade)
end
-- PC:0xA82819CAC9C4C403 Old:0xD5F1EEE1
function VEHICLE.GET_VEHICLE_ENVEFF_SCALE(vehicle)
  return Velora.invoke(0xB17C50,"float", vehicle)
end
-- PC:0x52BBA29D5EC69356 Old:0x37677590
function VEHICLE.SET_CAN_RESPRAY_VEHICLE(vehicle, state)
  Velora.invoke(0xB17CD0,"void", vehicle, state)
end
function VEHICLE.SET_GOON_BOSS_VEHICLE(vehicle, toggle)
  Velora.invoke(0xB17D80,"void", vehicle, toggle)
end
function VEHICLE.SET_OPEN_REAR_DOORS_ON_EXPLOSION(vehicle, toggle)
  Velora.invoke(0xB17DE0,"void", vehicle, toggle)
end
-- PC:0x33506883545AC0DF Old:0x54E9EE75
function VEHICLE.FORCE_SUBMARINE_SURFACE_MODE(vehicle, toggle)
  Velora.invoke(0xB17E40,"void", vehicle, toggle)
end
function VEHICLE.FORCE_SUBMARINE_NEURTAL_BUOYANCY(p0, p1)
  Velora.invoke(0xB17EB0,"void", p0, p1)
end
-- PC:0xC59872A5134879C7 Old:0x4A46E814
function VEHICLE.SET_SUBMARINE_CRUSH_DEPTHS(vehicle, p1, depth1, depth2, depth3)
  Velora.invoke(0xB17F10,"void", vehicle, p1, depth1, depth2, depth3)
end
function VEHICLE.GET_SUBMARINE_IS_UNDER_DESIGN_DEPTH(submarine)
  return Velora.invoke(0xB17FB0,"bool", submarine)
end
function VEHICLE.GET_SUBMARINE_NUMBER_OF_AIR_LEAKS(submarine)
  return Velora.invoke(0xB18030,"int", submarine)
end
function VEHICLE.SET_BOAT_IGNORE_LAND_PROBES(p0, p1)
  Velora.invoke(0xB18090,"void", p0, p1)
end
-- PC:0x75DBEC174AEEAD10 Old:0xA3906284
function VEHICLE.SET_BOAT_ANCHOR(vehicle, toggle)
  Velora.invoke(0xB18150,"void", vehicle, toggle)
end
-- PC:0x26C10ECBDA5D043B Old:0xE97A4F5E
function VEHICLE.CAN_ANCHOR_BOAT_HERE(vehicle)
  return Velora.invoke(0xB18170,"bool", vehicle)
end
function VEHICLE.CAN_ANCHOR_BOAT_HERE_IGNORE_PLAYERS(vehicle)
  return Velora.invoke(0xB181F0,"bool", vehicle)
end
-- PC:0xE3EBAAE484798530 Old:0x0ED84792
function VEHICLE.SET_BOAT_REMAINS_ANCHORED_WHILE_PLAYER_IS_DRIVER(vehicle, toggle)
  Velora.invoke(0xB18270,"void", vehicle, toggle)
end
-- PC:0xB28B1FE5BFADD7F5 Old:0xA739012A
function VEHICLE.SET_FORCE_LOW_LOD_ANCHOR_MODE(vehicle, p1)
  Velora.invoke(0xB18290,"void", vehicle, p1)
end
-- PC:0xE842A9398079BD82 Old:0x66FA450C
function VEHICLE.SET_BOAT_LOW_LOD_ANCHOR_DISTANCE(vehicle, value)
  Velora.invoke(0xB182F0,"void", vehicle, value)
end
function VEHICLE.IS_BOAT_ANCHORED(vehicle)
  return Velora.invoke(0xB18350,"bool", vehicle)
end
-- PC:0x8F719973E1445BA2 Old:0x35614622
function VEHICLE.SET_BOAT_SINKS_WHEN_WRECKED(vehicle, toggle)
  Velora.invoke(0xB183C0,"void", vehicle, toggle)
end
function VEHICLE.SET_BOAT_WRECKED(vehicle)
  Velora.invoke(0xB18420,"void", vehicle)
end
-- PC:0xF4924635A19EB37D Old:0x4AC1EFC7
function VEHICLE.SET_VEHICLE_SIREN(vehicle, toggle)
  Velora.invoke(0xB18470,"void", vehicle, toggle)
end
-- PC:0x4C9BF537BE2634B2 Old:0x25EB5873
function VEHICLE.IS_VEHICLE_SIREN_ON(vehicle)
  return Velora.invoke(0xB184D0,"bool", vehicle)
end
-- PC:0xB5CC40FBCB586380 Old:0xC9458688
function VEHICLE.IS_VEHICLE_SIREN_AUDIO_ON(vehicle)
  return Velora.invoke(0xB18560,"bool", vehicle)
end
-- PC:0x3E8C8727991A8A0B Old:0xC758D19F
function VEHICLE.SET_VEHICLE_STRONG(vehicle, toggle)
  Velora.invoke(0xB185F0,"void", vehicle, toggle)
end
-- PC:0x8386BFB614D06749 Old:0x81594917
function VEHICLE.REMOVE_VEHICLE_STUCK_CHECK(vehicle)
  Velora.invoke(0xB18690,"void", vehicle)
end
-- PC:0xA19435F193E081AC Old:0x40D82D88
function VEHICLE.GET_VEHICLE_COLOURS(vehicle)
  Velora.invoke(0xB186B0,"void", vehicle)
end
-- PC:0x22AC59A870E6A669 Old:0xDAF42B02
function VEHICLE.IS_VEHICLE_SEAT_FREE(vehicle, seatIndex)
  return Velora.invoke(0xB18710,"bool", vehicle, seatIndex)
end
-- PC:0xBB40DD2270B65366 Old:0x388FDE9A
function VEHICLE.GET_PED_IN_VEHICLE_SEAT(vehicle, seatIndex, p2)
  return Velora.invoke(0xB18740,"int", vehicle, seatIndex, p2)
end
-- PC:0x83F969AA1EE2A664 Old:0xF7C6792D
function VEHICLE.GET_LAST_PED_IN_VEHICLE_SEAT(vehicle, seatIndex)
  return Velora.invoke(0xB18770,"int", vehicle, seatIndex)
end
-- PC:0xB91B4C20085BD12F Old:0x7C278621
function VEHICLE.GET_VEHICLE_LIGHTS_STATE(vehicle)
  return Velora.invoke(0xB187F0,"bool", vehicle)
end
-- PC:0xBA291848A0815CA9 Old:0x48C80210
function VEHICLE.IS_VEHICLE_TYRE_BURST(vehicle, wheelID, completely)
  return Velora.invoke(0xB18880,"bool", vehicle, wheelID, completely)
end
-- PC:0xAB54A438726D25D5 Old:0x69880D14
function VEHICLE.SET_VEHICLE_FORWARD_SPEED(vehicle, speed)
  Velora.invoke(0xB18950,"void", vehicle, speed)
end
function VEHICLE.SET_VEHICLE_FORWARD_SPEED_XY(vehicle, speed)
  Velora.invoke(0xB189C0,"void", vehicle, speed)
end
-- PC:0x260BE8F09E326A20 Old:0xCBC7D3C8
function VEHICLE.BRING_VEHICLE_TO_HALT(vehicle, distance, duration, p3)
  Velora.invoke(0xB18A30,"void", vehicle, distance, duration, p3)
end
function VEHICLE.SET_VEHICLE_STEER_FOR_BUILDINGS(vehicle, p1)
  Velora.invoke(0xB18A50,"void", vehicle, p1)
end
function VEHICLE.SET_VEHICLE_CAUSES_SWERVING(vehicle, toggle)
  Velora.invoke(0xB18AB0,"void", vehicle, toggle)
end
function VEHICLE.SET_IGNORE_PLANES_SMALL_PITCH_CHANGE(p0, p1)
  Velora.invoke(0xB18B20,"void", p0, p1)
end
function VEHICLE.STOP_BRINGING_VEHICLE_TO_HALT(vehicle)
  Velora.invoke(0xB18B80,"void", vehicle)
end
function VEHICLE.IS_VEHICLE_BEING_BROUGHT_TO_HALT(vehicle)
  return Velora.invoke(0xB18BF0,"bool", vehicle)
end
function VEHICLE.LOWER_FORKLIFT_FORKS(forklift)
  Velora.invoke(0xB18C70,"void", forklift)
end
-- PC:0x37EBBF3117BD6A25 Old:0x943A6CFC
function VEHICLE.SET_FORKLIFT_FORK_HEIGHT(vehicle, height)
  Velora.invoke(0xB18C80,"void", vehicle, height)
end
-- PC:0x57715966069157AD Old:0x7FB25568
function VEHICLE.IS_ENTITY_ATTACHED_TO_HANDLER_FRAME(vehicle, entity)
  return Velora.invoke(0xB18C90,"bool", vehicle, entity)
end
-- PC:0x62CA17B74C435651 Old:0x593143B9
function VEHICLE.IS_ANY_ENTITY_ATTACHED_TO_HANDLER_FRAME(vehicle)
  return Velora.invoke(0xB18CC0,"bool", vehicle)
end
-- PC:0x375E7FC44F21C8AB Old:0x70DD5E25
function VEHICLE.FIND_HANDLER_VEHICLE_CONTAINER_IS_ATTACHED_TO(entity)
  return Velora.invoke(0xB18D80,"int", entity)
end
-- PC:0x89D630CF5EA96D23 Old:0xFBF5536A
function VEHICLE.IS_HANDLER_FRAME_LINED_UP_WITH_CONTAINER(vehicle, entity)
  return Velora.invoke(0xB18DA0,"bool", vehicle, entity)
end
-- PC:0x6A98C2ECF57FA5D4 Old:0x20AB5783
function VEHICLE.ATTACH_CONTAINER_TO_HANDLER_FRAME_WHEN_LINED_UP(vehicle, entity)
  Velora.invoke(0xB18DD0,"void", vehicle, entity)
end
-- PC:0x7C0043FDFF6436BC Old:0x0F11D01F
function VEHICLE.DETACH_CONTAINER_FROM_HANDLER_FRAME(vehicle)
  Velora.invoke(0xB18DE0,"void", vehicle)
end
-- PC:0x8AA9180DE2FEDD45 Old:0xAE040377
function VEHICLE.SET_VEHICLE_DISABLE_HEIGHT_MAP_AVOIDANCE(vehicle, p1)
  Velora.invoke(0xB18DF0,"void", vehicle, p1)
end
-- PC:0x0A6A279F3AA4FD70 Old:0x4C0E4031
function VEHICLE.SET_BOAT_DISABLE_AVOIDANCE(vehicle, p1)
  Velora.invoke(0xB18EE0,"void", vehicle, p1)
end
-- PC:0x634148744F385576 Old:0x6346B7CC
function VEHICLE.IS_HELI_LANDING_AREA_BLOCKED(vehicle)
  return Velora.invoke(0xB18F40,"bool", vehicle)
end
function VEHICLE.SET_SHORT_SLOWDOWN_FOR_LANDING(vehicle)
  Velora.invoke(0xB18FB0,"void", vehicle)
end
-- PC:0xE6F13851780394DA Old:0xCCB41A55
function VEHICLE.SET_HELI_TURBULENCE_SCALAR(vehicle, p1)
  Velora.invoke(0xB19020,"void", vehicle, p1)
end
function VEHICLE.SET_CAR_BOOT_OPEN(vehicle)
  Velora.invoke(0xB19080,"void", vehicle)
end
-- PC:0xEC6A202EE4960385 Old:0x89D28068
function VEHICLE.SET_VEHICLE_TYRE_BURST(vehicle, index, onRim, p3)
  Velora.invoke(0xB190F0,"void", vehicle, index, onRim, p3)
end
-- PC:0x781B3D62BB013EF5 Old:0xBB1FF6E7
function VEHICLE.SET_VEHICLE_DOORS_SHUT(vehicle, closeInstantly)
  Velora.invoke(0xB19110,"void", vehicle, closeInstantly)
end
-- PC:0xEB9DC3C7D8596C46 Old:0xA198DB54
function VEHICLE.SET_VEHICLE_TYRES_CAN_BURST(vehicle, toggle)
  Velora.invoke(0xB19130,"void", vehicle, toggle)
end
-- PC:0x678B9BB8C3F58FEB Old:0x4D76CD2F
function VEHICLE.GET_VEHICLE_TYRES_CAN_BURST(vehicle)
  return Velora.invoke(0xB19190,"bool", vehicle)
end
-- PC:0x29B18B4FD460CA8F Old:0x829ED654
function VEHICLE.SET_VEHICLE_WHEELS_CAN_BREAK(vehicle, enabled)
  Velora.invoke(0xB191F0,"void", vehicle, enabled)
end
-- PC:0x7C65DAC73C35C862 Old:0xBB75D38B
function VEHICLE.SET_VEHICLE_DOOR_OPEN(vehicle, doorId, loose, openInstantly)
  Velora.invoke(0xB19290,"void", vehicle, doorId, loose, openInstantly)
end
function VEHICLE.SET_VEHICLE_DOOR_AUTO_LOCK(vehicle, doorId, toggle)
  Velora.invoke(0xB192C0,"void", vehicle, doorId, toggle)
end
function VEHICLE.SET_FLEEING_VEHICLES_USE_SWITCHED_OFF_NODES(p0)
  Velora.invoke(0xB19350,"void", p0)
end
-- PC:0xA711568EEDB43069 Old:0xBB8104A3
function VEHICLE.REMOVE_VEHICLE_WINDOW(vehicle, windowIndex)
  Velora.invoke(0xB19370,"void", vehicle, windowIndex)
end
-- PC:0x85796B0549DDE156 Old:0x51A16DC6
function VEHICLE.ROLL_DOWN_WINDOWS(vehicle)
  Velora.invoke(0xB193E0,"void", vehicle)
end
-- PC:0x7AD9E6CE657D69E3 Old:0xF840134C
function VEHICLE.ROLL_DOWN_WINDOW(vehicle, windowIndex)
  Velora.invoke(0xB193F0,"void", vehicle, windowIndex)
end
-- PC:0x602E548F46E24D59 Old:0x83B7E06A
function VEHICLE.ROLL_UP_WINDOW(vehicle, windowIndex)
  Velora.invoke(0xB19450,"void", vehicle, windowIndex)
end
-- PC:0x9E5B5E4D2CCD2259 Old:0xDDD9A8C2
function VEHICLE.SMASH_VEHICLE_WINDOW(vehicle, windowIndex)
  Velora.invoke(0xB194B0,"void", vehicle, windowIndex)
end
-- PC:0x772282EBEB95E682 Old:0x6B8E990D
function VEHICLE.FIX_VEHICLE_WINDOW(vehicle, windowIndex)
  Velora.invoke(0xB194C0,"void", vehicle, windowIndex)
end
-- PC:0x6D645D59FB5F5AD3 Old:0xCC95C96B
function VEHICLE.POP_OUT_VEHICLE_WINDSCREEN(vehicle)
  Velora.invoke(0xB19520,"void", vehicle)
end
-- PC:0xE38CB9D7D39FDBCC Old:0xFDA7B6CA
function VEHICLE.POP_OFF_VEHICLE_ROOF_WITH_IMPULSE(vehicle, x, y, z)
  Velora.invoke(0xB19580,"void", vehicle, x, y, z)
end
-- PC:0x34E710FF01247C5A Old:0xE8930226
function VEHICLE.SET_VEHICLE_LIGHTS(vehicle, state)
  Velora.invoke(0xB19630,"void", vehicle, state)
end
-- PC:0xC45C27EF50F36ADC Old:0x4221E435
function VEHICLE.SET_VEHICLE_USE_PLAYER_LIGHT_SETTINGS(vehicle, toggle)
  Velora.invoke(0xB19730,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_HEADLIGHT_SHADOWS(vehicle, p1)
  Velora.invoke(0xB19780,"void", vehicle, p1)
end
-- PC:0xCDE5E70C1DDB954C Old:0x24877D84
function VEHICLE.SET_VEHICLE_ALARM(vehicle, state)
  Velora.invoke(0xB197E0,"void", vehicle, state)
end
-- PC:0xB8FF7AB45305C345 Old:0x5B451FF7
function VEHICLE.START_VEHICLE_ALARM(vehicle)
  Velora.invoke(0xB19830,"void", vehicle)
end
-- PC:0x4319E335B71FFF34 Old:0xF2630A4C
function VEHICLE.IS_VEHICLE_ALARM_ACTIVATED(vehicle)
  return Velora.invoke(0xB19880,"bool", vehicle)
end
-- PC:0xBC2042F090AF6AD3 Old:0x9AD1FE1E
function VEHICLE.SET_VEHICLE_INTERIORLIGHT(vehicle, toggle)
  Velora.invoke(0xB198F0,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_FORCE_INTERIORLIGHT(vehicle, toggle)
  Velora.invoke(0xB19990,"void", vehicle, toggle)
end
-- PC:0xB385454F8791F57C Old:0x48039D6A
function VEHICLE.SET_VEHICLE_LIGHT_MULTIPLIER(vehicle, multiplier)
  Velora.invoke(0xB199E0,"void", vehicle, multiplier)
end
-- PC:0x3C7D42D58F770B54 Old:0x2133977F
function VEHICLE.ATTACH_VEHICLE_TO_TRAILER(vehicle, trailer, radius)
  Velora.invoke(0xB19A30,"void", vehicle, trailer, radius)
end
-- PC:0x16B5E274BDE402F8 Old:0x12AC1A16
function VEHICLE.ATTACH_VEHICLE_ON_TO_TRAILER(vehicle, trailer, offsetX, offsetY, offsetZ, coordsX, coordsY, coordsZ, rotationX, rotationY, rotationZ, disableCollisions)
  Velora.invoke(0xB19B10,"void", vehicle, trailer, offsetX, offsetY, offsetZ, coordsX, coordsY, coordsZ, rotationX, rotationY, rotationZ, disableCollisions)
end
-- PC:0x374706271354CB18 Old:0x40C4763F
function VEHICLE.STABILISE_ENTITY_ATTACHED_TO_HELI(vehicle, entity, p2)
  Velora.invoke(0xB19B30,"void", vehicle, entity, p2)
end
-- PC:0x90532EDF0D2BDD86 Old:0xB5DBF91D
function VEHICLE.DETACH_VEHICLE_FROM_TRAILER(vehicle)
  Velora.invoke(0xB19BE0,"void", vehicle)
end
-- PC:0xE7CF3C4F9F489F0C Old:0xE142BBCC
function VEHICLE.IS_VEHICLE_ATTACHED_TO_TRAILER(vehicle)
  return Velora.invoke(0xB19C70,"bool", vehicle)
end
-- PC:0x2A8F319B392E7B3F Old:0xE74E85CE
function VEHICLE.SET_TRAILER_INVERSE_MASS_SCALE(vehicle, p1)
  Velora.invoke(0xB19D30,"void", vehicle, p1)
end
-- PC:0x95CF53B3D687F9FA Old:0x06C47A6F
function VEHICLE.SET_TRAILER_LEGS_RAISED(vehicle)
  Velora.invoke(0xB19DC0,"void", vehicle)
end
function VEHICLE.SET_TRAILER_LEGS_LOWERED(vehicle)
  Velora.invoke(0xB19E20,"void", vehicle)
end
-- PC:0x6E13FC662B882D1D Old:0xA42EFA6B
function VEHICLE.SET_VEHICLE_TYRE_FIXED(vehicle, tyreIndex)
  Velora.invoke(0xB19E80,"void", vehicle, tyreIndex)
end
-- PC:0x95A88F0B409CDA47 Old:0x400F9556
function VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT(vehicle, plateText)
  Velora.invoke(0xB19F00,"void", vehicle, plateText)
end
-- PC:0x4C4D6B2644F458CB Old:0xD24BC1AE
function VEHICLE.GET_NUMBER_OF_VEHICLE_NUMBER_PLATES()
  return Velora.invoke(0xB19FB0,"int")
end
-- PC:0x9088EB5A43FFB0A1 Old:0xA1A1890E
function VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(vehicle, plateIndex)
  Velora.invoke(0xB19FD0,"void", vehicle, plateIndex)
end
-- PC:0xF11BC2DD9A3E7195 Old:0x499747B6
function VEHICLE.GET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(vehicle)
  return Velora.invoke(0xB1A020,"int", vehicle)
end
-- PC:0x80D9F74197EA47D9 Old:0xD461CA7F
function VEHICLE.SET_RANDOM_TRAINS(toggle)
  Velora.invoke(0xB1A080,"void", toggle)
end
-- PC:0x63C6CCA8E68AE8C8 Old:0xD4C2EAFD
function VEHICLE.CREATE_MISSION_TRAIN(variation, x, y, z, direction, p5, p6)
  return Velora.invoke(0xB1A0A0,"int", variation, x, y, z, direction, p5, p6)
end
-- PC:0xFD813BB7DB977F20 Old:0x68BFDD61
function VEHICLE.SWITCH_TRAIN_TRACK(trackId, state)
  Velora.invoke(0xB1A0F0,"void", trackId, state)
end
-- PC:0x21973BBF8D17EDFA Old:0xD5774FB7
function VEHICLE.SET_TRAIN_TRACK_SPAWN_FREQUENCY(trackIndex, frequency)
  Velora.invoke(0xB1A120,"void", trackIndex, frequency)
end
function VEHICLE.ALLOW_TRAIN_TO_BE_REMOVED_BY_POPULATION(p0)
  Velora.invoke(0xB1A150,"void", p0)
end
-- PC:0x736A718577F39C7D Old:0x83DE7ABF
function VEHICLE.DELETE_ALL_TRAINS()
  Velora.invoke(0xB1A1A0,"void")
end
-- PC:0xAA0BC91BE0B796E3 Old:0xDFC35E4D
function VEHICLE.SET_TRAIN_SPEED(train, speed)
  Velora.invoke(0xB1A1B0,"void", train, speed)
end
-- PC:0x16469284DB8C62B5 Old:0xB507F51D
function VEHICLE.SET_TRAIN_CRUISE_SPEED(train, speed)
  Velora.invoke(0xB1A220,"void", train, speed)
end
-- PC:0x84436EC293B1415F Old:0xB505BD89
function VEHICLE.SET_RANDOM_BOATS(toggle)
  Velora.invoke(0xB1A290,"void", toggle)
end
function VEHICLE.SET_RANDOM_BOATS_MP(toggle)
  Velora.invoke(0xB1A2B0,"void", toggle)
end
-- PC:0x2AFD795EEAC8D30D Old:0xD9ABB0FF
function VEHICLE.SET_GARBAGE_TRUCKS(toggle)
  Velora.invoke(0xB1A2D0,"void", toggle)
end
-- PC:0x57E4C39DE5EE8470 Old:0x5D91D9AC
function VEHICLE.DOES_VEHICLE_HAVE_STUCK_VEHICLE_CHECK(vehicle)
  return Velora.invoke(0xB1A2F0,"bool", vehicle)
end
-- PC:0x21543C612379DB3C Old:0x328D601D
function VEHICLE.GET_VEHICLE_RECORDING_ID(recording, script)
  return Velora.invoke(0xB1A370,"int", recording, script)
end
-- PC:0xAF514CABE74CBF15 Old:0x91AFEFD9
function VEHICLE.REQUEST_VEHICLE_RECORDING(recording, script)
  Velora.invoke(0xB1A3A0,"void", recording, script)
end
-- PC:0x300D614A4C785FC4 Old:0xF52CD7F5
function VEHICLE.HAS_VEHICLE_RECORDING_BEEN_LOADED(recording, script)
  return Velora.invoke(0xB1A420,"bool", recording, script)
end
-- PC:0xF1160ACCF98A3FC8 Old:0xD3C05B00
function VEHICLE.REMOVE_VEHICLE_RECORDING(recording, script)
  Velora.invoke(0xB1A460,"void", recording, script)
end
-- PC:0x92523B76657A517D Old:0xF31973BB
function VEHICLE.GET_POSITION_OF_VEHICLE_RECORDING_ID_AT_TIME(id, time)
  local x,y,z=Velora.invoke(0xB1A4B0,"vector3", id, time)
  return {x=x,y=y,z=z}
end
-- PC:0xD242728AA6F0FBA2 Old:0x7178558D
function VEHICLE.GET_POSITION_OF_VEHICLE_RECORDING_AT_TIME(recording, time, script)
  local x,y,z=Velora.invoke(0xB1A520,"vector3", recording, time, script)
  return {x=x,y=y,z=z}
end
-- PC:0xF0F2103EFAF8CBA7 Old:0x4D1C15C2
function VEHICLE.GET_ROTATION_OF_VEHICLE_RECORDING_ID_AT_TIME(id, time)
  local x,y,z=Velora.invoke(0xB1A5C0,"vector3", id, time)
  return {x=x,y=y,z=z}
end
-- PC:0x2058206FBE79A8AD Old:0xD96DEC68
function VEHICLE.GET_ROTATION_OF_VEHICLE_RECORDING_AT_TIME(recording, time, script)
  local x,y,z=Velora.invoke(0xB1A630,"vector3", recording, time, script)
  return {x=x,y=y,z=z}
end
-- PC:0x102D125411A7B6E6 Old:0x7116785E
function VEHICLE.GET_TOTAL_DURATION_OF_VEHICLE_RECORDING_ID(id)
  return Velora.invoke(0xB1A6D0,"float", id)
end
-- PC:0x0E48D1C262390950 Old:0x5B35EEB7
function VEHICLE.GET_TOTAL_DURATION_OF_VEHICLE_RECORDING(recording, script)
  return Velora.invoke(0xB1A700,"float", recording, script)
end
-- PC:0x2DACD605FC681475 Old:0x7DCD644C
function VEHICLE.GET_POSITION_IN_RECORDING(vehicle)
  return Velora.invoke(0xB1A740,"float", vehicle)
end
-- PC:0x5746F3A7AB7FE544 Old:0xF8C3E4A2
function VEHICLE.GET_TIME_POSITION_IN_RECORDING(vehicle)
  return Velora.invoke(0xB1A790,"float", vehicle)
end
-- PC:0x3F878F92B3A7A071 Old:0xCF614CA8
function VEHICLE.START_PLAYBACK_RECORDED_VEHICLE(vehicle, recording, script, p3)
  Velora.invoke(0xB1A7E0,"void", vehicle, recording, script, p3)
end
-- PC:0x7D80FD645D4DA346 Old:0x4E721AD2
function VEHICLE.START_PLAYBACK_RECORDED_VEHICLE_WITH_FLAGS(vehicle, recording, script, flags, time, drivingStyle)
  Velora.invoke(0xB1A800,"void", vehicle, recording, script, flags, time, drivingStyle)
end
-- PC:0x1F2E4E06DEA8992B Old:0x01B91CD0
function VEHICLE.FORCE_PLAYBACK_RECORDED_VEHICLE_UPDATE(vehicle, p1)
  Velora.invoke(0xB1A820,"void", vehicle, p1)
end
-- PC:0x54833611C17ABDEA Old:0xAE99C57C
function VEHICLE.STOP_PLAYBACK_RECORDED_VEHICLE(vehicle)
  Velora.invoke(0xB1A840,"void", vehicle)
end
-- PC:0x632A689BF42301B1 Old:0xCCF54912
function VEHICLE.PAUSE_PLAYBACK_RECORDED_VEHICLE(vehicle)
  Velora.invoke(0xB1A890,"void", vehicle)
end
-- PC:0x8879EE09268305D5 Old:0x59060F75
function VEHICLE.UNPAUSE_PLAYBACK_RECORDED_VEHICLE(vehicle)
  Velora.invoke(0xB1A8E0,"void", vehicle)
end
-- PC:0x1C8A4C2C19E68EEC Old:0x61F7650D
function VEHICLE.IS_PLAYBACK_GOING_ON_FOR_VEHICLE(vehicle)
  return Velora.invoke(0xB1A930,"bool", vehicle)
end
-- PC:0xAEA8FD591FAD4106 Old:0x63022C58
function VEHICLE.IS_PLAYBACK_USING_AI_GOING_ON_FOR_VEHICLE(vehicle)
  return Velora.invoke(0xB1A990,"bool", vehicle)
end
-- PC:0x42BC05C27A946054 Old:0xA3F44390
function VEHICLE.GET_CURRENT_PLAYBACK_FOR_VEHICLE(vehicle)
  return Velora.invoke(0xB1AA00,"int", vehicle)
end
-- PC:0xAB8E2EDA0C0A5883 Old:0x8DEA18C8
function VEHICLE.SKIP_TO_END_AND_STOP_PLAYBACK_RECORDED_VEHICLE(vehicle)
  Velora.invoke(0xB1AA50,"void", vehicle)
end
-- PC:0x6683AB880E427778 Old:0x684E26E4
function VEHICLE.SET_PLAYBACK_SPEED(vehicle, speed)
  Velora.invoke(0xB1AAA0,"void", vehicle, speed)
end
-- PC:0x29DE5FA52D00428C Old:0x8DE8E24E
function VEHICLE.START_PLAYBACK_RECORDED_VEHICLE_USING_AI(vehicle, recording, script, speed, drivingStyle)
  Velora.invoke(0xB1AB00,"void", vehicle, recording, script, speed, drivingStyle)
end
-- PC:0x9438F7AD68771A20 Old:0xCF3EFA4B
function VEHICLE.SKIP_TIME_IN_PLAYBACK_RECORDED_VEHICLE(vehicle, time)
  Velora.invoke(0xB1AB20,"void", vehicle, time)
end
-- PC:0xA549C3B37EA28131 Old:0xB536CCD7
function VEHICLE.SET_PLAYBACK_TO_USE_AI(vehicle, drivingStyle)
  Velora.invoke(0xB1AB80,"void", vehicle, drivingStyle)
end
-- PC:0x6E63860BBB190730 Old:0x0C8ABAA4
function VEHICLE.SET_PLAYBACK_TO_USE_AI_TRY_TO_REVERT_BACK_LATER(vehicle, time, drivingStyle, p3)
  Velora.invoke(0xB1ABD0,"void", vehicle, time, drivingStyle, p3)
end
-- PC:0x5845066D8A1EA7F7 Old:0x943A58EB
function VEHICLE.SET_ADDITIONAL_ROTATION_FOR_RECORDED_VEHICLE_PLAYBACK(vehicle, x, y, z, p4)
  Velora.invoke(0xB1AC40,"void", vehicle, x, y, z, p4)
end
-- PC:0x796A877E459B99EA Old:0x5C9F477C
function VEHICLE.SET_POSITION_OFFSET_FOR_RECORDED_VEHICLE_PLAYBACK(vehicle, x, y, z)
  Velora.invoke(0xB1AC60,"void", vehicle, x, y, z)
end
-- PC:0xFAF2A78061FD9EF4 Old:0xCD83C393
function VEHICLE.SET_GLOBAL_POSITION_OFFSET_FOR_RECORDED_VEHICLE_PLAYBACK(vehicle, x, y, z)
  Velora.invoke(0xB1ACC0,"void", vehicle, x, y, z)
end
-- PC:0x063AE2B2CC273588 Old:0x2EF8435C
function VEHICLE.SET_SHOULD_LERP_FROM_AI_TO_FULL_RECORDING(vehicle, p1)
  Velora.invoke(0xB1AD20,"void", vehicle, p1)
end
-- PC:0x786A4EB67B01BF0B Old:0xA85207B5
function VEHICLE.EXPLODE_VEHICLE_IN_CUTSCENE(vehicle, p1)
  Velora.invoke(0xB1ADC0,"void", vehicle, p1)
end
-- PC:0x2FA9923062DD396C Old:0xC8B789AD
function VEHICLE.ADD_VEHICLE_STUCK_CHECK_WITH_WARP(p0, p1, p2, p3, p4, p5, p6)
  Velora.invoke(0xB1AE40,"void", p0, p1, p2, p3, p4, p5, p6)
end
-- PC:0x0FC2D89AC25A5814 Old:0x42A08C9B
function VEHICLE.SET_VEHICLE_MODEL_IS_SUPPRESSED(model, suppressed)
  Velora.invoke(0xB1AEF0,"void", model, suppressed)
end
-- PC:0x386F6CE5BAF6091C Old:0x57216D03
function VEHICLE.GET_RANDOM_VEHICLE_IN_SPHERE(x, y, z, radius, modelHash, flags)
  return Velora.invoke(0xB1AF10,"int", x, y, z, radius, modelHash, flags)
end
-- PC:0xC5574E0AEB86BA68 Old:0xDCADEB66
function VEHICLE.GET_RANDOM_VEHICLE_FRONT_BUMPER_IN_SPHERE(p0, p1, p2, p3, p4, p5, p6)
  return Velora.invoke(0xB1AF90,"int", p0, p1, p2, p3, p4, p5, p6)
end
-- PC:0xB50807EABE20A8DC Old:0xD6343F6B
function VEHICLE.GET_RANDOM_VEHICLE_BACK_BUMPER_IN_SPHERE(p0, p1, p2, p3, p4, p5, p6)
  return Velora.invoke(0xB1B010,"int", p0, p1, p2, p3, p4, p5, p6)
end
-- PC:0xF73EB622C4F1689B Old:0xD7E26B2C
function VEHICLE.GET_CLOSEST_VEHICLE(x, y, z, radius, modelHash, flags)
  return Velora.invoke(0xB1B090,"int", x, y, z, radius, modelHash, flags)
end
-- PC:0x08AAFD0814722BC3 Old:0x2544E7A6
function VEHICLE.GET_TRAIN_CARRIAGE(train, trailerNumber)
  return Velora.invoke(0xB1B0C0,"int", train, trailerNumber)
end
function VEHICLE.IS_MISSION_TRAIN(train)
  return Velora.invoke(0xB1B1B0,"bool", train)
end
-- PC:0x5B76B14AE875C795 Old:0x86C9497D
function VEHICLE.DELETE_MISSION_TRAIN()
  Velora.invoke(0xB1B230,"void")
end
-- PC:0xBBE7648349B49BE8 Old:0x19808560
function VEHICLE.SET_MISSION_TRAIN_AS_NO_LONGER_NEEDED(p1)
  Velora.invoke(0xB1B240,"void", p1)
end
-- PC:0x591CA673AA6AB736 Old:0xD6D70803
function VEHICLE.SET_MISSION_TRAIN_COORDS(train, x, y, z)
  Velora.invoke(0xB1B250,"void", train, x, y, z)
end
-- PC:0x45A9187928F4B9E3 Old:0x10F6085C
function VEHICLE.IS_THIS_MODEL_A_BOAT(model)
  return Velora.invoke(0xB1B2F0,"bool", model)
end
function VEHICLE.IS_THIS_MODEL_A_JETSKI(model)
  return Velora.invoke(0xB1B370,"bool", model)
end
-- PC:0xA0948AB42D7BA0DE Old:0x3B3907BB
function VEHICLE.IS_THIS_MODEL_A_PLANE(model)
  return Velora.invoke(0xB1B3F0,"bool", model)
end
-- PC:0xDCE4334788AF94EA Old:0x8AF7F568
function VEHICLE.IS_THIS_MODEL_A_HELI(model)
  return Velora.invoke(0xB1B470,"bool", model)
end
-- PC:0x7F6DB52EEFC96DF8 Old:0x60E4C22F
function VEHICLE.IS_THIS_MODEL_A_CAR(model)
  return Velora.invoke(0xB1B4F0,"bool", model)
end
-- PC:0xAB935175B22E822B Old:0xF87DCFFD
function VEHICLE.IS_THIS_MODEL_A_TRAIN(model)
  return Velora.invoke(0xB1B570,"bool", model)
end
-- PC:0xB50C0B0CEDC6CE84 Old:0x7E702CDD
function VEHICLE.IS_THIS_MODEL_A_BIKE(model)
  return Velora.invoke(0xB1B5F0,"bool", model)
end
-- PC:0xBF94DD42F63BDED2 Old:0x328E6FF5
function VEHICLE.IS_THIS_MODEL_A_BICYCLE(model)
  return Velora.invoke(0xB1B670,"bool", model)
end
-- PC:0x39DAC362EE65FA28 Old:0xC1625277
function VEHICLE.IS_THIS_MODEL_A_QUADBIKE(model)
  return Velora.invoke(0xB1B6F0,"bool", model)
end
function VEHICLE.IS_THIS_MODEL_AN_AMPHIBIOUS_CAR(model)
  return Velora.invoke(0xB1B770,"bool", model)
end
function VEHICLE.IS_THIS_MODEL_AN_AMPHIBIOUS_QUADBIKE(model)
  return Velora.invoke(0xB1B7F0,"bool", model)
end
-- PC:0xA178472EBB8AE60D Old:0x033A9408
function VEHICLE.SET_HELI_BLADES_FULL_SPEED(vehicle)
  Velora.invoke(0xB1B870,"void", vehicle)
end
-- PC:0xFD280B4D7F3ABC4D Old:0x5C7D4EA9
function VEHICLE.SET_HELI_BLADES_SPEED(vehicle, speed)
  Velora.invoke(0xB1B930,"void", vehicle, speed)
end
-- PC:0x99CAD8E7AFDB60FA Old:0x1128A45B
function VEHICLE.FORCE_SUB_THROTTLE_FOR_TIME(vehicle, p1, p2)
  Velora.invoke(0xB1BA10,"void", vehicle, p1, p2)
end
-- PC:0x3750146A28097A82 Old:0x64B70B1D
function VEHICLE.SET_VEHICLE_CAN_BE_TARGETTED(vehicle, state)
  Velora.invoke(0xB1BAA0,"void", vehicle, state)
end
-- PC:0xDBC631F109350B8C Old:0x486C1280
function VEHICLE.SET_DONT_ALLOW_PLAYER_TO_ENTER_VEHICLE_IF_LOCKED_FOR_PLAYER(vehicle, p1)
  Velora.invoke(0xB1BB40,"void", vehicle, p1)
end
-- PC:0x4C7028F78FFD3681 Old:0xC5D94017
function VEHICLE.SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(vehicle, state)
  Velora.invoke(0xB1BC40,"void", vehicle, state)
end
-- PC:0x1AA8A837D2169D94 Old:0x009AB49E
function VEHICLE.SET_VEHICLE_HAS_UNBREAKABLE_LIGHTS(vehicle, toggle)
  Velora.invoke(0xB1BCE0,"void", vehicle, toggle)
end
-- PC:0x2311DD7159F00582 Old:0x758C5E2E
function VEHICLE.SET_VEHICLE_RESPECTS_LOCKS_WHEN_HAS_DRIVER(vehicle, p1)
  Velora.invoke(0xB1BD80,"void", vehicle, p1)
end
function VEHICLE.SET_VEHICLE_CAN_EJECT_PASSENGERS_IF_LOCKED(p0, p1)
  Velora.invoke(0xB1BE20,"void", p0, p1)
end
-- PC:0x8F17BC8BA08DA62B Old:0xFD15C065
function VEHICLE.GET_VEHICLE_DIRT_LEVEL(vehicle)
  return Velora.invoke(0xB1BE70,"float", vehicle)
end
-- PC:0x79D3B596FE44EE8B Old:0x2B39128B
function VEHICLE.SET_VEHICLE_DIRT_LEVEL(vehicle, dirtLevel)
  Velora.invoke(0xB1BEC0,"void", vehicle, dirtLevel)
end
-- PC:0xBCDC5017D3CE1E9E Old:0xDAC523BC
function VEHICLE.GET_DOES_VEHICLE_HAVE_DAMAGE_DECALS(vehicle)
  return Velora.invoke(0xB1BF30,"bool", vehicle)
end
-- PC:0x3E933CFF7B111C22 Old:0xC2385B6F
function VEHICLE.IS_VEHICLE_DOOR_FULLY_OPEN(vehicle, doorId)
  return Velora.invoke(0xB1BF90,"bool", vehicle, doorId)
end
-- PC:0x2497C4717C8B881E Old:0x7FBC86F1
function VEHICLE.SET_VEHICLE_ENGINE_ON(vehicle, value, instantly, disableAutoStart)
  Velora.invoke(0xB1C010,"void", vehicle, value, instantly, disableAutoStart)
end
-- PC:0x8ABA6AF54B942B95 Old:0x48D02A4E
function VEHICLE.SET_VEHICLE_UNDRIVEABLE(vehicle, toggle)
  Velora.invoke(0xB1C040,"void", vehicle, toggle)
end
-- PC:0x5AFEEDD9BB2899D7 Old:0xEFC01CA9
function VEHICLE.SET_VEHICLE_PROVIDES_COVER(vehicle, toggle)
  Velora.invoke(0xB1C110,"void", vehicle, toggle)
end
-- PC:0xF2BFA0430F0A0FCB Old:0x572DD360
function VEHICLE.SET_VEHICLE_DOOR_CONTROL(vehicle, doorId, speed, angle)
  Velora.invoke(0xB1C1B0,"void", vehicle, doorId, speed, angle)
end
-- PC:0xA5A9653A8D2CAF48 Old:0x4EB7BBFC
function VEHICLE.SET_VEHICLE_DOOR_LATCHED(vehicle, doorId, p2, p3, p4)
  Velora.invoke(0xB1C1D0,"void", vehicle, doorId, p2, p3, p4)
end
-- PC:0xFE3F9C29F7B32BD5 Old:0x0E399C26
function VEHICLE.GET_VEHICLE_DOOR_ANGLE_RATIO(vehicle, doorId)
  return Velora.invoke(0xB1C200,"float", vehicle, doorId)
end
-- PC:0x218297BF0CFD853B Old:0x0630101F
function VEHICLE.GET_PED_USING_VEHICLE_DOOR(vehicle, doord)
  return Velora.invoke(0xB1C290,"int", vehicle, doord)
end
-- PC:0x93D9BD300D7789E5 Old:0x142606BD
function VEHICLE.SET_VEHICLE_DOOR_SHUT(vehicle, doorId, closeInstantly)
  Velora.invoke(0xB1C2C0,"void", vehicle, doorId, closeInstantly)
end
-- PC:0xD4D4F6A4AB575A33 Old:0x8147FEA7
function VEHICLE.SET_VEHICLE_DOOR_BROKEN(vehicle, doorId, deleteDoor)
  Velora.invoke(0xB1C2E0,"void", vehicle, doorId, deleteDoor)
end
-- PC:0x59BF8C3D52C92F66 Old:0x90A810D1
function VEHICLE.SET_VEHICLE_CAN_BREAK(vehicle, toggle)
  Velora.invoke(0xB1C300,"void", vehicle, toggle)
end
-- PC:0x8AC862B0B32C5B80 Old:0xDB817403
function VEHICLE.DOES_VEHICLE_HAVE_ROOF(vehicle)
  return Velora.invoke(0xB1C370,"bool", vehicle)
end
function VEHICLE.SET_VEHICLE_REMOVE_AGGRESSIVE_CARJACK_MISSION(p0)
  Velora.invoke(0xB1C3D0,"void", p0)
end
function VEHICLE.SET_VEHICLE_AVOID_PLAYER_VEHICLE_RIOT_VAN_MISSION(p0)
  Velora.invoke(0xB1C420,"void", p0)
end
function VEHICLE.SET_CARJACK_MISSION_REMOVAL_PARAMETERS(p0, p1)
  Velora.invoke(0xB1C470,"void", p0, p1)
end
-- PC:0x9F243D3919F442FE Old:0x9CDBA8DE
function VEHICLE.IS_BIG_VEHICLE(vehicle)
  return Velora.invoke(0xB1C490,"bool", vehicle)
end
-- PC:0x3B963160CD65D41E Old:0xF2442EE2
function VEHICLE.GET_NUMBER_OF_VEHICLE_COLOURS(vehicle)
  return Velora.invoke(0xB1C4F0,"int", vehicle)
end
-- PC:0x33E8CD3322E2FE31 Old:0xA557AEAD
function VEHICLE.SET_VEHICLE_COLOUR_COMBINATION(vehicle, colorCombination)
  Velora.invoke(0xB1C560,"void", vehicle, colorCombination)
end
-- PC:0x6A842D197F845D56 Old:0x77AC1B4C
function VEHICLE.GET_VEHICLE_COLOUR_COMBINATION(vehicle)
  return Velora.invoke(0xB1C570,"int", vehicle)
end
function VEHICLE.SET_VEHICLE_XENON_LIGHT_COLOR_INDEX(vehicle, colorIndex)
  Velora.invoke(0xB1C590,"void", vehicle, colorIndex)
end
function VEHICLE.GET_VEHICLE_XENON_LIGHT_COLOR_INDEX(vehicle)
  return Velora.invoke(0xB1C5E0,"int", vehicle)
end
-- PC:0x31B927BBC44156CD Old:0x14413319
function VEHICLE.SET_VEHICLE_IS_CONSIDERED_BY_PLAYER(vehicle, toggle)
  Velora.invoke(0xB1C640,"void", vehicle, toggle)
end
-- PC:0xBE5C1255A1830FF5 Old:0xA6D8D7A5
function VEHICLE.SET_VEHICLE_WILL_FORCE_OTHER_VEHICLES_TO_STOP(vehicle, toggle)
  Velora.invoke(0xB1C6E0,"void", vehicle, toggle)
end
-- PC:0x9BECD4B9FEF3F8A6 Old:0xACAB8FF3
function VEHICLE.SET_VEHICLE_ACT_AS_IF_HAS_SIREN_ON(vehicle, p1)
  Velora.invoke(0xB1C780,"void", vehicle, p1)
end
-- PC:0x88BC673CA9E0AE99 Old:0xF0E5C41D
function VEHICLE.SET_VEHICLE_USE_MORE_RESTRICTIVE_SPAWN_CHECKS(vehicle, p1)
  Velora.invoke(0xB1C7E0,"void", vehicle, p1)
end
-- PC:0xE851E480B814D4BA Old:0x2F98B4B7
function VEHICLE.SET_VEHICLE_MAY_BE_USED_BY_GOTO_POINT_ANY_MEANS(vehicle, p1)
  Velora.invoke(0xB1C840,"void", vehicle, p1)
end
-- PC:0x055BF0AC0C34F4FD Old:0xE2C45631
function VEHICLE.GET_RANDOM_VEHICLE_MODEL_IN_MEMORY(p0)
  Velora.invoke(0xB1C8B0,"void", p0)
end
-- PC:0x25BC98A59C2EA962 Old:0x0D72CEF2
function VEHICLE.GET_VEHICLE_DOOR_LOCK_STATUS(vehicle)
  return Velora.invoke(0xB1C8C0,"int", vehicle)
end
function VEHICLE.GET_VEHICLE_INDIVIDUAL_DOOR_LOCK_STATUS(vehicle, doorId)
  return Velora.invoke(0xB1C910,"int", vehicle, doorId)
end
-- PC:0xB8E181E559464527 Old:0x4999E3C3
function VEHICLE.IS_VEHICLE_DOOR_DAMAGED(veh, doorID)
  return Velora.invoke(0xB1C980,"bool", veh, doorID)
end
-- PC:0x2FA133A4A9D37ED8 Old:0x065B92B3
function VEHICLE.SET_DOOR_ALLOWED_TO_BE_BROKEN_OFF(vehicle, doorId, isBreakable)
  Velora.invoke(0xB1CA10,"void", vehicle, doorId, isBreakable)
end
-- PC:0x27B926779DEB502D Old:0xB3A2CC4F
function VEHICLE.IS_VEHICLE_BUMPER_BOUNCING(vehicle, frontBumper)
  return Velora.invoke(0xB1CAA0,"bool", vehicle, frontBumper)
end
-- PC:0x468056A6BB6F3846 Old:0xAF25C027
function VEHICLE.IS_VEHICLE_BUMPER_BROKEN_OFF(vehicle, frontBumper)
  return Velora.invoke(0xB1CB30,"bool", vehicle, frontBumper)
end
-- PC:0x7EEF65D5F153E26A Old:0xFB16C6D1
function VEHICLE.IS_COP_VEHICLE_IN_AREA_3D(x1, x2, y1, y2, z1, z2)
  return Velora.invoke(0xB1CB60,"bool", x1, x2, y1, y2, z1, z2)
end
-- PC:0xB104CD1BABF302E2 Old:0x10089F8E
function VEHICLE.IS_VEHICLE_ON_ALL_WHEELS(vehicle)
  return Velora.invoke(0xB1CC10,"bool", vehicle)
end
-- PC:0x5873C14A52D74236 Old:0x58FEFC3D
function VEHICLE.GET_VEHICLE_MODEL_VALUE(vehicleModel)
  return Velora.invoke(0xB1CC70,"int", vehicleModel)
end
-- PC:0x28D37D4F71AC5C58 Old:0xE0B35187
function VEHICLE.GET_VEHICLE_LAYOUT_HASH(vehicle)
  return Velora.invoke(0xB1CC90,"int", vehicle)
end
function VEHICLE.GET_IN_VEHICLE_CLIPSET_HASH_FOR_SEAT(vehicle, p1)
  return Velora.invoke(0xB1CCF0,"int", vehicle, p1)
end
-- PC:0x317B11A312DF5534 Old:0x899D9092
function VEHICLE.SET_RENDER_TRAIN_AS_DERAILED(train, toggle)
  Velora.invoke(0xB1CD70,"void", train, toggle)
end
-- PC:0x2036F561ADD12E33 Old:0x515DB2A0
function VEHICLE.SET_VEHICLE_EXTRA_COLOURS(vehicle, pearlescentColor, wheelColor)
  Velora.invoke(0xB1CD90,"void", vehicle, pearlescentColor, wheelColor)
end
-- PC:0x3BC4245933A166F7 Old:0x80E4659B
function VEHICLE.GET_VEHICLE_EXTRA_COLOURS(vehicle)
  Velora.invoke(0xB1CE30,"void", vehicle)
end
function VEHICLE.SET_VEHICLE_EXTRA_COLOUR_5(vehicle, color)
  Velora.invoke(0xB1CE90,"void", vehicle, color)
end
function VEHICLE.GET_VEHICLE_EXTRA_COLOUR_5(vehicle)
  Velora.invoke(0xB1CF00,"void", vehicle)
end
function VEHICLE.SET_VEHICLE_EXTRA_COLOUR_6(vehicle, color)
  Velora.invoke(0xB1CF50,"void", vehicle, color)
end
function VEHICLE.GET_VEHICLE_EXTRA_COLOUR_6(vehicle)
  Velora.invoke(0xB1CFC0,"void", vehicle)
end
-- PC:0x0F87E938BDF29D66 Old:0x17A0BCE5
function VEHICLE.STOP_ALL_GARAGE_ACTIVITY()
  Velora.invoke(0xB1D010,"void")
end
-- PC:0x115722B1B9C14C1C Old:0x17469AA1
function VEHICLE.SET_VEHICLE_FIXED(vehicle)
  Velora.invoke(0xB1D020,"void", vehicle)
end
-- PC:0x953DA1E1B12C0491 Old:0xDD2920C8
function VEHICLE.SET_VEHICLE_DEFORMATION_FIXED(vehicle)
  Velora.invoke(0xB1D090,"void", vehicle)
end
-- PC:0x206BC5DC9D1AC70A Old:0x8EACBD13
function VEHICLE.SET_VEHICLE_CAN_ENGINE_MISSFIRE(vehicle, toggle)
  Velora.invoke(0xB1D0E0,"void", vehicle, toggle)
end
-- PC:0x51BB2D88D31A914B Old:0x88F0F7E7
function VEHICLE.SET_VEHICLE_CAN_LEAK_OIL(vehicle, toggle)
  Velora.invoke(0xB1D190,"void", vehicle, toggle)
end
-- PC:0x192547247864DFDD Old:0x90D6EE57
function VEHICLE.SET_VEHICLE_CAN_LEAK_PETROL(vehicle, toggle)
  Velora.invoke(0xB1D240,"void", vehicle, toggle)
end
-- PC:0x465BF26AB9684352 Old:0xC40192B5
function VEHICLE.SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(vehicle, toggle)
  Velora.invoke(0xB1D2F0,"void", vehicle, toggle)
end
-- PC:0x37C8252A7C92D017 Old:0xAD3E05F2
function VEHICLE.SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(vehicle, toggle)
  Velora.invoke(0xB1D3A0,"void", vehicle, toggle)
end
-- PC:0x91A0BD635321F145 Old:0x1784BA1A
function VEHICLE.SET_DISABLE_VEHICLE_ENGINE_FIRES(vehicle, toggle)
  Velora.invoke(0xB1D450,"void", vehicle, toggle)
end
-- PC:0xC50CE861B55EAB8B Old:0x40C323AE
function VEHICLE.SET_VEHICLE_LIMIT_SPEED_WHEN_PLAYER_INACTIVE(vehicle, toggle)
  Velora.invoke(0xB1D500,"void", vehicle, toggle)
end
-- PC:0x6EBFB22D646FFC18 Old:0x847F1304
function VEHICLE.SET_VEHICLE_STOP_INSTANTLY_WHEN_PLAYER_INACTIVE(vehicle, toggle)
  Velora.invoke(0xB1D5B0,"void", vehicle, toggle)
end
-- PC:0x25367DE49D64CF16 Old:0xCBD98BA1
function VEHICLE.SET_DISABLE_PRETEND_OCCUPANTS(vehicle, toggle)
  Velora.invoke(0xB1D650,"void", vehicle, toggle)
end
-- PC:0x46A1E1A299EC4BBA Old:0x42CC15E0
function VEHICLE.REMOVE_VEHICLES_FROM_GENERATORS_IN_AREA(x1, y1, z1, x2, y2, z2, p6)
  Velora.invoke(0xB1D700,"void", x1, y1, z1, x2, y2, z2, p6)
end
-- PC:0x42A8EC77D5150CBE Old:0x7357C1EB
function VEHICLE.SET_VEHICLE_STEER_BIAS(vehicle, value)
  Velora.invoke(0xB1D720,"void", vehicle, value)
end
-- PC:0xD2E6822DBFD6C8BD Old:0x042098B5
function VEHICLE.IS_VEHICLE_EXTRA_TURNED_ON(vehicle, extraId)
  return Velora.invoke(0xB1D770,"bool", vehicle, extraId)
end
-- PC:0x7EE3A3C5E4A40CC9 Old:0x642D065C
function VEHICLE.SET_VEHICLE_EXTRA(vehicle, extraId, disable)
  Velora.invoke(0xB1D7E0,"void", vehicle, extraId, disable)
end
-- PC:0x1262D55792428154 Old:0x409411CC
function VEHICLE.DOES_EXTRA_EXIST(vehicle, extraId)
  return Velora.invoke(0xB1D800,"bool", vehicle, extraId)
end
function VEHICLE.IS_EXTRA_BROKEN_OFF(vehicle, extraId)
  return Velora.invoke(0xB1D880,"bool", vehicle, extraId)
end
-- PC:0xF39C4F538B5124C2 Old:0xC87B6A51
function VEHICLE.SET_CONVERTIBLE_ROOF(vehicle, p1)
  Velora.invoke(0xB1D930,"void", vehicle, p1)
end
-- PC:0xDED51F703D0FA83D Old:0xC5F72EAE
function VEHICLE.LOWER_CONVERTIBLE_ROOF(vehicle, instantlyLower)
  Velora.invoke(0xB1D9A0,"void", vehicle, instantlyLower)
end
-- PC:0x8F5FB35D7E88FC70 Old:0xA4E4CBA3
function VEHICLE.RAISE_CONVERTIBLE_ROOF(vehicle, instantlyRaise)
  Velora.invoke(0xB1D9F0,"void", vehicle, instantlyRaise)
end
-- PC:0xF8C397922FC03F41 Old:0x1B09714D
function VEHICLE.GET_CONVERTIBLE_ROOF_STATE(vehicle)
  return Velora.invoke(0xB1DA40,"int", vehicle)
end
-- PC:0x52F357A30698BCCE Old:0x6EF54490
function VEHICLE.IS_VEHICLE_A_CONVERTIBLE(vehicle, p1)
  return Velora.invoke(0xB1DAA0,"bool", vehicle, p1)
end
-- PC:0xBE4C854FFDB6EEBE Old:0xCAFE5FE0
function VEHICLE.TRANSFORM_TO_SUBMARINE(vehicle, noAnimation)
  return Velora.invoke(0xB1DB20,"bool", vehicle, noAnimation)
end
-- PC:0x2A69FFD1B42BFF9E Old:0xD8B90941
function VEHICLE.TRANSFORM_TO_CAR(vehicle, noAnimation)
  Velora.invoke(0xB1DB70,"void", vehicle, noAnimation)
end
-- PC:0xA77DC70BD689A1E5 Old:0xE2FF06DB
function VEHICLE.IS_VEHICLE_IN_SUBMARINE_MODE(vehicle)
  return Velora.invoke(0xB1DBC0,"bool", vehicle)
end
-- PC:0x2959F696AE390A99 Old:0x69200FA4
function VEHICLE.IS_VEHICLE_STOPPED_AT_TRAFFIC_LIGHTS(vehicle)
  return Velora.invoke(0xB1DC20,"bool", vehicle)
end
-- PC:0xA1DD317EA8FD4F29 Old:0x21B458B2
function VEHICLE.SET_VEHICLE_DAMAGE(vehicle, xOffset, yOffset, zOffset, damage, radius, focusOnModel)
  Velora.invoke(0xB1DCC0,"void", vehicle, xOffset, yOffset, zOffset, damage, radius, focusOnModel)
end
function VEHICLE.SET_VEHICLE_OCCUPANTS_TAKE_EXPLOSIVE_DAMAGE(vehicle, toggle)
  Velora.invoke(0xB1DCF0,"void", vehicle, toggle)
end
-- PC:0xC45D23BAF168AAB8 Old:0x8880038A
function VEHICLE.GET_VEHICLE_ENGINE_HEALTH(vehicle)
  return Velora.invoke(0xB1DD40,"float", vehicle)
end
-- PC:0x45F6D8EEF34ABEF1 Old:0x1B760FB5
function VEHICLE.SET_VEHICLE_ENGINE_HEALTH(vehicle, health)
  Velora.invoke(0xB1DDA0,"void", vehicle, health)
end
function VEHICLE.SET_PLANE_ENGINE_HEALTH(vehicle, health)
  Velora.invoke(0xB1DEA0,"void", vehicle, health)
end
-- PC:0x7D5DABE888D2D074 Old:0xE41595CE
function VEHICLE.GET_VEHICLE_PETROL_TANK_HEALTH(vehicle)
  return Velora.invoke(0xB1DF40,"float", vehicle)
end
-- PC:0x70DB57649FA8D0D8 Old:0x660A3692
function VEHICLE.SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, health)
  Velora.invoke(0xB1DFA0,"void", vehicle, health)
end
-- PC:0x679BE1DAF71DA874 Old:0x2FCF58C1
function VEHICLE.IS_VEHICLE_STUCK_TIMER_UP(vehicle, p1, ms)
  return Velora.invoke(0xB1DFF0,"bool", vehicle, p1, ms)
end
-- PC:0xD7591B0065AFAA7A Old:0xEF2A6016
function VEHICLE.RESET_VEHICLE_STUCK_TIMER(vehicle, nullAttributes)
  Velora.invoke(0xB1E080,"void", vehicle, nullAttributes)
end
-- PC:0x4C241E39B23DF959 Old:0x41A7267A
function VEHICLE.IS_VEHICLE_DRIVEABLE(vehicle, isOnFireCheck)
  return Velora.invoke(0xB1E0D0,"bool", vehicle, isOnFireCheck)
end
-- PC:0x2B5F9D2AF1F1722D Old:0xB4D3DBFB
function VEHICLE.SET_VEHICLE_HAS_BEEN_OWNED_BY_PLAYER(vehicle, owned)
  Velora.invoke(0xB1E160,"void", vehicle, owned)
end
-- PC:0xFBA550EA44404EE6 Old:0xD8260751
function VEHICLE.SET_VEHICLE_NEEDS_TO_BE_HOTWIRED(vehicle, toggle)
  Velora.invoke(0xB1E200,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_BLIP_THROTTLE_RANDOMLY(vehicle, p1)
  Velora.invoke(0xB1E2A0,"void", vehicle, p1)
end
-- PC:0x4E74E62E0A97E901 Old:0x5690F6C3
function VEHICLE.SET_POLICE_FOCUS_WILL_TRACK_VEHICLE(vehicle, toggle)
  Velora.invoke(0xB1E340,"void", vehicle, toggle)
end
-- PC:0x9C8C6504B5B63D2C Old:0x0DF5ADB3
function VEHICLE.START_VEHICLE_HORN(vehicle, duration, mode, forever)
  Velora.invoke(0xB1E3E0,"void", vehicle, duration, mode, forever)
end
-- PC:0x9D44FCCE98450843 Old:0x968E5770
function VEHICLE.SET_VEHICLE_IN_CAR_MOD_SHOP(vehicle, toggle)
  Velora.invoke(0xB1E4B0,"void", vehicle, toggle)
end
-- PC:0x92F0CF722BC4202F Old:0x0D1CBC65
function VEHICLE.SET_VEHICLE_HAS_STRONG_AXLES(vehicle, toggle)
  Velora.invoke(0xB1E510,"void", vehicle, toggle)
end
-- PC:0x4EC6CFBC7B2E9536 Old:0xABF02075
function VEHICLE.GET_VEHICLE_DEFORMATION_AT_POS(vehicle, offsetX, offsetY, offsetZ)
  local x,y,z=Velora.invoke(0xB1E6B0,"vector3", vehicle, offsetX, offsetY, offsetZ)
  return {x=x,y=y,z=z}
end
-- PC:0x60BF608F1B8CD1B6 Old:0x7AD87059
function VEHICLE.SET_VEHICLE_LIVERY(vehicle, livery)
  Velora.invoke(0xB1E780,"void", vehicle, livery)
end
-- PC:0x2BB9230590DA5E8A Old:0xEC82A51D
function VEHICLE.GET_VEHICLE_LIVERY(vehicle)
  return Velora.invoke(0xB1E7E0,"int", vehicle)
end
-- PC:0x87B63E25A529D526 Old:0xFB0CA947
function VEHICLE.GET_VEHICLE_LIVERY_COUNT(vehicle)
  return Velora.invoke(0xB1E840,"int", vehicle)
end
function VEHICLE.SET_VEHICLE_LIVERY2(vehicle, livery)
  Velora.invoke(0xB1E8A0,"void", vehicle, livery)
end
function VEHICLE.GET_VEHICLE_LIVERY2(vehicle)
  return Velora.invoke(0xB1E900,"int", vehicle)
end
function VEHICLE.GET_VEHICLE_LIVERY2_COUNT(vehicle)
  return Velora.invoke(0xB1E960,"int", vehicle)
end
-- PC:0x46E571A0E20D01F1 Old:0xAC4EF23D
function VEHICLE.IS_VEHICLE_WINDOW_INTACT(vehicle, windowIndex)
  return Velora.invoke(0xB1E9C0,"bool", vehicle, windowIndex)
end
-- PC:0x11D862A3E977A9EF Old:0xBB619744
function VEHICLE.ARE_ALL_VEHICLE_WINDOWS_INTACT(vehicle)
  return Velora.invoke(0xB1EA30,"bool", vehicle)
end
-- PC:0x2D34FC3BC4ADB780 Old:0x648E685A
function VEHICLE.ARE_ANY_VEHICLE_SEATS_FREE(vehicle)
  return Velora.invoke(0xB1EA90,"bool", vehicle)
end
-- PC:0x21D2E5662C1F6FED Old:0xD5FFE779
function VEHICLE.RESET_VEHICLE_WHEELS(vehicle, toggle)
  Velora.invoke(0xB1EB00,"void", vehicle, toggle)
end
-- PC:0xBC74B4BE25EB6C8A Old:0xF4E4C439
function VEHICLE.IS_HELI_PART_BROKEN(vehicle, p1, p2, p3)
  return Velora.invoke(0xB1EB80,"bool", vehicle, p1, p2, p3)
end
-- PC:0xE4CB7541F413D2C5 Old:0xF01E2AAB
function VEHICLE.GET_HELI_MAIN_ROTOR_HEALTH(vehicle)
  return Velora.invoke(0xB1EC30,"float", vehicle)
end
-- PC:0xAE8CE82A4219AC8C Old:0xA41BC13D
function VEHICLE.GET_HELI_TAIL_ROTOR_HEALTH(vehicle)
  return Velora.invoke(0xB1ECB0,"float", vehicle)
end
-- PC:0xAC51915D27E4A5F7 Old:0x8A68388F
function VEHICLE.GET_HELI_TAIL_BOOM_HEALTH(vehicle)
  return Velora.invoke(0xB1ED30,"float", vehicle)
end
function VEHICLE.SET_HELI_MAIN_ROTOR_HEALTH(vehicle, health)
  Velora.invoke(0xB1EDB0,"void", vehicle, health)
end
function VEHICLE.SET_HELI_TAIL_ROTOR_HEALTH(vehicle, health)
  Velora.invoke(0xB1EE10,"void", vehicle, health)
end
-- PC:0x3EC8BF18AA453FE9 Old:0x2916D69B
function VEHICLE.SET_HELI_TAIL_BOOM_CAN_BREAK_OFF(vehicle, toggle)
  return Velora.invoke(0xB1EE70,"bool", vehicle, toggle)
end
-- PC:0xBFDF984E2C22B94F Old:0xA712FF5C
function VEHICLE.SET_VEHICLE_NAME_DEBUG(vehicle, name)
  Velora.invoke(0xB1EEC0,"void", vehicle, name)
end
-- PC:0x71B0892EC081D60A Old:0x38CC692B
function VEHICLE.SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle, toggle)
  Velora.invoke(0xB1EED0,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_EXPLODES_ON_EXPLOSION_DAMAGE_AT_ZERO_BODY_HEALTH(vehicle, toggle)
  Velora.invoke(0xB1EF70,"void", vehicle, toggle)
end
-- PC:0x3441CAD2F2231923 Old:0xC306A9A3
function VEHICLE.SET_ALLOW_VEHICLE_EXPLODES_ON_CONTACT(vehicle, toggle)
  Velora.invoke(0xB1EFC0,"void", vehicle, toggle)
end
-- PC:0x2B6747FAA9DB9D6B Old:0x95A9ACCB
function VEHICLE.SET_VEHICLE_DISABLE_TOWING(vehicle, toggle)
  Velora.invoke(0xB1F060,"void", vehicle, toggle)
end
function VEHICLE.GET_VEHICLE_HAS_LANDING_GEAR(vehicle)
  return Velora.invoke(0xB1F100,"bool", vehicle)
end
-- PC:0xCFC8BE9A5E1FE575 Old:0x24F873FB
function VEHICLE.CONTROL_LANDING_GEAR(vehicle, state)
  Velora.invoke(0xB1F160,"void", vehicle, state)
end
-- PC:0x9B0F3DCA3DB0F4CD Old:0xA6F02670
function VEHICLE.GET_LANDING_GEAR_STATE(vehicle)
  return Velora.invoke(0xB1F1E0,"int", vehicle)
end
-- PC:0x61E1DD6125A3EEE6 Old:0x2867A834
function VEHICLE.IS_ANY_VEHICLE_NEAR_POINT(x, y, z, radius)
  return Velora.invoke(0xB1F260,"bool", x, y, z, radius)
end
-- PC:0xA6E9FDCB2C76785E Old:0x9DA21956
function VEHICLE.REQUEST_VEHICLE_HIGH_DETAIL_MODEL(vehicle)
  Velora.invoke(0xB1F360,"void", vehicle)
end
-- PC:0x00689CDE5F7C6787 Old:0x382BE070
function VEHICLE.REMOVE_VEHICLE_HIGH_DETAIL_MODEL(vehicle)
  Velora.invoke(0xB1F530,"void", vehicle)
end
-- PC:0x1F25887F3C104278 Old:0x55D41928
function VEHICLE.IS_VEHICLE_HIGH_DETAIL(vehicle)
  return Velora.invoke(0xB1F570,"bool", vehicle)
end
-- PC:0x81A15811460FAB3A Old:0x902B4F06
function VEHICLE.REQUEST_VEHICLE_ASSET(vehicleHash, vehicleAsset)
  Velora.invoke(0xB1F5D0,"void", vehicleHash, vehicleAsset)
end
-- PC:0x1BBE0523B8DB9A21 Old:0x8DAAC3CB
function VEHICLE.HAS_VEHICLE_ASSET_LOADED(vehicleAsset)
  return Velora.invoke(0xB1F680,"bool", vehicleAsset)
end
-- PC:0xACE699C71AB9DEB5 Old:0x9620E9C6
function VEHICLE.REMOVE_VEHICLE_ASSET(vehicleAsset)
  Velora.invoke(0xB1F6B0,"void", vehicleAsset)
end
-- PC:0xFE54B92A344583CA Old:0x88236E22
function VEHICLE.SET_VEHICLE_TOW_TRUCK_ARM_POSITION(vehicle, position)
  Velora.invoke(0xB1F730,"void", vehicle, position)
end
-- PC:0x29A16F8D621C4508 Old:0x8151571A
function VEHICLE.ATTACH_VEHICLE_TO_TOW_TRUCK(towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)
  Velora.invoke(0xB1F7E0,"void", towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)
end
-- PC:0xC2DB6B6708350ED8 Old:0xC666CF33
function VEHICLE.DETACH_VEHICLE_FROM_TOW_TRUCK(towTruck, vehicle)
  Velora.invoke(0xB1F800,"void", towTruck, vehicle)
end
-- PC:0xD0E9CE05A1E68CD8 Old:0x3BF93651
function VEHICLE.DETACH_VEHICLE_FROM_ANY_TOW_TRUCK(vehicle)
  return Velora.invoke(0xB1F810,"bool", vehicle)
end
-- PC:0x146DF9EC4C4B9FD4 Old:0x9699CFDC
function VEHICLE.IS_VEHICLE_ATTACHED_TO_TOW_TRUCK(towTruck, vehicle)
  return Velora.invoke(0xB1F840,"bool", towTruck, vehicle)
end
-- PC:0xEFEA18DCF10F8F75 Old:0x11EC7844
function VEHICLE.GET_ENTITY_ATTACHED_TO_TOW_TRUCK(towTruck)
  return Velora.invoke(0xB1F870,"int", towTruck)
end
-- PC:0x8BA6F76BC53A1493 Old:0x4273A8D3
function VEHICLE.SET_VEHICLE_AUTOMATICALLY_ATTACHES(vehicle, p1, p2)
  return Velora.invoke(0xB1F920,"int", vehicle, p1, p2)
end
-- PC:0xF8EBCCC96ADB9FB7 Old:0xED23C8A3
function VEHICLE.SET_VEHICLE_BULLDOZER_ARM_POSITION(vehicle, position, p2)
  Velora.invoke(0xB1F9E0,"void", vehicle, position, p2)
end
-- PC:0x56B94C6D7127DFBA Old:0xB1A52EF7
function VEHICLE.SET_VEHICLE_TANK_TURRET_POSITION(vehicle, position, p2)
  Velora.invoke(0xB1FA00,"void", vehicle, position, p2)
end
function VEHICLE.SET_VEHICLE_TURRET_TARGET(vehicle, p1, x, y, z, p5)
  Velora.invoke(0xB1FA20,"void", vehicle, p1, x, y, z, p5)
end
function VEHICLE.SET_VEHICLE_TANK_STATIONARY(vehicle, p1)
  Velora.invoke(0xB1FA40,"void", vehicle, p1)
end
-- PC:0x1093408B4B9D1146 Old:0xF30C566F
function VEHICLE.SET_VEHICLE_TURRET_SPEED_THIS_FRAME(vehicle, speed)
  Velora.invoke(0xB1FAA0,"void", vehicle, speed)
end
function VEHICLE.DISABLE_VEHICLE_TURRET_MOVEMENT_THIS_FRAME(vehicle)
  Velora.invoke(0xB1FAB0,"void", vehicle)
end
-- PC:0x30D779DE7C4F6DD3 Old:0xA7DF64D7
function VEHICLE.SET_VEHICLE_FLIGHT_NOZZLE_POSITION(vehicle, angleRatio)
  Velora.invoke(0xB1FAC0,"void", vehicle, angleRatio)
end
-- PC:0x9AA47FFF660CB932 Old:0xDD7936F5
function VEHICLE.SET_VEHICLE_FLIGHT_NOZZLE_POSITION_IMMEDIATE(vehicle, angle)
  Velora.invoke(0xB1FB30,"void", vehicle, angle)
end
-- PC:0xDA62027C8BDB326E Old:0xAD40AD55
function VEHICLE.GET_VEHICLE_FLIGHT_NOZZLE_POSITION(plane)
  return Velora.invoke(0xB1FBA0,"float", plane)
end
function VEHICLE.SET_DISABLE_VERTICAL_FLIGHT_MODE_TRANSITION(vehicle, toggle)
  Velora.invoke(0xB1FC10,"void", vehicle, toggle)
end
-- PC:0xA4822F1CF23F4810 Old:0x34E02FCD
function VEHICLE.GENERATE_VEHICLE_CREATION_POS_FROM_PATHS(p1, p3, p4, p5, p6, p7, p8)
  return Velora.invoke(0xB1FC70,"bool", p1, p3, p4, p5, p6, p7, p8)
end
-- PC:0xFB8794444A7D60FB Old:0x9B6EF0EA
function VEHICLE.SET_VEHICLE_BURNOUT(vehicle, toggle)
  Velora.invoke(0xB1FD60,"void", vehicle, toggle)
end
-- PC:0x1297A88E081430EB Old:0x6632BC12
function VEHICLE.IS_VEHICLE_IN_BURNOUT(vehicle)
  return Velora.invoke(0xB1FDC0,"bool", vehicle)
end
-- PC:0x222FF6A823D122E2 Old:0x90D3A0D9
function VEHICLE.SET_VEHICLE_REDUCE_GRIP(vehicle, toggle)
  Velora.invoke(0xB1FE30,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_REDUCE_GRIP_LEVEL(vehicle, val)
  Velora.invoke(0xB1FEB0,"void", vehicle, val)
end
-- PC:0xB5D45264751B7DF0 Old:0xA6073B5D
function VEHICLE.SET_VEHICLE_INDICATOR_LIGHTS(vehicle, turnSignal, toggle)
  Velora.invoke(0xB1FF10,"void", vehicle, turnSignal, toggle)
end
-- PC:0x92B35082E0B42F66 Old:0x6D9BA11E
function VEHICLE.SET_VEHICLE_BRAKE_LIGHTS(vehicle, toggle)
  Velora.invoke(0xB20020,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_TAIL_LIGHTS(vehicle, toggle)
  Velora.invoke(0xB200C0,"void", vehicle, toggle)
end
-- PC:0x684785568EF26A22 Old:0xBA729A25
function VEHICLE.SET_VEHICLE_HANDBRAKE(vehicle, toggle)
  Velora.invoke(0xB20120,"void", vehicle, toggle)
end
-- PC:0xE4E2FD323574965C Old:0x5A36BC37
function VEHICLE.SET_VEHICLE_BRAKE(vehicle, toggle)
  Velora.invoke(0xB201F0,"void", vehicle, toggle)
end
-- PC:0x48ADC8A773564670 Old:0x37BC6ACB
function VEHICLE.INSTANTLY_FILL_VEHICLE_POPULATION()
  Velora.invoke(0xB20240,"void")
end
-- PC:0x91D6DD290888CBAB Old:0x71D898EF
function VEHICLE.HAS_INSTANT_FILL_VEHICLE_POPULATION_FINISHED()
  return Velora.invoke(0xB20250,"bool")
end
-- PC:0x51DB102F4A3BA5E0 Old:0x0B0523B0
function VEHICLE.NETWORK_ENABLE_EMPTY_CROWDING_VEHICLES_REMOVAL(toggle)
  Velora.invoke(0xB20270,"void", toggle)
end
function VEHICLE.NETWORK_CAP_EMPTY_CROWDING_VEHICLES_REMOVAL(p0)
  Velora.invoke(0xB20290,"void", p0)
end
-- PC:0x1CDD6BADC297830D Old:0xAE84D758
function VEHICLE.GET_VEHICLE_TRAILER_VEHICLE(vehicle)
  return Velora.invoke(0xB202A0,"bool", vehicle)
end
-- PC:0xCAC66558B944DA67 Old:0x0B200CE2
function VEHICLE.SET_VEHICLE_USES_LARGE_REAR_RAMP(vehicle, toggle)
  Velora.invoke(0xB203E0,"void", vehicle, toggle)
end
-- PC:0x09606148B6C71DEF Old:0x3FAC3CD4
function VEHICLE.SET_VEHICLE_RUDDER_BROKEN(vehicle, toggle)
  Velora.invoke(0xB20480,"void", vehicle, toggle)
end
-- PC:0x1A78AD3D8240536F Old:0x0858678C
function VEHICLE.SET_CONVERTIBLE_ROOF_LATCH_STATE(vehicle, state)
  Velora.invoke(0xB20600,"void", vehicle, state)
end
-- PC:0x53AF99BAA671CA47 Old:0x7D1A0616
function VEHICLE.GET_VEHICLE_ESTIMATED_MAX_SPEED(vehicle)
  return Velora.invoke(0xB20660,"float", vehicle)
end
-- PC:0xAD7E85FC227197C4 Old:0x03B926F6
function VEHICLE.GET_VEHICLE_MAX_BRAKING(vehicle)
  return Velora.invoke(0xB20690,"float", vehicle)
end
-- PC:0xA132FB5370554DB0 Old:0x7E5A1587
function VEHICLE.GET_VEHICLE_MAX_TRACTION(vehicle)
  return Velora.invoke(0xB206C0,"float", vehicle)
end
-- PC:0x5DD35C8D074E57AE Old:0x00478321
function VEHICLE.GET_VEHICLE_ACCELERATION(vehicle)
  return Velora.invoke(0xB206F0,"float", vehicle)
end
-- PC:0xF417C2502FFFED43 Old:0x8F291C4A
function VEHICLE.GET_VEHICLE_MODEL_ESTIMATED_MAX_SPEED(modelHash)
  return Velora.invoke(0xB20720,"float", modelHash)
end
-- PC:0xDC53FD41B4ED944C Old:0x7EF02883
function VEHICLE.GET_VEHICLE_MODEL_MAX_BRAKING(modelHash)
  return Velora.invoke(0xB207D0,"float", modelHash)
end
-- PC:0xBFBA3BA79CFF7EBF Old:0xF3A7293F
function VEHICLE.GET_VEHICLE_MODEL_MAX_BRAKING_MAX_MODS(modelHash)
  return Velora.invoke(0xB208A0,"float", modelHash)
end
-- PC:0x539DE94D44FDFD0D Old:0x7F985597
function VEHICLE.GET_VEHICLE_MODEL_MAX_TRACTION(modelHash)
  return Velora.invoke(0xB20980,"float", modelHash)
end
-- PC:0x8C044C5C84505B6A Old:0x29CB3537
function VEHICLE.GET_VEHICLE_MODEL_ACCELERATION(modelHash)
  return Velora.invoke(0xB20A60,"float", modelHash)
end
-- PC:0x53409B5163D5B846 Old:0x37FBA7BC
function VEHICLE.GET_VEHICLE_MODEL_ACCELERATION_MAX_MODS(modelHash)
  return Velora.invoke(0xB20B20,"float", modelHash)
end
-- PC:0xC6AD107DDC9054CC Old:0x95BB67EB
function VEHICLE.GET_FLYING_VEHICLE_MODEL_AGILITY(modelHash)
  return Velora.invoke(0xB20B50,"float", modelHash)
end
-- PC:0x5AA3F878A178C4FC Old:0x87C5D271
function VEHICLE.GET_BOAT_VEHICLE_MODEL_AGILITY(modelHash)
  return Velora.invoke(0xB20B80,"float", modelHash)
end
-- PC:0x00C09F246ABEDD82 Old:0xCE67162C
function VEHICLE.GET_VEHICLE_CLASS_ESTIMATED_MAX_SPEED(vehicleClass)
  return Velora.invoke(0xB20C40,"float", vehicleClass)
end
-- PC:0xDBC86D85C5059461 Old:0x5B4FDC16
function VEHICLE.GET_VEHICLE_CLASS_MAX_TRACTION(vehicleClass)
  return Velora.invoke(0xB20C70,"float", vehicleClass)
end
-- PC:0x4F930AD022D6DE3B Old:0x45F2BD83
function VEHICLE.GET_VEHICLE_CLASS_MAX_AGILITY(vehicleClass)
  return Velora.invoke(0xB20CB0,"float", vehicleClass)
end
-- PC:0x2F83E7E45D9EA7AE Old:0x3E220A9B
function VEHICLE.GET_VEHICLE_CLASS_MAX_ACCELERATION(vehicleClass)
  return Velora.invoke(0xB20CF0,"float", vehicleClass)
end
-- PC:0x4BF54C16EC8FEC03 Old:0xD08CC1A5
function VEHICLE.GET_VEHICLE_CLASS_MAX_BRAKING(vehicleClass)
  return Velora.invoke(0xB20D30,"float", vehicleClass)
end
-- PC:0x2CE544C68FB812A0 Old:0xD6685803
function VEHICLE.ADD_ROAD_NODE_SPEED_ZONE(x, y, z, radius, speed, p5)
  return Velora.invoke(0xB20D70,"int", x, y, z, radius, speed, p5)
end
-- PC:0x1033371FC8E842A7 Old:0x0C0332A6
function VEHICLE.REMOVE_ROAD_NODE_SPEED_ZONE(speedzone)
  return Velora.invoke(0xB20E20,"bool", speedzone)
end
-- PC:0x87E7F24270732CB1 Old:0x6574041D
function VEHICLE.OPEN_BOMB_BAY_DOORS(vehicle)
  Velora.invoke(0xB20E60,"void", vehicle)
end
-- PC:0x3556041742A0DC74 Old:0xF8EC5751
function VEHICLE.CLOSE_BOMB_BAY_DOORS(vehicle)
  Velora.invoke(0xB20EE0,"void", vehicle)
end
function VEHICLE.GET_ARE_BOMB_BAY_DOORS_OPEN(aircraft)
  return Velora.invoke(0xB20F60,"bool", aircraft)
end
-- PC:0xC0F97FCE55094987 Old:0xADAF3513
function VEHICLE.IS_VEHICLE_SEARCHLIGHT_ON(vehicle)
  return Velora.invoke(0xB20FF0,"bool", vehicle)
end
-- PC:0x14E85C5EE7A4D542 Old:0xE2C0DD8A
function VEHICLE.SET_VEHICLE_SEARCHLIGHT(heli, toggle, canBeUsedByAI)
  Velora.invoke(0xB210C0,"void", heli, toggle, canBeUsedByAI)
end
function VEHICLE.DOES_VEHICLE_HAVE_SEARCHLIGHT(vehicle)
  return Velora.invoke(0xB210E0,"bool", vehicle)
end
-- PC:0x639431E895B9AA57 Old:0xAB0E79EB
function VEHICLE.IS_ENTRY_POINT_FOR_SEAT_CLEAR(ped, vehicle, seatIndex, side, onEnter)
  return Velora.invoke(0xB21190,"bool", ped, vehicle, seatIndex, side, onEnter)
end
function VEHICLE.GET_ENTRY_POINT_POSITION(vehicle, doorId)
  local x,y,z=Velora.invoke(0xB211D0,"vector3", vehicle, doorId)
  return {x=x,y=y,z=z}
end
-- PC:0x30785D90C956BF35 Old:0xB3EB01ED
function VEHICLE.CAN_SHUFFLE_SEAT(vehicle, seatIndex)
  return Velora.invoke(0xB212B0,"bool", vehicle, seatIndex)
end
-- PC:0x33F2E3FE70EAAE1D Old:0xE4903AA0
function VEHICLE.GET_NUM_MOD_KITS(vehicle)
  return Velora.invoke(0xB21360,"int", vehicle)
end
-- PC:0x1F2AA07F00B3217A Old:0xB8132158
function VEHICLE.SET_VEHICLE_MOD_KIT(vehicle, modKit)
  Velora.invoke(0xB213C0,"void", vehicle, modKit)
end
-- PC:0x6325D1A044AE510D Old:0x9FE60927
function VEHICLE.GET_VEHICLE_MOD_KIT(vehicle)
  return Velora.invoke(0xB21430,"int", vehicle)
end
-- PC:0xFC058F5121E54C32 Old:0xE5F76765
function VEHICLE.GET_VEHICLE_MOD_KIT_TYPE(vehicle)
  return Velora.invoke(0xB21490,"int", vehicle)
end
-- PC:0xB3ED1BFB4BE636DC Old:0xDA58D7AE
function VEHICLE.GET_VEHICLE_WHEEL_TYPE(vehicle)
  return Velora.invoke(0xB21500,"int", vehicle)
end
-- PC:0x487EB21CC7295BA1 Old:0x64BDAAAD
function VEHICLE.SET_VEHICLE_WHEEL_TYPE(vehicle, WheelType)
  Velora.invoke(0xB21560,"void", vehicle, WheelType)
end
-- PC:0xA551BE18C11A476D Old:0x73722CD9
function VEHICLE.GET_NUM_MOD_COLORS(paintType, p1)
  return Velora.invoke(0xB21600,"int", paintType, p1)
end
-- PC:0x43FEB945EE7F85B8 Old:0xCBE9A54D
function VEHICLE.SET_VEHICLE_MOD_COLOR_1(vehicle, paintType, color, pearlescentColor)
  Velora.invoke(0xB216A0,"void", vehicle, paintType, color, pearlescentColor)
end
-- PC:0x816562BADFDEC83E Old:0xC32613C2
function VEHICLE.SET_VEHICLE_MOD_COLOR_2(vehicle, paintType, color)
  Velora.invoke(0xB21730,"void", vehicle, paintType, color)
end
-- PC:0xE8D65CA700C9A693 Old:0xE625510A
function VEHICLE.GET_VEHICLE_MOD_COLOR_1(vehicle)
  Velora.invoke(0xB217C0,"void", vehicle)
end
-- PC:0x81592BE4E3878728 Old:0x9B76BB8E
function VEHICLE.GET_VEHICLE_MOD_COLOR_2(vehicle)
  Velora.invoke(0xB21870,"void", vehicle)
end
-- PC:0x9A83F5F9963775EF Old:0x112D637A
function VEHICLE.HAVE_VEHICLE_MODS_STREAMED_IN(vehicle)
  return Velora.invoke(0xB21A20,"bool", vehicle)
end
function VEHICLE.IS_VEHICLE_MOD_GEN9_EXCLUSIVE(vehicle, modType, modIndex)
  return Velora.invoke(0xB21A80,"bool", vehicle, modType, modIndex)
end
-- PC:0x6AF0636DDEDCB6DD Old:0xB52E5ED5
function VEHICLE.SET_VEHICLE_MOD(vehicle, modType, modIndex, customTires)
  Velora.invoke(0xB21B10,"void", vehicle, modType, modIndex, customTires)
end
-- PC:0x772960298DA26FDB Old:0xDC520069
function VEHICLE.GET_VEHICLE_MOD(vehicle, modType)
  return Velora.invoke(0xB21BF0,"int", vehicle, modType)
end
-- PC:0xB3924ECD70E095DC Old:0xC1B92003
function VEHICLE.GET_VEHICLE_MOD_VARIATION(vehicle, modType)
  return Velora.invoke(0xB21CD0,"int", vehicle, modType)
end
-- PC:0xE38E9162A2500646 Old:0x8A814FF9
function VEHICLE.GET_NUM_VEHICLE_MODS(vehicle, modType)
  return Velora.invoke(0xB21DA0,"int", vehicle, modType)
end
-- PC:0x92D619E420858204 Old:0x9CC80A43
function VEHICLE.REMOVE_VEHICLE_MOD(vehicle, modType)
  Velora.invoke(0xB21E40,"void", vehicle, modType)
end
-- PC:0x2A1F4F37F95BAD08 Old:0xD095F811
function VEHICLE.TOGGLE_VEHICLE_MOD(vehicle, modType, toggle)
  Velora.invoke(0xB21F10,"void", vehicle, modType, toggle)
end
-- PC:0x84B233A8C8FC8AE7 Old:0xF0E1689F
function VEHICLE.IS_TOGGLE_MOD_ON(vehicle, modType)
  return Velora.invoke(0xB21FA0,"bool", vehicle, modType)
end
-- PC:0x90A38E9838E0A8C1 Old:0x73AE5505
function VEHICLE.GET_VEHICLE_MOD_MODIFIER_VALUE(vehicle, modType, modIndex)
  return Velora.invoke(0xB221F0,"int", vehicle, modType, modIndex)
end
-- PC:0x4593CF82AA179706 Old:0x94850968
function VEHICLE.GET_VEHICLE_MOD_IDENTIFIER_HASH(vehicle, modType, modIndex)
  return Velora.invoke(0xB22220,"int", vehicle, modType, modIndex)
end
-- PC:0x758F49C24925568A Old:0x6EA5F4A8
function VEHICLE.PRELOAD_VEHICLE_MOD(vehicle, modType, modIndex)
  Velora.invoke(0xB22250,"void", vehicle, modType, modIndex)
end
-- PC:0x06F43E5175EB6D96 Old:0xA8A0D246
function VEHICLE.HAS_PRELOAD_MODS_FINISHED(vehicle)
  return Velora.invoke(0xB222F0,"bool", vehicle)
end
-- PC:0x445D79F995508307 Old:0xD442521F
function VEHICLE.RELEASE_PRELOAD_MODS(vehicle)
  Velora.invoke(0xB22350,"void", vehicle)
end
-- PC:0xB5BA80F839791C0F Old:0x3EDEC0DB
function VEHICLE.SET_VEHICLE_TYRE_SMOKE_COLOR(vehicle, r, g, b)
  Velora.invoke(0xB223A0,"void", vehicle, r, g, b)
end
-- PC:0xB635392A4938B3C3 Old:0x75280015
function VEHICLE.GET_VEHICLE_TYRE_SMOKE_COLOR(vehicle)
  Velora.invoke(0xB22400,"void", vehicle)
end
-- PC:0x57C51E6BAD752696 Old:0x497C8787
function VEHICLE.SET_VEHICLE_WINDOW_TINT(vehicle, tint)
  Velora.invoke(0xB22470,"void", vehicle, tint)
end
-- PC:0x0EE21293DAD47C95 Old:0x13D53892
function VEHICLE.GET_VEHICLE_WINDOW_TINT(vehicle)
  return Velora.invoke(0xB224C0,"int", vehicle)
end
-- PC:0x9D1224004B3A6707 Old:0x625C7B66
function VEHICLE.GET_NUM_VEHICLE_WINDOW_TINTS()
  return Velora.invoke(0xB22530,"int")
end
-- PC:0xF3CC740D36221548 Old:0x03BC8F1B
function VEHICLE.GET_VEHICLE_COLOR(vehicle)
  Velora.invoke(0xB22550,"void", vehicle)
end
-- PC:0xEEBFC7A7EFDC35B4 Old:0x749DEEA2
function VEHICLE.GET_VEHICLE_COLOURS_WHICH_CAN_BE_SET(vehicle)
  return Velora.invoke(0xB22570,"int", vehicle)
end
-- PC:0xE495D1EF4C91FD20 Old:0x7F8C20DD
function VEHICLE.GET_VEHICLE_CAUSE_OF_DESTRUCTION(vehicle)
  return Velora.invoke(0xB22590,"int", vehicle)
end
function VEHICLE.OVERRIDE_PLANE_DAMAGE_THREHSOLD(vehicle, health)
  Velora.invoke(0xB225E0,"void", vehicle, health)
end
-- PC:0x5EF77C9ADD3B11A3 Old:0xA0777943
function VEHICLE.GET_IS_LEFT_VEHICLE_HEADLIGHT_DAMAGED(vehicle)
  return Velora.invoke(0xB22750,"bool", vehicle)
end
-- PC:0xA7ECB73355EB2F20 Old:0xF178390B
function VEHICLE.GET_IS_RIGHT_VEHICLE_HEADLIGHT_DAMAGED(vehicle)
  return Velora.invoke(0xB227D0,"bool", vehicle)
end
function VEHICLE.GET_BOTH_VEHICLE_HEADLIGHTS_DAMAGED(vehicle)
  return Velora.invoke(0xB22850,"bool", vehicle)
end
-- PC:0x93A3996368C94158 Old:0xE943B09C
function VEHICLE.MODIFY_VEHICLE_TOP_SPEED(vehicle, value)
  Velora.invoke(0xB228B0,"void", vehicle, value)
end
function VEHICLE.SET_VEHICLE_MAX_SPEED(vehicle, speed)
  Velora.invoke(0xB228C0,"void", vehicle, speed)
end
-- PC:0x1CF38D529D7441D9 Old:0xDF594D8D
function VEHICLE.SET_VEHICLE_STAYS_FROZEN_WHEN_CLEANED_UP(vehicle, toggle)
  Velora.invoke(0xB22910,"void", vehicle, toggle)
end
-- PC:0x1F9FB66F3A3842D2 Old:0x4D840FC4
function VEHICLE.SET_VEHICLE_ACT_AS_IF_HIGH_SPEED_FOR_FRAG_SMASHING(vehicle, p1)
  Velora.invoke(0xB229B0,"void", vehicle, p1)
end
function VEHICLE.SET_PEDS_CAN_FALL_OFF_THIS_VEHICLE_FROM_LARGE_FALL_DAMAGE(vehicle, toggle, p2)
  Velora.invoke(0xB22A40,"void", vehicle, toggle, p2)
end
-- PC:0x54B0F614960F4A5F Old:0x5AB26C2B
function VEHICLE.ADD_VEHICLE_COMBAT_ANGLED_AVOIDANCE_AREA(p0, p1, p2, p3, p4, p5, p6)
  return Velora.invoke(0xB22B10,"int", p0, p1, p2, p3, p4, p5, p6)
end
-- PC:0xE30524E1871F481D Old:0xEF05F807
function VEHICLE.REMOVE_VEHICLE_COMBAT_AVOIDANCE_AREA(p0)
  Velora.invoke(0xB22BB0,"void", p0)
end
-- PC:0x291E373D483E7EE7 Old:0xD656E7E5
function VEHICLE.IS_ANY_PED_RAPPELLING_FROM_HELI(vehicle)
  return Velora.invoke(0xB22BF0,"bool", vehicle)
end
-- PC:0xB59E4BD37AE292DB Old:0x642DA5AA
function VEHICLE.SET_VEHICLE_CHEAT_POWER_INCREASE(vehicle, value)
  Velora.invoke(0xB22C20,"void", vehicle, value)
end
-- PC:0x0AD9E8F87FF7C16F Old:0x04F5546C
function VEHICLE.SET_VEHICLE_INFLUENCES_WANTED_LEVEL(p0, p1)
  Velora.invoke(0xB22C70,"void", p0, p1)
end
-- PC:0xF7EC25A3EBEEC726 Old:0xDAA388E8
function VEHICLE.SET_VEHICLE_IS_WANTED(vehicle, state)
  Velora.invoke(0xB22D00,"void", vehicle, state)
end
-- PC:0xF488C566413B4232 Old:0xA25CCB8C
function VEHICLE.SWING_BOAT_BOOM_TO_RATIO(vehicle, ratio)
  Velora.invoke(0xB22DA0,"void", vehicle, ratio)
end
-- PC:0xC1F981A6F74F0C23 Old:0x00966934
function VEHICLE.SWING_BOAT_BOOM_FREELY(vehicle, toggle)
  Velora.invoke(0xB22E40,"void", vehicle, toggle)
end
-- PC:0x0F3B4D4E43177236 Old:0x113DF5FD
function VEHICLE.ALLOW_BOAT_BOOM_TO_ANIMATE(vehicle, toggle)
  Velora.invoke(0xB22EE0,"void", vehicle, toggle)
end
-- PC:0x6636C535F6CC2725 Old:0x7C8D6464
function VEHICLE.GET_BOAT_BOOM_POSITION_RATIO(vehicle)
  return Velora.invoke(0xB22F80,"float", vehicle)
end
-- PC:0x23428FC53C60919C Old:0x7E84C45C
function VEHICLE.DISABLE_PLANE_AILERON(vehicle, p1, p2)
  Velora.invoke(0xB23020,"void", vehicle, p1, p2)
end
-- PC:0xAE31E7DF9B5B132E Old:0x7DC6D022
function VEHICLE.GET_IS_VEHICLE_ENGINE_RUNNING(vehicle)
  return Velora.invoke(0xB230A0,"bool", vehicle)
end
-- PC:0x1D97D1E3A70A649F Old:0xA03E42DF
function VEHICLE.SET_VEHICLE_USE_ALTERNATE_HANDLING(vehicle, toggle)
  Velora.invoke(0xB23100,"void", vehicle, toggle)
end
-- PC:0x9CFA4896C3A53CBB Old:0x15D40761
function VEHICLE.SET_BIKE_ON_STAND(vehicle, x, y)
  Velora.invoke(0xB231C0,"void", vehicle, x, y)
end
-- PC:0xAB04325045427AAE Old:0x1984F88D
function VEHICLE.SET_VEHICLE_NOT_STEALABLE_AMBIENTLY(vehicle, p1)
  Velora.invoke(0xB23240,"void", vehicle, p1)
end
-- PC:0xCFD778E7904C255E Old:0x3FBE904F
function VEHICLE.LOCK_DOORS_WHEN_NO_LONGER_NEEDED(vehicle)
  Velora.invoke(0xB232E0,"void", vehicle)
end
-- PC:0xACFB2463CC22BED2 Old:0xD1B71A25
function VEHICLE.SET_LAST_DRIVEN_VEHICLE(vehicle)
  Velora.invoke(0xB23330,"void", vehicle)
end
-- PC:0xB2D06FAEDE65B577 Old:0xFEB0C0C8
function VEHICLE.GET_LAST_DRIVEN_VEHICLE()
  return Velora.invoke(0xB23380,"int")
end
-- PC:0xE01903C47C7AC89E Old:0x07186AD9
function VEHICLE.CLEAR_LAST_DRIVEN_VEHICLE()
  Velora.invoke(0xB233B0,"void")
end
-- PC:0x02398B627547189C Old:0x08CD58F9
function VEHICLE.SET_VEHICLE_HAS_BEEN_DRIVEN_FLAG(vehicle, toggle)
  Velora.invoke(0xB233C0,"void", vehicle, toggle)
end
-- PC:0xB893215D8D4C015B Old:0x8C4B63E2
function VEHICLE.SET_TASK_VEHICLE_GOTO_PLANE_MIN_HEIGHT_ABOVE_TERRAIN(plane, height)
  Velora.invoke(0xB23460,"void", plane, height)
end
-- PC:0x93AE6A61BE015BF1 Old:0x569E5AE3
function VEHICLE.SET_VEHICLE_LOD_MULTIPLIER(vehicle, multiplier)
  Velora.invoke(0xB23470,"void", vehicle, multiplier)
end
-- PC:0x428BACCDF5E26EAD Old:0x1604C2F5
function VEHICLE.SET_VEHICLE_CAN_SAVE_IN_GARAGE(vehicle, toggle)
  Velora.invoke(0xB234C0,"void", vehicle, toggle)
end
-- PC:0x42A4BEB35D372407 Old:0x8CDB0C09
function VEHICLE.GET_VEHICLE_NUM_OF_BROKEN_OFF_PARTS(vehicle)
  return Velora.invoke(0xB23560,"int", vehicle)
end
-- PC:0x2C8CBFE1EA5FC631 Old:0xABC99E21
function VEHICLE.GET_VEHICLE_NUM_OF_BROKEN_LOOSEN_PARTS(vehicle)
  return Velora.invoke(0xB235C0,"int", vehicle)
end
-- PC:0x4D9D109F63FEE1D4 Old:0x900C878C
function VEHICLE.SET_FORCE_VEHICLE_ENGINE_DAMAGE_BY_BULLET(p0, p1)
  Velora.invoke(0xB23620,"void", p0, p1)
end
-- PC:0x279D50DE5652D935 Old:0xB3200F72
function VEHICLE.SET_VEHICLE_GENERATES_ENGINE_SHOCKING_EVENTS(vehicle, toggle)
  Velora.invoke(0xB236C0,"void", vehicle, toggle)
end
-- PC:0xE44A982368A4AF23 Old:0xBAE491C7
function VEHICLE.COPY_VEHICLE_DAMAGES(sourceVehicle, targetVehicle)
  Velora.invoke(0xB23760,"void", sourceVehicle, targetVehicle)
end
-- PC:0xF25E02CB9C5818F8 Old:0xF0E59BC1
function VEHICLE.DISABLE_VEHICLE_EXPLOSION_BREAK_OFF_PARTS()
  Velora.invoke(0xB237F0,"void")
end
-- PC:0xBC3CCA5844452B06 Old:0x929801C6
function VEHICLE.SET_LIGHTS_CUTOFF_DISTANCE_TWEAK(distance)
  Velora.invoke(0xB23800,"void", distance)
end
-- PC:0x74CD9A9327A282EA Old:0x2343FFDF
function VEHICLE.SET_VEHICLE_SHOOT_AT_TARGET(driver, entity, xTarget, yTarget, zTarget)
  Velora.invoke(0xB23820,"void", driver, entity, xTarget, yTarget, zTarget)
end
-- PC:0x8F5EBAB1F260CFCE Old:0x4A557117
function VEHICLE.GET_VEHICLE_LOCK_ON_TARGET(vehicle)
  return Velora.invoke(0xB23840,"bool", vehicle)
end
-- PC:0x97CE68CB032583F0 Old:0xE0FC6A32
function VEHICLE.SET_FORCE_HD_VEHICLE(vehicle, toggle)
  Velora.invoke(0xB238B0,"void", vehicle, toggle)
end
-- PC:0x182F266C2D9E2BEB Old:0x7D0DE7EA
function VEHICLE.SET_VEHICLE_CUSTOM_PATH_NODE_STREAMING_RADIUS(vehicle, p1)
  Velora.invoke(0xB23950,"void", vehicle, p1)
end
-- PC:0x9CCC9525BF2408E0 Old:0x65CA9286
function VEHICLE.GET_VEHICLE_PLATE_TYPE(vehicle)
  return Velora.invoke(0xB239B0,"int", vehicle)
end
-- PC:0x64473AEFDCF47DCA Old:0x78122DC1
function VEHICLE.TRACK_VEHICLE_VISIBILITY(vehicle)
  Velora.invoke(0xB23A10,"void", vehicle)
end
-- PC:0xAA0A52D24FB98293 Old:0x7E0D6056
function VEHICLE.IS_VEHICLE_VISIBLE(vehicle)
  return Velora.invoke(0xB23A50,"bool", vehicle)
end
-- PC:0x89F149B6131E57DA Old:0x07B2A6DC
function VEHICLE.SET_VEHICLE_GRAVITY(vehicle, toggle)
  Velora.invoke(0xB23AC0,"void", vehicle, toggle)
end
-- PC:0xE6C0C80B8C867537 Old:0xD2B8ACBD
function VEHICLE.SET_ENABLE_VEHICLE_SLIPSTREAMING(toggle)
  Velora.invoke(0xB23B20,"void", toggle)
end
function VEHICLE.SET_VEHICLE_SLIPSTREAMING_SHOULD_TIME_OUT(toggle)
  Velora.invoke(0xB23B40,"void", toggle)
end
-- PC:0x36492C2F0D134C56 Old:0xA4A75FCF
function VEHICLE.GET_VEHICLE_CURRENT_TIME_IN_SLIP_STREAM(vehicle)
  return Velora.invoke(0xB23B60,"float", vehicle)
end
function VEHICLE.IS_VEHICLE_PRODUCING_SLIP_STREAM(vehicle)
  return Velora.invoke(0xB23BB0,"bool", vehicle)
end
-- PC:0x06582AFF74894C75 Old:0x50F89338
function VEHICLE.SET_VEHICLE_INACTIVE_DURING_PLAYBACK(vehicle, toggle)
  Velora.invoke(0xB23C10,"void", vehicle, toggle)
end
-- PC:0xDFFCEF48E511DB48 Old:0xEB7D7C27
function VEHICLE.SET_VEHICLE_ACTIVE_DURING_PLAYBACK(vehicle, toggle)
  Velora.invoke(0xB23D20,"void", vehicle, toggle)
end
-- PC:0x8D474C8FAEFF6CDE Old:0x5EB00A6A
function VEHICLE.IS_VEHICLE_SPRAYABLE(vehicle)
  return Velora.invoke(0xB23DC0,"bool", vehicle)
end
-- PC:0x983765856F2564F9 Old:0x081DAC12
function VEHICLE.SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle, toggle)
  Velora.invoke(0xB23E20,"void", vehicle, toggle)
end
-- PC:0xF0E4BA16D1DB546C Old:0x5BD8D82D
function VEHICLE.DISABLE_VEHCILE_DYNAMIC_AMBIENT_SCALES(vehicle, p1, p2)
  Velora.invoke(0xB23ED0,"void", vehicle, p1, p2)
end
-- PC:0xF87D9F2301F7D206 Old:0x450AD03A
function VEHICLE.ENABLE_VEHICLE_DYNAMIC_AMBIENT_SCALES(vehicle)
  Velora.invoke(0xB23F50,"void", vehicle)
end
-- PC:0x4198AB0022B15F87 Old:0xBD085DCA
function VEHICLE.IS_PLANE_LANDING_GEAR_INTACT(plane)
  return Velora.invoke(0xB23F90,"bool", plane)
end
-- PC:0x755D6D5267CBBD7E Old:0xABBDD5C6
function VEHICLE.ARE_PLANE_PROPELLERS_INTACT(plane)
  return Velora.invoke(0xB24010,"bool", plane)
end
function VEHICLE.SET_PLANE_PROPELLER_HEALTH(plane, health)
  return Velora.invoke(0xB24080,"bool", plane, health)
end
-- PC:0x0CDDA42F9E360CA6 Old:0x9B581DE7
function VEHICLE.SET_VEHICLE_CAN_DEFORM_WHEELS(vehicle, toggle)
  Velora.invoke(0xB240F0,"void", vehicle, toggle)
end
-- PC:0x4AF9BD80EEBEB453 Old:0x20B61DDE
function VEHICLE.IS_VEHICLE_STOLEN(vehicle)
  return Velora.invoke(0xB241A0,"bool", vehicle)
end
-- PC:0x67B2C79AA7FF5738 Old:0x70912E42
function VEHICLE.SET_VEHICLE_IS_STOLEN(vehicle, isStolen)
  Velora.invoke(0xB24200,"void", vehicle, isStolen)
end
-- PC:0xAD2D28A1AFDFF131 Old:0xED159AE6
function VEHICLE.SET_PLANE_TURBULENCE_MULTIPLIER(vehicle, multiplier)
  Velora.invoke(0xB24290,"void", vehicle, multiplier)
end
-- PC:0x5991A01434CE9677 Old:0xAF8CB3DF
function VEHICLE.ARE_WINGS_OF_PLANE_INTACT(plane)
  return Velora.invoke(0xB24310,"bool", plane)
end
-- PC:0xB264C4D2F2B0A78B Old:0x45F72495
function VEHICLE.ALLOW_AMBIENT_VEHICLES_TO_AVOID_ADVERSE_CONDITIONS(vehicle)
  Velora.invoke(0xB243A0,"void", vehicle)
end
-- PC:0x0E21D3DF1051399D Old:0x83D3D331
function VEHICLE.DETACH_VEHICLE_FROM_CARGOBOB(vehicle, cargobob)
  Velora.invoke(0xB243B0,"void", vehicle, cargobob)
end
-- PC:0xADF7BE450512C12F Old:0x50E0EABE
function VEHICLE.DETACH_VEHICLE_FROM_ANY_CARGOBOB(vehicle)
  return Velora.invoke(0xB243C0,"bool", vehicle)
end
function VEHICLE.DETACH_ENTITY_FROM_CARGOBOB(cargobob, entity)
  return Velora.invoke(0xB24420,"bool", cargobob, entity)
end
-- PC:0xD40148F22E81A1D9 Old:0x5DEEC76C
function VEHICLE.IS_VEHICLE_ATTACHED_TO_CARGOBOB(cargobob, vehicleAttached)
  return Velora.invoke(0xB24430,"bool", cargobob, vehicleAttached)
end
-- PC:0x873B82D42AC2B9E5 Old:0x301A1D24
function VEHICLE.GET_VEHICLE_ATTACHED_TO_CARGOBOB(cargobob)
  return Velora.invoke(0xB24460,"int", cargobob)
end
function VEHICLE.GET_ENTITY_ATTACHED_TO_CARGOBOB(p0)
  return Velora.invoke(0xB24480,"int", p0)
end
-- PC:0x4127F1D84E347769 Old:0x607DC9D5
function VEHICLE.ATTACH_VEHICLE_TO_CARGOBOB(vehicle, cargobob, p2, x, y, z)
  Velora.invoke(0xB244A0,"void", vehicle, cargobob, p2, x, y, z)
end
-- PC:0xA1DD82F3CCF9A01E Old:0xAEB29F98
function VEHICLE.ATTACH_ENTITY_TO_CARGOBOB(p0, p1, p2, p3, p4, p5)
  Velora.invoke(0xB244C0,"void", p0, p1, p2, p3, p4, p5)
end
-- PC:0x571FEB383F629926 Old:0x49949FDA
function VEHICLE.SET_CARGOBOB_FORCE_DONT_DETACH_VEHICLE(cargobob, toggle)
  Velora.invoke(0xB244E0,"void", cargobob, toggle)
end
function VEHICLE.SET_CARGOBOB_EXCLUDE_FROM_PICKUP_ENTITY(p0, p1)
  Velora.invoke(0xB24500,"void", p0, p1)
end
function VEHICLE.CAN_CARGOBOB_PICK_UP_ENTITY(p0, p1)
  return Velora.invoke(0xB24510,"bool", p0, p1)
end
-- PC:0xCBDB9B923CACC92D Old:0xE6633DCF
function VEHICLE.GET_ATTACHED_PICK_UP_HOOK_POSITION(cargobob)
  local x,y,z=Velora.invoke(0xB24540,"vector3", cargobob)
  return {x=x,y=y,z=z}
end
-- PC:0x1821D91AD4B56108 Old:0xAF769B81
function VEHICLE.DOES_CARGOBOB_HAVE_PICK_UP_ROPE(cargobob)
  return Velora.invoke(0xB246A0,"bool", cargobob)
end
-- PC:0x7BEB0C7A235F6F3B Old:0x4D3C9A99
function VEHICLE.CREATE_PICK_UP_ROPE_FOR_CARGOBOB(cargobob, state)
  Velora.invoke(0xB24750,"void", cargobob, state)
end
-- PC:0x9768CF648F54C804 Old:0xA8211EE9
function VEHICLE.REMOVE_PICK_UP_ROPE_FOR_CARGOBOB(cargobob)
  Velora.invoke(0xB24760,"void", cargobob)
end
-- PC:0x877C1EAEAC531023 Old:0x3A8AB081
function VEHICLE.SET_PICKUP_ROPE_LENGTH_FOR_CARGOBOB(cargobob, length1, length2, p3)
  Velora.invoke(0xB247C0,"void", cargobob, length1, length2, p3)
end
function VEHICLE.SET_PICKUP_ROPE_LENGTH_WITHOUT_CREATING_ROPE_FOR_CARGOBOB(p0, p1, p2)
  Velora.invoke(0xB247E0,"void", p0, p1, p2)
end
-- PC:0xCF1182F682F65307 Old:0x7D927E1B
function VEHICLE.SET_CARGOBOB_PICKUP_ROPE_DAMPING_MULTIPLIER(p0, p1)
  Velora.invoke(0xB24800,"void", p0, p1)
end
-- PC:0x0D5F65A8F4EBDAB5 Old:0xF258ADA1
function VEHICLE.SET_CARGOBOB_PICKUP_ROPE_TYPE(p0, p1)
  Velora.invoke(0xB24810,"void", p0, p1)
end
-- PC:0x6E08BF5B3722BAC9 Old:0x4778CA0A
function VEHICLE.DOES_CARGOBOB_HAVE_PICKUP_MAGNET(cargobob)
  return Velora.invoke(0xB24870,"bool", cargobob)
end
-- PC:0x9A665550F8DA349B Old:0xF57066DA
function VEHICLE.SET_CARGOBOB_PICKUP_MAGNET_ACTIVE(cargobob, isActive)
  Velora.invoke(0xB24920,"void", cargobob, isActive)
end
-- PC:0xBCBFCD9D1DAC19E2 Old:0xCC3CF97D
function VEHICLE.SET_CARGOBOB_PICKUP_MAGNET_STRENGTH(cargobob, strength)
  Velora.invoke(0xB24940,"void", cargobob, strength)
end
function VEHICLE.SET_CARGOBOB_PICKUP_MAGNET_FALLOFF(cargobob, p1)
  Velora.invoke(0xB249F0,"void", cargobob, p1)
end
function VEHICLE.SET_CARGOBOB_PICKUP_MAGNET_REDUCED_STRENGTH(cargobob, p1)
  Velora.invoke(0xB24AA0,"void", cargobob, p1)
end
function VEHICLE.SET_CARGOBOB_PICKUP_MAGNET_REDUCED_FALLOFF(cargobob, p1)
  Velora.invoke(0xB24B50,"void", cargobob, p1)
end
-- PC:0xED8286F71A819BAA Old:0x8191BC1A
function VEHICLE.SET_CARGOBOB_PICKUP_MAGNET_PULL_STRENGTH(cargobob, p1)
  Velora.invoke(0xB24C00,"void", cargobob, p1)
end
function VEHICLE.SET_CARGOBOB_PICKUP_MAGNET_PULL_ROPE_LENGTH(vehicle, p1)
  Velora.invoke(0xB24CB0,"void", vehicle, p1)
end
function VEHICLE.SET_CARGOBOB_PICKUP_MAGNET_SET_TARGETED_MODE(vehicle, cargobob)
  Velora.invoke(0xB24D60,"void", vehicle, cargobob)
end
-- PC:0x9BDDC73CC6A115D4 Old:0x50CDB295
function VEHICLE.SET_CARGOBOB_PICKUP_MAGNET_SET_AMBIENT_MODE(vehicle, p1, p2)
  Velora.invoke(0xB24D70,"void", vehicle, p1, p2)
end
-- PC:0x56EB5E94318D3FB6 Old:0x30F43FE3
function VEHICLE.SET_CARGOBOB_PICKUP_MAGNET_ENSURE_PICKUP_ENTITY_UPRIGHT(vehicle, p1)
  Velora.invoke(0xB24D90,"void", vehicle, p1)
end
-- PC:0x25ECB9F8017D98E0 Old:0xB2E1E1FB
function VEHICLE.DOES_VEHICLE_HAVE_WEAPONS(vehicle)
  return Velora.invoke(0xB24E30,"bool", vehicle)
end
-- PC:0x2C4A1590ABF43E8B Old:0x2EC19A8B
function VEHICLE.SET_VEHICLE_WILL_TELL_OTHERS_TO_HURRY(vehicle, p1)
  Velora.invoke(0xB24EB0,"void", vehicle, p1)
end
-- PC:0xF4FC6A6F67D8D856 Old:0xA688B7D1
function VEHICLE.DISABLE_VEHICLE_WEAPON(disabled, weaponHash, vehicle, owner)
  Velora.invoke(0xB24F10,"void", disabled, weaponHash, vehicle, owner)
end
function VEHICLE.IS_VEHICLE_WEAPON_DISABLED(weaponHash, vehicle, owner)
  return Velora.invoke(0xB24F30,"bool", weaponHash, vehicle, owner)
end
-- PC:0xE05DD0E9707003A3 Old:0x123E5B90
function VEHICLE.SET_VEHICLE_USED_FOR_PILOT_SCHOOL(vehicle, toggle)
  Velora.invoke(0xB24F60,"void", vehicle, toggle)
end
-- PC:0x21115BCD6E44656A Old:0xEBC225C1
function VEHICLE.SET_VEHICLE_ACTIVE_FOR_PED_NAVIGATION(vehicle, toggle)
  Velora.invoke(0xB25000,"void", vehicle, toggle)
end
-- PC:0x29439776AAA00A62 Old:0xC025338E
function VEHICLE.GET_VEHICLE_CLASS(vehicle)
  return Velora.invoke(0xB250C0,"int", vehicle)
end
-- PC:0xDEDF1C8BD47C2200 Old:0xEA469980
function VEHICLE.GET_VEHICLE_CLASS_FROM_NAME(modelHash)
  return Velora.invoke(0xB25120,"int", modelHash)
end
-- PC:0xBCDF8BAF56C87B6A Old:0xDE86447D
function VEHICLE.SET_PLAYERS_LAST_VEHICLE(vehicle)
  Velora.invoke(0xB25190,"void", vehicle)
end
-- PC:0x300504B23BD3B711 Old:0x5130DB1E
function VEHICLE.SET_VEHICLE_CAN_BE_USED_BY_FLEEING_PEDS(vehicle, toggle)
  Velora.invoke(0xB251E0,"void", vehicle, toggle)
end
-- PC:0xE5810AC70602F2F5 Old:0xB6BE07E0
function VEHICLE.SET_AIRCRAFT_PILOT_SKILL_NOISE_SCALAR(vehicle, p1)
  Velora.invoke(0xB25290,"void", vehicle, p1)
end
-- PC:0x068F64F2470F9656 Old:0x4BB5605D
function VEHICLE.SET_VEHICLE_DROPS_MONEY_WHEN_BLOWN_UP(vehicle, toggle)
  Velora.invoke(0xB25330,"void", vehicle, toggle)
end
-- PC:0xB8FBC8B1330CA9B4 Old:0x51E0064F
function VEHICLE.SET_VEHICLE_KEEP_ENGINE_ON_WHEN_ABANDONED(vehicle, toggle)
  Velora.invoke(0xB253B0,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_IMPATIENCE_TIMER(vehicle, p1)
  Velora.invoke(0xB25450,"void", vehicle, p1)
end
function VEHICLE.SET_VEHICLE_HANDLING_OVERRIDE(vehicle, hash)
  Velora.invoke(0xB254A0,"void", vehicle, hash)
end
-- PC:0x79DF7E806202CE01 Old:0xAEF9611C
function VEHICLE.SET_VEHICLE_EXTENDED_REMOVAL_RANGE(vehicle, range)
  Velora.invoke(0xB254F0,"void", vehicle, range)
end
-- PC:0x9007A2F21DC108D4 Old:0x585E49B6
function VEHICLE.SET_VEHICLE_STEERING_BIAS_SCALAR(p0, p1)
  Velora.invoke(0xB25530,"void", p0, p1)
end
-- PC:0x6E0859B530A365CC Old:0x6E67FD35
function VEHICLE.SET_HELI_CONTROL_LAGGING_RATE_SCALAR(helicopter, multiplier)
  Velora.invoke(0xB25590,"void", helicopter, multiplier)
end
-- PC:0x1837AF7C627009BA Old:0x32AFD42E
function VEHICLE.SET_VEHICLE_FRICTION_OVERRIDE(vehicle, friction)
  Velora.invoke(0xB25600,"void", vehicle, friction)
end
-- PC:0xA37B9A517B133349 Old:0x670913A4
function VEHICLE.SET_VEHICLE_WHEELS_CAN_BREAK_OFF_WHEN_BLOW_UP(vehicle, toggle)
  Velora.invoke(0xB25650,"void", vehicle, toggle)
end
-- PC:0xF78F94D60248C737 Old:0x3B51B348
function VEHICLE.ARE_PLANE_CONTROL_PANELS_INTACT(vehicle, p1)
  return Velora.invoke(0xB256F0,"bool", vehicle, p1)
end
-- PC:0xA46413066687A328 Old:0x98A10A86
function VEHICLE.SET_VEHICLE_CEILING_HEIGHT(vehicle, height)
  Velora.invoke(0xB25760,"void", vehicle, height)
end
-- PC:0x5E569EC46EC21CAE Old:0xBC649C49
function VEHICLE.SET_VEHICLE_NO_EXPLOSION_DAMAGE_FROM_DRIVER(vehicle, toggle)
  Velora.invoke(0xB257D0,"void", vehicle, toggle)
end
-- PC:0x6D6AF961B72728AE Old:0x8DD9AA0C
function VEHICLE.CLEAR_VEHICLE_ROUTE_HISTORY(vehicle)
  Velora.invoke(0xB25820,"void", vehicle)
end
-- PC:0x956B409B984D9BF7 Old:0x39E68EDD
function VEHICLE.DOES_VEHICLE_EXIST_WITH_DECORATOR(decorator)
  return Velora.invoke(0xB25870,"int", decorator)
end
function VEHICLE.SET_VEHICLE_AI_CAN_USE_EXCLUSIVE_SEATS(vehicle, toggle)
  Velora.invoke(0xB258A0,"void", vehicle, toggle)
end
-- PC:0xB5C51B5502E85E83 Old:0xAA8BD440
function VEHICLE.SET_VEHICLE_EXCLUSIVE_DRIVER(vehicle, ped, index)
  Velora.invoke(0xB25940,"void", vehicle, ped, index)
end
function VEHICLE.IS_PED_EXCLUSIVE_DRIVER_OF_VEHICLE(ped, vehicle)
  return Velora.invoke(0xB25960,"bool", ped, vehicle)
end
-- PC:0x500873A45724C863 Old:0x004926A3
function VEHICLE.DISABLE_INDIVIDUAL_PLANE_PROPELLER(vehicle, propeller)
  Velora.invoke(0xB25A20,"void", vehicle, propeller)
end
-- PC:0xB055A34527CB8FD7 Old:0xC195803B
function VEHICLE.SET_VEHICLE_FORCE_AFTERBURNER(vehicle, toggle)
  Velora.invoke(0xB25AE0,"void", vehicle, toggle)
end
function VEHICLE.SET_DONT_PROCESS_VEHICLE_GLASS(vehicle, toggle)
  Velora.invoke(0xB25B80,"void", vehicle, toggle)
end
function VEHICLE.SET_DISABLE_WANTED_CONES_RESPONSE(vehicle, toggle)
  Velora.invoke(0xB25BD0,"void", vehicle, toggle)
end
function VEHICLE.SET_USE_DESIRED_Z_CRUISE_SPEED_FOR_LANDING(vehicle, toggle)
  Velora.invoke(0xB25C20,"void", vehicle, toggle)
end
function VEHICLE.SET_ARRIVE_DISTANCE_OVERRIDE_FOR_VEHICLE_PERSUIT_ATTACK(vehicle, p1)
  Velora.invoke(0xB25C70,"void", vehicle, p1)
end
function VEHICLE.SET_VEHICLE_READY_FOR_CLEANUP(p0)
  Velora.invoke(0xB25CC0,"void", p0)
end
-- PC:0xF796359A959DF65D Old:0xB5CC548B
function VEHICLE.SET_DISTANT_CARS_ENABLED(toggle)
  Velora.invoke(0xB25D00,"void", toggle)
end
function VEHICLE.SET_VEHICLE_NEON_COLOUR(vehicle, r, g, b)
  Velora.invoke(0xB25D20,"void", vehicle, r, g, b)
end
function VEHICLE.SET_VEHICLE_NEON_INDEX_COLOUR(vehicle, index)
  Velora.invoke(0xB25DE0,"void", vehicle, index)
end
function VEHICLE.GET_VEHICLE_NEON_COLOUR(vehicle)
  Velora.invoke(0xB25E70,"void", vehicle)
end
function VEHICLE.SET_VEHICLE_NEON_ENABLED(vehicle, index, toggle)
  Velora.invoke(0xB25EF0,"void", vehicle, index, toggle)
end
function VEHICLE.GET_VEHICLE_NEON_ENABLED(vehicle, index)
  return Velora.invoke(0xB25FA0,"bool", vehicle, index)
end
function VEHICLE.SET_AMBIENT_VEHICLE_NEON_ENABLED(p0)
  Velora.invoke(0xB26050,"void", p0)
end
function VEHICLE.SUPPRESS_NEONS_ON_VEHICLE(vehicle, toggle)
  Velora.invoke(0xB26070,"void", vehicle, toggle)
end
function VEHICLE.SET_DISABLE_SUPERDUMMY(vehicle, p1)
  Velora.invoke(0xB260C0,"void", vehicle, p1)
end
function VEHICLE.REQUEST_VEHICLE_DIAL(vehicle)
  Velora.invoke(0xB26150,"void", vehicle)
end
-- PC:0xF271147EB7B40F12 Old:0x2B2FCC28
function VEHICLE.GET_VEHICLE_BODY_HEALTH(vehicle)
  return Velora.invoke(0xB261A0,"float", vehicle)
end
-- PC:0xB77D05AC8C78AADB Old:0x920C2517
function VEHICLE.SET_VEHICLE_BODY_HEALTH(vehicle, value)
  Velora.invoke(0xB26200,"void", vehicle, value)
end
function VEHICLE.GET_VEHICLE_SIZE(vehicle)
  Velora.invoke(0xB26280,"void", vehicle)
end
-- PC:0x53952FD2BAA19F17 Old:0xB73A1486
function VEHICLE.GET_FAKE_SUSPENSION_LOWERING_AMOUNT(vehicle)
  return Velora.invoke(0xB26320,"float", vehicle)
end
function VEHICLE.SET_CAR_HIGH_SPEED_BUMP_SEVERITY_MULTIPLIER(multiplier)
  Velora.invoke(0xB26390,"void", multiplier)
end
function VEHICLE.GET_NUMBER_OF_VEHICLE_DOORS(vehicle)
  return Velora.invoke(0xB263B0,"int", vehicle)
end
function VEHICLE.SET_HYDRAULICS_CONTROL(vehicle, toggle)
  Velora.invoke(0xB26400,"void", vehicle, toggle)
end
function VEHICLE.SET_CAN_ADJUST_GROUND_CLEARANCE(vehicle, p1)
  Velora.invoke(0xB26420,"void", vehicle, p1)
end
-- PC:0xB8EF61207C2393A9 Old:0x196BA503
function VEHICLE.GET_VEHICLE_HEALTH_PERCENTAGE(vehicle, maxEngineHealth, maxPetrolTankHealth, maxBodyHealth, maxMainRotorHealth, maxTailRotorHealth, maxUnkHealth)
  return Velora.invoke(0xB264B0,"float", vehicle, maxEngineHealth, maxPetrolTankHealth, maxBodyHealth, maxMainRotorHealth, maxTailRotorHealth, maxUnkHealth)
end
-- PC:0xD4C4642CB7F50B5D Old:0x575504DE
function VEHICLE.GET_VEHICLE_IS_MERCENARY(vehicle)
  return Velora.invoke(0xB26570,"bool", vehicle)
end
-- PC:0xC361AA040D6637A8 Old:0x819CD954
function VEHICLE.SET_VEHICLE_BROKEN_PARTS_DONT_AFFECT_AI_HANDLING(vehicle, p1)
  Velora.invoke(0xB265D0,"void", vehicle, p1)
end
-- PC:0x99C82F8A139F3E4E Old:0x71CDD52F
function VEHICLE.SET_VEHICLE_KERS_ALLOWED(vehicle, toggle)
  Velora.invoke(0xB26620,"void", vehicle, toggle)
end
-- PC:0x50634E348C8D44EF Old:0x0761E635
function VEHICLE.GET_VEHICLE_HAS_KERS(vehicle)
  return Velora.invoke(0xB26680,"bool", vehicle)
end
-- PC:0xE16142B94664DEFD Old:0xFBBA699A
function VEHICLE.SET_PLANE_RESIST_TO_EXPLOSION(vehicle, toggle)
  Velora.invoke(0xB266E0,"void", vehicle, toggle)
end
function VEHICLE.SET_HELI_RESIST_TO_EXPLOSION(vehicle, toggle)
  Velora.invoke(0xB26780,"void", vehicle, toggle)
end
function VEHICLE.SET_DISABLE_BMX_EXTRA_TRICK_FORCES(p0)
  Velora.invoke(0xB26830,"void", p0)
end
function VEHICLE.SET_HYDRAULIC_SUSPENSION_RAISE_FACTOR(vehicle, wheelId, value)
  Velora.invoke(0xB26850,"void", vehicle, wheelId, value)
end
function VEHICLE.GET_HYDRAULIC_SUSPENSION_RAISE_FACTOR(vehicle, wheelId)
  return Velora.invoke(0xB26870,"float", vehicle, wheelId)
end
function VEHICLE.SET_CAN_USE_HYDRAULICS(vehicle, toggle)
  Velora.invoke(0xB26950,"void", vehicle, toggle)
end
function VEHICLE.SET_HYDRAULIC_VEHICLE_STATE(vehicle, state)
  Velora.invoke(0xB26970,"void", vehicle, state)
end
function VEHICLE.SET_HYDRAULIC_WHEEL_STATE(vehicle, wheelId, state, value, p4)
  Velora.invoke(0xB26980,"void", vehicle, wheelId, state, value, p4)
end
function VEHICLE.HAS_VEHICLE_PETROLTANK_SET_ON_FIRE_BY_ENTITY(p0, p1)
  return Velora.invoke(0xB269A0,"bool", p0, p1)
end
function VEHICLE.CLEAR_VEHICLE_PETROLTANK_FIRE_CULPRIT(vehicle)
  Velora.invoke(0xB26A40,"void", vehicle)
end
function VEHICLE.SET_VEHICLE_BOBBLEHEAD_VELOCITY(x, y, p2)
  Velora.invoke(0xB26AA0,"void", x, y, p2)
end
function VEHICLE.GET_VEHICLE_IS_DUMMY(p0)
  return Velora.invoke(0xB26B00,"bool", p0)
end
function VEHICLE.SET_VEHICLE_DAMAGE_SCALE(vehicle, p1)
  return Velora.invoke(0xB26B60,"bool", vehicle, p1)
end
function VEHICLE.SET_VEHICLE_WEAPON_DAMAGE_SCALE(vehicle, multiplier)
  return Velora.invoke(0xB26C00,"bool", vehicle, multiplier)
end
function VEHICLE.SET_DISABLE_DAMAGE_WITH_PICKED_UP_ENTITY(p0, p1)
  return Velora.invoke(0xB26C50,"bool", p0, p1)
end
function VEHICLE.SET_VEHICLE_USES_MP_PLAYER_DAMAGE_MULTIPLIER(p0, p1)
  Velora.invoke(0xB26CA0,"void", p0, p1)
end
function VEHICLE.SET_BIKE_EASY_TO_LAND(vehicle, toggle)
  Velora.invoke(0xB26CF0,"void", vehicle, toggle)
end
function VEHICLE.SET_INVERT_VEHICLE_CONTROLS(vehicle, state)
  Velora.invoke(0xB26D40,"void", vehicle, state)
end
function VEHICLE.SET_SPEED_BOOST_EFFECT_DISABLED(disabled)
  Velora.invoke(0xB26D90,"void", disabled)
end
function VEHICLE.SET_SLOW_DOWN_EFFECT_DISABLED(disabled)
  Velora.invoke(0xB26DB0,"void", disabled)
end
function VEHICLE.SET_FORMATION_LEADER(vehicle, x, y, z, p4)
  Velora.invoke(0xB26DD0,"void", vehicle, x, y, z, p4)
end
function VEHICLE.RESET_FORMATION_LEADER()
  Velora.invoke(0xB26E70,"void")
end
function VEHICLE.GET_IS_BOAT_CAPSIZED(vehicle)
  return Velora.invoke(0xB26E80,"bool", vehicle)
end
function VEHICLE.SET_ALLOW_RAMMING_SOOP_OR_RAMP(p0, p1)
  Velora.invoke(0xB26EE0,"void", p0, p1)
end
function VEHICLE.SET_SCRIPT_RAMP_IMPULSE_SCALE(vehicle, impulseScale)
  Velora.invoke(0xB26F30,"void", vehicle, impulseScale)
end
function VEHICLE.GET_IS_DOOR_VALID(vehicle, doorId)
  return Velora.invoke(0xB26F80,"bool", vehicle, doorId)
end
function VEHICLE.SET_SCRIPT_ROCKET_BOOST_RECHARGE_TIME(vehicle, seconds)
  Velora.invoke(0xB26FF0,"void", vehicle, seconds)
end
function VEHICLE.GET_HAS_ROCKET_BOOST(vehicle)
  return Velora.invoke(0xB270C0,"bool", vehicle)
end
function VEHICLE.IS_ROCKET_BOOST_ACTIVE(vehicle)
  return Velora.invoke(0xB27120,"bool", vehicle)
end
function VEHICLE.SET_ROCKET_BOOST_ACTIVE(vehicle, active)
  Velora.invoke(0xB27190,"void", vehicle, active)
end
function VEHICLE.GET_HAS_RETRACTABLE_WHEELS(vehicle)
  return Velora.invoke(0xB271B0,"bool", vehicle)
end
function VEHICLE.GET_IS_WHEELS_RETRACTED(vehicle)
  return Velora.invoke(0xB27210,"bool", vehicle)
end
function VEHICLE.SET_WHEELS_EXTENDED_INSTANTLY(vehicle)
  Velora.invoke(0xB27280,"void", vehicle)
end
function VEHICLE.SET_WHEELS_RETRACTED_INSTANTLY(vehicle)
  Velora.invoke(0xB272D0,"void", vehicle)
end
function VEHICLE.GET_CAR_HAS_JUMP(vehicle)
  return Velora.invoke(0xB27320,"bool", vehicle)
end
function VEHICLE.SET_USE_HIGHER_CAR_JUMP(vehicle, toggle)
  Velora.invoke(0xB27380,"void", vehicle, toggle)
end
function VEHICLE.SET_CLEAR_FREEZE_WAITING_ON_COLLISION_ONCE_PLAYER_ENTERS(vehicle, toggle)
  Velora.invoke(0xB273D0,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_WEAPON_RESTRICTED_AMMO(vehicle, weaponIndex, capacity)
  Velora.invoke(0xB27420,"void", vehicle, weaponIndex, capacity)
end
function VEHICLE.GET_VEHICLE_WEAPON_RESTRICTED_AMMO(vehicle, weaponIndex)
  return Velora.invoke(0xB27480,"int", vehicle, weaponIndex)
end
function VEHICLE.GET_VEHICLE_HAS_PARACHUTE(vehicle)
  return Velora.invoke(0xB274E0,"bool", vehicle)
end
function VEHICLE.GET_VEHICLE_CAN_DEPLOY_PARACHUTE(vehicle)
  return Velora.invoke(0xB27550,"bool", vehicle)
end
function VEHICLE.VEHICLE_START_PARACHUTING(vehicle, active)
  Velora.invoke(0xB275C0,"void", vehicle, active)
end
function VEHICLE.IS_VEHICLE_PARACHUTE_DEPLOYED(vehicle)
  return Velora.invoke(0xB27630,"bool", vehicle)
end
function VEHICLE.VEHICLE_SET_RAMP_AND_RAMMING_CARS_TAKE_DAMAGE(vehicle, toggle)
  Velora.invoke(0xB276A0,"void", vehicle, toggle)
end
function VEHICLE.VEHICLE_SET_ENABLE_RAMP_CAR_SIDE_IMPULSE(p0, p1)
  Velora.invoke(0xB27710,"void", p0, p1)
end
function VEHICLE.VEHICLE_SET_ENABLE_NORMALISE_RAMP_CAR_VERTICAL_VELOCTIY(p0, p1)
  Velora.invoke(0xB27770,"void", p0, p1)
end
function VEHICLE.VEHICLE_SET_JET_WASH_FORCE_ENABLED(p0)
  Velora.invoke(0xB277D0,"void", p0)
end
function VEHICLE.SET_VEHICLE_WEAPON_CAN_TARGET_OBJECTS(vehicle, toggle)
  Velora.invoke(0xB277F0,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_USE_BOOST_BUTTON_FOR_WHEEL_RETRACT(toggle)
  Velora.invoke(0xB27840,"void", toggle)
end
function VEHICLE.VEHICLE_SET_PARACHUTE_MODEL_OVERRIDE(vehicle, modelHash)
  Velora.invoke(0xB27880,"void", vehicle, modelHash)
end
function VEHICLE.VEHICLE_SET_PARACHUTE_MODEL_TINT_INDEX(vehicle, textureVariation)
  Velora.invoke(0xB278E0,"void", vehicle, textureVariation)
end
function VEHICLE.VEHICLE_SET_OVERRIDE_EXTENABLE_SIDE_RATIO(p0, p1)
  return Velora.invoke(0xB27970,"int", p0, p1)
end
function VEHICLE.VEHICLE_SET_EXTENABLE_SIDE_TARGET_RATIO(p0, p1)
  return Velora.invoke(0xB27980,"int", p0, p1)
end
function VEHICLE.VEHICLE_SET_OVERRIDE_SIDE_RATIO(p0, p1)
  return Velora.invoke(0xB27990,"int", p0, p1)
end
function VEHICLE.GET_ALL_VEHICLES(vehsStruct)
  return Velora.invoke(0xB279A0,"int", vehsStruct)
end
function VEHICLE.SET_CARGOBOB_EXTA_PICKUP_RANGE(p0, p1)
  Velora.invoke(0xB279D0,"void", p0, p1)
end
function VEHICLE.SET_OVERRIDE_VEHICLE_DOOR_TORQUE(p0, p1, p2)
  Velora.invoke(0xB279E0,"void", p0, p1, p2)
end
function VEHICLE.SET_WHEELIE_ENABLED(vehicle, enabled)
  Velora.invoke(0xB27A60,"void", vehicle, enabled)
end
function VEHICLE.SET_DISABLE_HELI_EXPLODE_FROM_BODY_DAMAGE(p0, p1)
  Velora.invoke(0xB27AB0,"void", p0, p1)
end
function VEHICLE.SET_DISABLE_EXPLODE_FROM_BODY_DAMAGE_ON_COLLISION(vehicle, value)
  Velora.invoke(0xB27B10,"void", vehicle, value)
end
function VEHICLE.SET_TRAILER_ATTACHMENT_ENABLED(p0, p1)
  Velora.invoke(0xB27BB0,"void", p0, p1)
end
function VEHICLE.SET_ROCKET_BOOST_FILL(vehicle, percentage)
  Velora.invoke(0xB27C00,"void", vehicle, percentage)
end
function VEHICLE.SET_GLIDER_ACTIVE(vehicle, state)
  Velora.invoke(0xB27D00,"void", vehicle, state)
end
function VEHICLE.SET_SHOULD_RESET_TURRET_IN_SCRIPTED_CAMERAS(vehicle, shouldReset)
  Velora.invoke(0xB27D60,"void", vehicle, shouldReset)
end
function VEHICLE.SET_VEHICLE_DISABLE_COLLISION_UPON_CREATION(vehicle, disable)
  Velora.invoke(0xB27DB0,"void", vehicle, disable)
end
function VEHICLE.SET_GROUND_EFFECT_REDUCES_DRAG(toggle)
  Velora.invoke(0xB27E40,"void", toggle)
end
function VEHICLE.SET_DISABLE_MAP_COLLISION(vehicle)
  Velora.invoke(0xB27E60,"void", vehicle)
end
function VEHICLE.SET_DISABLE_PED_STAND_ON_TOP(vehicle, toggle)
  Velora.invoke(0xB27ED0,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_DAMAGE_SCALES(vehicle, p1, p2, p3, p4)
  Velora.invoke(0xB27F20,"void", vehicle, p1, p2, p3, p4)
end
function VEHICLE.SET_PLANE_SECTION_DAMAGE_SCALE(vehicle, p1, p2)
  Velora.invoke(0xB27FB0,"void", vehicle, p1, p2)
end
function VEHICLE.SET_HELI_CAN_PICKUP_ENTITY_THAT_HAS_PICK_UP_DISABLED(vehicle, toggle)
  Velora.invoke(0xB28080,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_BOMB_AMMO(vehicle, bombCount)
  Velora.invoke(0xB280D0,"void", vehicle, bombCount)
end
function VEHICLE.GET_VEHICLE_BOMB_AMMO(vehicle)
  return Velora.invoke(0xB28120,"int", vehicle)
end
function VEHICLE.SET_VEHICLE_COUNTERMEASURE_AMMO(vehicle, counterMeasureCount)
  Velora.invoke(0xB28180,"void", vehicle, counterMeasureCount)
end
function VEHICLE.GET_VEHICLE_COUNTERMEASURE_AMMO(vehicle)
  return Velora.invoke(0xB281D0,"int", vehicle)
end
function VEHICLE.SET_HELI_COMBAT_OFFSET(vehicle, x, y, z)
  Velora.invoke(0xB28230,"void", vehicle, x, y, z)
end
function VEHICLE.GET_CAN_VEHICLE_BE_PLACED_HERE(vehicle, x, y, z, rotX, rotY, rotZ, p7, p8)
  return Velora.invoke(0xB282C0,"bool", vehicle, x, y, z, rotX, rotY, rotZ, p7, p8)
end
function VEHICLE.SET_DISABLE_AUTOMATIC_CRASH_TASK(vehicle, toggle)
  Velora.invoke(0xB28300,"void", vehicle, toggle)
end
function VEHICLE.SET_SPECIAL_FLIGHT_MODE_RATIO(vehicle, ratio)
  Velora.invoke(0xB28380,"void", vehicle, ratio)
end
function VEHICLE.SET_SPECIAL_FLIGHT_MODE_TARGET_RATIO(vehicle, targetRatio)
  Velora.invoke(0xB283F0,"void", vehicle, targetRatio)
end
function VEHICLE.SET_SPECIAL_FLIGHT_MODE_ALLOWED(vehicle, toggle)
  Velora.invoke(0xB28460,"void", vehicle, toggle)
end
function VEHICLE.SET_DISABLE_HOVER_MODE_FLIGHT(vehicle, toggle)
  Velora.invoke(0xB284C0,"void", vehicle, toggle)
end
function VEHICLE.GET_OUTRIGGERS_DEPLOYED(vehicle)
  return Velora.invoke(0xB28520,"bool", vehicle)
end
function VEHICLE.FIND_SPAWN_COORDINATES_FOR_HELI(ped)
  local x,y,z=Velora.invoke(0xB28590,"vector3", ped)
  return {x=x,y=y,z=z}
end
function VEHICLE.SET_DEPLOY_FOLDING_WINGS(vehicle, deploy, p2)
  Velora.invoke(0xB28630,"void", vehicle, deploy, p2)
end
function VEHICLE.ARE_FOLDING_WINGS_DEPLOYED(vehicle)
  return Velora.invoke(0xB286A0,"bool", vehicle)
end
function VEHICLE.SET_DIP_STRAIGHT_DOWN_WHEN_CRASHING_PLANE(vehicle, toggle)
  Velora.invoke(0xB287B0,"void", vehicle, toggle)
end
function VEHICLE.SET_TURRET_HIDDEN(vehicle, index, toggle)
  Velora.invoke(0xB28800,"void", vehicle, index, toggle)
end
function VEHICLE.SET_HOVER_MODE_WING_RATIO(vehicle, ratio)
  Velora.invoke(0xB288A0,"void", vehicle, ratio)
end
function VEHICLE.SET_DISABLE_TURRET_MOVEMENT(vehicle, turretId)
  Velora.invoke(0xB28900,"void", vehicle, turretId)
end
function VEHICLE.SET_FORCE_FIX_LINK_MATRICES(vehicle)
  Velora.invoke(0xB28990,"void", vehicle)
end
function VEHICLE.SET_TRANSFORM_RATE_FOR_ANIMATION(vehicle, transformRate)
  Velora.invoke(0xB289D0,"void", vehicle, transformRate)
end
function VEHICLE.SET_TRANSFORM_TO_SUBMARINE_USES_ALTERNATE_INPUT(vehicle, toggle)
  Velora.invoke(0xB28A30,"void", vehicle, toggle)
end
function VEHICLE.SET_VEHICLE_COMBAT_MODE(toggle)
  Velora.invoke(0xB28AA0,"void", toggle)
end
function VEHICLE.SET_VEHICLE_DETONATION_MODE(toggle)
  Velora.invoke(0xB28AB0,"void", toggle)
end
function VEHICLE.SET_VEHICLE_SHUNT_ON_STICK(toggle)
  Velora.invoke(0xB28AC0,"void", toggle)
end
function VEHICLE.GET_IS_VEHICLE_SHUNTING(vehicle)
  return Velora.invoke(0xB28B40,"bool", vehicle)
end
function VEHICLE.GET_HAS_VEHICLE_BEEN_HIT_BY_SHUNT(vehicle)
  return Velora.invoke(0xB28BB0,"bool", vehicle)
end
function VEHICLE.GET_LAST_SHUNT_VEHICLE(vehicle)
  return Velora.invoke(0xB28C20,"int", vehicle)
end
function VEHICLE.SET_DISABLE_VEHICLE_EXPLOSIONS_DAMAGE(toggle)
  Velora.invoke(0xB28C80,"void", toggle)
end
function VEHICLE.SET_OVERRIDE_NITROUS_LEVEL(vehicle, toggle, level, power, rechargeTime, disableSound)
  Velora.invoke(0xB28CA0,"void", vehicle, toggle, level, power, rechargeTime, disableSound)
end
function VEHICLE.SET_INCREASE_WHEEL_CRUSH_DAMAGE(vehicle, toggle)
  Velora.invoke(0xB290A0,"void", vehicle, toggle)
end
function VEHICLE.SET_DISABLE_WEAPON_BLADE_FORCES(toggle)
  Velora.invoke(0xB290F0,"void", toggle)
end
function VEHICLE.SET_USE_DOUBLE_CLICK_FOR_CAR_JUMP(toggle)
  Velora.invoke(0xB29110,"void", toggle)
end
function VEHICLE.GET_DOES_VEHICLE_HAVE_TOMBSTONE(vehicle)
  return Velora.invoke(0xB29130,"bool", vehicle)
end
function VEHICLE.HIDE_TOMBSTONE(vehicle, toggle)
  Velora.invoke(0xB29190,"void", vehicle, toggle)
end
function VEHICLE.GET_IS_VEHICLE_DISABLED_BY_EMP(vehicle)
  return Velora.invoke(0xB29240,"bool", vehicle)
end
function VEHICLE.SET_DISABLE_RETRACTING_WEAPON_BLADES(toggle)
  Velora.invoke(0xB292A0,"void", toggle)
end
function VEHICLE.GET_TYRE_HEALTH(vehicle, wheelIndex)
  return Velora.invoke(0xB292C0,"float", vehicle, wheelIndex)
end
function VEHICLE.SET_TYRE_HEALTH(vehicle, wheelIndex, health)
  Velora.invoke(0xB29340,"void", vehicle, wheelIndex, health)
end
function VEHICLE.GET_TYRE_WEAR_RATE(vehicle, wheelIndex)
  return Velora.invoke(0xB293F0,"float", vehicle, wheelIndex)
end
function VEHICLE.SET_TYRE_WEAR_RATE(vehicle, wheelIndex, multiplier)
  Velora.invoke(0xB29470,"void", vehicle, wheelIndex, multiplier)
end
function VEHICLE.SET_TYRE_WEAR_RATE_SCALE(vehicle, wheelIndex, multiplier)
  Velora.invoke(0xB294F0,"void", vehicle, wheelIndex, multiplier)
end
function VEHICLE.SET_TYRE_MAXIMUM_GRIP_DIFFERENCE_DUE_TO_WEAR_RATE(vehicle, wheelIndex, multiplier)
  Velora.invoke(0xB29560,"void", vehicle, wheelIndex, multiplier)
end
function VEHICLE.SET_AIRCRAFT_IGNORE_HIGHTMAP_OPTIMISATION(vehicle, p1)
  Velora.invoke(0xB295D0,"void", vehicle, p1)
end
function VEHICLE.SET_REDUCED_SUSPENSION_FORCE(vehicle, enable)
  Velora.invoke(0xB29630,"void", vehicle, enable)
end
function VEHICLE.SET_DRIFT_TYRES(vehicle, toggle)
  Velora.invoke(0xB29690,"void", vehicle, toggle)
end
function VEHICLE.GET_DRIFT_TYRES_SET(vehicle)
  return Velora.invoke(0xB296E0,"bool", vehicle)
end
function VEHICLE.NETWORK_USE_HIGH_PRECISION_TRAIN_BLENDING(vehicle, toggle)
  Velora.invoke(0xB29740,"void", vehicle, toggle)
end
function VEHICLE.SET_CHECK_FOR_ENOUGH_ROOM_FOR_PED(vehicle, p1)
  Velora.invoke(0xB297A0,"void", vehicle, p1)
end
