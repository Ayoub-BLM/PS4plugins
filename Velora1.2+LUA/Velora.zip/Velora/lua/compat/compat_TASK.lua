-- compat_TASK.lua — AUTO GENERATO
-- TASK
TASK=TASK or {}
-- PC:0xE73A266DB0CA9042 Old:0x17A64668
function TASK.TASK_PAUSE(ped, ms)
  Velora.invoke(0xAECFF0,"void", ped, ms)
end
-- PC:0x919BE13EED931959 Old:0x6F80965D
function TASK.TASK_STAND_STILL(ped, time)
  Velora.invoke(0xAED060,"void", ped, time)
end
-- PC:0x0AE4086104E067B1 Old:0x0356E3CE
function TASK.TASK_JUMP(ped, usePlayerLaunchForce, doSuperJump, useFullSuperJumpForce)
  Velora.invoke(0xAED0F0,"void", ped, usePlayerLaunchForce, doSuperJump, useFullSuperJumpForce)
end
-- PC:0x3EB1FE9E8E908E15 Old:0x9CF1C19B
function TASK.TASK_COWER(ped, duration)
  Velora.invoke(0xAED170,"void", ped, duration)
end
-- PC:0xF2EAB31979A7F910 Old:0x8DCC19C5
function TASK.TASK_HANDS_UP(ped, duration, facingPed, timeToFacePed, flags)
  Velora.invoke(0xAED1F0,"void", ped, duration, facingPed, timeToFacePed, flags)
end
-- PC:0xA98FCAFD7893C834 Old:0x3AA39BE9
function TASK.UPDATE_TASK_HANDS_UP_DURATION(ped, duration)
  Velora.invoke(0xAED2C0,"void", ped, duration)
end
-- PC:0x965791A9A488A062 Old:0x8EE06BF4
function TASK.TASK_OPEN_VEHICLE_DOOR(ped, vehicle, timeOut, seat, speed)
  Velora.invoke(0xAED320,"void", ped, vehicle, timeOut, seat, speed)
end
-- PC:0xC20E50AA46D09CA8 Old:0xB8689B4E
function TASK.TASK_ENTER_VEHICLE(ped, vehicle, timeout, seat, speed, flag, overrideEntryClipsetName)
  Velora.invoke(0xAED340,"void", ped, vehicle, timeout, seat, speed, flag, overrideEntryClipsetName)
end
-- PC:0xD3DBCE61A490BE02 Old:0x7B1141C6
function TASK.TASK_LEAVE_VEHICLE(ped, vehicle, flags)
  Velora.invoke(0xAED370,"void", ped, vehicle, flags)
end
-- PC:0x9C00E77AF14B2DFF Old:0x4293601F
function TASK.TASK_GET_OFF_BOAT(ped, boat)
  Velora.invoke(0xAED390,"void", ped, boat)
end
-- PC:0x601736CFE536B0A0 Old:0xD3874AFA
function TASK.TASK_SKY_DIVE(ped, instant)
  Velora.invoke(0xAED410,"void", ped, instant)
end
-- PC:0xD2F1C53C97EE81AB Old:0xEC3060A2
function TASK.TASK_PARACHUTE(ped, giveParachuteItem, instant)
  Velora.invoke(0xAED430,"void", ped, giveParachuteItem, instant)
end
-- PC:0xB33E291AFA6BD03A Old:0xE0104D6C
function TASK.TASK_PARACHUTE_TO_TARGET(ped, x, y, z)
  Velora.invoke(0xAED4B0,"void", ped, x, y, z)
end
-- PC:0xC313379AF0FCEDA7 Old:0x6ED3AD81
function TASK.SET_PARACHUTE_TASK_TARGET(ped, x, y, z)
  Velora.invoke(0xAED540,"void", ped, x, y, z)
end
-- PC:0x0729BAC1B8C64317 Old:0xD07C8AAA
function TASK.SET_PARACHUTE_TASK_THRUST(ped, thrust)
  Velora.invoke(0xAED5C0,"void", ped, thrust)
end
-- PC:0x09693B0312F91649 Old:0x2C7ADB93
function TASK.TASK_RAPPEL_FROM_HELI(ped, minHeightAboveGround)
  Velora.invoke(0xAED630,"void", ped, minHeightAboveGround)
end
-- PC:0xE2A2AA2F659D77A7 Old:0xE4AC0387
function TASK.TASK_VEHICLE_DRIVE_TO_COORD(ped, vehicle, x, y, z, speed, p6, vehicleModel, drivingMode, stopRange, straightLineDistance)
  Velora.invoke(0xAED6B0,"void", ped, vehicle, x, y, z, speed, p6, vehicleModel, drivingMode, stopRange, straightLineDistance)
end
-- PC:0x158BB33F920D360C Old:0x1490182A
function TASK.TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE(ped, vehicle, x, y, z, speed, driveMode, stopRange)
  Velora.invoke(0xAED730,"void", ped, vehicle, x, y, z, speed, driveMode, stopRange)
end
-- PC:0x480142959D337D00 Old:0x36EC0EB0
function TASK.TASK_VEHICLE_DRIVE_WANDER(ped, vehicle, speed, drivingStyle)
  Velora.invoke(0xAED750,"void", ped, vehicle, speed, drivingStyle)
end
-- PC:0x304AE42E357B8C7E Old:0x2DF5A6AC
function TASK.TASK_FOLLOW_TO_OFFSET_OF_ENTITY(ped, entity, offsetX, offsetY, offsetZ, movementSpeed, timeout, stoppingRange, persistFollowing)
  Velora.invoke(0xAED820,"void", ped, entity, offsetX, offsetY, offsetZ, movementSpeed, timeout, stoppingRange, persistFollowing)
end
-- PC:0xD76B57B44F1E6F8B Old:0x80A9E7A7
function TASK.TASK_GO_STRAIGHT_TO_COORD(ped, x, y, z, speed, timeout, targetHeading, distanceToSlide)
  Velora.invoke(0xAED850,"void", ped, x, y, z, speed, timeout, targetHeading, distanceToSlide)
end
-- PC:0x61E360B7E040D12E Old:0xD26CAC68
function TASK.TASK_GO_STRAIGHT_TO_COORD_RELATIVE_TO_ENTITY(ped, entity, x, y, z, moveBlendRatio, time)
  Velora.invoke(0xAED880,"void", ped, entity, x, y, z, moveBlendRatio, time)
end
-- PC:0x93B93A37987F1F3D Old:0x0A0E9B42
function TASK.TASK_ACHIEVE_HEADING(ped, heading, timeout)
  Velora.invoke(0xAED8A0,"void", ped, heading, timeout)
end
-- PC:0x841142A1376E9006 Old:0x34219154
function TASK.TASK_FLUSH_ROUTE()
  Velora.invoke(0xAED8C0,"void")
end
-- PC:0x1E7889778264843A Old:0x43271F69
function TASK.TASK_EXTEND_ROUTE(x, y, z)
  Velora.invoke(0xAED8D0,"void", x, y, z)
end
-- PC:0x595583281858626E Old:0xB837C816
function TASK.TASK_FOLLOW_POINT_ROUTE(ped, speed, mode)
  Velora.invoke(0xAED910,"void", ped, speed, mode)
end
-- PC:0x6A071245EB0D1882 Old:0x374827C2
function TASK.TASK_GO_TO_ENTITY(entity, target, duration, distance, moveBlendRatio, slowDownDistance, flags)
  Velora.invoke(0xAED930,"void", entity, target, duration, distance, moveBlendRatio, slowDownDistance, flags)
end
-- PC:0x94587F17E9C365D5 Old:0xB2E686FC
function TASK.TASK_SMART_FLEE_COORD(ped, x, y, z, distance, time, preferPavements, quitIfOutOfRange)
  Velora.invoke(0xAED960,"void", ped, x, y, z, distance, time, preferPavements, quitIfOutOfRange)
end
-- PC:0x22B0D0E37CCB840D Old:0xE52EB560
function TASK.TASK_SMART_FLEE_PED(ped, fleeTarget, safeDistance, fleeTime, preferPavements, updateToNearestHatedPed)
  Velora.invoke(0xAED990,"void", ped, fleeTarget, safeDistance, fleeTime, preferPavements, updateToNearestHatedPed)
end
-- PC:0x72C896464915D1B1 Old:0x8A632BD8
function TASK.TASK_REACT_AND_FLEE_PED(ped, fleeTarget)
  Velora.invoke(0xAED9C0,"void", ped, fleeTarget)
end
-- PC:0x452419CBD838065B Old:0x9BD00ACF
function TASK.TASK_SHOCKING_EVENT_REACT(ped, eventHandle)
  Velora.invoke(0xAED9D0,"void", ped, eventHandle)
end
-- PC:0xE054346CA3A0F315 Old:0xC6981FB9
function TASK.TASK_WANDER_IN_AREA(ped, x, y, z, radius, minimalLength, timeBetweenWalks)
  Velora.invoke(0xAED9E0,"void", ped, x, y, z, radius, minimalLength, timeBetweenWalks)
end
-- PC:0xBB9CE077274F6A1B Old:0xAF59151A
function TASK.TASK_WANDER_STANDARD(ped, heading, flags)
  Velora.invoke(0xAEDAF0,"void", ped, heading, flags)
end
function TASK.TASK_WANDER_SPECIFIC(ped, conditionalAnimGroupStr, conditionalAnimStr, heading)
  Velora.invoke(0xAEDB10,"void", ped, conditionalAnimGroupStr, conditionalAnimStr, heading)
end
-- PC:0x0F3E34E968EA374E Old:0x5C85FF90
function TASK.TASK_VEHICLE_PARK(ped, vehicle, x, y, z, heading, mode, radius, keepEngineOn)
  Velora.invoke(0xAEDB30,"void", ped, vehicle, x, y, z, heading, mode, radius, keepEngineOn)
end
-- PC:0xAA5DC05579D60BD9 Old:0x0D64C2FA
function TASK.TASK_STEALTH_KILL(killer, target, stealthKillActionResultHash, desiredMoveBlendRatio, stealthFlags)
  Velora.invoke(0xAEDB60,"void", killer, target, stealthKillActionResultHash, desiredMoveBlendRatio, stealthFlags)
end
-- PC:0x965FEC691D55E9BF Old:0x33457535
function TASK.TASK_PLANT_BOMB(ped, x, y, z, heading)
  Velora.invoke(0xAEDB80,"void", ped, x, y, z, heading)
end
-- PC:0x15D3A79D4E44B913 Old:0xFE4A10D9
function TASK.TASK_FOLLOW_NAV_MESH_TO_COORD(ped, x, y, z, moveBlendRatio, time, targetRadius, flags, targetHeading)
  Velora.invoke(0xAEDBC0,"void", ped, x, y, z, moveBlendRatio, time, targetRadius, flags, targetHeading)
end
-- PC:0x17F58B88D085DBAC Old:0x6BF6E296
function TASK.TASK_FOLLOW_NAV_MESH_TO_COORD_ADVANCED(ped, x, y, z, moveBlendRatio, time, targetRadius, flags, slideToCoordHeading, maxSlopeNavigable, clampMaxSearchDistance, targetHeading)
  Velora.invoke(0xAD9560,"void", ped, x, y, z, moveBlendRatio, time, targetRadius, flags, slideToCoordHeading, maxSlopeNavigable, clampMaxSearchDistance, targetHeading)
end
-- PC:0x8E06A6FE76C9EFF4 Old:0xB7B7D442
function TASK.SET_PED_PATH_CAN_USE_CLIMBOVERS(ped, Toggle)
  Velora.invoke(0xAEDBF0,"void", ped, Toggle)
end
-- PC:0x77A5B103C87F476E Old:0x53A879EE
function TASK.SET_PED_PATH_CAN_USE_LADDERS(ped, Toggle)
  Velora.invoke(0xAEDC50,"void", ped, Toggle)
end
-- PC:0xE361C5C71C431A4F Old:0x394B7AC9
function TASK.SET_PED_PATH_CAN_DROP_FROM_HEIGHT(ped, Toggle)
  Velora.invoke(0xAEDCB0,"void", ped, Toggle)
end
-- PC:0x88E32DB8C1A4AA4B Old:0x55E06443
function TASK.SET_PED_PATH_CLIMB_COST_MODIFIER(ped, modifier)
  Velora.invoke(0xAEDD10,"void", ped, modifier)
end
-- PC:0xF35425A4204367EC Old:0x9C606EE3
function TASK.SET_PED_PATH_MAY_ENTER_WATER(ped, mayEnterWater)
  Velora.invoke(0xAEDD80,"void", ped, mayEnterWater)
end
-- PC:0x38FE1EC73743793C Old:0x0EA39A29
function TASK.SET_PED_PATH_PREFER_TO_AVOID_WATER(ped, avoidWater)
  Velora.invoke(0xAEDDE0,"void", ped, avoidWater)
end
-- PC:0x4455517B28441E60 Old:0xDCC5B934
function TASK.SET_PED_PATH_AVOID_FIRE(ped, avoidFire)
  Velora.invoke(0xAEDE40,"void", ped, avoidFire)
end
-- PC:0x6C6B148586F934F7 Old:0x2AFB14B8
function TASK.SET_GLOBAL_MIN_BIRD_FLIGHT_HEIGHT(height)
  Velora.invoke(0xAEDEA0,"void", height)
end
-- PC:0xC6F5C0BCDC74D62D Old:0xD9281778
function TASK.GET_NAVMESH_ROUTE_DISTANCE_REMAINING(ped)
  return Velora.invoke(0xAEDED0,"int", ped)
end
-- PC:0x632E831F382A0FA8 Old:0x96491602
function TASK.GET_NAVMESH_ROUTE_RESULT(ped)
  return Velora.invoke(0xAEDFB0,"int", ped)
end
-- PC:0x3E38E28A1D80DDF6 Old:0x54856309
function TASK.IS_CONTROLLED_VEHICLE_UNABLE_TO_GET_TO_ROAD(ped)
  return Velora.invoke(0xAEDFD0,"bool", ped)
end
-- PC:0x5BC448CB78FA3E88 Old:0xF91DF93B
function TASK.TASK_GO_TO_COORD_ANY_MEANS(ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets)
  Velora.invoke(0xAEE050,"void", ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets)
end
-- PC:0x1DD45F9ECFDB1BC9 Old:0x094B75EF
function TASK.TASK_GO_TO_COORD_ANY_MEANS_EXTRA_PARAMS(ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets, extraVehToTargetDistToPreferVehicle, driveStraightLineDistance, extraFlags, warpTimerMS)
  Velora.invoke(0xAEE080,"void", ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets, extraVehToTargetDistToPreferVehicle, driveStraightLineDistance, extraFlags, warpTimerMS)
end
-- PC:0xB8ECD61F531A7B02 Old:0x86DC03F9
function TASK.TASK_GO_TO_COORD_ANY_MEANS_EXTRA_PARAMS_WITH_CRUISE_SPEED(ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets, extraVehToTargetDistToPreferVehicle, driveStraightLineDistance, extraFlags, cruiseSpeed, targetArriveDist)
  Velora.invoke(0xAEE0C0,"void", ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets, extraVehToTargetDistToPreferVehicle, driveStraightLineDistance, extraFlags, cruiseSpeed, targetArriveDist)
end
-- PC:0xEA47FE3719165B94 Old:0x5AB552C6
function TASK.TASK_PLAY_ANIM(ped, animDictionary, animationName, blendInSpeed, blendOutSpeed, duration, flag, playbackRate, lockX, lockY, lockZ)
  Velora.invoke(0xAEE110,"void", ped, animDictionary, animationName, blendInSpeed, blendOutSpeed, duration, flag, playbackRate, lockX, lockY, lockZ)
end
-- PC:0x83CDB10EA29B370B Old:0x3DDEB0E6
function TASK.TASK_PLAY_ANIM_ADVANCED(ped, animDict, animName, posX, posY, posZ, rotX, rotY, rotZ, animEnterSpeed, animExitSpeed, duration, flag, animTime, rotOrder, ikFlags)
  Velora.invoke(0xAEE1A0,"void", ped, animDict, animName, posX, posY, posZ, rotX, rotY, rotZ, animEnterSpeed, animExitSpeed, duration, flag, animTime, rotOrder, ikFlags)
end
-- PC:0x97FF36A1D40EA00A Old:0x2B520A57
function TASK.STOP_ANIM_TASK(entity, animDictionary, animationName, blendDelta)
  Velora.invoke(0xAEE290,"void", entity, animDictionary, animationName, blendDelta)
end
-- PC:0x126EF75F1E17ABE5 Old:0xFC2DCF47
function TASK.TASK_SCRIPTED_ANIMATION(ped, blendInDelta, blendOutDelta)
  Velora.invoke(0xAEE2B0,"void", ped, blendInDelta, blendOutDelta)
end
-- PC:0x77A1EEC547E7FCF1 Old:0x02F72AE5
function TASK.PLAY_ENTITY_SCRIPTED_ANIM(entity, blendInDelta, blendOutDelta)
  Velora.invoke(0xAEE2E0,"void", entity, blendInDelta, blendOutDelta)
end
-- PC:0xEE08C992D238C5D1 Old:0xE5F16398
function TASK.STOP_ANIM_PLAYBACK(entity, priority, secondary)
  Velora.invoke(0xAEE310,"void", entity, priority, secondary)
end
-- PC:0x207F1A47C0342F48 Old:0x17229D98
function TASK.SET_ANIM_WEIGHT(entity, weight, priority, index, secondary)
  Velora.invoke(0xAEE3B0,"void", entity, weight, priority, index, secondary)
end
-- PC:0xDDF3CB5A0A4C0B49 Old:0xB621E7E4
function TASK.SET_ANIM_PHASE(entity, phase, priority, secondary)
  Velora.invoke(0xAEE3D0,"void", entity, phase, priority, secondary)
end
-- PC:0x032D49C5E359C847 Old:0x6DB46584
function TASK.SET_ANIM_RATE(entity, rate, priority, secondary)
  Velora.invoke(0xAEE480,"void", entity, rate, priority, secondary)
end
-- PC:0x70033C3CC29A1FF4 Old:0x095D61A4
function TASK.SET_ANIM_LOOPED(entity, looped, priority, secondary)
  Velora.invoke(0xAEE530,"void", entity, looped, priority, secondary)
end
-- PC:0x8FBB6758B3B3E9EC Old:0x1582162C
function TASK.TASK_PLAY_PHONE_GESTURE_ANIMATION(ped, animDict, animation, boneMaskType, blendInDuration, blendOutDuration, isLooping, holdLastFrame)
  Velora.invoke(0xAEE560,"void", ped, animDict, animation, boneMaskType, blendInDuration, blendOutDuration, isLooping, holdLastFrame)
end
-- PC:0x3FA00D4F4641BFAE Old:0x5A32D4B4
function TASK.TASK_STOP_PHONE_GESTURE_ANIMATION(ped, blendOutOverride)
  Velora.invoke(0xAEE5A0,"void", ped, blendOutOverride)
end
-- PC:0xB8EBB1E9D3588C10 Old:0x500B6805
function TASK.IS_PLAYING_PHONE_GESTURE_ANIM(ped)
  return Velora.invoke(0xAEE620,"bool", ped)
end
-- PC:0x47619ABE8B268C60 Old:0x7B72AFD1
function TASK.GET_PHONE_GESTURE_ANIM_CURRENT_TIME(ped)
  return Velora.invoke(0xAEE6B0,"float", ped)
end
-- PC:0x1EE0F68A7C25DEC6 Old:0xEF8C3959
function TASK.GET_PHONE_GESTURE_ANIM_TOTAL_TIME(ped)
  return Velora.invoke(0xAEE750,"float", ped)
end
-- PC:0x69F5C3BD0F3EBD89 Old:0x2B28F598
function TASK.TASK_VEHICLE_PLAY_ANIM(vehicle, animationSet, animationName)
  Velora.invoke(0xAEE7F0,"void", vehicle, animationSet, animationName)
end
-- PC:0x6FA46612594F7973 Old:0x7B784DD8
function TASK.TASK_LOOK_AT_COORD(entity, x, y, z, duration, flags, priority)
  Velora.invoke(0xAEE810,"void", entity, x, y, z, duration, flags, priority)
end
-- PC:0x69F4BE8C8CC4796C Old:0x991D6619
function TASK.TASK_LOOK_AT_ENTITY(ped, lookAt, duration, flags, priority)
  Velora.invoke(0xAEE830,"void", ped, lookAt, duration, flags, priority)
end
-- PC:0x0F804F1DB19B9689 Old:0x60EB4054
function TASK.TASK_CLEAR_LOOK_AT(ped)
  Velora.invoke(0xAEE850,"void", ped)
end
-- PC:0xE8854A4326B9E12B Old:0xABA6923E
function TASK.OPEN_SEQUENCE_TASK()
  Velora.invoke(0xAEE860,"void")
end
-- PC:0x39E72BC99E6360CB Old:0x1A7CEBD0
function TASK.CLOSE_SEQUENCE_TASK(taskSequenceId)
  Velora.invoke(0xAEE8D0,"void", taskSequenceId)
end
-- PC:0x5ABA3986D90D8A3B Old:0x4D9FBD11
function TASK.TASK_PERFORM_SEQUENCE(ped, taskSequenceId)
  Velora.invoke(0xAEE920,"void", ped, taskSequenceId)
end
function TASK.TASK_PERFORM_SEQUENCE_LOCALLY(ped, taskSequenceId)
  Velora.invoke(0xAEE930,"void", ped, taskSequenceId)
end
-- PC:0x3841422E9C488D8C Old:0x47ED03CE
function TASK.CLEAR_SEQUENCE_TASK()
  Velora.invoke(0xAEE940,"void")
end
-- PC:0x58C70CF3A41E4AE7 Old:0xCDDF1508
function TASK.SET_SEQUENCE_TO_REPEAT(taskSequenceId, p_repeat)
  Velora.invoke(0xAEE980,"void", taskSequenceId, p_repeat)
end
-- PC:0x00A9010CFE1E3533 Old:0xA3419909
function TASK.GET_SEQUENCE_PROGRESS(ped)
  return Velora.invoke(0xAEEA50,"int", ped)
end
-- PC:0xB0760331C7AA4155 Old:0x86FDDF55
function TASK.GET_IS_TASK_ACTIVE(ped, taskIndex)
  return Velora.invoke(0xAEEA70,"bool", ped, taskIndex)
end
-- PC:0x77F1BEB8863288D5 Old:0xB2477B23
function TASK.GET_SCRIPT_TASK_STATUS(ped, taskHash)
  return Velora.invoke(0xAEEB10,"int", ped, taskHash)
end
-- PC:0x534AEBA6E5ED4CAB Old:0xAFA914EF
function TASK.GET_ACTIVE_VEHICLE_MISSION_TYPE(vehicle)
  return Velora.invoke(0xAEEB80,"int", vehicle)
end
-- PC:0x504D54DF3F6F2247 Old:0xDBDD79FA
function TASK.TASK_LEAVE_ANY_VEHICLE(ped, delayTime, flags)
  Velora.invoke(0xAEEBA0,"void", ped, delayTime, flags)
end
-- PC:0x7A192BE16D373D00 Old:0x9D296BCD
function TASK.TASK_AIM_GUN_SCRIPTED(ped, scriptTask, disableBlockingClip, instantBlendToAim)
  Velora.invoke(0xAEEBC0,"void", ped, scriptTask, disableBlockingClip, instantBlendToAim)
end
-- PC:0x8605AF0DE8B3A5AC Old:0xFD517CE3
function TASK.TASK_AIM_GUN_SCRIPTED_WITH_TARGET(ped, target, x, y, z, gunTaskType, disableBlockingClip, forceAim)
  Velora.invoke(0xAEEBF0,"void", ped, target, x, y, z, gunTaskType, disableBlockingClip, forceAim)
end
-- PC:0x9724FB59A3E72AD0 Old:0x67E73525
function TASK.UPDATE_TASK_AIM_GUN_SCRIPTED_TARGET(ped, target, x, y, z, disableBlockingClip)
  Velora.invoke(0xAEEC20,"void", ped, target, x, y, z, disableBlockingClip)
end
-- PC:0x9B53BB6E8943AF53 Old:0xBE32B3B6
function TASK.TASK_AIM_GUN_AT_ENTITY(ped, entity, duration, instantBlendToAim)
  Velora.invoke(0xAEEC80,"void", ped, entity, duration, instantBlendToAim)
end
-- PC:0x5AD23D40115353AC Old:0x3C37C767
function TASK.TASK_TURN_PED_TO_FACE_ENTITY(ped, entity, duration)
  Velora.invoke(0xAEECA0,"void", ped, entity, duration)
end
-- PC:0x6671F3EEC681BDA1 Old:0xFBF44AD3
function TASK.TASK_AIM_GUN_AT_COORD(ped, x, y, z, time, instantBlendToAim, playAnimIntro)
  Velora.invoke(0xAEECC0,"void", ped, x, y, z, time, instantBlendToAim, playAnimIntro)
end
-- PC:0x46A6CC01E0826106 Old:0x601C22E3
function TASK.TASK_SHOOT_AT_COORD(ped, x, y, z, duration, firingPattern)
  Velora.invoke(0xAEECF0,"void", ped, x, y, z, duration, firingPattern)
end
-- PC:0x7AA80209BDA643EB Old:0xBEAF8F67
function TASK.TASK_SHUFFLE_TO_NEXT_VEHICLE_SEAT(ped, vehicle, useAlternateShuffle)
  Velora.invoke(0xAEED10,"void", ped, vehicle, useAlternateShuffle)
end
-- PC:0xE1EF3C1216AFF2CD Old:0xDE3316AB
function TASK.CLEAR_PED_TASKS(ped)
  Velora.invoke(0xAEED30,"void", ped)
end
-- PC:0x176CECF6F920D707 Old:0xA635F451
function TASK.CLEAR_PED_SECONDARY_TASK(ped)
  Velora.invoke(0xAEEDB0,"void", ped)
end
-- PC:0x7F93691AB4B92272 Old:0xC1971F30
function TASK.TASK_EVERYONE_LEAVE_VEHICLE(vehicle)
  Velora.invoke(0xAEEE40,"void", vehicle)
end
-- PC:0xE39B4FF4FDEBDE27 Old:0x1A17A85E
function TASK.TASK_GOTO_ENTITY_OFFSET(ped, entity, time, seekRadius, seekAngleDeg, moveBlendRatio, gotoEntityOffsetFlags)
  Velora.invoke(0xAEEE50,"void", ped, entity, time, seekRadius, seekAngleDeg, moveBlendRatio, gotoEntityOffsetFlags)
end
-- PC:0x338E7EF52B6095A9 Old:0xBC1E3D0A
function TASK.TASK_GOTO_ENTITY_OFFSET_XY(ped, entity, duration, targetRadius, offsetX, offsetY, moveBlendRatio, gotoEntityOffsetFlags)
  Velora.invoke(0xAEEE80,"void", ped, entity, duration, targetRadius, offsetX, offsetY, moveBlendRatio, gotoEntityOffsetFlags)
end
-- PC:0x1DDA930A0AC38571 Old:0x30463D73
function TASK.TASK_TURN_PED_TO_FACE_COORD(ped, x, y, z, duration)
  Velora.invoke(0xAEEEB0,"void", ped, x, y, z, duration)
end
-- PC:0xC429DCEEB339E129 Old:0x0679DFB8
function TASK.TASK_VEHICLE_TEMP_ACTION(driver, vehicle, action, time)
  Velora.invoke(0xAEEFA0,"void", driver, vehicle, action, time)
end
-- PC:0x659427E0EF36BCDE Old:0x20609E56
function TASK.TASK_VEHICLE_MISSION(driver, vehicle, vehicleTarget, missionType, cruiseSpeed, drivingStyle, targetReached, straightLineDistance, DriveAgainstTraffic)
  Velora.invoke(0xAEEFC0,"void", driver, vehicle, vehicleTarget, missionType, cruiseSpeed, drivingStyle, targetReached, straightLineDistance, DriveAgainstTraffic)
end
-- PC:0x9454528DF15D657A Old:0xC81C4677
function TASK.TASK_VEHICLE_MISSION_PED_TARGET(ped, vehicle, pedTarget, missionType, maxSpeed, drivingStyle, minDistance, straightLineDistance, DriveAgainstTraffic)
  Velora.invoke(0xAEF010,"void", ped, vehicle, pedTarget, missionType, maxSpeed, drivingStyle, minDistance, straightLineDistance, DriveAgainstTraffic)
end
-- PC:0xF0AF20AA7731F8C3 Old:0x6719C109
function TASK.TASK_VEHICLE_MISSION_COORS_TARGET(ped, vehicle, x, y, z, mission, cruiseSpeed, drivingStyle, targetReached, straightLineDistance, DriveAgainstTraffic)
  Velora.invoke(0xAEF050,"void", ped, vehicle, x, y, z, mission, cruiseSpeed, drivingStyle, targetReached, straightLineDistance, DriveAgainstTraffic)
end
-- PC:0x0FA6E4B75F302400 Old:0x9FDCB250
function TASK.TASK_VEHICLE_ESCORT(ped, vehicle, targetVehicle, mode, speed, drivingStyle, minDistance, minHeightAboveTerrain, noRoadsDistance)
  Velora.invoke(0xAEF0E0,"void", ped, vehicle, targetVehicle, mode, speed, drivingStyle, minDistance, minHeightAboveTerrain, noRoadsDistance)
end
-- PC:0xFC545A9F0626E3B6 Old:0xA8B917D7
function TASK.TASK_VEHICLE_FOLLOW(driver, vehicle, targetEntity, speed, drivingStyle, minDistance)
  Velora.invoke(0xAEF110,"void", driver, vehicle, targetEntity, speed, drivingStyle, minDistance)
end
-- PC:0x3C08A8E30363B353 Old:0x55634798
function TASK.TASK_VEHICLE_CHASE(driver, targetEnt)
  Velora.invoke(0xAEF130,"void", driver, targetEnt)
end
-- PC:0x1E09C32048FEFD1C Old:0x0CB415EE
function TASK.TASK_VEHICLE_HELI_PROTECT(pilot, vehicle, entityToFollow, targetSpeed, drivingFlags, radius, altitude, heliFlags)
  Velora.invoke(0xAEF140,"void", pilot, vehicle, entityToFollow, targetSpeed, drivingFlags, radius, altitude, heliFlags)
end
-- PC:0xCC665AAC360D31E7 Old:0x2A83083F
function TASK.SET_TASK_VEHICLE_CHASE_BEHAVIOR_FLAG(ped, flag, set)
  Velora.invoke(0xAEF170,"void", ped, flag, set)
end
-- PC:0x639B642FACBE4EDD Old:0x04FD3EE7
function TASK.SET_TASK_VEHICLE_CHASE_IDEAL_PURSUIT_DISTANCE(ped, distance)
  Velora.invoke(0xAEF200,"void", ped, distance)
end
-- PC:0xAC83B1DB38D0ADA0 Old:0xAC290A21
function TASK.TASK_HELI_CHASE(pilot, entityToFollow, x, y, z)
  Velora.invoke(0xAEF270,"void", pilot, entityToFollow, x, y, z)
end
-- PC:0x2D2386F273FF7A25 Old:0x12FA1C28
function TASK.TASK_PLANE_CHASE(pilot, entityToFollow, x, y, z)
  Velora.invoke(0xAEF290,"void", pilot, entityToFollow, x, y, z)
end
-- PC:0xBF19721FA34D32C0 Old:0x5F7E23EA
function TASK.TASK_PLANE_LAND(pilot, plane, runwayStartX, runwayStartY, runwayStartZ, runwayEndX, runwayEndY, runwayEndZ)
  Velora.invoke(0xAEF2B0,"void", pilot, plane, runwayStartX, runwayStartY, runwayStartZ, runwayEndX, runwayEndY, runwayEndZ)
end
function TASK.CLEAR_DEFAULT_PRIMARY_TASK(ped)
  Velora.invoke(0xAEF2D0,"void", ped)
end
function TASK.CLEAR_PRIMARY_VEHICLE_TASK(vehicle)
  Velora.invoke(0xAEF350,"void", vehicle)
end
function TASK.CLEAR_VEHICLE_CRASH_TASK(vehicle)
  Velora.invoke(0xAEF3B0,"void", vehicle)
end
function TASK.TASK_PLANE_GOTO_PRECISE_VTOL(ped, vehicle, x, y, z, flightHeight, minHeightAboveTerrain, useDesiredOrientation, desiredOrientation, autopilot)
  Velora.invoke(0xAEF410,"void", ped, vehicle, x, y, z, flightHeight, minHeightAboveTerrain, useDesiredOrientation, desiredOrientation, autopilot)
end
function TASK.TASK_SUBMARINE_GOTO_AND_STOP(ped, submarine, x, y, z, autopilot)
  Velora.invoke(0xAEF460,"void", ped, submarine, x, y, z, autopilot)
end
-- PC:0xDAD029E187A2BEB4 Old:0x0C143E97
function TASK.TASK_HELI_MISSION(pilot, aircraft, targetVehicle, targetPed, destinationX, destinationY, destinationZ, missionFlag, maxSpeed, radius, targetHeading, maxHeight, minHeight, slowDownDistance, behaviorFlags)
  Velora.invoke(0xAEF480,"void", pilot, aircraft, targetVehicle, targetPed, destinationX, destinationY, destinationZ, missionFlag, maxSpeed, radius, targetHeading, maxHeight, minHeight, slowDownDistance, behaviorFlags)
end
function TASK.TASK_HELI_ESCORT_HELI(pilot, heli1, heli2, offsetX, offsetY, offsetZ)
  Velora.invoke(0xAEF4E0,"void", pilot, heli1, heli2, offsetX, offsetY, offsetZ)
end
-- PC:0x23703CD154E83B88 Old:0x1D007E65
function TASK.TASK_PLANE_MISSION(pilot, aircraft, targetVehicle, targetPed, destinationX, destinationY, destinationZ, missionFlag, angularDrag, targetReached, targetHeading, maxZ, minZ, precise)
  Velora.invoke(0xAEF500,"void", pilot, aircraft, targetVehicle, targetPed, destinationX, destinationY, destinationZ, missionFlag, angularDrag, targetReached, targetHeading, maxZ, minZ, precise)
end
function TASK.TASK_PLANE_TAXI(pilot, aircraft, x, y, z, cruiseSpeed, targetReached)
  Velora.invoke(0xAEF560,"void", pilot, aircraft, x, y, z, cruiseSpeed, targetReached)
end
-- PC:0x15C86013127CE63F Old:0x5865B031
function TASK.TASK_BOAT_MISSION(pedDriver, vehicle, targetVehicle, targetPed, x, y, z, mission, maxSpeed, drivingStyle, targetReached, boatFlags)
  Velora.invoke(0xAEF580,"void", pedDriver, vehicle, targetVehicle, targetPed, x, y, z, mission, maxSpeed, drivingStyle, targetReached, boatFlags)
end
-- PC:0x2F8AF0E82773A171 Old:0x2B84D1C4
function TASK.TASK_DRIVE_BY(driverPed, targetPed, targetVehicle, targetX, targetY, targetZ, distanceToShoot, pedAccuracy, pushUnderneathDrivingTaskIfDriving, firingPattern)
  Velora.invoke(0xAEF5D0,"void", driverPed, targetPed, targetVehicle, targetX, targetY, targetZ, distanceToShoot, pedAccuracy, pushUnderneathDrivingTaskIfDriving, firingPattern)
end
-- PC:0xE5B302114D8162EE Old:0xDA6A6FC1
function TASK.SET_DRIVEBY_TASK_TARGET(shootingPed, targetPed, targetVehicle, x, y, z)
  Velora.invoke(0xAEF610,"void", shootingPed, targetPed, targetVehicle, x, y, z)
end
-- PC:0xC35B5CDB2824CF69 Old:0x9B76F7E6
function TASK.CLEAR_DRIVEBY_TASK_UNDERNEATH_DRIVING_TASK(ped)
  Velora.invoke(0xAEF630,"void", ped)
end
-- PC:0x8785E6E40C7A8818 Old:0xB23F46E6
function TASK.IS_DRIVEBY_TASK_UNDERNEATH_DRIVING_TASK(ped)
  return Velora.invoke(0xAEF6C0,"bool", ped)
end
-- PC:0xDCFE42068FE0135A Old:0x500D9244
function TASK.CONTROL_MOUNTED_WEAPON(ped)
  return Velora.invoke(0xAEF750,"bool", ped)
end
-- PC:0xCCD892192C6D2BB9 Old:0x98713C68
function TASK.SET_MOUNTED_WEAPON_TARGET(shootingPed, targetPed, targetVehicle, x, y, z, taskMode, ignoreTargetVehDeadCheck)
  Velora.invoke(0xAEF7F0,"void", shootingPed, targetPed, targetVehicle, x, y, z, taskMode, ignoreTargetVehDeadCheck)
end
-- PC:0xA320EF046186FA3B Old:0x291E938C
function TASK.IS_MOUNTED_WEAPON_TASK_UNDERNEATH_DRIVING_TASK(ped)
  return Velora.invoke(0xAEF820,"bool", ped)
end
-- PC:0xBD2A8EC3AF4DE7DB Old:0x225A38C8
function TASK.TASK_USE_MOBILE_PHONE(ped, usePhone, desiredPhoneMode)
  Velora.invoke(0xAEF890,"void", ped, usePhone, desiredPhoneMode)
end
-- PC:0x5EE02954A14C69DB Old:0xC99C19F5
function TASK.TASK_USE_MOBILE_PHONE_TIMED(ped, duration)
  Velora.invoke(0xAEF8B0,"void", ped, duration)
end
-- PC:0x8C338E0263E4FD19 Old:0xA2BE1821
function TASK.TASK_CHAT_TO_PED(ped, target, flags, goToLocationX, goToLocationY, goToLocationZ, headingDegs, idleTime)
  Velora.invoke(0xAEF8C0,"void", ped, target, flags, goToLocationX, goToLocationY, goToLocationZ, headingDegs, idleTime)
end
-- PC:0x9A7D091411C5F684 Old:0x65D4A35D
function TASK.TASK_WARP_PED_INTO_VEHICLE(ped, vehicle, seat)
  Velora.invoke(0xAEF8E0,"void", ped, vehicle, seat)
end
-- PC:0x08DA95E8298AE772 Old:0xAC0631C9
function TASK.TASK_SHOOT_AT_ENTITY(entity, target, duration, firingPattern)
  Velora.invoke(0xAEF900,"void", entity, target, duration, firingPattern)
end
-- PC:0x89D9FCC2435112F1 Old:0x90847790
function TASK.TASK_CLIMB(ped, usePlayerLaunchForce)
  Velora.invoke(0xAEF920,"void", ped, usePlayerLaunchForce)
end
-- PC:0xB6C987F9285A3814 Old:0x35BB4EE0
function TASK.TASK_CLIMB_LADDER(ped, fast)
  Velora.invoke(0xAEF980,"void", ped, fast)
end
function TASK.TASK_RAPPEL_DOWN_WALL_USING_CLIPSET_OVERRIDE(ped, x1, y1, z1, x2, y2, z2, minZ, ropeHandle, clipSet, p10)
  Velora.invoke(0xAEF9F0,"void", ped, x1, y1, z1, x2, y2, z2, minZ, ropeHandle, clipSet, p10)
end
function TASK.GET_TASK_RAPPEL_DOWN_WALL_STATE(ped)
  return Velora.invoke(0xAEFA20,"int", ped)
end
-- PC:0xAAA34F8A7CB32098 Old:0xBC045625
function TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
  Velora.invoke(0xAEFAE0,"void", ped)
end
-- PC:0x89221B16730234F0 Old:0xFA60601B
function TASK.TASK_PERFORM_SEQUENCE_FROM_PROGRESS(ped, taskIndex, progress1, progress2)
  Velora.invoke(0xAEFAF0,"void", ped, taskIndex, progress1, progress2)
end
-- PC:0xF1B9F16E89E2C93A Old:0x4E937D57
function TASK.SET_NEXT_DESIRED_MOVE_STATE(nextMoveState)
  Velora.invoke(0xAEFB10,"void", nextMoveState)
end
-- PC:0x1E982AC8716912C5 Old:0xC65FC712
function TASK.SET_PED_DESIRED_MOVE_BLEND_RATIO(ped, newMoveBlendRatio)
  Velora.invoke(0xAEFB20,"void", ped, newMoveBlendRatio)
end
-- PC:0x8517D4A6CA8513ED Old:0x5FEFAB72
function TASK.GET_PED_DESIRED_MOVE_BLEND_RATIO(ped)
  return Velora.invoke(0xAEFB30,"float", ped)
end
-- PC:0xA9DA48FAB8A76C12 Old:0xF1C493CF
function TASK.TASK_GOTO_ENTITY_AIMING(ped, target, distanceToStopAt, StartAimingDist)
  Velora.invoke(0xAEFB80,"void", ped, target, distanceToStopAt, StartAimingDist)
end
-- PC:0xEB8517DDA73720DA Old:0x830AD50C
function TASK.TASK_SET_DECISION_MAKER(ped, decisionMakerId)
  Velora.invoke(0xAEFC30,"void", ped, decisionMakerId)
end
-- PC:0x933C06518B52A9A4 Old:0x9F3C5D6A
function TASK.TASK_SET_SPHERE_DEFENSIVE_AREA(ped, x, y, z, radius)
  Velora.invoke(0xAEFC40,"void", ped, x, y, z, radius)
end
-- PC:0x95A6C46A31D1917D Old:0x7A05BF0D
function TASK.TASK_CLEAR_DEFENSIVE_AREA(ped)
  Velora.invoke(0xAEFC60,"void", ped)
end
-- PC:0xD04FE6765D990A06 Old:0x225380EF
function TASK.TASK_PED_SLIDE_TO_COORD(ped, x, y, z, heading, speed)
  Velora.invoke(0xAEFC70,"void", ped, x, y, z, heading, speed)
end
-- PC:0x5A4A6A6D3DC64F52 Old:0x38A995C1
function TASK.TASK_PED_SLIDE_TO_COORD_HDG_RATE(ped, x, y, z, heading, speed, headingChangeRate)
  Velora.invoke(0xAEFC90,"void", ped, x, y, z, heading, speed, headingChangeRate)
end
-- PC:0xD5C12A75C7B9497F Old:0xA0AF0B98
function TASK.ADD_COVER_POINT(x, y, z, direction, usage, height, arc, isPriority)
  return Velora.invoke(0xAEFCB0,"int", x, y, z, direction, usage, height, arc, isPriority)
end
-- PC:0xAE287C923D891715 Old:0x0776888B
function TASK.REMOVE_COVER_POINT(coverpoint)
  Velora.invoke(0xAEFD60,"void", coverpoint)
end
-- PC:0xA98B8E3C088E5A31 Old:0x29F97A71
function TASK.DOES_SCRIPTED_COVER_POINT_EXIST_AT_COORDS(x, y, z)
  return Velora.invoke(0xAEFDA0,"bool", x, y, z)
end
-- PC:0x594A1028FC2A3E85 Old:0xC6B6CCC1
function TASK.GET_SCRIPTED_COVER_POINT_COORDS(coverpoint)
  local x,y,z=Velora.invoke(0xAEFE30,"vector3", coverpoint)
  return {x=x,y=y,z=z}
end
function TASK.ADD_SCRIPTED_COVER_AREA(x, y, z, radius)
  Velora.invoke(0xAEFF00,"void", x, y, z, radius)
end
-- PC:0xF166E48407BAC484 Old:0xCB0D8932
function TASK.TASK_COMBAT_PED(ped, targetPed, combatFlags, threatResponseFlags)
  Velora.invoke(0xAEFFC0,"void", ped, targetPed, combatFlags, threatResponseFlags)
end
-- PC:0x944F30DCB7096BDE Old:0xF5CA2A45
function TASK.TASK_COMBAT_PED_TIMED(ped, target, time, flags)
  Velora.invoke(0xAEFFE0,"void", ped, target, time, flags)
end
-- PC:0x75AC2B60386D89F2 Old:0x83F18EE9
function TASK.TASK_SEEK_COVER_FROM_POS(ped, x, y, z, duration, allowPeekingAndFiring)
  Velora.invoke(0xAF0000,"void", ped, x, y, z, duration, allowPeekingAndFiring)
end
-- PC:0x84D32B3BEC531324 Old:0xC1EC907E
function TASK.TASK_SEEK_COVER_FROM_PED(ped, target, duration, allowPeekingAndFiring)
  Velora.invoke(0xAF0020,"void", ped, target, duration, allowPeekingAndFiring)
end
-- PC:0xD43D95C7A869447F Old:0x3D026B29
function TASK.TASK_SEEK_COVER_TO_COVER_POINT(ped, coverpoint, x, y, z, time, allowPeekingAndFiring)
  Velora.invoke(0xAF0040,"void", ped, coverpoint, x, y, z, time, allowPeekingAndFiring)
end
-- PC:0x39246A6958EF072C Old:0xFFFE754E
function TASK.TASK_SEEK_COVER_TO_COORDS(ped, x1, y1, z1, x2, y2, z2, timeout, shortRoute)
  Velora.invoke(0xAF0060,"void", ped, x1, y1, z1, x2, y2, z2, timeout, shortRoute)
end
-- PC:0x4172393E6BE1FECE Old:0xC9F00E68
function TASK.TASK_PUT_PED_DIRECTLY_INTO_COVER(ped, x, y, z, time, allowPeekingAndFiring, blendInDuration, forceInitialFacingDirection, forceFaceLeft, identifier, doEntry)
  Velora.invoke(0xAF0090,"void", ped, x, y, z, time, allowPeekingAndFiring, blendInDuration, forceInitialFacingDirection, forceFaceLeft, identifier, doEntry)
end
function TASK.TASK_WARP_PED_DIRECTLY_INTO_COVER(ped, time, allowPeekingAndFiring, forceInitialFacingDirection, forceFaceLeft, identifier)
  Velora.invoke(0xAF01A0,"void", ped, time, allowPeekingAndFiring, forceInitialFacingDirection, forceFaceLeft, identifier)
end
-- PC:0x79B258E397854D29 Old:0xC829FAC9
function TASK.TASK_EXIT_COVER(ped, exitType, x, y, z)
  Velora.invoke(0xAF01E0,"void", ped, exitType, x, y, z)
end
-- PC:0x1C6CD14A876FFE39 Old:0x79E1D27D
function TASK.TASK_PUT_PED_DIRECTLY_INTO_MELEE(ped, meleeTarget, blendInDuration, timeInMelee, strafePhaseSync, aiCombatFlags)
  Velora.invoke(0xAF0200,"void", ped, meleeTarget, blendInDuration, timeInMelee, strafePhaseSync, aiCombatFlags)
end
-- PC:0xAC96609B9995EDF8 Old:0x61CFBCBF
function TASK.TASK_TOGGLE_DUCK(ped, toggleType)
  Velora.invoke(0xAF0220,"void", ped, toggleType)
end
-- PC:0x4A58A47A72E3FCB4 Old:0x2FB099E9
function TASK.TASK_GUARD_CURRENT_POSITION(ped, maxPatrolProximity, defensiveAreaRadius, setDefensiveArea)
  Velora.invoke(0xAF02B0,"void", ped, maxPatrolProximity, defensiveAreaRadius, setDefensiveArea)
end
-- PC:0xD2A207EEBDF9889B Old:0x7AF0133D
function TASK.TASK_GUARD_ASSIGNED_DEFENSIVE_AREA(ped, x, y, z, heading, maxPatrolProximity, timer)
  Velora.invoke(0xAF02D0,"void", ped, x, y, z, heading, maxPatrolProximity, timer)
end
-- PC:0xC946FE14BE0EB5E2 Old:0x86B76CB7
function TASK.TASK_GUARD_SPHERE_DEFENSIVE_AREA(ped, defendPositionX, defendPositionY, defendPositionZ, heading, maxPatrolProximity, time, x, y, z, defensiveAreaRadius)
  Velora.invoke(0xAF02F0,"void", ped, defendPositionX, defendPositionY, defendPositionZ, heading, maxPatrolProximity, time, x, y, z, defensiveAreaRadius)
end
-- PC:0xAE032F8BBA959E90 Old:0xD130F636
function TASK.TASK_STAND_GUARD(ped, x, y, z, heading, scenarioName)
  Velora.invoke(0xAF0320,"void", ped, x, y, z, heading, scenarioName)
end
-- PC:0x5C9B84BD7D31D908 Old:0x3CEC07B1
function TASK.SET_DRIVE_TASK_CRUISE_SPEED(driver, cruiseSpeed)
  Velora.invoke(0xAF0340,"void", driver, cruiseSpeed)
end
-- PC:0x404A5AA9B9F0B746 Old:0x7FDF6131
function TASK.SET_DRIVE_TASK_MAX_CRUISE_SPEED(ped, speed)
  Velora.invoke(0xAF0350,"void", ped, speed)
end
-- PC:0xDACE1BE37D88AF67 Old:0x59C5FAD7
function TASK.SET_DRIVE_TASK_DRIVING_STYLE(ped, drivingStyle)
  Velora.invoke(0xAF0370,"void", ped, drivingStyle)
end
-- PC:0x45C597097DD7CB81 Old:0x3536946F
function TASK.ADD_COVER_BLOCKING_AREA(startX, startY, startZ, endX, endY, endZ, blockObjects, blockVehicles, blockMap, blockPlayer)
  Velora.invoke(0xAF0400,"void", startX, startY, startZ, endX, endY, endZ, blockObjects, blockVehicles, blockMap, blockPlayer)
end
-- PC:0xDB6708C0B46F56D8 Old:0xCF9221A7
function TASK.REMOVE_ALL_COVER_BLOCKING_AREAS()
  Velora.invoke(0xAF04B0,"void")
end
function TASK.REMOVE_COVER_BLOCKING_AREAS_AT_POSITION(x, y, z)
  Velora.invoke(0xAF04D0,"void", x, y, z)
end
function TASK.REMOVE_SPECIFIC_COVER_BLOCKING_AREAS(startX, startY, startZ, endX, endY, endZ, blockObjects, blockVehicles, blockMap, blockPlayer)
  Velora.invoke(0xAF0530,"void", startX, startY, startZ, endX, endY, endZ, blockObjects, blockVehicles, blockMap, blockPlayer)
end
-- PC:0x142A02425FF02BD9 Old:0xE50D6DDE
function TASK.TASK_START_SCENARIO_IN_PLACE(ped, scenarioName, unkDelay, playEnterAnim)
  Velora.invoke(0xAF05E0,"void", ped, scenarioName, unkDelay, playEnterAnim)
end
-- PC:0xFA4EFC79F69D4F07 Old:0xAA2C4AC2
function TASK.TASK_START_SCENARIO_AT_POSITION(ped, scenarioName, x, y, z, heading, duration, sittingScenario, teleport)
  Velora.invoke(0xAF0600,"void", ped, scenarioName, x, y, z, heading, duration, sittingScenario, teleport)
end
-- PC:0x277F471BA9DB000B Old:0x9C50FBF0
function TASK.TASK_USE_NEAREST_SCENARIO_TO_COORD(ped, x, y, z, distance, duration)
  Velora.invoke(0xAF0640,"void", ped, x, y, z, distance, duration)
end
-- PC:0x58E2E0F23F6B76C3 Old:0x1BE9D65C
function TASK.TASK_USE_NEAREST_SCENARIO_TO_COORD_WARP(ped, x, y, z, radius, timeToLeave)
  Velora.invoke(0xAF06F0,"void", ped, x, y, z, radius, timeToLeave)
end
-- PC:0x9FDA1B3D7E7028B3 Old:0xE32FFB22
function TASK.TASK_USE_NEAREST_SCENARIO_CHAIN_TO_COORD(ped, x, y, z, maxRange, timeToLeave)
  Velora.invoke(0xAF07A0,"void", ped, x, y, z, maxRange, timeToLeave)
end
-- PC:0x97A28E63F0BA5631 Old:0xBAB4C0AE
function TASK.TASK_USE_NEAREST_SCENARIO_CHAIN_TO_COORD_WARP(ped, x, y, z, radius, timeToLeave)
  Velora.invoke(0xAF07C0,"void", ped, x, y, z, radius, timeToLeave)
end
-- PC:0x5A59271FFADD33C1 Old:0xFA7F5047
function TASK.DOES_SCENARIO_EXIST_IN_AREA(x, y, z, radius, mustBeFree)
  return Velora.invoke(0xAF07E0,"bool", x, y, z, radius, mustBeFree)
end
-- PC:0x0A9D0C2A3BBC86C1 Old:0x0FB138A5
function TASK.DOES_SCENARIO_OF_TYPE_EXIST_IN_AREA(x, y, z, scenarioName, radius, mustBeFree)
  return Velora.invoke(0xAF0880,"bool", x, y, z, scenarioName, radius, mustBeFree)
end
-- PC:0x788756D73AC2E07C Old:0x697FC008
function TASK.IS_SCENARIO_OCCUPIED(x, y, z, maxRange, onlyUsersActuallyAtScenario)
  return Velora.invoke(0xAF0940,"bool", x, y, z, maxRange, onlyUsersActuallyAtScenario)
end
-- PC:0x295E3CCEC879CCD7 Old:0x9BE9C691
function TASK.PED_HAS_USE_SCENARIO_TASK(ped)
  return Velora.invoke(0xAF0970,"bool", ped)
end
-- PC:0x748040460F8DF5DC Old:0x1984A5D1
function TASK.PLAY_ANIM_ON_RUNNING_SCENARIO(ped, animDict, animName)
  Velora.invoke(0xAF09D0,"void", ped, animDict, animName)
end
-- PC:0xF9034C136C9E00D3 Old:0x5F072EB9
function TASK.DOES_SCENARIO_GROUP_EXIST(scenarioGroup)
  return Velora.invoke(0xAF09F0,"bool", scenarioGroup)
end
-- PC:0x367A09DED4E05B99 Old:0x90991122
function TASK.IS_SCENARIO_GROUP_ENABLED(scenarioGroup)
  return Velora.invoke(0xAF0A70,"bool", scenarioGroup)
end
-- PC:0x02C8E5B49848664E Old:0x116997B1
function TASK.SET_SCENARIO_GROUP_ENABLED(scenarioGroup, enabled)
  Velora.invoke(0xAF0B10,"void", scenarioGroup, enabled)
end
-- PC:0xDD902D0349AFAD3A Old:0xBF55025D
function TASK.RESET_SCENARIO_GROUPS_ENABLED()
  Velora.invoke(0xAF0BA0,"void")
end
-- PC:0x535E97E1F7FC0C6A Old:0x59DB8F26
function TASK.SET_EXCLUSIVE_SCENARIO_GROUP(scenarioGroup)
  Velora.invoke(0xAF0BB0,"void", scenarioGroup)
end
-- PC:0x4202BBCB8684563D Old:0x17F9DFE8
function TASK.RESET_EXCLUSIVE_SCENARIO_GROUP()
  Velora.invoke(0xAF0C30,"void")
end
-- PC:0x3A815DB3EA088722 Old:0xAE37E969
function TASK.IS_SCENARIO_TYPE_ENABLED(scenarioType)
  return Velora.invoke(0xAF0C50,"bool", scenarioType)
end
-- PC:0xEB47EC4E34FB7EE1 Old:0xDB18E5DE
function TASK.SET_SCENARIO_TYPE_ENABLED(scenarioType, toggle)
  Velora.invoke(0xAF0CE0,"void", scenarioType, toggle)
end
-- PC:0x0D40EE2A7F2B2D6D Old:0xF58FDEB4
function TASK.RESET_SCENARIO_TYPES_ENABLED()
  Velora.invoke(0xAF0D70,"void")
end
-- PC:0xAA135F9482C82CC3 Old:0x05038F1A
function TASK.IS_PED_ACTIVE_IN_SCENARIO(ped)
  return Velora.invoke(0xAF0D80,"bool", ped)
end
-- PC:0x621C6E4729388E41 Old:0xA0DA6B1D
function TASK.IS_PED_PLAYING_BASE_CLIP_IN_SCENARIO(ped)
  return Velora.invoke(0xAF0E00,"bool", ped)
end
-- PC:0x8FD89A6240813FD0 Old:0xB5AD044E
function TASK.SET_PED_CAN_PLAY_AMBIENT_IDLES(ped, blockIdleClips, removeIdleClipIfPlaying)
  Velora.invoke(0xAF0E30,"void", ped, blockIdleClips, removeIdleClipIfPlaying)
end
-- PC:0x4CF5F55DAC3280A0 Old:0xDF099E18
function TASK.TASK_COMBAT_HATED_TARGETS_IN_AREA(ped, x, y, z, radius, combatFlags)
  Velora.invoke(0xAF0EB0,"void", ped, x, y, z, radius, combatFlags)
end
-- PC:0x7BF835BB9E2698C8 Old:0x2E7064E4
function TASK.TASK_COMBAT_HATED_TARGETS_AROUND_PED(ped, radius, combatFlags)
  Velora.invoke(0xAF0FB0,"void", ped, radius, combatFlags)
end
-- PC:0x2BBA30B854534A0C Old:0xF127AD6A
function TASK.TASK_COMBAT_HATED_TARGETS_AROUND_PED_TIMED(ped, radius, time, combatFlags)
  Velora.invoke(0xAF10A0,"void", ped, radius, time, combatFlags)
end
-- PC:0x7285951DBF6B5A51 Old:0xF65C20A7
function TASK.TASK_THROW_PROJECTILE(ped, x, y, z, ignoreCollisionEntityIndex, createInvincibleProjectile)
  Velora.invoke(0xAF11A0,"void", ped, x, y, z, ignoreCollisionEntityIndex, createInvincibleProjectile)
end
-- PC:0xA21C51255B205245 Old:0xDAF4F8FC
function TASK.TASK_SWAP_WEAPON(ped, drawWeapon)
  Velora.invoke(0xAF11C0,"void", ped, drawWeapon)
end
-- PC:0x62D2916F56B9CD2D Old:0xCA6E91FD
function TASK.TASK_RELOAD_WEAPON(ped, drawWeapon)
  Velora.invoke(0xAF1240,"void", ped, drawWeapon)
end
-- PC:0x2A74E1D5F2F00EEC Old:0x320813E6
function TASK.IS_PED_GETTING_UP(ped)
  return Velora.invoke(0xAF1260,"bool", ped)
end
-- PC:0xCDDC2B77CE54AC6E Old:0x0FDC54FC
function TASK.TASK_WRITHE(ped, target, minFireLoops, startState, forceShootOnGround, shootFromGroundTimer)
  Velora.invoke(0xAF12C0,"void", ped, target, minFireLoops, startState, forceShootOnGround, shootFromGroundTimer)
end
-- PC:0xDEB6D52126E7D640 Old:0x09E61921
function TASK.IS_PED_IN_WRITHE(ped)
  return Velora.invoke(0xAF12F0,"bool", ped)
end
-- PC:0xA36BFB5EE89F3D82 Old:0xF33F83CA
function TASK.OPEN_PATROL_ROUTE(patrolRoute)
  Velora.invoke(0xAF1350,"void", patrolRoute)
end
-- PC:0xB043ECA801B8CBC1 Old:0x67305E59
function TASK.CLOSE_PATROL_ROUTE()
  Velora.invoke(0xAF1370,"void")
end
-- PC:0x8EDF950167586B7C Old:0x21B48F10
function TASK.ADD_PATROL_ROUTE_NODE(nodeId, nodeType, posX, posY, posZ, headingX, headingY, headingZ, duration)
  Velora.invoke(0xAF1380,"void", nodeId, nodeType, posX, posY, posZ, headingX, headingY, headingZ, duration)
end
-- PC:0x23083260DEC3A551 Old:0xD8761BB3
function TASK.ADD_PATROL_ROUTE_LINK(nodeId1, nodeId2)
  Velora.invoke(0xAF1410,"void", nodeId1, nodeId2)
end
-- PC:0xAF8A443CCC8018DC Old:0x0A6C7864
function TASK.CREATE_PATROL_ROUTE()
  Velora.invoke(0xAF1430,"void")
end
-- PC:0x7767DD9D65E91319 Old:0x2A4E6706
function TASK.DELETE_PATROL_ROUTE(patrolRoute)
  Velora.invoke(0xAF1440,"void", patrolRoute)
end
function TASK.GET_PATROL_TASK_INFO(ped)
  return Velora.invoke(0xAF1480,"bool", ped)
end
-- PC:0xBDA5DF49D080FE4E Old:0xB92E5AF6
function TASK.TASK_PATROL(ped, patrolRouteName, alertState, canChatToPeds, useHeadLookAt)
  Velora.invoke(0xAF1520,"void", ped, patrolRouteName, alertState, canChatToPeds, useHeadLookAt)
end
-- PC:0xE5DA8615A6180789 Old:0xA27A9413
function TASK.TASK_STAY_IN_COVER(ped)
  Velora.invoke(0xAF15C0,"void", ped)
end
-- PC:0x5CF0D8F9BBA0DD75 Old:0x50779A2C
function TASK.ADD_VEHICLE_SUBTASK_ATTACK_COORD(ped, x, y, z)
  Velora.invoke(0xAF1620,"void", ped, x, y, z)
end
-- PC:0x85F462BADC7DA47F Old:0x80461113
function TASK.ADD_VEHICLE_SUBTASK_ATTACK_PED(ped, target)
  Velora.invoke(0xAF1630,"void", ped, target)
end
-- PC:0x10AB107B887214D8 Old:0x59677BA0
function TASK.TASK_VEHICLE_SHOOT_AT_PED(ped, target, fireTolerance)
  Velora.invoke(0xAF1640,"void", ped, target, fireTolerance)
end
-- PC:0xE41885592B08B097 Old:0x920AE6DB
function TASK.TASK_VEHICLE_AIM_AT_PED(ped, target)
  Velora.invoke(0xAF1660,"void", ped, target)
end
-- PC:0x5190796ED39C9B6D Old:0xA7AAA4D6
function TASK.TASK_VEHICLE_SHOOT_AT_COORD(ped, x, y, z, fireTolerance)
  Velora.invoke(0xAF1670,"void", ped, x, y, z, fireTolerance)
end
-- PC:0x447C1E9EF844BC0F Old:0x010F47CE
function TASK.TASK_VEHICLE_AIM_AT_COORD(ped, x, y, z)
  Velora.invoke(0xAF1690,"void", ped, x, y, z)
end
-- PC:0x195AEEB13CEFE2EE Old:0x55CF3BCD
function TASK.TASK_VEHICLE_GOTO_NAVMESH(ped, vehicle, x, y, z, speed, behaviorFlag, stoppingRange)
  Velora.invoke(0xAF16A0,"void", ped, vehicle, x, y, z, speed, behaviorFlag, stoppingRange)
end
-- PC:0x11315AB3385B8AC0 Old:0x1552DC91
function TASK.TASK_GO_TO_COORD_WHILE_AIMING_AT_COORD(ped, x, y, z, aimAtX, aimAtY, aimAtZ, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, navFlags, instantBlendToAim, firingPattern)
  Velora.invoke(0xAF16C0,"void", ped, x, y, z, aimAtX, aimAtY, aimAtZ, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, navFlags, instantBlendToAim, firingPattern)
end
-- PC:0xB2A16444EAD9AE47 Old:0x9BD52ABD
function TASK.TASK_GO_TO_COORD_WHILE_AIMING_AT_ENTITY(ped, x, y, z, aimAtID, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, navFlags, instantBlendToAim, firingPattern, time)
  Velora.invoke(0xAF1720,"void", ped, x, y, z, aimAtID, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, navFlags, instantBlendToAim, firingPattern, time)
end
-- PC:0xA55547801EB331FC Old:0x3F91358E
function TASK.TASK_GO_TO_COORD_AND_AIM_AT_HATED_ENTITIES_NEAR_COORD(pedHandle, goToLocationX, goToLocationY, goToLocationZ, focusLocationX, focusLocationY, focusLocationZ, speed, shootAtEnemies, distanceToStopAt, noRoadsDistance, useNavMesh, navFlags, taskFlags, firingPattern)
  Velora.invoke(0xAF1790,"void", pedHandle, goToLocationX, goToLocationY, goToLocationZ, focusLocationX, focusLocationY, focusLocationZ, speed, shootAtEnemies, distanceToStopAt, noRoadsDistance, useNavMesh, navFlags, taskFlags, firingPattern)
end
-- PC:0x04701832B739DCE5 Old:0xD896CD82
function TASK.TASK_GO_TO_ENTITY_WHILE_AIMING_AT_COORD(ped, entity, aimX, aimY, aimZ, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, instantBlendToAim, firingPattern)
  Velora.invoke(0xAF17F0,"void", ped, entity, aimX, aimY, aimZ, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, instantBlendToAim, firingPattern)
end
-- PC:0x97465886D35210E9 Old:0x68E36B7A
function TASK.TASK_GO_TO_ENTITY_WHILE_AIMING_AT_ENTITY(ped, entityToWalkTo, entityToAimAt, speed, shootatEntity, targetRadius, slowDistance, useNavMesh, instantBlendToAim, firingPattern)
  Velora.invoke(0xAF1850,"void", ped, entityToWalkTo, entityToAimAt, speed, shootatEntity, targetRadius, slowDistance, useNavMesh, instantBlendToAim, firingPattern)
end
-- PC:0x8C825BDC7741D37C Old:0xBBB26172
function TASK.SET_HIGH_FALL_TASK(ped, minTime, maxTime, entryType)
  Velora.invoke(0xAF18B0,"void", ped, minTime, maxTime, entryType)
end
-- PC:0x9EEFB62EB27B5792 Old:0xAFABFB5D
function TASK.REQUEST_WAYPOINT_RECORDING(name)
  Velora.invoke(0xAF18D0,"void", name)
end
-- PC:0xCB4E8BE8A0063C5D Old:0x87125F5D
function TASK.GET_IS_WAYPOINT_RECORDING_LOADED(name)
  return Velora.invoke(0xAF1910,"bool", name)
end
-- PC:0xFF1B8B4AA1C25DC8 Old:0x624530B0
function TASK.REMOVE_WAYPOINT_RECORDING(name)
  Velora.invoke(0xAF1950,"void", name)
end
-- PC:0x5343532C01A07234 Old:0xF5F9B71E
function TASK.WAYPOINT_RECORDING_GET_NUM_POINTS(name)
  return Velora.invoke(0xAF1990,"bool", name)
end
-- PC:0x2FB897405C90B361 Old:0x19266913
function TASK.WAYPOINT_RECORDING_GET_COORD(name, point)
  return Velora.invoke(0xAF19F0,"bool", name, point)
end
-- PC:0x005622AEBC33ACA9 Old:0xC765633A
function TASK.WAYPOINT_RECORDING_GET_SPEED_AT_POINT(name, point)
  return Velora.invoke(0xAF1A60,"float", name, point)
end
-- PC:0xB629A298081F876F Old:0xC4CD35AF
function TASK.WAYPOINT_RECORDING_GET_CLOSEST_WAYPOINT(name, x, y, z)
  return Velora.invoke(0xAF1B00,"bool", name, x, y, z)
end
-- PC:0x0759591819534F7B Old:0xADF9904D
function TASK.TASK_FOLLOW_WAYPOINT_RECORDING(ped, name, p2, p3, p4)
  Velora.invoke(0xAF1BB0,"void", ped, name, p2, p3, p4)
end
-- PC:0xE03B3F2D3DC59B64 Old:0x85B7725F
function TASK.IS_WAYPOINT_PLAYBACK_GOING_ON_FOR_PED(ped)
  return Velora.invoke(0xAF1C70,"bool", ped)
end
-- PC:0x2720AAA75001E094 Old:0x3595B104
function TASK.GET_PED_WAYPOINT_PROGRESS(ped)
  return Velora.invoke(0xAF1CF0,"int", ped)
end
-- PC:0xE6A877C64CAF1BC5 Old:0x084B35B0
function TASK.GET_PED_WAYPOINT_DISTANCE(p0)
  return Velora.invoke(0xAF1DF0,"float", p0)
end
-- PC:0xED98E10B0AFCE4B4 Old:0xF867F747
function TASK.SET_PED_WAYPOINT_ROUTE_OFFSET(ped, x, y, z)
  return Velora.invoke(0xAF1E80,"bool", ped, x, y, z)
end
-- PC:0xA5B769058763E497 Old:0xE8422AC4
function TASK.GET_WAYPOINT_DISTANCE_ALONG_ROUTE(name, point)
  return Velora.invoke(0xAF1F30,"float", name, point)
end
-- PC:0x701375A7D43F01CB Old:0xA6BB5717
function TASK.WAYPOINT_PLAYBACK_GET_IS_PAUSED(p0)
  return Velora.invoke(0xAF1F90,"bool", p0)
end
-- PC:0x0F342546AA06FED5 Old:0xFE39ECF8
function TASK.WAYPOINT_PLAYBACK_PAUSE(p0, p1, p2)
  Velora.invoke(0xAF2020,"void", p0, p1, p2)
end
-- PC:0x244F70C84C547D2D Old:0x50F392EF
function TASK.WAYPOINT_PLAYBACK_RESUME(p0, p1, p2, p3)
  Velora.invoke(0xAF20C0,"void", p0, p1, p2, p3)
end
-- PC:0x7D7D2B47FA788E85 Old:0x23E6BA96
function TASK.WAYPOINT_PLAYBACK_OVERRIDE_SPEED(p0, p1, p2)
  Velora.invoke(0xAF2160,"void", p0, p1, p2)
end
-- PC:0x6599D834B12D0800 Old:0x1BBB2CAC
function TASK.WAYPOINT_PLAYBACK_USE_DEFAULT_SPEED(p0)
  Velora.invoke(0xAF2220,"void", p0)
end
-- PC:0x5A353B8E6B1095B5 Old:0x4DFD5FEC
function TASK.USE_WAYPOINT_RECORDING_AS_ASSISTED_MOVEMENT_ROUTE(name, p1, p2, p3)
  Velora.invoke(0xAF2290,"void", name, p1, p2, p3)
end
-- PC:0x20E330937C399D29 Old:0x75E60CF6
function TASK.WAYPOINT_PLAYBACK_START_AIMING_AT_PED(ped, target, p2)
  Velora.invoke(0xAF22B0,"void", ped, target, p2)
end
-- PC:0x8968400D900ED8B3 Old:0xF120A34E
function TASK.WAYPOINT_PLAYBACK_START_AIMING_AT_COORD(ped, x, y, z, p4)
  Velora.invoke(0xAF2370,"void", ped, x, y, z, p4)
end
-- PC:0xE70BA7B90F8390DC Old:0xBD5F0EB8
function TASK.WAYPOINT_PLAYBACK_START_SHOOTING_AT_PED(ped, ped2, p2, p3)
  Velora.invoke(0xAF2440,"void", ped, ped2, p2, p3)
end
-- PC:0x057A25CFCC9DB671 Old:0xCDDB44D5
function TASK.WAYPOINT_PLAYBACK_START_SHOOTING_AT_COORD(ped, x, y, z, p4, firingPattern)
  Velora.invoke(0xAF2460,"void", ped, x, y, z, p4, firingPattern)
end
-- PC:0x47EFA040EBB8E2EA Old:0x6D7CF40C
function TASK.WAYPOINT_PLAYBACK_STOP_AIMING_OR_SHOOTING(ped)
  Velora.invoke(0xAF2480,"void", ped)
end
-- PC:0x817268968605947A Old:0x48262EDA
function TASK.ASSISTED_MOVEMENT_REQUEST_ROUTE(route)
  Velora.invoke(0xAF24F0,"void", route)
end
-- PC:0x3548536485DD792B Old:0xB3CEC06F
function TASK.ASSISTED_MOVEMENT_REMOVE_ROUTE(route)
  Velora.invoke(0xAF2500,"void", route)
end
-- PC:0x60F9A4393A21F741 Old:0x79B067AF
function TASK.ASSISTED_MOVEMENT_IS_ROUTE_LOADED(route)
  return Velora.invoke(0xAF2540,"bool", route)
end
-- PC:0xD5002D78B7162E1B Old:0x01CAAFCC
function TASK.ASSISTED_MOVEMENT_SET_ROUTE_PROPERTIES(route, props)
  Velora.invoke(0xAF25C0,"void", route, props)
end
-- PC:0x13945951E16EF912 Old:0x8FB923EC
function TASK.ASSISTED_MOVEMENT_OVERRIDE_LOAD_DISTANCE_THIS_FRAME(dist)
  Velora.invoke(0xAF25D0,"void", dist)
end
-- PC:0x3123FAA6DB1CF7ED Old:0x959818B6
function TASK.TASK_VEHICLE_FOLLOW_WAYPOINT_RECORDING(ped, vehicle, WPRecording, p3, p4, p5, p6, p7, p8, p9)
  Velora.invoke(0xAF25F0,"void", ped, vehicle, WPRecording, p3, p4, p5, p6, p7, p8, p9)
end
-- PC:0xF5134943EA29868C Old:0x80DD15DB
function TASK.IS_WAYPOINT_PLAYBACK_GOING_ON_FOR_VEHICLE(vehicle)
  return Velora.invoke(0xAF2640,"bool", vehicle)
end
-- PC:0x9824CFF8FC66E159 Old:0xD3CCF64E
function TASK.GET_VEHICLE_WAYPOINT_PROGRESS(vehicle)
  return Velora.invoke(0xAF26C0,"int", vehicle)
end
-- PC:0x416B62AC8B9E5BBD Old:0x81049608
function TASK.GET_VEHICLE_WAYPOINT_TARGET_POINT(vehicle)
  return Velora.invoke(0xAF2740,"int", vehicle)
end
-- PC:0x8A4E6AC373666BC5 Old:0x7C00B415
function TASK.VEHICLE_WAYPOINT_PLAYBACK_PAUSE(vehicle)
  Velora.invoke(0xAF27D0,"void", vehicle)
end
-- PC:0xDC04FCAA7839D492 Old:0xBEB14C82
function TASK.VEHICLE_WAYPOINT_PLAYBACK_RESUME(vehicle)
  Velora.invoke(0xAF28D0,"void", vehicle)
end
-- PC:0x5CEB25A7D2848963 Old:0x923C3AA4
function TASK.VEHICLE_WAYPOINT_PLAYBACK_USE_DEFAULT_SPEED(vehicle)
  Velora.invoke(0xAF2940,"void", vehicle)
end
-- PC:0x121F0593E0A431D7 Old:0xBE1E7BB4
function TASK.VEHICLE_WAYPOINT_PLAYBACK_OVERRIDE_SPEED(vehicle, speed)
  Velora.invoke(0xAF29B0,"void", vehicle, speed)
end
-- PC:0x90D2156198831D69 Old:0x1B54FB6B
function TASK.TASK_SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(ped, toggle)
  Velora.invoke(0xAF2A30,"void", ped, toggle)
end
-- PC:0x4F056E1AFFEF17AB Old:0xCAD2EF77
function TASK.TASK_FORCE_MOTION_STATE(ped, state, forceRestart)
  Velora.invoke(0xAF2AB0,"void", ped, state, forceRestart)
end
-- PC:0x2D537BA194896636 Old:0x6F5D215F
function TASK.TASK_MOVE_NETWORK_BY_NAME(ped, task, multiplier, allowOverrideCloneUpdate, animDict, flags)
  Velora.invoke(0xAF2AD0,"void", ped, task, multiplier, allowOverrideCloneUpdate, animDict, flags)
end
-- PC:0xD5B35BEA41919ACB Old:0x71A5C5DB
function TASK.TASK_MOVE_NETWORK_ADVANCED_BY_NAME(ped, network, x, y, z, rotX, rotY, rotZ, rotOrder, blendDuration, allowOverrideCloneUpdate, animDict, flags)
  Velora.invoke(0xAF2B00,"void", ped, network, x, y, z, rotX, rotY, rotZ, rotOrder, blendDuration, allowOverrideCloneUpdate, animDict, flags)
end
function TASK.TASK_MOVE_NETWORK_BY_NAME_WITH_INIT_PARAMS(ped, network, blendDuration, allowOverrideCloneUpdate, animDict, flags)
  Velora.invoke(0xAF2B50,"void", ped, network, blendDuration, allowOverrideCloneUpdate, animDict, flags)
end
function TASK.TASK_MOVE_NETWORK_ADVANCED_BY_NAME_WITH_INIT_PARAMS(ped, network, x, y, z, rotX, rotY, rotZ, rotOrder, blendDuration, allowOverrideCloneUpdate, dictionary, flags)
  Velora.invoke(0xAF2B80,"void", ped, network, x, y, z, rotX, rotY, rotZ, rotOrder, blendDuration, allowOverrideCloneUpdate, dictionary, flags)
end
-- PC:0x921CE12C489C4C41 Old:0x902656EB
function TASK.IS_TASK_MOVE_NETWORK_ACTIVE(ped)
  return Velora.invoke(0xAF2BE0,"bool", ped)
end
-- PC:0x30ED88D5E0C56A37 Old:0x92FDBAE6
function TASK.IS_TASK_MOVE_NETWORK_READY_FOR_TRANSITION(ped)
  return Velora.invoke(0xAF2C70,"bool", ped)
end
-- PC:0xD01015C7316AE176 Old:0x885724DE
function TASK.REQUEST_TASK_MOVE_NETWORK_STATE_TRANSITION(ped, name)
  return Velora.invoke(0xAF2D20,"bool", ped, name)
end
-- PC:0xAB13A5565480B6D9 Old:0x1E58A7AD
function TASK.SET_EXPECTED_CLONE_NEXT_TASK_MOVE_NETWORK_STATE(ped, state)
  return Velora.invoke(0xAF2D30,"bool", ped, state)
end
function TASK.SET_TASK_MOVE_NETWORK_ANIM_SET(ped, clipSet, variableClipSet)
  Velora.invoke(0xAF2DF0,"void", ped, clipSet, variableClipSet)
end
-- PC:0xD5BB4025AE449A4E Old:0xA79BE783
function TASK.SET_TASK_MOVE_NETWORK_SIGNAL_FLOAT(ped, signalName, value)
  Velora.invoke(0xAF2E10,"void", ped, signalName, value)
end
function TASK.SET_TASK_MOVE_NETWORK_SIGNAL_LOCAL_FLOAT(ped, signalName, value)
  Velora.invoke(0xAF2E30,"void", ped, signalName, value)
end
function TASK.SET_TASK_MOVE_NETWORK_SIGNAL_FLOAT_LERP_RATE(ped, signalName, value)
  Velora.invoke(0xAF2EE0,"void", ped, signalName, value)
end
-- PC:0xB0A6CFD2C69C1088 Old:0xF3538041
function TASK.SET_TASK_MOVE_NETWORK_SIGNAL_BOOL(ped, signalName, value)
  Velora.invoke(0xAF2F90,"void", ped, signalName, value)
end
function TASK.GET_TASK_MOVE_NETWORK_SIGNAL_FLOAT(ped, signalName)
  return Velora.invoke(0xAF2FB0,"float", ped, signalName)
end
-- PC:0xA7FFBA498E4AAF67 Old:0x1EBB6F3D
function TASK.GET_TASK_MOVE_NETWORK_SIGNAL_BOOL(ped, signalName)
  return Velora.invoke(0xAF3060,"bool", ped, signalName)
end
-- PC:0xB4F47213DF45A64C Old:0x72FA5EF2
function TASK.GET_TASK_MOVE_NETWORK_EVENT(ped, eventName)
  return Velora.invoke(0xAF3100,"bool", ped, eventName)
end
function TASK.SET_TASK_MOVE_NETWORK_ENABLE_COLLISION_ON_NETWORK_CLONE_WHEN_FIXED(ped, enable)
  return Velora.invoke(0xAF31A0,"bool", ped, enable)
end
-- PC:0x349CE7B56DAFD95C Old:0xE9DAF877
function TASK.IS_MOVE_BLEND_RATIO_STILL(ped)
  return Velora.invoke(0xAF3310,"bool", ped)
end
-- PC:0xF133BBBE91E1691F Old:0xD21639A8
function TASK.IS_MOVE_BLEND_RATIO_WALKING(ped)
  return Velora.invoke(0xAF3330,"bool", ped)
end
-- PC:0xD4D8636C0199A939 Old:0xE76A2353
function TASK.IS_MOVE_BLEND_RATIO_RUNNING(ped)
  return Velora.invoke(0xAF3370,"bool", ped)
end
-- PC:0x24A2AD74FA9814E2 Old:0xDD616893
function TASK.IS_MOVE_BLEND_RATIO_SPRINTING(ped)
  return Velora.invoke(0xAF33B0,"bool", ped)
end
-- PC:0xAC29253EEF8F0180 Old:0x09E3418D
function TASK.IS_PED_STILL(ped)
  return Velora.invoke(0xAF33D0,"bool", ped)
end
-- PC:0xDE4C184B2B9B071A Old:0x4B865C4A
function TASK.IS_PED_WALKING(ped)
  return Velora.invoke(0xAF3480,"bool", ped)
end
-- PC:0xC5286FFC176F28A2 Old:0xE9A5578F
function TASK.IS_PED_RUNNING(ped)
  return Velora.invoke(0xAF3530,"bool", ped)
end
-- PC:0x57E457CD2C0FC168 Old:0x4F3E0633
function TASK.IS_PED_SPRINTING(ped)
  return Velora.invoke(0xAF35E0,"bool", ped)
end
-- PC:0xE45B7F222DE47E09 Old:0xEFEED13C
function TASK.IS_PED_STRAFING(ped)
  return Velora.invoke(0xAF3680,"bool", ped)
end
-- PC:0xEEA929141F699854 Old:0x4F217E7B
function TASK.TASK_SYNCHRONIZED_SCENE(ped, scene, animDictionary, animationName, blendIn, blendOut, flags, ragdollBlockingFlags, moverBlendDelta, ikFlags)
  Velora.invoke(0xAF36E0,"void", ped, scene, animDictionary, animationName, blendIn, blendOut, flags, ragdollBlockingFlags, moverBlendDelta, ikFlags)
end
function TASK.TASK_AGITATED_ACTION_CONFRONT_RESPONSE(ped, ped2)
  Velora.invoke(0xAF3730,"void", ped, ped2)
end
-- PC:0x2047C02158D6405A Old:0x4D210467
function TASK.TASK_SWEEP_AIM_ENTITY(ped, animDict, lowAnimName, medAnimName, hiAnimName, runtime, targetEntity, turnRate, blendInDuration)
  Velora.invoke(0xAF3740,"void", ped, animDict, lowAnimName, medAnimName, hiAnimName, runtime, targetEntity, turnRate, blendInDuration)
end
-- PC:0xE4973DBDBE6E44B3 Old:0xF65F0F4F
function TASK.UPDATE_TASK_SWEEP_AIM_ENTITY(ped, entity)
  Velora.invoke(0xAF3780,"void", ped, entity)
end
-- PC:0x7AFE8FDC10BC07D2 Old:0x1683FE66
function TASK.TASK_SWEEP_AIM_POSITION(ped, animDict, lowAnimName, medAnimName, hiAnimName, runtime, x, y, z, turnRate, blendInDuration)
  Velora.invoke(0xAF3790,"void", ped, animDict, lowAnimName, medAnimName, hiAnimName, runtime, x, y, z, turnRate, blendInDuration)
end
-- PC:0xBB106883F5201FC4 Old:0x6345EC80
function TASK.UPDATE_TASK_SWEEP_AIM_POSITION(ped, x, y, z)
  Velora.invoke(0xAF37D0,"void", ped, x, y, z)
end
-- PC:0xF3B9A78A178572B1 Old:0xBC0F153D
function TASK.TASK_ARREST_PED(ped, target)
  Velora.invoke(0xAF3860,"void", ped, target)
end
-- PC:0x3DC52677769B4AE0 Old:0x6942DB7A
function TASK.IS_PED_RUNNING_ARREST_TASK(ped)
  return Velora.invoke(0xAF3870,"bool", ped)
end
-- PC:0x90A09F3A45FED688 Old:0x5FF6C2ED
function TASK.IS_PED_BEING_ARRESTED(ped)
  return Velora.invoke(0xAF3900,"bool", ped)
end
-- PC:0x67406F2C8F87FC4F Old:0xA23A1D61
function TASK.UNCUFF_PED(ped)
  Velora.invoke(0xAF3910,"void", ped)
end
-- PC:0x74E559B3BC910685 Old:0x511CE741
function TASK.IS_PED_CUFFED(ped)
  return Velora.invoke(0xAF3960,"bool", ped)
end
