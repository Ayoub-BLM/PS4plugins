-- compat_WEAPON.lua — AUTO GENERATO
-- WEAPON
WEAPON=WEAPON or {}
-- PC:0xC8B46D7727D864AA Old:0xE3438955
function WEAPON.ENABLE_LASER_SIGHT_RENDERING(toggle)
  Velora.invoke(0xB33180,"void", toggle)
end
-- PC:0x0DB57B41EC1DB083 Old:0x324FA47A
function WEAPON.GET_WEAPON_COMPONENT_TYPE_MODEL(componentHash)
  return Velora.invoke(0xB331A0,"int", componentHash)
end
-- PC:0xF46CDC33180FDA94 Old:0x44E1C269
function WEAPON.GET_WEAPONTYPE_MODEL(weaponHash)
  return Velora.invoke(0xB33260,"int", weaponHash)
end
-- PC:0x4215460B9B8B7FA0 Old:0x2E3759AF
function WEAPON.GET_WEAPONTYPE_SLOT(weaponHash)
  return Velora.invoke(0xB33330,"int", weaponHash)
end
-- PC:0xC3287EE3050FB74C Old:0x5F2DE833
function WEAPON.GET_WEAPONTYPE_GROUP(weaponHash)
  return Velora.invoke(0xB333A0,"int", weaponHash)
end
function WEAPON.GET_WEAPON_COMPONENT_VARIANT_EXTRA_COUNT(componentHash)
  return Velora.invoke(0xB33410,"int", componentHash)
end
function WEAPON.GET_WEAPON_COMPONENT_VARIANT_EXTRA_MODEL(componentHash, extraComponentIndex)
  return Velora.invoke(0xB334A0,"int", componentHash, extraComponentIndex)
end
-- PC:0xADF692B254977C0C Old:0xB8278882
function WEAPON.SET_CURRENT_PED_WEAPON(ped, weaponHash, bForceInHand)
  Velora.invoke(0xB33580,"void", ped, weaponHash, bForceInHand)
end
-- PC:0x3A87E44BB9A01D54 Old:0xB0237302
function WEAPON.GET_CURRENT_PED_WEAPON(ped, p2)
  return Velora.invoke(0xB335A0,"bool", ped, p2)
end
-- PC:0x3B390A939AF0B5FC Old:0x5D73CD20
function WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(ped, p1)
  return Velora.invoke(0xB33640,"int", ped, p1)
end
-- PC:0x8483E98E8B888AE2 Old:0xB998D444
function WEAPON.GET_BEST_PED_WEAPON(ped, p1)
  return Velora.invoke(0xB336B0,"int", ped, p1)
end
-- PC:0x75C55983C2C39DAA Old:0x8E6F2AF1
function WEAPON.SET_CURRENT_PED_VEHICLE_WEAPON(ped, weaponHash)
  return Velora.invoke(0xB33720,"bool", ped, weaponHash)
end
-- PC:0x1017582BCD3832DC Old:0xF26C5D65
function WEAPON.GET_CURRENT_PED_VEHICLE_WEAPON(ped)
  return Velora.invoke(0xB33750,"bool", ped)
end
function WEAPON.SET_PED_CYCLE_VEHICLE_WEAPONS_ONLY(ped)
  Velora.invoke(0xB337D0,"void", ped)
end
-- PC:0x475768A975D5AD17 Old:0x0BFC892C
function WEAPON.IS_PED_ARMED(ped, typeFlags)
  return Velora.invoke(0xB33810,"bool", ped, typeFlags)
end
-- PC:0x937C71165CF334B3 Old:0x38CA2954
function WEAPON.IS_WEAPON_VALID(weaponHash)
  return Velora.invoke(0xB33840,"bool", weaponHash)
end
-- PC:0x8DECB02F88F428BC Old:0x43D2FA82
function WEAPON.HAS_PED_GOT_WEAPON(ped, weaponHash, p2)
  return Velora.invoke(0xB338B0,"bool", ped, weaponHash, p2)
end
-- PC:0xB80CA294F2F26749 Old:0x02A32CB0
function WEAPON.IS_PED_WEAPON_READY_TO_SHOOT(ped)
  return Velora.invoke(0xB338E0,"bool", ped)
end
-- PC:0xEFFED78E9011134D Old:0x9BC64E16
function WEAPON.GET_PED_WEAPONTYPE_IN_SLOT(ped, weaponSlot)
  return Velora.invoke(0xB33950,"int", ped, weaponSlot)
end
-- PC:0x015A522136D7F951 Old:0x0C755733
function WEAPON.GET_AMMO_IN_PED_WEAPON(ped, weaponhash)
  return Velora.invoke(0xB33A00,"int", ped, weaponhash)
end
-- PC:0x78F0424C34306220 Old:0x7F0580C7
function WEAPON.ADD_AMMO_TO_PED(ped, weaponHash, ammo)
  Velora.invoke(0xB33A30,"void", ped, weaponHash, ammo)
end
-- PC:0x14E56BC5B5DB6A19 Old:0xBF90DF1A
function WEAPON.SET_PED_AMMO(ped, weaponHash, ammo, p3)
  Velora.invoke(0xB33AA0,"void", ped, weaponHash, ammo, p3)
end
-- PC:0x3EDCB0505123623B Old:0x9CB8D278
function WEAPON.SET_PED_INFINITE_AMMO(ped, toggle, weaponHash)
  Velora.invoke(0xB33AC0,"void", ped, toggle, weaponHash)
end
-- PC:0x183DADC6AA953186 Old:0x5A5E3B67
function WEAPON.SET_PED_INFINITE_AMMO_CLIP(ped, toggle)
  Velora.invoke(0xB33AE0,"void", ped, toggle)
end
function WEAPON.SET_PED_STUN_GUN_FINITE_AMMO(p0, p1)
  Velora.invoke(0xB33B50,"void", p0, p1)
end
-- PC:0xBF0FD6E56C964FCB Old:0xC4D88A85
function WEAPON.GIVE_WEAPON_TO_PED(ped, weaponHash, ammoCount, isHidden, bForceInHand)
  Velora.invoke(0xB33BD0,"void", ped, weaponHash, ammoCount, isHidden, bForceInHand)
end
-- PC:0xB282DC6EBD803C75 Old:0x5868D20D
function WEAPON.GIVE_DELAYED_WEAPON_TO_PED(ped, weaponHash, ammoCount, bForceInHand)
  Velora.invoke(0xB33C00,"void", ped, weaponHash, ammoCount, bForceInHand)
end
-- PC:0xF25DF915FA38C5F3 Old:0xA44CE817
function WEAPON.REMOVE_ALL_PED_WEAPONS(ped, p1)
  Velora.invoke(0xB33C20,"void", ped, p1)
end
-- PC:0x4899CB088EDF59B8 Old:0x9C37F220
function WEAPON.REMOVE_WEAPON_FROM_PED(ped, weaponHash)
  Velora.invoke(0xB33CA0,"void", ped, weaponHash)
end
-- PC:0x6F6981D2253C208F Old:0x00CFD6E9
function WEAPON.HIDE_PED_WEAPON_FOR_SCRIPTED_CUTSCENE(ped, toggle)
  Velora.invoke(0xB33D20,"void", ped, toggle)
end
-- PC:0x0725A4CCFDED9A70 Old:0x00BECD77
function WEAPON.SET_PED_CURRENT_WEAPON_VISIBLE(ped, visible, deselectWeapon, p3, p4)
  Velora.invoke(0xB33DB0,"void", ped, visible, deselectWeapon, p3, p4)
end
-- PC:0x476AE72C1D19D1A8 Old:0x8A444056
function WEAPON.SET_PED_DROPS_WEAPONS_WHEN_DEAD(ped, toggle)
  Velora.invoke(0xB33DF0,"void", ped, toggle)
end
-- PC:0x2D343D2219CD027A Old:0xCDFBBCC6
function WEAPON.HAS_PED_BEEN_DAMAGED_BY_WEAPON(ped, weaponHash, weaponType)
  return Velora.invoke(0xB33E50,"bool", ped, weaponHash, weaponType)
end
-- PC:0x0E98F88A24C5F4B8 Old:0x52C68832
function WEAPON.CLEAR_PED_LAST_WEAPON_DAMAGE(ped)
  Velora.invoke(0xB33EC0,"void", ped)
end
-- PC:0x131D401334815E94 Old:0x6DAABB39
function WEAPON.HAS_ENTITY_BEEN_DAMAGED_BY_WEAPON(entity, weaponHash, weaponType)
  return Velora.invoke(0xB33F20,"bool", entity, weaponHash, weaponType)
end
-- PC:0xAC678E40BE7C74D2 Old:0xCEC2732B
function WEAPON.CLEAR_ENTITY_LAST_WEAPON_DAMAGE(entity)
  Velora.invoke(0xB33FA0,"void", entity)
end
-- PC:0x6B7513D9966FBEC0 Old:0x3D3329FA
function WEAPON.SET_PED_DROPS_WEAPON(ped)
  Velora.invoke(0xB34000,"void", ped)
end
-- PC:0x208A1888007FC0E6 Old:0x81FFB874
function WEAPON.SET_PED_DROPS_INVENTORY_WEAPON(ped, weaponHash, xOffset, yOffset, zOffset, ammoCount)
  Velora.invoke(0xB34010,"void", ped, weaponHash, xOffset, yOffset, zOffset, ammoCount)
end
-- PC:0xA38DCFFCEA8962FA Old:0x6961E2A4
function WEAPON.GET_MAX_AMMO_IN_CLIP(ped, weaponHash, p2)
  return Velora.invoke(0xB34030,"int", ped, weaponHash, p2)
end
-- PC:0x2E1202248937775C Old:0x73C100C3
function WEAPON.GET_AMMO_IN_CLIP(ped, weaponHash)
  return Velora.invoke(0xB342D0,"bool", ped, weaponHash)
end
-- PC:0xDCD2A934D65CB497 Old:0xA54B0B10
function WEAPON.SET_AMMO_IN_CLIP(ped, weaponHash, ammo)
  return Velora.invoke(0xB343B0,"bool", ped, weaponHash, ammo)
end
-- PC:0xDC16122C7A20C933 Old:0x0B294796
function WEAPON.GET_MAX_AMMO(ped, weaponHash)
  return Velora.invoke(0xB343E0,"bool", ped, weaponHash)
end
function WEAPON.GET_MAX_AMMO_BY_TYPE(ped, ammoTypeHash)
  return Velora.invoke(0xB344A0,"bool", ped, ammoTypeHash)
end
function WEAPON.ADD_PED_AMMO_BY_TYPE(ped, ammoTypeHash, ammo)
  Velora.invoke(0xB34560,"void", ped, ammoTypeHash, ammo)
end
-- PC:0x5FD1E1F011E76D7E Old:0x311C52BB
function WEAPON.SET_PED_AMMO_BY_TYPE(ped, ammoTypeHash, ammo)
  Velora.invoke(0xB345D0,"void", ped, ammoTypeHash, ammo)
end
-- PC:0x39D22031557946C1 Old:0x54077C4D
function WEAPON.GET_PED_AMMO_BY_TYPE(ped, ammoTypeHash)
  return Velora.invoke(0xB34640,"int", ped, ammoTypeHash)
end
-- PC:0xA4EFEF9440A5B0EF Old:0x2386A307
function WEAPON.SET_PED_AMMO_TO_DROP(ped, p1)
  Velora.invoke(0xB346B0,"void", ped, p1)
end
-- PC:0xE620FD3512A04F18 Old:0xD6460EA2
function WEAPON.SET_PICKUP_AMMO_AMOUNT_SCALER(p0)
  Velora.invoke(0xB34700,"void", p0)
end
-- PC:0x7FEAD38B326B9F74 Old:0x09337863
function WEAPON.GET_PED_AMMO_TYPE_FROM_WEAPON(ped, weaponHash)
  return Velora.invoke(0xB34720,"int", ped, weaponHash)
end
function WEAPON.GET_PED_ORIGINAL_AMMO_TYPE_FROM_WEAPON(ped, weaponHash)
  return Velora.invoke(0xB34750,"int", ped, weaponHash)
end
-- PC:0x6C4D0409BA1A2BC2 Old:0x9B266079
function WEAPON.GET_PED_LAST_WEAPON_IMPACT_COORD(ped)
  return Velora.invoke(0xB34800,"bool", ped)
end
-- PC:0xD0D7B1E680ED4A1A Old:0x8A256D0A
function WEAPON.SET_PED_GADGET(ped, gadgetHash, p2)
  Velora.invoke(0xB34900,"void", ped, gadgetHash, p2)
end
-- PC:0xF731332072F5156C Old:0x8DDD0B5B
function WEAPON.GET_IS_PED_GADGET_EQUIPPED(ped, gadgetHash)
  return Velora.invoke(0xB34920,"bool", ped, gadgetHash)
end
-- PC:0x0A6DB4965674D243 Old:0xD240123E
function WEAPON.GET_SELECTED_PED_WEAPON(ped)
  return Velora.invoke(0xB34990,"int", ped)
end
-- PC:0xFC4BD125DE7611E4 Old:0x35A0B955
function WEAPON.EXPLODE_PROJECTILES(ped, weaponHash, p2)
  Velora.invoke(0xB349F0,"void", ped, weaponHash, p2)
end
-- PC:0xFC52E0F37E446528 Old:0xA5F89919
function WEAPON.REMOVE_ALL_PROJECTILES_OF_TYPE(weaponHash, explode)
  Velora.invoke(0xB34A10,"void", weaponHash, explode)
end
-- PC:0x840F03E9041E2C9C Old:0x3612110D
function WEAPON.GET_LOCKON_DISTANCE_OF_CURRENT_PED_WEAPON(ped)
  return Velora.invoke(0xB34AA0,"float", ped)
end
-- PC:0x814C9D19DFD69679 Old:0xB2B2BBAA
function WEAPON.GET_MAX_RANGE_OF_CURRENT_PED_WEAPON(ped)
  return Velora.invoke(0xB34AD0,"float", ped)
end
-- PC:0x717C8481234E3B88 Old:0xA57E2E80
function WEAPON.HAS_VEHICLE_GOT_PROJECTILE_ATTACHED(driver, vehicle, weaponHash, p3)
  return Velora.invoke(0xB34B00,"bool", driver, vehicle, weaponHash, p3)
end
-- PC:0xD966D51AA5B28BB9 Old:0x3E1E286D
function WEAPON.GIVE_WEAPON_COMPONENT_TO_PED(ped, weaponHash, componentHash)
  Velora.invoke(0xB34B30,"void", ped, weaponHash, componentHash)
end
-- PC:0x1E8BE90C74FB4C09 Old:0x412AA00D
function WEAPON.REMOVE_WEAPON_COMPONENT_FROM_PED(ped, weaponHash, componentHash)
  Velora.invoke(0xB34BA0,"void", ped, weaponHash, componentHash)
end
-- PC:0xC593212475FAE340 Old:0xDC0FC145
function WEAPON.HAS_PED_GOT_WEAPON_COMPONENT(ped, weaponHash, componentHash)
  return Velora.invoke(0xB34C10,"bool", ped, weaponHash, componentHash)
end
-- PC:0x0D78DE0572D3969E Old:0x7565FB19
function WEAPON.IS_PED_WEAPON_COMPONENT_ACTIVE(ped, weaponHash, componentHash)
  return Velora.invoke(0xB34C40,"bool", ped, weaponHash, componentHash)
end
-- PC:0x8C0D57EA686FAD87 Old:0x82EEAF0F
function WEAPON.REFILL_AMMO_INSTANTLY(ped)
  return Velora.invoke(0xB34C70,"bool", ped)
end
-- PC:0x20AE33F3AC9C0033 Old:0x515292C2
function WEAPON.MAKE_PED_RELOAD(ped)
  return Velora.invoke(0xB34CD0,"bool", ped)
end
-- PC:0x5443438F033E29C3 Old:0x65D139A5
function WEAPON.REQUEST_WEAPON_ASSET(weaponHash, p1, p2)
  Velora.invoke(0xB34D80,"void", weaponHash, p1, p2)
end
-- PC:0x36E353271F0E90EE Old:0x1891D5BB
function WEAPON.HAS_WEAPON_ASSET_LOADED(weaponHash)
  return Velora.invoke(0xB34E40,"bool", weaponHash)
end
-- PC:0xAA08EF13F341C8FC Old:0x2C0DFE3C
function WEAPON.REMOVE_WEAPON_ASSET(weaponHash)
  Velora.invoke(0xB34E70,"void", weaponHash)
end
-- PC:0x9541D3CF0D398F36 Old:0x62F5987F
function WEAPON.CREATE_WEAPON_OBJECT(weaponHash, ammoCount, x, y, z, showWorldModel, scale, p7, p8, p9)
  return Velora.invoke(0xB34F00,"int", weaponHash, ammoCount, x, y, z, showWorldModel, scale, p7, p8, p9)
end
-- PC:0x33E179436C0B31DB Old:0xF7612A37
function WEAPON.GIVE_WEAPON_COMPONENT_TO_WEAPON_OBJECT(weaponObject, componentHash)
  Velora.invoke(0xB34F60,"void", weaponObject, componentHash)
end
-- PC:0xF7D82B0D66777611 Old:0xA6E7ED3C
function WEAPON.REMOVE_WEAPON_COMPONENT_FROM_WEAPON_OBJECT(object, componentHash)
  Velora.invoke(0xB34FB0,"void", object, componentHash)
end
-- PC:0x76A18844E743BF91 Old:0x1D368510
function WEAPON.HAS_WEAPON_GOT_WEAPON_COMPONENT(weapon, componentHash)
  return Velora.invoke(0xB35030,"bool", weapon, componentHash)
end
-- PC:0xB1FA61371AF7C4B7 Old:0x639AF3EF
function WEAPON.GIVE_WEAPON_OBJECT_TO_PED(weaponObject, ped)
  Velora.invoke(0xB350C0,"void", weaponObject, ped)
end
-- PC:0x5CEE3DF569CECAB0 Old:0xB1817BAA
function WEAPON.DOES_WEAPON_TAKE_WEAPON_COMPONENT(weaponHash, componentHash)
  return Velora.invoke(0xB350D0,"bool", weaponHash, componentHash)
end
-- PC:0xCAE1DC9A0E22A16D Old:0xDF939A38
function WEAPON.GET_WEAPON_OBJECT_FROM_PED(ped, p1)
  return Velora.invoke(0xB35100,"int", ped, p1)
end
function WEAPON.GIVE_LOADOUT_TO_PED(ped, loadoutHash)
  Velora.invoke(0xB35130,"void", ped, loadoutHash)
end
-- PC:0x50969B9B89ED5738 Old:0xEB2A7B23
function WEAPON.SET_PED_WEAPON_TINT_INDEX(ped, weaponHash, tintIndex)
  Velora.invoke(0xB35180,"void", ped, weaponHash, tintIndex)
end
-- PC:0x2B9EEDC07BD06B9F Old:0x3F9C90A7
function WEAPON.GET_PED_WEAPON_TINT_INDEX(ped, weaponHash)
  return Velora.invoke(0xB351A0,"int", ped, weaponHash)
end
-- PC:0xF827589017D4E4A9 Old:0x44ACC1DA
function WEAPON.SET_WEAPON_OBJECT_TINT_INDEX(weapon, tintIndex)
  Velora.invoke(0xB351D0,"void", weapon, tintIndex)
end
-- PC:0xCD183314F7CD2E57 Old:0xD91D9576
function WEAPON.GET_WEAPON_OBJECT_TINT_INDEX(weapon)
  return Velora.invoke(0xB35220,"int", weapon)
end
-- PC:0x5DCF6C5CAB2E9BF7 Old:0x99E4EAAB
function WEAPON.GET_WEAPON_TINT_COUNT(weaponHash)
  return Velora.invoke(0xB35280,"int", weaponHash)
end
function WEAPON.SET_PED_WEAPON_COMPONENT_TINT_INDEX(ped, weaponHash, camoComponentHash, colorIndex)
  Velora.invoke(0xB352F0,"void", ped, weaponHash, camoComponentHash, colorIndex)
end
function WEAPON.GET_PED_WEAPON_COMPONENT_TINT_INDEX(ped, weaponHash, camoComponentHash)
  return Velora.invoke(0xB35310,"int", ped, weaponHash, camoComponentHash)
end
function WEAPON.SET_WEAPON_OBJECT_COMPONENT_TINT_INDEX(weaponObject, camoComponentHash, colorIndex)
  Velora.invoke(0xB35340,"void", weaponObject, camoComponentHash, colorIndex)
end
function WEAPON.GET_WEAPON_OBJECT_COMPONENT_TINT_INDEX(weaponObject, camoComponentHash)
  return Velora.invoke(0xB353E0,"int", weaponObject, camoComponentHash)
end
function WEAPON.GET_PED_WEAPON_CAMO_INDEX(ped, weaponHash)
  return Velora.invoke(0xB35470,"int", ped, weaponHash)
end
function WEAPON.SET_WEAPON_OBJECT_CAMO_INDEX(weaponObject, p1)
  Velora.invoke(0xB354A0,"void", weaponObject, p1)
end
-- PC:0xD92C739EE34C9EBA Old:0xA9AD3D98
function WEAPON.GET_WEAPON_HUD_STATS(weaponHash, outData)
  return Velora.invoke(0xB354F0,"bool", weaponHash, outData)
end
-- PC:0xB3CAF387AE12E9F8 Old:0xBB5498F4
function WEAPON.GET_WEAPON_COMPONENT_HUD_STATS(componentHash, outData)
  return Velora.invoke(0xB355A0,"bool", componentHash, outData)
end
-- PC:0x3133B907D8B32053 Old:0xE81649C0
function WEAPON.GET_WEAPON_DAMAGE(weaponHash, componentHash)
  return Velora.invoke(0xB35640,"float", weaponHash, componentHash)
end
-- PC:0x583BE370B1EC6EB4 Old:0x8D515E66
function WEAPON.GET_WEAPON_CLIP_SIZE(weaponHash)
  return Velora.invoke(0xB35670,"int", weaponHash)
end
function WEAPON.GET_WEAPON_TIME_BETWEEN_SHOTS(weaponHash)
  return Velora.invoke(0xB356F0,"float", weaponHash)
end
-- PC:0x8378627201D5497D Old:0xB4F44C6E
function WEAPON.SET_PED_CHANCE_OF_FIRING_BLANKS(ped, xBias, yBias)
  Velora.invoke(0xB35770,"void", ped, xBias, yBias)
end
-- PC:0xB4C8D77C80C0421E Old:0xEC2E5304
function WEAPON.SET_PED_SHOOT_ORDNANCE_WEAPON(ped, p1)
  return Velora.invoke(0xB357E0,"int", ped, p1)
end
-- PC:0x48164DBB970AC3F0 Old:0xE3BD00F9
function WEAPON.REQUEST_WEAPON_HIGH_DETAIL_MODEL(weaponObject)
  Velora.invoke(0xB35810,"void", weaponObject)
end
function WEAPON.SET_WEAPON_DAMAGE_MODIFIER(weaponHash, damageMultiplier)
  Velora.invoke(0xB358C0,"void", weaponHash, damageMultiplier)
end
function WEAPON.SET_WEAPON_AOE_MODIFIER(weaponHash, multiplier)
  Velora.invoke(0xB35920,"void", weaponHash, multiplier)
end
function WEAPON.SET_WEAPON_EFFECT_DURATION_MODIFIER(p0, p1)
  Velora.invoke(0xB35980,"void", p0, p1)
end
-- PC:0x65F0C5AE05943EC7 Old:0xBAF7BFBE
function WEAPON.IS_PED_CURRENT_WEAPON_SILENCED(ped)
  return Velora.invoke(0xB359E0,"bool", ped)
end
-- PC:0x4B7620C47217126C Old:0x76876154
function WEAPON.IS_FLASH_LIGHT_ON(ped)
  return Velora.invoke(0xB35A50,"bool", ped)
end
-- PC:0xCEA66DAD478CD39B Old:0xB0127EA7
function WEAPON.SET_FLASH_LIGHT_FADE_DISTANCE(distance)
  return Velora.invoke(0xB35AD0,"bool", distance)
end
function WEAPON.SET_FLASH_LIGHT_ACTIVE_HISTORY(ped, toggle)
  Velora.invoke(0xB35AE0,"void", ped, toggle)
end
-- PC:0x1055AC3A667F09D9 Old:0xA5DF7484
function WEAPON.SET_WEAPON_ANIMATION_OVERRIDE(ped, animStyle)
  Velora.invoke(0xB35B50,"void", ped, animStyle)
end
-- PC:0x3BE0BB12D25FB305 Old:0x013AFC13
function WEAPON.GET_WEAPON_DAMAGE_TYPE(weaponHash)
  return Velora.invoke(0xB35BE0,"int", weaponHash)
end
-- PC:0xE4DCEC7FD5B739A5 Old:0x64646F1D
function WEAPON.SET_EQIPPED_WEAPON_START_SPINNING_AT_FULL_SPEED(ped)
  Velora.invoke(0xB35C50,"void", ped)
end
-- PC:0xBC7BE5ABC0879F74 Old:0x135E7AD4
function WEAPON.CAN_USE_WEAPON_ON_PARACHUTE(weaponHash)
  return Velora.invoke(0xB35CB0,"bool", weaponHash)
end
function WEAPON.CREATE_AIR_DEFENCE_SPHERE(x, y, z, radius, p4, p5, p6, weaponHash)
  return Velora.invoke(0xB35CE0,"int", x, y, z, radius, p4, p5, p6, weaponHash)
end
function WEAPON.CREATE_AIR_DEFENCE_ANGLED_AREA(p0, p1, p2, p3, p4, p5, p6, p7, p8, radius, weaponHash)
  return Velora.invoke(0xB35D50,"int", p0, p1, p2, p3, p4, p5, p6, p7, p8, radius, weaponHash)
end
function WEAPON.REMOVE_AIR_DEFENCE_SPHERE(zoneId)
  return Velora.invoke(0xB35F40,"bool", zoneId)
end
function WEAPON.REMOVE_ALL_AIR_DEFENCE_SPHERES()
  Velora.invoke(0xB35F70,"void")
end
function WEAPON.SET_PLAYER_TARGETTABLE_FOR_AIR_DEFENCE_SPHERE(player, zoneId, enable)
  Velora.invoke(0xB35F80,"void", player, zoneId, enable)
end
function WEAPON.IS_AIR_DEFENCE_SPHERE_IN_AREA(x, y, z, radius)
  return Velora.invoke(0xB35FC0,"bool", x, y, z, radius)
end
function WEAPON.FIRE_AIR_DEFENCE_SPHERE_WEAPON_AT_POSITION(zoneId, x, y, z)
  Velora.invoke(0xB36050,"void", zoneId, x, y, z)
end
function WEAPON.DOES_AIR_DEFENCE_SPHERE_EXIST(zoneId)
  return Velora.invoke(0xB360D0,"bool", zoneId)
end
function WEAPON.SET_CAN_PED_SELECT_INVENTORY_WEAPON(ped, weaponHash, toggle)
  Velora.invoke(0xB36100,"void", ped, weaponHash, toggle)
end
function WEAPON.SET_CAN_PED_SELECT_ALL_WEAPONS(ped, toggle)
  Velora.invoke(0xB36120,"void", ped, toggle)
end
