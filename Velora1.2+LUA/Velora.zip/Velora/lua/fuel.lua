-- ╔══════════════════════════════════════════════════════════════╗
--                           FUEL MOD
--            Built for Velora Lua Loader / ORBX Core
-- ╚══════════════════════════════════════════════════════════════╝

local MOD_TITLE    = "FUEL MOD"
local ACCENT_COLOR = {0, 195, 255, 255} -- Enhanced Neon Cyber Blue

-- ──────────────────────────────────────────────────────────────
-- CONFIG SYSTEM
-- ──────────────────────────────────────────────────────────────
local Config = (function()
    local _path = "/data/Velora/lua/config/" .. MOD_TITLE:gsub("%s+", "_") .. ".cfg"
    local _data = {}
    local function _load()
        local raw = Velora.ReadFile(_path)
        if not raw then return end
        for k, v in raw:gmatch("([^=\n]+)=([^\n]*)\n?") do
            if v == "true" then _data[k] = true
            elseif v == "false" then _data[k] = false
            else local n = tonumber(v); _data[k] = n ~= nil and n or v end
        end
    end
    local function _save()
        local out = ""
        for k, v in pairs(_data) do out = out .. k .. "=" .. tostring(v) .. "\n" end
        Velora.WriteFile(_path, out)
    end
    _load()
    return {
        get = function(k, default) return _data[k] ~= nil and _data[k] or default end,
        set = function(k, v) _data[k] = v; _save() end,
        reset = function() _data = {}; _save() end
    }
end)()

-- ──────────────────────────────────────────────────────────────
-- SAFE HELPERS 
-- ──────────────────────────────────────────────────────────────
local function ncall(name, ...)
    if Native and Native[name] then return Native[name](...) end
    return nil
end

local function notify(msg) Velora.Print(msg) end
local function ped() return ncall("PLAYER_PED_ID") end

local function currentVehicle()
    local p = ped()
    if ncall("IS_PED_IN_ANY_VEHICLE", p, false) then
        return ncall("GET_VEHICLE_PED_IS_IN", p, false)
    end
    return 0
end

local function getVehicleGearMemory(veh)
    if not veh or veh == 0 then return 0 end
    local pVehicle = Velora.GetEntityAddress and Velora.GetEntityAddress(veh)
    if not pVehicle or pVehicle == 0 then return 1 end
    
    local currentGear = Velora.ReadMemoryInt and Velora.ReadMemoryInt(pVehicle + 0x7E0)
    if not currentGear or currentGear < 0 or currentGear > 10 then return 1 end
    return currentGear
end

-- ──────────────────────────────────────────────────────────────
-- DATA INTERFACE
-- ──────────────────────────────────────────────────────────────
local T = {
    speedo = Config.get("speedo", true),
    speedoMph = Config.get("speedoMph", false),
    fuelModEnabled = Config.get("fuelModEnabled", true),
    partsDegradation = Config.get("partsDegradation", true),
    fuelHudOverlay = Config.get("fuelHudOverlay", true),
    closeStations = Config.get("closeStations", false),
    marketFluctuate = Config.get("marketFluctuate", true),
}

local Tunables = {
    fuelTankCapacity = Config.get("fuelTankCapacity", 60),
    fuelConsumptionRate = Config.get("fuelConsumptionRate", 5),
    pricePerLiter = Config.get("pricePerLiter", 15),
    priceEngineOil = Config.get("priceEngineOil", 35),
    priceTransFluid = Config.get("priceTransFluid", 25)
}

local RealSpeedometer = { currentKmh = 0.0, currentMph = 0.0, rpm = 0.0, gear = 0 }
local FuelSystem = { currentFuel = 20.0, engineOil = 200.0, maxEngineOil = 200.0, transFluid = 250.0, maxTransFluid = 250.0 }

local function boolItem(label, key, desc, onChange)
    return {
        label=label, kind="bool", desc=desc,
        getValue=function() return T[key] end,
        setValue=function(v)
            T[key] = v; Config.set(key, v)
            if onChange then onChange(v) end
            notify((v and "~g~ON: " or "~r~OFF: ") .. label)
        end
    }
end

local function intTunableItem(label, key, min, max, step, desc)
    return {
        label=label, kind="int", min=min, max=max, step=step, desc=desc,
        getValue=function() return Tunables[key] end,
        setValue=function(v) Tunables[key] = v; Config.set(key, v) end
    }
end

local function action(label, desc, fn) return { label=label, desc=desc, action=fn } end
local function submenu(label, title, items) return { label=label, submenu={ title=title or label, items=items } } end

local MyMenu = {
    title = MOD_TITLE,
    items = {
        submenu("Fuel System Simulation", "Fuel Logistics", {
            boolItem("Fuel Mod System", "fuelModEnabled", "Toggle the entire global smart fuel simulation engine calculation loops."),
            boolItem("Parts Degradation System", "partsDegradation", "Enable active oil degradation and tire puncture wears on vehicles over distance."),
            boolItem("Fuel Display HUD Overlay", "fuelHudOverlay", "Toggles the lower-left telemetry dashboard layout box display metrics."),
            boolItem("Simulate Closed Gas Stations", "closeStations", "Simulate closing all background station fuel depots locations across San Andreas."),
            boolItem("Market Price Fluctuation", "marketFluctuate", "Causes prices per liter to randomize periodically dynamically based on market shifts."),
            
            submenu("Mod Tunables & Adjustments", "Tunable Configuration", {
                intTunableItem("Fuel Tank Limit (L)", "fuelTankCapacity", 20, 200, 5, "Adjust the total maximum liquid liter configuration arrays per fill."),
                intTunableItem("Fuel Consumption Rate", "fuelConsumptionRate", 1, 20, 1, "Multiplier for how fast fuel drops. Higher values speed up consumption."),
                intTunableItem("Gas Price Per Liter", "pricePerLiter", 1, 100, 1, "Modify market price values directly when pulling up to standard fuel pumps."),
                intTunableItem("Engine Oil Unit Cost", "priceEngineOil", 5, 200, 5, "Set custom cash transaction values required when siphoning engine lubricants."),
                intTunableItem("Transmission Fluid Cost", "priceTransFluid", 5, 200, 5, "Set transaction requirements necessary to flush transmission cases components."),
            }),

            action("Refuel Current Vehicle", "Instantaneous maximum replenishment of gas tank capacity arrays inside current vehicle.", function()
                local v = currentVehicle()
                if v ~= 0 then
                    FuelSystem.currentFuel = Tunables.fuelTankCapacity
                    ncall("SET_VEHICLE_ENGINE_HEALTH", v, 1000.0)
                    notify("~g~Replenished to max capacity: " .. Tunables.fuelTankCapacity .. "L")
                else notify("~r~Not inside any vehicle.") end
            end),
            action("Change Engine Oil", "Flush crankcase engine lubricants back to pristine conditions limits.", function()
                FuelSystem.engineOil = FuelSystem.maxEngineOil
                notify("~g~Engine oil replaced successfully.")
            end),
            action("Flush Transmission Fluid", "Siphon transmission gear wear components and top off dynamic fluids.", function()
                FuelSystem.transFluid = FuelSystem.maxTransFluid
                notify("~g~Transmission fluid flushed clean.")
            end),
        }),

        submenu("Speedometer Configuration", "HUD Settings", {
            boolItem("Display Metrics Hud", "speedo", "Toggle lower dashboard telemetry display interface panels."),
            boolItem("Enable Imperial MP/H", "speedoMph", "Saves calculations preferences between standard configurations."),
        }),

        submenu("Menu Configuration", "Settings", {
            boolItem("Fuel Mod Enabled", "fuelModEnabled", "Direct toggle to switch the framework loop configurations on or off entirely."),
        }),
    }
}

-- ──────────────────────────────────────────────────────────────
-- RENDERING ENGINE & TICK HOOKS
-- ──────────────────────────────────────────────────────────────
local UI = { visible=false, scroll=0, selected=0 }
local _stack = {}
local KEY_UP=27; local KEY_DOWN=173; local KEY_LEFT=174; local KEY_RIGHT=175; local KEY_ENTER=176; local KEY_BACK=177; local KEY_OPEN=206

local S = {
    x=0.145, y=0.090, w=0.240, itemH=0.035, maxItems=10,
    headerBg={14, 16, 22, 250}, headerText={255, 255, 255, 255}, accentBg=ACCENT_COLOR,
    subBg={20, 22, 30, 240}, subText={0, 195, 255, 255}, selBg={0, 195, 255, 230}, selText={10, 12, 18, 255},
    itemBg={26, 29, 40, 220}, itemText={235, 240, 250, 255}, descBg={16, 18, 26, 245}, descText={180, 195, 220, 240},
    scrollBar=ACCENT_COLOR, toggleOn={0, 200, 120, 255}, toggleOff={230, 50, 80, 255},
}
local inputTimer=0; local toggleTimer=0; local INPUT_DELAY=3; local TOGGLE_DELAY=15
local lastGameTime = 0
local hintTimer = 400 

local function drawRect(x,y,w,h,c) ncall("DRAW_RECT",x,y,w,h,c[1],c[2],c[3],c[4]) end
local function drawText(t,x,y,sc,c,ctr,ol)
    ncall("SET_TEXT_FONT",0); ncall("SET_TEXT_SCALE",sc,sc); ncall("SET_TEXT_COLOUR",c[1],c[2],c[3],c[4])
    if ctr then ncall("SET_TEXT_CENTRE",true) end; if ol then ncall("SET_TEXT_OUTLINE") end
    ncall("BEGIN_TEXT_COMMAND_DISPLAY_TEXT","STRING"); ncall("ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME",t); ncall("END_TEXT_COMMAND_DISPLAY_TEXT",x,y)
end
local function drawWrapped(t,x,y,w,c)
    ncall("SET_TEXT_FONT",0); ncall("SET_TEXT_SCALE",0.21,0.21); ncall("SET_TEXT_COLOUR",c[1],c[2],c[3],c[4])
    ncall("SET_TEXT_WRAP",x-w*0.46,x+w*0.46); ncall("BEGIN_TEXT_COMMAND_DISPLAY_TEXT","STRING"); ncall("ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME",t); ncall("END_TEXT_COMMAND_DISPLAY_TEXT",x-w*0.46,y)
end
local function activeMenu() return #_stack==0 and MyMenu or _stack[#_stack].menu end
local function clamp()
    local n=#activeMenu().items; if n==0 then UI.selected=0; UI.scroll=0; return end
    if UI.selected<0 then UI.selected=n-1 end; if UI.selected>=n then UI.selected=0 end
    if UI.selected<UI.scroll then UI.scroll=UI.selected elseif UI.selected>=UI.scroll+S.maxItems then UI.scroll=UI.selected-S.maxItems+1 end
end
local function press()
    local item=activeMenu().items[UI.selected+1]; if not item then return end
    if item.submenu then table.insert(_stack,{menu=item.submenu,last=UI.selected}); UI.selected=0; UI.scroll=0
    elseif item.kind=="bool" and item.setValue then item.setValue(not item.getValue())
    elseif item.action then item.action() end
end
local function slider(d)
    local item=activeMenu().items[UI.selected+1]; if not item or item.kind~="int" then return end
    local v=item.getValue()+d*(item.step or 1)
    if v>item.max then v=item.min end; if v<item.min then v=item.max end; item.setValue(v)
end
local function back()
    if #_stack>0 then local e=table.remove(_stack); UI.selected=e.last or 0; UI.scroll=0; clamp() else UI.visible=false end
end
local function render()
    local menu=activeMenu(); local count=#menu.items; local x,w=S.x,S.w; local hH=S.itemH*1.40; local aH=S.itemH*0.18; local sH=S.itemH*0.85; local dH=S.itemH*1.45; local y=S.y
    drawRect(x,y+aH*0.5,w,aH,S.accentBg); y=y+aH
    drawRect(x,y+hH*0.5,w,hH,S.headerBg); drawText(menu.title,x,y+hH*0.28,0.50,S.headerText,true,false); y=y+hH
    drawRect(x,y+sH*0.5,w,sH,S.subBg); drawText(string.format("%d / %d",count>0 and UI.selected+1 or 0,count),x+w*0.38,y+sH*0.15,0.22,S.subText,false,false); y=y+sH
    local vis=math.min(S.maxItems,count)
    for i=0,vis-1 do
        local idx=UI.scroll+i+1; local item=menu.items[idx]; if not item then break end
        local iy=y+i*S.itemH; local sel=(idx-1==UI.selected); local bg=sel and S.selBg or S.itemBg; local tc=sel and S.selText or S.itemText
        drawRect(x,iy+S.itemH*0.5,w,S.itemH,bg); drawText(item.label or "",x-w*0.45,iy+S.itemH*0.22,0.25,tc,false,false)
        if item.kind=="int" and item.getValue then 
            local valText = tostring(item.getValue())
            if item.label:find("Multiplier") or item.label:find("Amount") or item.label:find("Cost") or item.label:find("Price") or item.label:find("Size") or item.label:find("Limit") then 
                valText = string.format("$%d", item.getValue()) 
            end
            drawText("< " .. valText .. " >", x+w*0.22, iy+S.itemH*0.22, 0.21, tc, false, false)
        elseif item.kind=="bool" then local on=item.getValue and item.getValue(); drawRect(x+w*0.36,iy+S.itemH*0.5,w*0.15,S.itemH*0.60,on and S.toggleOn or S.toggleOff); drawText(on and "ON" or "OFF",x+w*0.36,iy+S.itemH*0.22,0.20,{255,255,255,255},true,false)
        elseif item.submenu then drawText(">>",x+w*0.41,iy+S.itemH*0.23,0.23,tc,false,false) end
    end
    if count>S.maxItems then local bH=S.itemH*vis; local sH2=bH/count*S.maxItems; drawRect(x+w*0.5-0.003,y+bH*(UI.scroll/count)+sH2*0.5,0.003,sH2,S.scrollBar) end
    local dy=y+vis*S.itemH; local selItem=menu.items[UI.selected+1]; local desc=selItem and selItem.desc or ""
    if desc~="" then drawRect(x,dy+dH*0.5,w,dH,S.descBg); drawWrapped(desc,x,dy+dH*0.15,w,S.descText) end
    drawRect(x,dy+dH+aH*0.5,w,aH,S.accentBg)
end

-- ──────────────────────────────────────────────────────────────
-- ADVANCED CIRCULAR INSTRUMENT CLUSTER
-- ──────────────────────────────────────────────────────────────
local function runCircularCluster()
    local veh = currentVehicle()
    if veh == 0 or not T.speedo or UI.visible then return end

    local vx, vy, vz = ncall("GET_ENTITY_VELOCITY", veh)
    vx, vy, vz = vx or 0, vy or 0, vz or 0
    local rawSpeedSec = math.sqrt((vx^2) + (vy^2) + (vz^2))
    
    RealSpeedometer.currentKmh = rawSpeedSec * 3.6
    RealSpeedometer.currentMph = rawSpeedSec * 2.236936
    RealSpeedometer.rpm = ncall("GET_VEHICLE_CURRENT_RPM", veh) or 0.0
    RealSpeedometer.gear = getVehicleGearMemory(veh)

    local cx, cy = 0.88, 0.82
    local radiusX = 0.045  
    local radiusY = 0.080

    -- 1. Solid Black Background Disk
    local bgSegments = 24
    for i = 1, bgSegments do
        drawRect(cx, cy, radiusX * 2.0, radiusY * 0.15, {0, 0, 0, 230})
    end
    drawRect(cx, cy, radiusX * 1.6, radiusY * 1.6, {0, 0, 0, 230})

    -- 2. Outer Dial Ring Frame
    local segments = 32
    for i = 1, segments do
        local angle1 = ((i - 1) / segments) * 2 * math.pi
        local angle2 = (i / segments) * 2 * math.pi

        local x1 = cx + (math.cos(angle1) * radiusX)
        local y1 = cy + (math.sin(angle1) * radiusY)
        local x2 = cx + (math.cos(angle2) * radiusX)
        local y2 = cy + (math.sin(angle2) * radiusY)

        local midX = (x1 + x2) / 2
        local midY = (y1 + y2) / 2
        drawRect(midX, midY, 0.002, 0.004, {60, 60, 65, 255})
    end

    -- 3. Gauge Needle Sweeper
    local maxVelocityRange = T.speedoMph and 160.0 or 240.0
    local currentVelocity = T.speedoMph and RealSpeedometer.currentMph or RealSpeedometer.currentKmh
    local velocityPercentage = math.min(1.0, currentVelocity / maxVelocityRange)
    
    local needleAngle = 135.0 + (velocityPercentage * 285.0)
    local needleRad = (needleAngle * math.pi) / 180.0

    local needleResolution = 10
    for step = 1, needleResolution do
        local factor = step / needleResolution
        local ix = cx + (math.cos(needleRad) * (radiusX * 0.85) * factor)
        local iy = cy + (math.sin(needleRad) * (radiusY * 0.85) * factor)
        drawRect(ix, iy, 0.0012, 0.0022, {255, 30, 30, 255})
    end

    -- 4. RPM Tracker Arc
    local rpmSegments = math.floor(16 * math.min(1.0, RealSpeedometer.rpm))
    for i = 1, rpmSegments do
        local rpmAngle = 135.0 + ((i / 16) * 270.0)
        local rpmRad = (rpmAngle * math.pi) / 180.0
        local rx = cx + (math.cos(rpmRad) * (radiusX * 0.95))
        local ry = cy + (math.sin(rpmRad) * (radiusY * 0.95))
        
        local rpmColor = (i > 13) and {255, 0, 50, 255} or ACCENT_COLOR
        drawRect(rx, ry, 0.002, 0.004, rpmColor)
    end

    -- 5. Digital Displays
    local displaySpeedText = string.format("%d", math.floor(currentVelocity))
    local unitString = T.speedoMph and "MPH" or "KM/H"
    
    drawText(displaySpeedText, cx, cy - 0.015, 0.45, {255, 255, 255, 255}, true, true)
    drawText(unitString, cx, cy + 0.005, 0.20, {180, 180, 180, 255}, true, false)
    
    local gearLabel = tostring(RealSpeedometer.gear)
    if RealSpeedometer.gear == 0 then gearLabel = "N" end
    drawText(gearLabel, cx, cy + 0.022, 0.32, ACCENT_COLOR, true, true)
end

-- ──────────────────────────────────────────────────────────────
-- DESIGNED FUEL HUD PANEL OVERLAY
-- ──────────────────────────────────────────────────────────────
local function processFuelOverlay()
    local veh = currentVehicle()
    if veh == 0 or not T.fuelModEnabled or not T.fuelHudOverlay or UI.visible then return end
    
    local hx, hy = 0.135, 0.72
    local hw, hh = 0.125, 0.078
    
    -- Main background and decorative bottom border line
    drawRect(hx, hy, hw, hh, {14, 16, 22, 225})
    drawRect(hx, hy + (hh * 0.5) - 0.001, hw, 0.002, ACCENT_COLOR)
    
    -- Status Metrics Rows text
    drawText(string.format("FUEL STATUS: %.1f / %dL", FuelSystem.currentFuel, Tunables.fuelTankCapacity), hx - (hw * 0.45), hy - 0.028, 0.28, {255, 255, 255, 255}, false, true)
    drawText(string.format("OIL CONDITION: %.1f%%", (FuelSystem.engineOil / FuelSystem.maxEngineOil) * 100), hx - (hw * 0.45), hy - 0.002, 0.22, {185, 200, 215, 255}, false, false)
    drawText(string.format("TRANS FLUID:   %.1f%%", (FuelSystem.transFluid / FuelSystem.maxTransFluid) * 100), hx - (hw * 0.45), hy + 0.018, 0.22, {185, 200, 215, 255}, false, false)
end

-- ──────────────────────────────────────────────────────────────
-- STARTUP UI INSTRUCTIONS DISPLAY
-- ──────────────────────────────────────────────────────────────
local function showMenuOpeningHint()
    if hintTimer > 0 then
        hintTimer = hintTimer - 1
        drawRect(0.5, 0.04, 0.24, 0.035, {14, 16, 22, 230})
        drawRect(0.5, 0.0565, 0.24, 0.002, ACCENT_COLOR)
        drawText("Press ~b~R1 ~w~to toggle Menu", 0.5, 0.028, 0.24, {255, 255, 255, 255}, true, false)
    end
end

local _prev = onFrame
function onFrame()
    if _prev then _prev() end

    local curTime = ncall("GET_GAME_TIMER") or 0
    if lastGameTime == 0 then lastGameTime = curTime end
    local frameDiff = curTime - lastGameTime
    lastGameTime = curTime

    local veh = currentVehicle()
    if veh ~= 0 then
        if T.fuelModEnabled then
            local speed = ncall("GET_ENTITY_SPEED", veh) or 0.0
            if speed > 1.0 then
                local lossModifier = 0.0001 * Tunables.fuelConsumptionRate
                FuelSystem.currentFuel = math.max(0.0, FuelSystem.currentFuel - (lossModifier * frameDiff))
                if T.partsDegradation then
                    FuelSystem.engineOil = math.max(0.0, FuelSystem.engineOil - (0.0001 * frameDiff))
                    FuelSystem.transFluid = math.max(0.0, FuelSystem.transFluid - (0.00008 * frameDiff))
                end
            end
            if FuelSystem.currentFuel > Tunables.fuelTankCapacity then FuelSystem.currentFuel = Tunables.fuelTankCapacity end
            if FuelSystem.currentFuel <= 0.0 then
                ncall("SET_VEHICLE_ENGINE_HEALTH", veh, -4000.0)
                ncall("SET_VEHICLE_ENGINE_ON", veh, false, true, true)
                notify("~r~Damn, you ran out of fuel!")
            end
        end
    end

    runCircularCluster()
    processFuelOverlay()
    showMenuOpeningHint()

    if toggleTimer > 0 then toggleTimer = toggleTimer - 1 
    elseif ncall("IS_DISABLED_CONTROL_JUST_PRESSED", 0, KEY_OPEN) or ncall("IS_CONTROL_JUST_PRESSED", 2, 69) then 
        UI.visible = not UI.visible; toggleTimer = TOGGLE_DELAY
        if UI.visible then _stack = {}; UI.selected = 0; UI.scroll = 0 end 
    end

    if not UI.visible then return end
    for _, k in ipairs({201, 202, 188, 187, 189, 190, 174, 175, 176, 177}) do ncall("DISABLE_CONTROL_ACTION", 2, k, true) end

    if inputTimer > 0 then inputTimer = inputTimer - 1 else
        local function jp(k) return ncall("IS_DISABLED_CONTROL_JUST_PRESSED", 0, k) end
        if jp(KEY_UP) or ncall("IS_DISABLED_CONTROL_JUST_PRESSED", 2, 188) then UI.selected=UI.selected-1; clamp(); inputTimer=INPUT_DELAY
        elseif jp(KEY_DOWN) or ncall("IS_DISABLED_CONTROL_JUST_PRESSED", 2, 187) then UI.selected=UI.selected+1; clamp(); inputTimer=INPUT_DELAY
        elseif jp(KEY_LEFT) or ncall("IS_DISABLED_CONTROL_JUST_PRESSED", 2, 174) then slider(-1); inputTimer=INPUT_DELAY
        elseif jp(KEY_RIGHT) or ncall("IS_DISABLED_CONTROL_JUST_PRESSED", 2, 175) then slider(1); inputTimer=INPUT_DELAY
        elseif jp(KEY_ENTER) or ncall("IS_DISABLED_CONTROL_JUST_PRESSED", 2, 201) then press(); inputTimer=INPUT_DELAY
        elseif jp(KEY_BACK) or ncall("IS_DISABLED_CONTROL_JUST_PRESSED", 2, 202) then back(); inputTimer=INPUT_DELAY end
    end
    render()
end

function onShutdown() end
Velora.Print("~b~" .. MOD_TITLE .. " Module Initialized!")